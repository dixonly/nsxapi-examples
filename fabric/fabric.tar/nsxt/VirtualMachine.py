2#!/usr/bin/env python
import pinit
import os
import sys
import commands
import string
import json
import restlib
import argparse
import logging
import pprint
from toasterlib import Toaster
from nsxtlib import *
import uuid
import requests
import xml.etree.ElementTree as ET
from xml.dom import minidom
import subprocess
requests.packages.urllib3.disable_warnings()


class VirtualMachine(object):
    def __init__(self, macprefix, nameprefix, vmnum, dest, niccount=1,img=None):
        self.ifup = "/etc/ovs-ifup"
        self.macprefix = macprefix
        self.vmnum = vmnum
        self.prefix=nameprefix
        self.vmname = self.generateVmName(nameprefix, self.vmnum)
        self.macs={}
        self.ifaceups={}
        self.setDestination(dest=dest)
        self.niccount=niccount
        self.img=img
        self.genMacs()


    def genMacs(self):
        if self.niccount <=0 or self.niccount > 9:
            print "Number of Nics must be >0 and < 9"
            return

        for i in range(0,self.niccount):
            self.macs[i] = self.genMac(macprefix=self.macprefix,
                    vmnum = self.vmnum,
                    index = i + 1)
            val = str(i) + ',iface'
            self.ifaceups[val] = '%s-iface%d-ifup' %(self.vmname,i+1)
        self.uuid = str(uuid.uuid4())


    def clone(self, base, vmnum, count, switch=None):
        for i in range(vmnum, vmnum+count):
            self.vmnum = i
            self.vmname = self.generateVmName(self.prefix, self.vmnum)
            self.genMacs()
            self.img = self.vmname+".qcow2"
            cmd = ["/usr/bin/qemu-img", "create", 
                    "-f", "qcow2",
                    "-b", base, 
                    self.dest + self.vmname+".qcow2"]

            print ("Executing command: %s" %cmd)
            subprocess.call(cmd)

            self.generateXml()
            #self.generateIface()

            # now let's attach it to the logical switch
            
            self.attachPorts(switch)

    def attachPorts(self, switch):
        if not switch:
            return
        if len(self.macs) == len(switch):
            for i in range(macs):
                port = switch.createPort(swid=switch.index(i).id,
                                         vif = self.macToUuid(self.macs.index(i)),
                                         name=self.vmname,
                                         display = False)
        else:
            for i in self.macs:
                port = switch.createPort(swid=switch.id,
                                         vif = self.macToUuid(self.macs[i]),
                                         name=self.vmname,
                                         display = False)


    def generateIface(self):
        for i in self.macs:
            val = str(i) + ',iface'
            fname = self.dest+self.ifaceups[val]
            print "filename is: " + fname
            fp = open(fname, "w")
            fp.write("#!/bin/sh" + "\n")
            ifup = "%s $1 %s %s nsx-managed" %(self.ifup, 
                    self.macToUuid(self.macs[i]),
                    self.macs[i])
            fp.write(ifup + "\n")
            fp.close()
            os.chmod(fname, 0775)

    def setDestination(self, dest):
        if dest:
            self.dest = dest + '/'

    def setImage(self, img):
        self.img = img

    def genMac(self, macprefix, vmnum, index):
        mac="00:50:56:%02x:%x%x:%02x" %(macprefix, index, (vmnum/256)%16, vmnum%256)
        return mac

    def macToUuid(self, mac, prefix="00000000-0000-4000-8000"):
        first = prefix
        second = str.format("%012x" %(int(mac.translate(None,':'), 16)))
        return str(uuid.UUID(first+second))

    def generateVmName(self, prefix, num):
        return prefix + str.format("%04d" %num)

    def generateXml(self):
        if not self.img:
            print ("Error: image name not defined for VM")
            return

        domain = ET.Element(tag='domain', attrib={'type':'kvm'})
        name = ET.SubElement(domain,tag='name')
        name.text = self.vmname
        uuid = ET.SubElement(domain,tag='uuid')
        uuid.text = self.uuid
        memory = ET.SubElement(domain,tag='memory')
        memory.text = "512000"
        currentMemory = ET.SubElement(domain,tag='currentMemory')
        currentMemory.text = "512000"
        vcpu = ET.SubElement(domain,tag='vcpu')
        vcpu.text="2"
        oss = ET.SubElement(domain,tag='os')
        ostype = ET.SubElement(oss,tag='type', attrib={'arch':'x86_64'})
        ostype.text = "hvm"
        osboot = ET.SubElement(oss,tag='boot', attrib={'dev':'hd'})
        features = ET.SubElement(domain,tag='features')
        ET.SubElement(features, tag='acpi')
        ET.SubElement(features, tag='apic')
        ET.SubElement(features, tag='pae')
        ET.SubElement(domain, tag = 'clock', attrib={'offset':'localtime'})
        on_poweroff=ET.SubElement(domain,tag='on_poweroff')
        on_poweroff.text="destroy"
        on_reboot=ET.SubElement(domain,tag='on_reboot')
        on_reboot.text="restart"
        on_crash=ET.SubElement(domain,tag='on_crash')
        on_crash.text="restart"
        
        dev = ET.SubElement(domain,tag='devices')
        
        serial=ET.SubElement(dev,tag='serial', attrib={'type':'pty'})
        sertarget=ET.SubElement(serial,tag='target',attrib={'port':'0'})
        console=ET.SubElement(dev,tag='console', attrib={'type':'pty'})
        contarget=ET.SubElement(console,tag='target', attrib={'type':'serial', 'port':'0'})
        
        emu = ET.SubElement(dev,tag='emulator')
        # this change for RHEL.  This was /usr/bin/kvm for ubuntu
        emu.text="/usr/libexec/qemu-kvm"
        disk = ET.SubElement(dev,tag='disk', attrib={'type':'file', 'device':'disk'})
        d_driver=ET.SubElement(disk, tag='driver', attrib={'name':'qemu','type':'qcow2','cache':'none'})
        d_source=ET.SubElement(disk, tag='source', attrib={'file':self.dest + self.img})
        d_target=ET.SubElement(disk, tag='target', attrib={'dev':'hda', 'bus':'ide'})
        for i in self.macs:
            interface = ET.SubElement(dev, tag='interface', attrib={'type':'bridge'})
            int_mac = ET.SubElement(interface, tag='mac', attrib={'address': self.macs[i]})
            int_br = ET.SubElement(interface, tag='source', attrib={'bridge': 'nsx-managed'})
            int_vp = ET.SubElement(interface,tag='virtualport', attrib={'type':'openvswitch'})
            vp_uuid=self.macToUuid(self.macs[i])
            int_vpid = ET.SubElement(int_vp,tag='parameters', attrib={'interfaceid':vp_uuid})
            ET.SubElement(interface, tag='address', attrib={'type': 'pci', 'domain':'0x000', 'bus':'0x00','slot':'0x03','function':'0x0'})
            ET.SubElement(interface, tag="model", attrib={'type':'virtio'})
            ET.SubElement(interface, tag="driver", attrib={'name':'vhost', 'queues':'2'})
        ET.SubElement(dev, tag='graphics', attrib={'type':'vnc', 'port':'-1', 'autoport':'yes', 'keymap':'en-us', 'listen':'0.0.0.0'})
        console = ET.SubElement(dev, tag='console', attrib={'type':'pty'})
        conType = ET.SubElement(console, tag='target', attrib={'type':'serial', 'port':'0'})

        xmlout = ET.tostring(domain,'utf-8')
        prettyout = minidom.parseString(xmlout)
        fp = open(self.dest+self.vmname+'.xml', 'w')
        fp.write(prettyout.toprettyxml(indent="    "))
        fp.close()
        os.chmod(self.dest+self.vmname+'.xml', 0664)


def main():
    pass

if __name__ == "__main__":
    main()
