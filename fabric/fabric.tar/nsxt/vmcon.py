#!/usr/bin/python
import pinit
from pyVim import connect
from pyVmomi import vim
from pyVmomi import vmodl
import atexit
import argparse
import subprocess
import re
import uuid
from nsxtlib import *
import restlib

def parseParameters():

    parser = argparse.ArgumentParser(
            description='Arguments to connect to vCenter to add a hosts to a cluster')
    parser.add_argument('-s', '--host',
            required = True,
            action = 'store',
            help = 'Vcenter server name or IP')
    parser.add_argument('-u', '--user',
            required=True,
            action='store',
            help='User name to connect to vcenter')
    parser.add_argument('-p', '--password',
            required=False,
            action='store',
            help = 'Password for connection to vcenter')
    parser.add_argument("-w", '--switch',
            required = True,
            action='store',
            help = "NSX Switch Name")
    parser.add_argument("-n", '--name',
            required = False,
            action='store',
            help = "VM name or name pattern to match for poweron ")
    parser.add_argument('--nsxmgr',
                        required=True,
                        help="NSX Manager name  or ip")
    parser.add_argument('--nuser',
                        required=False,
                        default='admin',
                        help='NSX Manager user name, default: admin')
    parser.add_argument('--npass',
                        required=False,
                        default='Vmware123!',
                        help='NSX Manager user name, default: <cpt default>')

    args = parser.parse_args()
    args.loglevel="INFO"
    
    return args


def macToUuid(mac, prefix="00000000-0000-4000-8000"):
    first = prefix
    second = str.format("%012x" %(int(mac.translate(None,':'), 16)))
    return str(uuid.UUID(first+second))

def createSwitchPort(switch, swid, mac, name):
    if not switch:
        return
    port = switch.createPort(swid=swid, vif=macToUuid(mac),
                             name=name, display=False)
    
def getObject(inv, vimtype, name):
    """
    Get object by name from vcenter inventory
    """

    obj = None
    container = inv.viewManager.CreateContainerView(inv.rootFolder, vimtype, True)
    for i in container.view:
         if i.name == name:
             obj = i
             break
    return obj

def attachOpaqueNetworkDevBacking(dev, swid, vif=None, justvif=False):
    if not justvif:
        dev.backing = vim.vm.device.VirtualEthernetCard.OpaqueNetworkBackingInfo()
        dev.backing.opaqueNetworkId = swid
        dev.backing.opaqueNetworkType = 'nsx.LogicalSwitch'
    if vif:
        dev.externalId=vif
    else:
        dev.externalId = None 
                                                    
def main():
    args = parseParameters()
    if args.password:
        password = args.password
    else:
        password = getpass.getpass('Enter the password for vcenter %s and user %s:'
                                                           % (args.host, args.user))

    si = connect.SmartConnect(host=args.host, user=args.user, pwd=password)
    if not si:
        print("Could not connect to vcenter: %s" %args.host)
        return -1
    else:
        print("Connect to vcenter: %s" %args.host)

    atexit.register(connect.Disconnect, si)
    inv = si.RetrieveContent()
    dc = inv.rootFolder.childEntity[0]


    mgr = restlib.RestConnect('https://%s' % args.nsxmgr, user=args.nuser,
        password=args.npass, verify=False, content_type="application/json", 
        logLevel=args.loglevel)
    mgr.logger.debug(pprint.pformat(mgr.__dict__))

    sw = Switch(mgr=mgr)
    switch=sw.findByName(name=args.switch,display=False)
    if not switch:
        print("Switch %s not found" %args.switch)
    else:
        print("Switch name: %s" %switch['display_name'])
        
    vm = getObject(inv, [vim.VirtualMachine], args.name)
    if not vm:
        print ("VM not found: %s" %args.name)
        return
    print("VM Name: %s" %vm.name)
    for dev in vm.config.hardware.device:
        label = re.search(r'Network adapter (\d+)', dev.deviceInfo.label)
        if isinstance(dev, vim.vm.device.VirtualEthernetCard):
            print("Found network: %s" %dev.deviceInfo.label)
            if isinstance(dev.backing, vim.vm.device.VirtualEthernetCard.OpaqueNetworkBackingInfo):
                print("This is connected to LS: %s" % dev.backing.opaqueNetworkId)
            if hasattr(dev, 'externalId'):
                print("The VM's VIF is %s" %dev.externalId)

            vif = macToUuid(dev.macAddress)
            createSwitchPort(switch=sw,swid=switch['id'],mac=dev.macAddress,name=vm.name)
            attachOpaqueNetworkDevBacking(dev=dev, swid=switch['id'], vif=vif, justvif=False)

            virdev=vim.vm.device.VirtualDeviceSpec()
            virdev.device=dev
            virdev.operation = vim.vm.device.VirtualDeviceSpec.Operation.edit
            vmConfigSpec=vim.vm.ConfigSpec()
            vmConfigSpec.deviceChange=[virdev]
            vm.ReconfigVM_Task(vmConfigSpec)
            

            
        


if __name__ == "__main__":
    main()

    
