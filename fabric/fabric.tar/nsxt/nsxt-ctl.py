#!/usr/bin/env python
import pinit
import os, sys
import time, datetime
import getpass
import commands
import string
import json
#import yaml
import restlib
import argparse
import logging
import pprint
from pprint import pformat
from cptutil import pprint_od, expandArgFile, textAlign
import cptutil
#from nsxv import *
#from nsxvlib import *
import collections
from toasterlib import Toaster
from collections import OrderedDict as OD
from random import shuffle
import math
#import pexpect
from nsxtlib import *

from VirtualMachine import VirtualMachine

import requests, urllib3
requests.packages.urllib3.disable_warnings()                        # for older requests package
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning) # for new requests package


def get_vcenter_config(mgr, results=['ipAddress', 'userName']):
    url = '/api/2.0/services/vcconfig'
    r = mgr.get(url)
    if r.status_code >= 400:
        mgr.responseError(r)
    vcInfo = xmltodict.parse(r.text)['vcInfo']
    #print format_find_result(vcInfo, results=results)
    return format_find_result(vcInfo, results=results)


def mkArgParsers(elemSubparsers, ns, cmds, crNsSubparsers=True):
    ns_parser = elemSubparsers.add_parser(ns)
    ns_sub_parsers = ns_parser.add_subparsers(dest='%s' % ns) if crNsSubparsers else None

    r = {
        'parser':       ns_parser,
        'subparsers':   ns_sub_parsers,
    }

    '''
                    .               .               .               .               .
                    1               0/1             0+              1+
        opt-n       nop/name         -               -               n1op/names
        opt-ng      ngop/nameGlob    -               -               ng1op/namesGlob
        pos-n       npp/name        n_pp/name       n0pp/names      n1pp/names
        pos-ng      ngpp/nameGlob   ng_pp/nameGlob  ng0pp/namesGlob ng1pp/namesGlob
          nop.add_argument('--name')                    # on-1
         n1op.add_argument('--names', nargs='+')        # on-1+
         ngop.add_argument('--nameGlob')                # on-1
        ng1op.add_argument('--namesGlob', nargs='+')    # on-1+
          npp.add_argument('name')                  # pn-1
         n_pp.add_argument('name', nargs='?')       # pn-0/1
         n0pp.add_argument('names', nargs='*')      # pn-0+
         n1pp.add_argument('names', nargs='+')      # pn-1+
         ngpp.add_argument('nameGlob')              # pn-1
        ng_pp.add_argument('nameGlob', nargs='?')   # pn-0/1
        ng0pp.add_argument('namesGlob', nargs='*')  # pn-0+
        ng1pp.add_argument('namesGlob', nargs='+')  # pn-1+
    '''

    npp = argparse.ArgumentParser(add_help=False)
    npp.add_argument('name')                        # p_n-1

    ng_pp = argparse.ArgumentParser(add_help=False)
    ng_pp.add_argument('nameGlob', nargs='?', default='*')       # p_ng-0/1

    ngpp = argparse.ArgumentParser(add_help=False)
    ngpp.add_argument('nameGlob')                   # p_ng-1

    ng1pp = argparse.ArgumentParser(add_help=False)
    ng1pp.add_argument('namesGlob', nargs='+')      # p_ng-1+

    ng0op = argparse.ArgumentParser(add_help=False)
    ng0op.add_argument('--nameGlob', nargs='?')      # o_ng-0+

    ng1op = argparse.ArgumentParser(add_help=False)
    ng1op.add_argument('--namesGlob', nargs='+')      # o_ng-1+

    forcep = argparse.ArgumentParser(add_help=False)
    forcep.add_argument('--force', action='store_true')

    vmnsgp = argparse.ArgumentParser(add_help=False)
    vmnsgp.add_argument('vmNamesGlob', nargs='+')

    vmngp = argparse.ArgumentParser(add_help=False)
    vmngp.add_argument('vmNameGlob')

    tblp = argparse.ArgumentParser(add_help=False)
    tblp.add_argument('--table', action='store_true')

    fbnodep = argparse.ArgumentParser(add_help=False)
    fbnodep.add_argument('--node',
            required=True,
            help = "Name of the fabric node")
    hswp = argparse.ArgumentParser(add_help=False)
    hswp.add_argument('--hswname',
            required=True,
            help = "switchName: modifify switch configuration; +switchName: add new switch; ~switchName/!switchName: remove existing switch; =switchName: modify existing switch")
    nicsp = argparse.ArgumentParser(add_help=False)
    nicsp.add_argument('--nics', nargs='*',
            default = [],
            help = "List of physical NIC names")
    vlanswp = argparse.ArgumentParser(add_help=False)
    vlanswp.add_argument('--vlansw',
            help = "VLAN hostswitch name - should assign for Edge Nodes")
    vnicsp = argparse.ArgumentParser(add_help=False)
    vnicsp.add_argument('--vnics', nargs='*',
            help = "List of physical NIC names for the vlansw")
    ulprofp = argparse.ArgumentParser(add_help=False)
    ulprofp.add_argument('--uplinkprofile',
            help = "Name of the uplink port profile")
    lldpprofp = argparse.ArgumentParser(add_help=False)
    lldpprofp.add_argument('--lldpprofile',
            help = "Name of the LLDP profile")
    ippoolp = argparse.ArgumentParser(add_help=False)
    ippoolp.add_argument('--ippool', default=None,
            help = "Name of the IP pool")
    tzp = argparse.ArgumentParser(add_help=False)
    tzp.add_argument('--tzname', default=None,
            help = "Name of the TransportZone if adding to TZ")
    tagsSpecOP = argparse.ArgumentParser(add_help=False)
    tagsSpecOP.add_argument('--tagsSpec', default='', help='syntax: [<scope>:<tag>[,<scope>:<tag>]...]')

    restTypeOP = argparse.ArgumentParser(add_help=False)
    restTypeOP.add_argument('--resType', choices=['ippool', 'lr', 'ls', 'lsp', 'nsgroup', 'tz', 'vm'],
        required=True, help='Resource Type')

    #resNamep = argparse.ArgumentParser(add_help=False)
    #resNamep.add_argument('--resName', help='Name of the instance of the resouce')

    srcVmk = argparse.ArgumentParser(add_help=False)
    srcVmk.add_argument('--srcvmk', default=None,
                        help="Quote enclosed comma seperated list of vmknics")
    targetNets=argparse.ArgumentParser(add_help=False)
    targetNets.add_argument('--targets', default=None,
                            help="Quote enclosed comman seperated list of networks.\n \
                            Must be UUID if target is NSX-T logical switch.\n \
                            Must be portgroup name if VSS or DVS")

    if 'cluster_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('info')
        ns_cfg_parser = ns_sub_parsers.add_parser('nodes')
        ns_cfg_parser = ns_sub_parsers.add_parser('status')
        ns_cfg_parser = ns_sub_parsers.add_parser('join')
        ns_cfg_parser.add_argument('--primary', required=True,
                                   help='IP/hostname of current cluster member')
        ns_cfg_parser.add_argument('--secondaries', required=True, nargs='+',
                                   help='IP/hostname of one more secondary node')
        ns_cfg_parser = ns_sub_parsers.add_parser('jq')
        ns_cfg_parser.add_argument('jqType', nargs='?',
            choices=['status', 'details', 'nodes', 'vip', None], default=None)
    if 'pools_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('jq', parents=[ng_pp])
        ns_cfg_parser = ns_sub_parsers.add_parser('delete')
        ns_cfg_parser.add_argument('--name', required=True)
        ns_cfg_parser = ns_sub_parsers.add_parser('info')
        ns_cfg_parser = ns_sub_parsers.add_parser('config')
        ns_cfg_parser.add_argument('jsonFile')
        ns_cfg_parser.add_argument('targets', nargs='*')
    if 'manager_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('info')
        '''
        ns_cfg_parser = ns_sub_parsers.add_parser('join')
        ns_cfg_parser.add_argument('targets', nargs='+')
        '''
    if 'host_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('joinmp')
        ns_cfg_parser.add_argument('targets', nargs='+')
        ns_cfg_parser = ns_sub_parsers.add_parser('detachmp')
        ns_cfg_parser.add_argument('targets', nargs='+')
        ns_cfg_parser = ns_sub_parsers.add_parser('clearmp')
        ns_cfg_parser.add_argument('targets', nargs='+')
        ns_cfg_parser = ns_sub_parsers.add_parser('apijoinmp')
        ns_cfg_parser.add_argument('targets', nargs='+')
        ns_cfg_parser = ns_sub_parsers.add_parser('thumbprint')
        ns_cfg_parser.add_argument('targets', nargs='+')
        ns_cfg_parser = ns_sub_parsers.add_parser('delete')
        ns_cfg_parser.add_argument('targets', nargs='+')
        ns_cfg_parser.add_argument('--unprep', default='False',
                                   choices=['True','False'])
        ns_cfg_parser = ns_sub_parsers.add_parser('find')
        ns_cfg_parser.add_argument('--name', default=None)
        ns_cfg_parser.add_argument('--ip', default=None)
        ns_lst_parser = ns_sub_parsers.add_parser('list')
        ns_jq_parser  = ns_sub_parsers.add_parser('jq')
    if 'controller_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('info')
        ns_cfg_parser = ns_sub_parsers.add_parser('join')
        ns_cfg_parser.add_argument('manager')
        ns_cfg_parser.add_argument('targets', nargs='+')
        ns_cfg_parser = ns_sub_parsers.add_parser('secret')
        ns_cfg_parser.add_argument('targets', nargs='+')
        ns_cfg_parser = ns_sub_parsers.add_parser('joincp')
        ns_cfg_parser.add_argument('targets', nargs='+')
        ns_cfg_parser = ns_sub_parsers.add_parser('joinmp')
        ns_cfg_parser.add_argument('manager')
        ns_cfg_parser.add_argument('targets', nargs='+')
        ns_cfg_parser = ns_sub_parsers.add_parser('initialize')
        ns_cfg_parser.add_argument('target')
        ns_cfg_parser = ns_sub_parsers.add_parser('joinCluster')
        ns_cfg_parser.add_argument('from')
        ns_cfg_parser.add_argument('targets', nargs='+')
        ns_cfg_parser = ns_sub_parsers.add_parser('activate')
        ns_cfg_parser.add_argument('targets', nargs='+')
    if 'edgenode_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('joinmp')
        ns_cfg_parser.add_argument('manager')
        ns_cfg_parser.add_argument('targets')
        ns_cfg_parser = ns_sub_parsers.add_parser('list')
        ns_cfg_parser = ns_sub_parsers.add_parser('jq')

    if 'edgecluster_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('list')
        ns_cfg_parser = ns_sub_parsers.add_parser('jq')
        ns_cfg_parser = ns_sub_parsers.add_parser('config')
        ns_cfg_parser.add_argument('--name', required=True)
        ns_cfg_parser.add_argument('--members', nargs='+')
        ns_cfg_parser = ns_sub_parsers.add_parser('delete')
        ns_cfg_parser.add_argument('--name', required=True)


    if 'tz_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('list')
        ns_cfg_parser = ns_sub_parsers.add_parser('jq', parents=[ng_pp])
        ns_cfg_parser = ns_sub_parsers.add_parser('config')
        ns_cfg_parser.add_argument('jsonFile')
        ns_cfg_parser.add_argument('targets', nargs='*')
        ns_cfg_parser = ns_sub_parsers.add_parser('find')
        ns_cfg_parser.add_argument('target')
        ns_cfg_parser = ns_sub_parsers.add_parser('delete')
        ns_cfg_parser.add_argument('--ids', help='Comma seperated TZ IDs')
        ns_cfg_parser.add_argument('--namesGlob', default=[], nargs='?')
        ns_cfg_parser = ns_sub_parsers.add_parser('create')
        ns_cfg_parser.add_argument('--desc')
        ns_cfg_parser.add_argument('--swName')
        ns_cfg_parser.add_argument('--type', choices=['OVERLAY', 'VLAN'], default='VLAN')
        ns_cfg_parser.add_argument('name')


    if 'service_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('list')
        ns_cfg_parser = ns_sub_parsers.add_parser('jq', parents=[ng_pp])


    if 'nsservice_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('list')
        ns_cfg_parser = ns_sub_parsers.add_parser('find')
        ns_cfg_parser.add_argument('--name', required=True)
        ns_cfg_parser = ns_sub_parsers.add_parser('jq', parents=[ng_pp])
        ns_cfg_parser = ns_sub_parsers.add_parser('create',
                                formatter_class=argparse.RawTextHelpFormatter)
        ns_cfg_parser.add_argument('--update', action='store_true')
        ns_cfg_parser.add_argument('nsserviceSpec', help=NSServices.createNSService.__doc__)
        ns_cfg_parser = ns_sub_parsers.add_parser('delete', parents=[ng1pp])
        ns_cfg_parser.add_argument('--ids', help='Comma seperated NSService IDs')


    if 'nsservicegroup_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('list')
        ns_cfg_parser = ns_sub_parsers.add_parser('find')
        ns_cfg_parser.add_argument('--name', required=True)
        ns_cfg_parser = ns_sub_parsers.add_parser('jq', parents=[ng_pp])
        ns_cfg_parser = ns_sub_parsers.add_parser('create',
                                formatter_class=argparse.RawTextHelpFormatter)
        ns_cfg_parser.add_argument('--update', action='store_true')
        ns_cfg_parser.add_argument('nsservicegroupSpec', help=NSServiceGroups.createNSServiceGroup.__doc__)
        ns_cfg_parser = ns_sub_parsers.add_parser('delete', parents=[ng1pp])
        ns_cfg_parser.add_argument('--ids', help='Comma seperated NSServiceGroup IDs')


    if 'uplink_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('list')
        ns_cfg_parser = ns_sub_parsers.add_parser('jq', parents=[ng_pp])
        ns_cfg_parser = ns_sub_parsers.add_parser('find')
        ns_cfg_parser.add_argument('target')
        ns_cfg_parser = ns_sub_parsers.add_parser('config')
        ns_cfg_parser.add_argument('jsonFile')
        ns_cfg_parser.add_argument('targets', nargs='*')
        ns_cfg_parser = ns_sub_parsers.add_parser('delete')
        ns_cfg_parser.add_argument('targetGlob')

    if 'dhcp_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('list')                       # dhcp/list
        ns_cfg_parser = ns_sub_parsers.add_parser('find')                       # dhcp/find
        ns_cfg_parser.add_argument('target')
        ns_cfg_parser = ns_sub_parsers.add_parser('delete')                     # dhcp/delete
        ns_cfg_parser.add_argument('target')
        ns_cfg_parser = ns_sub_parsers.add_parser('config')                     # dhcp/config
        ns_cfg_parser.add_argument('--name',required=True)
        ns_cfg_parser.add_argument('--profile',required=True)
        ns_cfg_parser = ns_sub_parsers.add_parser('listprofile')                # dhcp/listprofile
        ns_cfg_parser = ns_sub_parsers.add_parser('findprofile')                # dhcp/findprofile
        ns_cfg_parser.add_argument('target')
        ns_cfg_parser = ns_sub_parsers.add_parser('delprofile')                 # dhcp/delprofile
        ns_cfg_parser.add_argument('target')
        ns_cfg_parser = ns_sub_parsers.add_parser('configprofile')              # dhcp/configprofile
        ns_cfg_parser.add_argument('--name',required=True)
        ns_cfg_parser.add_argument('--servers',required=True, nargs='+')

        #ns_cfg_parser = ns_sub_parsers.add_parser('relay')
        #ns_cfg_parsers = ns_cfg_parser.add_subparsers(dest='ns2')
        #ns2_cfg_parser = ns_cfg_parsers.add_parser('list')                      # dhcp/relay/list
        #ns2_cfg_parser = ns_cfg_parsers.add_parser('jq')                        # dhcp/relay/jq

        #ns2_cfg_parser = ns_cfg_parsers.add_parser('config')                   # dhcp/relay/config
        #ns2_cfg_parser.add_argument('--name', required=True)


    if 'br_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('list')
        ns_cfg_parser.add_argument('--switchname',
                                   required=False,
                                   default='')
        ns_cfg_parser = ns_sub_parsers.add_parser('create')
        ns_cfg_parser.add_argument('--switchname',
                                   required=False,
                                   default='')
        ns_cfg_parser.add_argument('--brcluster',
                                   required=True)
        ns_cfg_parser.add_argument('--vlan',
                                   type=int,
                                   choices=range(0,4095),
                                   metavar="[0-4094]",
                                   required=True)
        ns_cfg_parser = ns_sub_parsers.add_parser('delete')
        ns_cfg_parser.add_argument('--name',
                                   required=False,
                                   default='')
        ns_cfg_parser.add_argument('--id',
                                   required=False,
                                   default='')

        ns_cfg_parser = ns_sub_parsers.add_parser('cluster')
        ns_brclusterns_parser = ns_cfg_parser.add_subparsers(dest='brcluster')
        ns_brcluster_parser = ns_brclusterns_parser.add_parser('list')
        ns_brcluster_parser = ns_brclusterns_parser.add_parser('show')
        ns_brcluster_parser.add_argument('--name')
        ns_brcluster_parser = ns_brclusterns_parser.add_parser('create')
        ns_brcluster_parser.add_argument('--name')
        ns_brcluster_parser.add_argument('--tn', nargs='+',
                                         help = "List of TN names")
        ns_brcluster_parser = ns_brclusterns_parser.add_parser('delete')
        ns_brcluster_parser.add_argument('--name')

        ns_cfg_parser = ns_sub_parsers.add_parser('brendpoint')
        ns_bepns_parser = ns_cfg_parser.add_subparsers(dest="bep")
        ns_bep_parser = ns_bepns_parser.add_parser('list')
        ns_bep_parser = ns_bepns_parser.add_parser('delete')
        ns_bep_parser.add_argument('--name', default='', required=False)
        ns_bep_parser.add_argument('--id', default='', required=False)


    if 'lr_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('list')
        ns_cfg_parser.add_argument('--table', action='store_true')
        ns_cfg_parser = ns_sub_parsers.add_parser('jq', parents=[ng_pp])
        ns_cfg_parser = ns_sub_parsers.add_parser('find')
        ns_cfg_parser.add_argument('target')

        ns_cfg_parser = ns_sub_parsers.add_parser('config')
        ns_cfg_parser.add_argument('--name',required=True,
                help='Name of Logical Router')
        ns_cfg_parser.add_argument('--tier',required=True,
                type = int, choices=[0,1],
                help = 'Tier0 or Tier1, specify 0 or 1')
        ns_cfg_parser.add_argument('--edgecluster',required=False,
                default=None,
                help = "Name of edgecluster, required if creating Tier0")
        ns_cfg_parser.add_argument('--ha',required=False,
                default='ACTIVE_ACTIVE',
                choices=['ACTIVE_ACTIVE', 'ACTIVE_STANDBY'],
                help = "Highavailability mode: ACTIVE_ACTIVE or ACTIVE_STANDBY")
        ns_cfg_parser.add_argument('--tier0', required=False,
                default=None,
                help='Name of Tier0 LR to connect if creating Tier1 router')
        ns_cfg_parser = ns_sub_parsers.add_parser('delete')
        ns_cfg_parser.add_argument('--name', required=True)


        # Uplinks NS
        ns_cfg_parser = ns_sub_parsers.add_parser('link')
        ns_uplinkns_parser = ns_cfg_parser.add_subparsers(dest='lruplinks')

        ns_uplink_parser = ns_uplinkns_parser.add_parser('list')

        ns_uplink_parser = ns_uplinkns_parser.add_parser('find')
        ns_uplink_parser.add_argument('--name', required=True)

        ns_uplink_parser = ns_uplinkns_parser.add_parser('delete')
        ns_uplink_parser.add_argument('--name', required=True)

        ns_uplink_parser = ns_uplinkns_parser.add_parser('create')
        ns_uplink_parser.add_argument('--name',required=True)
        ns_uplink_parser.add_argument('--edgecluster',required=True)
        ns_uplink_parser.add_argument('--edge',required=True)
        ns_uplink_parser.add_argument('--router',required=True)
        ns_uplink_parser.add_argument('--switch',required=True)
        ns_uplink_parser.add_argument('--cidr',required=True)

        ns_uplink_parser = ns_uplinkns_parser.add_parser('createdownlink')
        ns_uplink_parser.add_argument('--router',required=True)
        ns_uplink_parser.add_argument('--switch',required=True)
        ns_uplink_parser.add_argument('--cidr',required=True)
        ns_uplink_parser.add_argument('--services',
                                   required=False,
                                   default=None,
                                   nargs='*')

        # End Uplinks NS

        # LR Route NS
        ns_cfg_parser = ns_sub_parsers.add_parser('route')
        ns_routens_parser = ns_cfg_parser.add_subparsers(dest='route')

        # Static routes ns

        ns_route_parser = ns_routens_parser.add_parser('static')
        ns_staticns_parser = ns_route_parser.add_subparsers(dest='static')

        ns_static_parser = ns_staticns_parser.add_parser('add')
        ns_static_parser.add_argument('--router',required=True)
        ns_static_parser.add_argument('--prefix',required=True)
        ns_static_parser.add_argument('--nexthop',required=True)

        ns_static_parser = ns_staticns_parser.add_parser('delete')
        ns_static_parser.add_argument('--router',required=True)
        ns_static_parser.add_argument('--prefix',required=True)
        ns_static_parser.add_argument('--nexthop',required=True)

        ns_static_parser = ns_staticns_parser.add_parser('list')
        ns_static_parser.add_argument('--router',required=True)

        # End Static routes ns

        # Begin Route Redistribution NS
        ns_route_parser = ns_routens_parser.add_parser('redist')
        ns_redistns_parsers = ns_route_parser.add_subparsers(dest='redist')

        ns_redist_parser = ns_redistns_parsers.add_parser('show')
        ns_redist_parser.add_argument('router')

        ns_redist_parser = ns_redistns_parsers.add_parser('update',
                                formatter_class=argparse.RawTextHelpFormatter)
        ns_redist_parser.add_argument('--router',required=True,
                                   help="Name of router")
        ns_redist_parser.add_argument('--enable',required=False,
                                   choices=['yes','no'],
                                   default=None,
                                   help="Enable/Disable route redistribution")

        ns_redist_parser.add_argument('--name',required=False,
                                   help="Name of redistribution rule")
        ns_redist_parser.add_argument('--desc',required=False,
                                   help="Description of redistribution rule")
        ns_redist_parser.add_argument('--sources',required=False, nargs='+',
                choices=['static','nsxcon','nsxstatic','nat0','nat1', 'lbvip1', 'lbnat1'],
                                   help="static: Static Routes \n"
                                   "nsxcon: NSX Connected \n"
                                   "sxstatic: NSX Static \n"
                                   "nat0: Tier-0 NAT\n"
                                   "nat1: Tier-1 NAT\n"
                                   "lbvip1: Tier1 LB VIP\n"
                                   "lbnat1: Tier1 LB SNAT")
        ns_redist_parser.add_argument('--append', required=False,
                                   default=False,
                                   action='store_true',
                                   help="Append to existing rules")
        ns_redist_parser.add_argument('--routemap', required=False,
                                   help="Name of routemap")
        ns_redist_parser.add_argument('--dest', required=False,
                                   choices=['BGP'],
                                   default='BGP',
                                   help="Learning protocol")
        # end Route Redistribution NS

        # Begin Route Advertisement NS
        ns_route_parser = ns_routens_parser.add_parser('advertise')
        ns_advertisens_parser = ns_route_parser.add_subparsers(dest='advertise')

        ns_advertise_parser = ns_advertisens_parser.add_parser('show')
        ns_advertise_parser.add_argument('--router',required=True)

        ns_advertise_parser = ns_advertisens_parser.add_parser('update',
                                   help='Change Route Advertisemnt')
        ns_advertise_parser.add_argument('--router',required=True)
        ns_advertise_parser.add_argument('--enable',required=False,
                                   default=None,
                                   choices=['yes','no'])
        ns_advertise_parser.add_argument('--nsx',required=False,
                                   default=None,
                                   choices=['yes','no'])
        ns_advertise_parser.add_argument('--nat',required=False,
                                   default=None,
                                   choices=['yes','no'])
        ns_advertise_parser.add_argument('--static',required=False,
                                   default=None,
                                   choices=['yes','no'])
        ns_advertise_parser.add_argument('--lbsnat', required=False,
                                         default=None,
                                         choices=['yes', 'no'])
        ns_advertise_parser.add_argument('--lbvip', required=False,
                                         default=None,
                                         choices=['yes', 'no'])
        
        # End Route Advertisement NS
        # End LR Route NS
        ns_cfg_parser = ns_sub_parsers.add_parser('addvip')
        ns_cfg_parser.add_argument('--router', required=True)
        ns_cfg_parser.add_argument('--cidr', required=True)
        ns_cfg_parser.add_argument('--uplink1', required=True)
        ns_cfg_parser.add_argument('--uplink2', required=True)


        ns_cfg_parser = ns_sub_parsers.add_parser('route-map')
        ns_routemapns_parser = ns_cfg_parser.add_subparsers(dest='routemap')
        ns_routemap_parser = ns_routemapns_parser.add_parser('list')
        ns_routemap_parser.add_argument('--router',
                                        required=True,
                                        help='Router name')
        ns_routemap_parser.add_argument('--brief',
                                      default=False,
                                      action='store_true',
                                      help="Show brief")
        ns_routemap_parser = ns_routemapns_parser.add_parser('find')
        ns_routemap_parser.add_argument('--router',
                                        required=True,
                                        help="Router name")
        ns_routemap_parser.add_argument('--name',
                                        required=True,
                                        help="Route-map name")

        ns_routemap_parser = ns_routemapns_parser.add_parser('config')
        ns_routemap_parser.add_argument('--router',
                                        required=True,
                                        help='Router name')
        ns_routemap_parser.add_argument('--name',
                                        required=True,
                                        help="Name of routemap")
        ns_routemap_parser.add_argument('--spec',
                                        required=True,
                                        nargs='*',
                                        help="List of routemap specs.  Format: <prefix list>:as_pre:med_dis:weight:community:action, where action is ACCEPT|DENY")
        ns_routemap_parser.add_argument('--description',
                                        required=False,
                                        help="Route map description")
        ns_routemap_parser.add_argument('--tags',
                                        nargs='*',
                                        required=False,
                                        help='Tag specs, format: scope:tag_name')
        ns_routemap_parser = ns_routemapns_parser.add_parser('delete')
        ns_routemap_parser.add_argument('--router',
                                        required=True,
                                        help='Router name')
        ns_routemap_parser.add_argument('--name',
                                        required=True,
                                        help="Name of routemap")

        ns_cfg_parser = ns_sub_parsers.add_parser('prefixlist')
        ns_prefixns_parser = ns_cfg_parser.add_subparsers(dest='prefixList')
        ns_prefix_parser = ns_prefixns_parser.add_parser('list')
        ns_prefix_parser.add_argument('--router',
                                      required=True,
                                      help='Tier0 router name')
        ns_prefix_parser.add_argument('--brief',
                                      default=False,
                                      action='store_true',
                                      help="Show brief")

        ns_prefix_parser = ns_prefixns_parser.add_parser('delete')
        ns_prefix_parser.add_argument('--router',
                                      required=True,
                                      help='Tier0 router name')
        ns_prefix_parser.add_argument('--name',
                                      required=True,
                                      help='PrefixList Spec')

        ns_prefix_parser = ns_prefixns_parser.add_parser('config')
        ns_prefix_parser.add_argument('--router',
                                      required=True,
                                      help='Tier0 router name')
        ns_prefix_parser.add_argument('--name',
                                      required=True,
                                      help='PrefixList Spec')

        ns_prefix_parser.add_argument('--spec',
                                      nargs='*',
                                      required=True,
                                      help='Spec, format: prefix:le:ge:action, where le/ge are 0-32')
        ns_prefix_parser.add_argument('--desc',
                                      required=False,
                                      help='PrefixList Description')
        ns_prefix_parser.add_argument('--tags',
                                      nargs='*',
                                      required=False,
                                      help='Tag specs, format: scope:tag_name')
        ns_prefix_parser = ns_prefixns_parser.add_parser('update')
        ns_prefix_parser.add_argument('--router',
                                      required=True,
                                      help='Tier0 router name')
        ns_prefix_parser.add_argument('--name',
                                      required=True,
                                      help='PrefixList Spec')

        ns_prefix_parser.add_argument('--spec',
                                      nargs='*',
                                      required=False,
                                      help='Spec, format: prefix:ge:le:action')
        ns_prefix_parser.add_argument('--desc',
                                      required=False,
                                      help='PrefixList Description')
        ns_prefix_parser.add_argument('--tags',
                                      nargs='*',
                                      required=False,
                                      help='Tag specs, format: scope:tag_name')




        # BGP NS
        ns_cfg_parser = ns_sub_parsers.add_parser('bgp')
        ns_bgpns_parser = ns_cfg_parser.add_subparsers(dest='bgpns')
        ns_bgp_parser = ns_bgpns_parser.add_parser('list')
        ns_bgp_parser.add_argument('--table', action='store_true')
        ns_cfg_parser.add_argument('--routers', nargs='*')

        ns_bgp_parser = ns_bgpns_parser.add_parser('bfd')
        ns_bgp_parser.add_argument('--router', required=True)
        ns_bgp_parser.add_argument('--neighbor', required=True)
        ns_bgp_parser.add_argument('--rx', default=1000)
        ns_bgp_parser.add_argument('--tx', default=1000)
        ns_bgp_parser.add_argument('--multi', default=39)
        ns_bgp_parser.add_argument('--enable', default= True,
                                   action='store_true')

        ns_bgp_parser = ns_bgpns_parser.add_parser('routemap')
        ns_bgp_parser.add_argument('--router', required=True)
        ns_bgp_parser.add_argument('--neighbor', required=True)
        ns_bgp_parser.add_argument('--inbound', default=None)
        ns_bgp_parser.add_argument('--outbound', default=None)
        ns_bgp_parser.add_argument('--addr', choices=['IPV4_UNICAST'],
                                   default='IPV4_UNICAST')

        ns_bgp_parser.add_argument('--enable', default= True,
                                   action='store_true')

        ns_bgp_parser = ns_bgpns_parser.add_parser('neighbor')
        ns_bgp_parser.add_argument('--router',required=True,
                help='Name of Logical Router')
        ns_bgp_parser.add_argument('--peer',required=True,
                help="IP address of peer")
        ns_bgp_parser.add_argument('--localip',required=False, nargs="*",
                default=None,
                help="Source IP address, default is all IPs if not specified")
        ns_bgp_parser.add_argument('--remoteas',required=True,type=int,
                help="Remote BGP AS")
        ns_bgp_parser.add_argument('--secret',required=False,
                default=None,
                help="BGP neighbor password")
        ns_bgp_parser.add_argument('--keepalive',required=False,
                type=int,default=60,
                help="BGP keepalive interval in seconds, default 60")
        ns_bgp_parser.add_argument('--holdtimer',required=False,
                type=int,default=180,
                help="BGP Hold Down timer in seconds, default 180")

        ns_bgp_parser = ns_bgpns_parser.add_parser('update')
        ns_bgp_parser.add_argument('--router',required=True,
                help='Name of Logical Router')
        ns_bgp_parser.add_argument('--localas',required=False,
                type=int,default=None,
                help="Local AS Number, specify if changing")
        ns_bgp_parser.add_argument('--ecmp',required=False,
                action='store_true',dest='ecmp',default=None,
                help="Enable ECMP")
        ns_bgp_parser.add_argument('--noecmp',required=False,
                action='store_false',dest='ecmp',default=None,
                help="Disable ECMP")
        ns_bgp_parser.add_argument('--gr',required=False,
                action='store_true',dest='gr',default=None,
                help='Enable GR')
        ns_bgp_parser.add_argument('--nogr',required=False,
                action='store_false',dest='gr',default=None,
                help='Disable GR')
        ns_bgp_parser.add_argument('--enable',required=False,
                action='store_true',dest='enable',default=None,
                help='Enable BGP')
        ns_bgp_parser.add_argument('--disable',required=False,
                action='store_false',dest='enable',default=None,
                help='Enable BGP')

        # End of BGP NS

        ns_cfg_parser = ns_sub_parsers.add_parser('bfd')
        ns_bfdns_parser = ns_cfg_parser.add_subparsers(dest='bfd')

        ns_bfd_parser = ns_bfdns_parser.add_parser('show')
        ns_bfd_parser.add_argument('--router', required=True)

        ns_bfd_parser = ns_bfdns_parser.add_parser('config')
        ns_bfd_parser.add_argument('--router', required=True)
        ns_bfd_parser.add_argument('--rx', default=1000)
        ns_bfd_parser.add_argument('--tx', default=1000)
        ns_bfd_parser.add_argument('--multi', default=39)
        ns_bfd_parser.add_argument('--enable', default= True,
                                   action='store_true')


        # End of BFD NS
        ns_cfg_parser = ns_sub_parsers.add_parser('nat')
        ns_natns = ns_cfg_parser.add_subparsers(dest='natNs')
        ns_natns_parser = ns_natns.add_parser('list')
        ns_natns_parser.add_argument('--router', required=True)
        ns_nat_ns_parser = ns_natns.add_parser('add',
                                              help="Add NAT Rule")
        ns_nat_ns_parser.add_argument('--router', required=True)
        ns_nat_ns_parser.add_argument('--name', required=False, default=None)
        ns_nat_ns_parser.add_argument('--action', required=True,
                                     choices=['SNAT', 'DNAT', 'NO_SNAT',
                                              'NO_DNAT'])
        ns_nat_ns_parser.add_argument('--service', required=False,
                                      default=None,
                                      help="Match Service Definition formats:\n"
                                      "IP Protocol:   ip:protocol_number\n"
                                      "ICMP: icmp:ICMPv4|iCMPV6:code:type\n"
                                      "     code and type can be blank\n"
                                      "L4: l4:TCP|UDP:src port:|dst port")
        ns_nat_ns_parser.add_argument('--source', default=None,
                                      help="Source IP/Range/CIDR to match")
        ns_nat_ns_parser.add_argument('--dest', default=None,
                                      help="Destination IP/Range/CIDR to match")
        ns_nat_ns_parser.add_argument('--passfw', type=bool, default=True,
                                      help="Enable/Disable to bypass firewall stage")
        ns_nat_ns_parser.add_argument('--priority', type=int, default=1024,
                                      help="NAT Rule priority")
        ns_nat_ns_parser.add_argument('--enable',type=bool, default=True,
                                      help="Set rule to enable/disable")
        ns_nat_ns_parser.add_argument('--log', type=bool,default=False,
                                      help="Enable/Disable logging of rule")
        ns_nat_ns_parser.add_argument('--natNet', required=False, default=None,
                                      help="Translated IP/Range/CIDR")
        ns_nat_ns_parser.add_argument('--natPort', required=False, default=None,
                                      help="port number or range for DNAT")
        ns_nat_ns_parser.add_argument('--desc', default=None)
        ns_nat_ns_parser.add_argument('--tags', default=None,nargs='+',
                                      help="Tags list in format of 'scope:tagname'")

    if 'lsp_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('list')
        ns_cfg_parser = ns_sub_parsers.add_parser('jq', parents=[ng_pp])
        ns_cfg_parser = ns_sub_parsers.add_parser('delete')
        ns_cfg_parser.add_argument('--namesGlob', nargs='+', required=True)

    if 'hswProf_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('list')
        ns_cfg_parser = ns_sub_parsers.add_parser('jq', parents=[ng_pp])

    if 'switch_api' in cmds:
        
        
        ns_cfg_parser = ns_sub_parsers.add_parser('list')
        ns_cfg_parser = ns_sub_parsers.add_parser('jq', parents=[ng_pp])
        ns_cfg_parser = ns_sub_parsers.add_parser('getid')
        ns_cfg_parser.add_argument('target')
        ns_cfg_parser = ns_sub_parsers.add_parser('getvni')
        ns_cfg_parser.add_argument('target')
        ns_cfg_parser = ns_sub_parsers.add_parser('ports')
        ns_cfg_parser.add_argument('--name', required=False)
        ns_cfg_parser.add_argument('--id', required=False)
        ns_cfg_parser = ns_sub_parsers.add_parser('delport')
        ns_cfg_parser.add_argument('--name',required=True)
        ns_cfg_parser.add_argument('--swname', required=False,default=None)
        ns_cfg_parser = ns_sub_parsers.add_parser('deldownports')
        ns_cfg_parser.add_argument('--id',default=None,required=False)
        ns_cfg_parser = ns_sub_parsers.add_parser('delunattachports')
        ns_cfg_parser.add_argument('--id',default=None,required=False)
        ns_cfg_parser = ns_sub_parsers.add_parser('delopdownports')
        ns_cfg_parser.add_argument('--id',default=None,required=False)
        ns_cfg_parser = ns_sub_parsers.add_parser('teaming')
        ns_cfg_parser.add_argument('--name', required=True,
                                   help="Switch name")
        ns_cfg_parser.add_argument('--policy', default=None,
                                   required=False,
                                   help="Name of teaming policy, leave None to delete")
        ns_cfg_parser = ns_sub_parsers.add_parser('addport')
        ns_cfg_parser.add_argument('--swname')
        ns_cfg_parser.add_argument('--vifuuid', default=None,
                                   required = False)
        ns_cfg_parser.add_argument('--name', default=None,
                                   required=False)
        ns_cfg_parser.add_argument('--tnname', required=False,
                                   default=None,
                                   help="Name of TN for BM TN port, will auto-gen VIF UUID if vifuuuid is not supplied")
        ns_cfg_parser.add_argument('--unblocked', required=False,
                                   default=None,
                                   help="Set this parameter to True is you want to create the port unblocked. Ignored by default")
        ns_cfg_parser=ns_sub_parsers.add_parser('addtag')
        ns_cfg_parser.add_argument('--name', required=False,
                                   default=None,
                                   help="Switch name")
        ns_cfg_parser.add_argument('--id', required=False,
                                   default=None,
                                   help="Switch ID.  Takes precedence over name")
        
        ns_cfg_parser.add_argument('--tags', required=True,
                                   nargs='+',
                                   help="one or more tags")
        ns_cfg_parser.add_argument('--scope', required=False,
                                   default=None,
                                   help="Scope string")
        ns_cfg_parser = ns_sub_parsers.add_parser('delzero')
        ns_cfg_parser.add_argument('target')
        ns_cfg_parser = ns_sub_parsers.add_parser('delete')
        ns_cfg_parser.add_argument('--name', required=True)
        ns_cfg_parser = ns_sub_parsers.add_parser('config')
        ns_cfg_parser.add_argument('--name', required = True,
                help = "Name of logical switch")
        ns_cfg_parser.add_argument('--tzname', required=True,
                help = "Name of Transport Zone")
        ns_cfg_parser.add_argument('--vlan', default=0,
                help = "VLAN ID if transportzone type is VLAN, default=0")
        ns_cfg_parser.add_argument('--replication', default="MTEP",
                help = "Replication mode, MTEP or SOURCE, \
                        if transportzone type is OVERLAY")
        ns_cfg_parser.add_argument('--teaming', default=None, required=False,
                                   help="Name of the switching uplink teaming policy")
        
        ns_cfg_parser = ns_sub_parsers.add_parser('profile')
        ns_switchprofile = ns_cfg_parser.add_subparsers(dest='switchprofile')
        ns_switchprofile_parser = ns_switchprofile.add_parser('list')
        ns_switchprofile_parser = ns_switchprofile.add_parser('delete')
        ns_switchprofile_parser.add_argument('--name', required=True)
        ns_switchprofile_parser = ns_switchprofile.add_parser('spoofguard')
        ns_spoofguard = ns_switchprofile_parser.add_subparsers(dest='spoofguardNs')
        ns_spoofguard_parser = ns_spoofguard.add_parser('config')
        ns_spoofguard_parser.add_argument('--name', required=True)
        ns_spoofguard_parser.add_argument('--bindings', default=None, nargs='+',
                                          choices=[None,'LPORT_BINDINGS',
                                                   'LSWITCH_BINDINGS'],
                                          help="Ways to provide white listed addresses for \
                                          spoofguard.  Default is None")
        ns_spoofguard_parser.add_argument('--desc', default = None)
        ns_spoofguard_parser.add_argument('--tags', default=None,nargs='+',
                                          help="list of tags in format of 'scope:tag'")
        ns_switchprofile_parser = ns_switchprofile.add_parser('mac')
        ns_macmanagement = ns_switchprofile_parser.add_subparsers(dest='MacManagementNs')
        ns_macmanagement_parser = ns_macmanagement.add_parser('config')
        ns_macmanagement_parser.add_argument('--name', required=True)
        ns_macmanagement_parser.add_argument('--macChange', default=True,
                                             type=bool, choices=[True, False],
                                             help="Allow mac change")
        ns_macmanagement_parser.add_argument('--macAge', default=300,
                                             help="MAC Age timer in second")
        ns_macmanagement_parser.add_argument('--macLearn', default=False,
                                             type=bool, choices=[True, False],
                                             help="Enable MAC learning")
        ns_macmanagement_parser.add_argument('--macLimit',default=4096,
                                             help="Limit on MACs learned, max is 4096")
        ns_macmanagement_parser.add_argument('--macLimitPolicy', default="ALLOW",
                                             choices=['ALLOWED', 'DROP'],
                                             help="Policy when MAC Limit exceeded")
        ns_macmanagement_parser.add_argument('--uflood', default=True, type=bool,
                                             help="Allow unknwon unicast flood")
        ns_macmanagement_parser.add_argument('--desc', default=None)
        ns_macmanagement_parser.add_argument('--tags', default=None, nargs='+',
                                             help="TAGs list in format of 'scope:tagname'")
        ns_switchprofile_parser = ns_switchprofile.add_parser('discovery')
        ns_ipdiscovery = ns_switchprofile_parser.add_subparsers(dest='IpDiscoveryNs')
        ns_ipdiscovery_parser = ns_ipdiscovery.add_parser('config')
        ns_ipdiscovery_parser.add_argument('--name', required=True)
        ns_ipdiscovery_parser.add_argument('--arpSnoop', default=True,
                                           type=bool,
                                           help="Enable ARP snooping")
        ns_ipdiscovery_parser.add_argument('--arpLimit', default=1, type=int,
                                           help='Number of ARP snooop entries to remember per port, max: 128')
        ns_ipdiscovery_parser.add_argument('--dhcpSnoop', default=True, type=bool,
                                           help="Enable DHCP snooping");
        ns_ipdiscovery_parser.add_argument('--vmtools', default=False, type=bool,
                                           help="Enable discovery via VMTools")
        ns_ipdiscovery_parser.add_argument('--desc', default=None)
        ns_ipdiscovery_parser.add_argument('--tags', default=None, nargs='+',
                                             help="TAGs list in format of 'scope:tagname'")
        ns_switchprofile_parser = ns_switchprofile.add_parser('qos')
        ns_qos = ns_switchprofile_parser.add_subparsers(dest='QosNs')
        ns_qos_parser = ns_qos.add_parser('config')
        ns_qos_parser.add_argument('--name', required=True)
        ns_qos_parser.add_argument('--cos', default=0, type=int,
                            help='Class of Service, 0-7')
        ns_qos_parser.add_argument('--dscpMode', default='TRUSTED',
                            choices=['TRUSTED', 'UNTRUSTED'],
                            help="DSCP code trust mode")
        ns_qos_parser.add_argument('--dscp', default=0, type=int,
                            help="DSCP value if dscpMode is UNTRUSTED, 0-63")
        ns_qos_parser.add_argument('--shapers', default=None, nargs='+',
                            choices=[None, 'IngressRateShaper',
                                     'IngressBroadcastRateShaper',
                                     'EgressRateShaper'],
                            help='If specified, enable that shaper config')
        ns_qos_parser.add_argument('--desc', default=None)
        ns_qos_parser.add_argument('--tags', default=None, nargs='+',
                                             help="TAGs list in format of 'scope:tagname'")

        ns_switchprofile_parser = ns_switchprofile.add_parser('mirror')
        ns_mirror = ns_switchprofile_parser.add_subparsers(dest='MirrorNs')
        ns_mirror_parser = ns_mirror.add_parser('config')
        ns_mirror_parser.add_argument('--name', required=True)
        ns_mirror_parser.add_argument('--dest', nargs='+', default=None,
                                      help='One or more IP address for the mirror destination')
        ns_mirror_parser.add_argument('--direction', default='BIDIRECTIONAL',
                                      choices=['BIDIRECTIONAL', 'INGRESS', 'EGRESS'],
                                      help="Port Mirror direction")
        ns_mirror_parser.add_argument('--snap', default=None, type=int,
                                      help='60-65535, truncate packet to snap lenght. \
                                      Do not specify for no truncation.')
        ns_mirror_parser.add_argument('--key', type=int, default=None,
                                      help='user configurable key?')
        ns_mirror_parser.add_argument('--desc', default=None)
        ns_mirror_parser.add_argument('--tags', default=None, nargs='+',
                                             help="TAGs list in format of 'scope:tagname'")
                                      
        ns_switchprofile_parser = ns_switchprofile.add_parser('security')
        ns_swsecurity = ns_switchprofile_parser.add_subparsers(dest='SwitchSecurityNs')
        ns_swsecurity_parser = ns_swsecurity.add_parser('config')
        ns_swsecurity_parser.add_argument('--name', required=True)
        ns_swsecurity_parser.add_argument('--bpdu', default=True, type=bool,
                                          help="Enable BPDU filtering")
        ns_swsecurity_parser.add_argument('--bpduMac', default=None, nargs='+',
                                          help='MACs excluded from BPDU filtering')
        ns_swsecurity_parser.add_argument('--blockDhcpServer', default=True,
                                          type=bool,
                                          help="Block DHCP Server")
        ns_swsecurity_parser.add_argument('--blockDhcpClient', default=False,
                                          type=bool,
                                          help="Block DHCP client")
        ns_swsecurity_parser.add_argument('--blockNonIp', default=False,
                                          type=bool,
                                          help="Block non IP/(G)ARP/BPDU traffic")
        ns_swsecurity_parser.add_argument('--rateLimit', default=False,
                                          type=bool,
                                          help="Enable rate limiting")
        ns_swsecurity_parser.add_argument('--rxbroadcast', default=0,
                                          type=int,
                                          help='Incoming broadcast pps limit, 0 means no limit')
        ns_swsecurity_parser.add_argument('--rxmulticast', default=0,
                                          type=int,
                                          help='Incoming multicast pps limit, 0 means no limit')
        
        ns_swsecurity_parser.add_argument('--txbroadcast', default=0,
                                          type=int,
                                          help='Outgoing broadcast pps limit, 0 means no limit')
        ns_swsecurity_parser.add_argument('--txmulticast', default=0,
                                          type=int,
                                          help='Outgoing multicast pps limit, 0 means no limit')
        
        ns_swsecurity_parser.add_argument('--desc', default=None)
        ns_swsecurity_parser.add_argument('--tags', default=None, nargs='+',
                                             help="TAGs list in format of 'scope:tagname'")
        
        

        
                                          
        
    if 'tn_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('list')
        ns_jq_parser = ns_sub_parsers.add_parser('jq', parents=[ng_pp])
        ns_jq_parser.add_argument('--feature', choices=['', 'state', 'status'], default='')
        ns_cfg_parser = ns_sub_parsers.add_parser('find',
                                                  help='Precedence: ID>IP>Name')
        ns_cfg_parser.add_argument('--name', required=False,
                                   help='Precedence: ID>IP>Name')
        ns_cfg_parser.add_argument('--ip', required=False)
        ns_cfg_parser.add_argument('--id', required=False)
        ns_cfg_parser = ns_sub_parsers.add_parser('state')
        ns_cfg_parser.add_argument('--name', required=False,default=None,
                                   help='Precedence: ID>IP>Name')
        ns_cfg_parser.add_argument('--id',required=False,default=None)
        ns_cfg_parser.add_argument('--ip',required=False,default=None)
        ns_cfg_parser.add_argument('--bond',required=False,default=False,
                                   action='store_true',
                                   help="Get TN pnic/bond status instead of TN state")
        ns_cfg_parser.add_argument('--detail',required=False,default=False,
                                   action='store_true')
        ns_cfg_parser.add_argument('--jq', action='store_true')

        ns_cfg_parser = ns_sub_parsers.add_parser('status')
        ns_cfg_parser.add_argument('--detail', action='store_true')
        ns_cfg_parser.add_argument('--name', help='TN name', default='*')
        ns_cfg_parser.add_argument('--jq', action='store_true')
        #ns_cfg_parser.add_argument('name', nargs='*', help='TN name')

        ns_cfg_parser = ns_sub_parsers.add_parser('delete')
        ns_cfg_parser.add_argument('--name')
        ns_cfg_parser = ns_sub_parsers.add_parser('addtz')
        ns_cfg_parser.add_argument('--node',required=True,
                help = 'TN node name')
        ns_cfg_parser.add_argument('--tz', required=True,
                help= 'Transport Zone name')
        ns_cfg_parser = ns_sub_parsers.add_parser('migrateVmk')
        ns_cfg_parser.add_argument('--node',required=True,
                help = 'TN node name')
        ns_cfg_parser.add_argument('--pg', required=True,
                                   help="Name of VSS portgroup or ID of VLAN logical switch")
        ns_cfg_parser.add_argument('--vmk', required=True,
                                   help="Name of vmknic interface")
        '''
        ns_cfg_parser = ns_sub_parsers.add_parser('lldp')
        ns_cfg_parser.add_argument('--node',
                required=True,
                help = "Name of the fabric node to set lldp setting")
        ns_cfg_parser.add_argument('--profile',
                                   required=True,
                                   help="Profile to set")
        '''

        ns_cfg_parser = ns_sub_parsers.add_parser('config')
        ns_cfg_parser.add_argument('--node',
                required=True,
                help = "Name of the fabric node")
        ns_cfg_parser.add_argument('--hswname',
                required=True,
                help = "Uplink Host switch name - should be same as in TZ")
        ns_cfg_parser.add_argument('--nics', nargs='*',
                required=True,
                help = "List of physical NIC names")
        ns_cfg_parser.add_argument('--vlansw',
                required=False,
                default=None,
                help = "VLAN hostswitch name - should assign for Edge Nodes")
        ns_cfg_parser.add_argument('--vnics', nargs='*',
                required=False,
                help = "List of physical NIC names for the vlansw")
        ns_cfg_parser.add_argument('--uplinkprofile',
                required=True,
                help = "Name of the uplink port profile")
        ns_cfg_parser.add_argument('--lldpprofile',
                default=None,
                help = "Name of the LLDP profile")
        ns_cfg_parser.add_argument('--ippool', default=None,
                help = "Name of the IP pool")
        ns_cfg_parser.add_argument('--tzname', default=None,
                help = "Name of the TransportZone if adding to TZ")

        ns_upd_parser = ns_sub_parsers.add_parser('update',
            parents = [ fbnodep, hswp, nicsp, ulprofp,
                        lldpprofp, ippoolp, srcVmk, targetNets, tzp])

    if 'node_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('list')
        ns_jq_parser = ns_sub_parsers.add_parser('jq', parents=[ng_pp])
        ns_jq_parser.add_argument('--feature', choices=['', 'state', 'status'], default='')
        ns_cfg_parser = ns_sub_parsers.add_parser('find')
        ns_cfg_parser.add_argument('target')
        ns_cfg_parser = ns_sub_parsers.add_parser('state')
        ns_cfg_parser.add_argument('--name',default=None)
        ns_cfg_parser.add_argument('--id',default=None)
        ns_cfg_parser.add_argument('--jq', action='store_true')
        ns_cfg_parser = ns_sub_parsers.add_parser('status')
        ns_cfg_parser.add_argument('--name',default=None)
        ns_cfg_parser.add_argument('--id',default=None)
        ns_cfg_parser.add_argument('--jq', action='store_true')
        ns_cfg_parser = ns_sub_parsers.add_parser('delete')
        ns_cfg_parser.add_argument('--name',default=None)
        ns_cfg_parser.add_argument('--uninstall',default=True,
                                   help="Defaults to True, uninstall VIBS")

        ns_cfg_parser = ns_sub_parsers.add_parser('prep',
                                   help="Host prep Discovered NOde")
        ns_cfg_parser.add_argument('--name', required=False, default=None,
                                   help="Name of node")
        ns_cfg_parser.add_argument('--ip', required=False, default=None,
                                   help="IP Address of node")

    if 'vm_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('list')
        ns_cfg_parser.add_argument('--brief',
                                   action='store_true')
        ns_cfg_parser = ns_sub_parsers.add_parser('find')
        ns_cfg_parser.add_argument('--name')
        ns_cfg_parser = ns_sub_parsers.add_parser('jq', parents=[ng_pp])

        ns_cfg_parser = ns_sub_parsers.add_parser('tag')
        ns_cfg_parsers = ns_cfg_parser.add_subparsers(dest='ns2')

        ns_tagAdd_parser = ns_cfg_parsers.add_parser('add', parents=[tagsSpecOP,vmnsgp])
        ns_tagSet_parser = ns_cfg_parsers.add_parser('set', parents=[tagsSpecOP,vmnsgp])
        ns_tagDel_parser = ns_cfg_parsers.add_parser('delete', parents=[tagsSpecOP,vmnsgp])
        ns_tagDel_parser = ns_cfg_parsers.add_parser('clear', parents=[vmnsgp])

        ns_vmVif_parser = ns_sub_parsers.add_parser('vifInfo', parents=[vmngp])


    if 'session_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('create')
        ns_cfg_parser.add_argument('sessCookieFile',
                                   help='file for storing session information (json)')
        ns_cfg_parser = ns_sub_parsers.add_parser('logout')
        ns_cfg_parser.add_argument('sessCookieFile',
                                   help='file for storing session information (json)')

    if 'eula_api' in cmds:
        ns_parser.add_argument('eulaOp', choices=['acceptance', 'accept', 'content'])

    if 'about_api' in cmds:
        ns_parser.add_argument('feature', nargs='?')

    if 'try_api' in cmds:
        ns_parser.add_argument('feature', nargs='?')

    if 'search_api' in cmds:
        ns_parser.add_argument('query', help=textAlign(Search.query.__doc__))
        ns_parser.formatter_class = argparse.RawTextHelpFormatter
        ns_parser.add_argument('jqFilter', default='', nargs='?',
            help='Fields to be returned in jq filter syntax')

    if 'tag_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('add',
            parents=[restTypeOP, ng1op, tagsSpecOP])
        ns_cfg_parser.add_argument('--parentid', default=None,
                                   help="Switch ID when resType is lsp")
        ns_cfg_parser.add_argument('--parentname', default=None,
                                   help="Switch name when resType is lsp" \
                                   " ID will take precedence if both are specified")
        ns_cfg_parser = ns_sub_parsers.add_parser('set',
            parents=[restTypeOP, ng1op, tagsSpecOP])
        ns_cfg_parser.add_argument('--parentid', default=None,
                                   help="Switch ID when resType is lsp")
        ns_cfg_parser.add_argument('--parentname', default=None,
                                   help="Switch name when resType is lsp" \
                                   " ID will take precedence if both are specified")
        ns_cfg_parser = ns_sub_parsers.add_parser('delete',
            parents=[restTypeOP, ng1op, tagsSpecOP])
        ns_cfg_parser.add_argument('--parentid', default=None,
                                   help="Switch ID when resType is lsp")
        ns_cfg_parser.add_argument('--parentname', default=None,
                                   help="Switch name when resType is lsp" \
                                   " ID will take precedence if both are specified")
        ns_cfg_parser = ns_sub_parsers.add_parser('clear',
            parents=[restTypeOP, ng1op])
        ns_cfg_parser.add_argument('--parentid', default=None,
                                   help="Switch ID when resType is lsp")
        ns_cfg_parser.add_argument('--parentname', default=None,
                                   help="Switch name when resType is lsp" \
                                   " ID will take precedence if both are specified")
        ns_cfg_parser = ns_sub_parsers.add_parser('list',
            parents=[restTypeOP, ng1op, tagsSpecOP])
        ns_cfg_parser = ns_sub_parsers.add_parser('jq',
            parents=[restTypeOP, ng1op, tagsSpecOP])

    if 'computeManager_api' in cmds:
        cmCfgParams = argparse.ArgumentParser(add_help=False)
        cmCfgParams.add_argument('--type', default='vCenter', choices=['vCenter'], help='manager type')
        cmCfgParams.add_argument('--username', default='admin', help='compute manager user credential')
        cmCfgParams.add_argument('--password', default='Vmware123!', help='compute manager user credential')
        cmCfgParams.add_argument('--thumbprint', default='', help='compute manager thumbprint')
        cmCfgParams.add_argument('--name', default='', help='compute manager name')
        cmCfgParams.add_argument('server')

        #'getall', 'create', 'update', 'delete', 'get', 'state', 'status'
        ns_cfg_parser = ns_sub_parsers.add_parser('list')
        ns_cfg_parser = ns_sub_parsers.add_parser('jq', parents=[ng_pp])
        ns_cfg_parser = ns_sub_parsers.add_parser('register', parents=[cmCfgParams])
        ns_cfg_parser = ns_sub_parsers.add_parser('update', parents=[cmCfgParams])
        ns_cfg_parser = ns_sub_parsers.add_parser('unregister', parents=[ng1pp])
        ns_cfg_parser.add_argument('--type', default='vCenter',
            choices=['vCenter'], help='manager type')
        ns_cfg_parser = ns_sub_parsers.add_parser('state', parents=[ng1pp])
        ns_cfg_parser = ns_sub_parsers.add_parser('status', parents=[ng1pp])

    if 'api_api' in cmds:
        ctp = argparse.ArgumentParser(add_help=False)
        ctp.add_argument('--ctype', choices=['json', 'xml'])
        aup = argparse.ArgumentParser(add_help=False)
        aup.add_argument('--accept', choices=['json', 'xml', 'ANY', '*/*'])
        aup.add_argument('--format', choices=['json', 'xml', 'yaml', 'raw', 'html'], default='raw')
        aup.add_argument('url')
        dtp = argparse.ArgumentParser(add_help=False)
        dtp.add_argument('--dataFile')
        dtp.add_argument('data', default='', nargs='?')
        urlp = argparse.ArgumentParser(add_help=False)
        urlp.add_argument('url')

        ns_get_parser = ns_sub_parsers.add_parser('get',    parents=[aup])           # get
        ns_pst_parser = ns_sub_parsers.add_parser('post',   parents=[ctp,aup,dtp])   # post
        ns_put_parser = ns_sub_parsers.add_parser('put',    parents=[ctp,aup,dtp])   # put
        ns_del_parser = ns_sub_parsers.add_parser('delete', parents=[ctp,aup,dtp])   # delete
        ns_hed_parser = ns_sub_parsers.add_parser('head',   parents=[urlp])          # head
        ns_opt_parser = ns_sub_parsers.add_parser('options',parents=[urlp])          # options


    if 'kvm_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('clone')
        ns_cfg_parser.add_argument('--prefix',
                help="VM name prefix")
        ns_cfg_parser.add_argument('--macprefix', type=int,
                help="Integer for MAC")
        ns_cfg_parser.add_argument('--vmnum', type=int,
                help="VM number, append to prefix to make name")
        ns_cfg_parser.add_argument('--dest',
                help="Destination directory to hold files")
        ns_cfg_parser.add_argument('--base',
                help="Baseline image for linked clone")
        ns_cfg_parser.add_argument('--switch', default=None,
                help = "Switch name if you want to attach the VM")
        ns_cfg_parser.add_argument('--total', type=int, default=1,
                help="Total # of clones. Will increment from vmnum.  Default 1")
        ns_cfg_parser.add_argument('--nics', type=int, default=1,
                help = "Number of NICs, default 1")


    if 'vif_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('list')
        ns_cfg_parser = ns_sub_parsers.add_parser('jq', parents=[ng_pp])


    if 'ipset_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('list')
        ns_cfg_parser = ns_sub_parsers.add_parser('jq', parents=[ng_pp])
        ns_cfg_parser = ns_sub_parsers.add_parser('find')
        ns_cfg_parser.add_argument('target')
        ns_cfg_parser = ns_sub_parsers.add_parser('delete')
        ns_cfg_parser.add_argument('target')
        ns_cfg_parser = ns_sub_parsers.add_parser('config')
        ns_cfg_parser.add_argument('--name',
                                   required=True,
                                   help="Name of IP Set")
        ns_cfg_parser.add_argument('--update', action='store_true')
        ns_cfg_parser.add_argument('--ips',
                                   required=False,
                                   default=None,
                                   nargs='+',
                                   help='List of IP addresses/ranges')
    if 'nsgroup_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('list')
        ns_cfg_parser.add_argument('--brief', action='store_true')
        ns_cfg_parser = ns_sub_parsers.add_parser('jq', parents=[ng_pp])
        ns_cfg_parser = ns_sub_parsers.add_parser('find')
        ns_cfg_parser.add_argument('target')
        ns_cfg_parser = ns_sub_parsers.add_parser('delete')
        ns_cfg_parser.add_argument('target')
        ns_cfg_parser = ns_sub_parsers.add_parser('config')
        ns_cfg_parser.add_argument('--name',
                                   required=True,
                                   help="Name of NSGroup")
        ns_cfg_parser.add_argument('--desc',
                                   required=False,
                                   default=None,
                                   help="Description of the NSGroup")
        ns_cfg_parser.add_argument('--ips',
                                   required=False,
                                   default=None,
                                   nargs='+',
                                   type=cptutil.expandArgFile,
                                   help='List of IPSet names')
        ns_cfg_parser.add_argument('--ls',
                                   required=False,
                                   default=None,
                                   nargs='+',
                                   type=cptutil.expandArgFile,
                                   help='List of LogicalSwitch names')
        ns_cfg_parser.add_argument('--nsgroups',
                                   required=False,
                                   default=None,
                                   nargs='+',
                                   type=cptutil.expandArgFile,
                                   help='List of NSGroup names')
        ns_cfg_parser.add_argument('--lp',
                                   required=False,
                                   default=None,
                                   nargs='+',
                                   type=cptutil.expandArgFile,
                                   help='List of LogicalPort names')
        ns_cfg_parser.add_argument('--vmcontain',
                                   required=False,
                                   default=None,
                                   nargs='+',
                                   type=cptutil.expandArgFile,
                                   help='List of VM names to be used with CONTAINS')
        ns_cfg_parser.add_argument('--vmequal',
                                   required=False,
                                   default=None,
                                   nargs='+',
                                   type=cptutil.expandArgFile,
                                   help='List of VM names to be used with EQUAL')
        ns_cfg_parser.add_argument('--vmstart',
                                   required=False,
                                   default=None,
                                   nargs='+',
                                   type=cptutil.expandArgFile,
                                   help='List of VM names to be used with STARTSWITH')
        ns_cfg_parser.add_argument('--lstag',
                                   required=False,
                                   default=None,
                                   nargs='+',
                                   type=cptutil.expandArgFile,
                                   help='List of LogicalSwitch Tags or scope:tag')
        ns_cfg_parser.add_argument('--lptag',
                                   required=False,
                                   default=None,
                                   nargs='+',
                                   type=cptutil.expandArgFile,
                                   help='List of LogicalPort Tags or scope:tag')
        ns_cfg_parser.add_argument('--vmtag',
                                   required=False,
                                   default=None,
                                   nargs='+',
                                   type=cptutil.expandArgFile,
                                   help='List of VM tags or scope:tag')
        ns_cfg_parser.add_argument('--update', action='store_true')
                                   
        
        ns_parser = ns_sub_parsers.add_parser('member')
        ns_parser.add_argument('memberType', choices=['vm', 'ip', 'ls', 'lp', 'type', 'ip-vm'],
                                   help='List effective members of type VM, IP, Logical Switche, Logical Port or types')
        ns_parser.add_argument('namesGlob', nargs='+', help='nsgroup names (glob)')
        ns_parser = ns_sub_parsers.add_parser('create')
        ns_parser.add_argument('nsgSpec', type=expandArgFile, help='NSGroup spec or @nsgroupSepcFile')



    if 'principal_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('list')
        ns_cfg_parser = ns_sub_parsers.add_parser('jq', parents=[ng_pp])
        ns_cfg_parser = ns_sub_parsers.add_parser('create', help='Create principal, associate it with a cert')
        ns_cfg_parser.add_argument('--desc')
        ns_cfg_parser.add_argument('--certId', required=True, help='Certificate ID')
        ns_cfg_parser.add_argument('--permission', default='read_write_api_users',
            choices=['read_write_api_users'],
            help='permission group')
        ns_cfg_parser.add_argument('--role', default='enterprise_admin',
            choices=['read_only_api_users', 'enterprise_admin'])
        ns_cfg_parser.add_argument('--name', help='pricipal name in name@node format')
        ns_cfg_parser = ns_sub_parsers.add_parser('delete', parents=[ng1pp])
        ns_cfg_parser.add_argument('--id', help='principal id')

    if 'cert_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('list', parents=[ng_pp])
        ns_cfg_parser.add_argument('--brief',
                                   required=False,
                                   action='store_true',
                                   help = "Brief display")
        ns_cfg_parser = ns_sub_parsers.add_parser('jq', parents=[ng_pp])
        ns_cfg_parser = ns_sub_parsers.add_parser('find')
        ns_cfg_parser.add_argument('--brief',
                                   required=False,
                                   action='store_true',
                                   help = "Brief display")
        ns_cfg_parser.add_argument('target')
        ns_cfg_parser = ns_sub_parsers.add_parser('applyhttp')
        ns_cfg_parser.add_argument('--name',
                                   required=True,
                                   help = "Name of the certificate to apply to MP http")

        ns_cfg_parser = ns_sub_parsers.add_parser('delete')
        ns_cfg_parser.add_argument('--name',
                                   required=False,
                                   default=None,
                                   help = "Name of the certificate to delete,name or id must be specified")
        ns_cfg_parser.add_argument('--id',
                                   required=False,
                                   default=None,
                                   help = "id of the certificate to delete,name or id must be specified")

        ns_cfg_parser = ns_sub_parsers.add_parser('import')
        ns_cfg_parser.add_argument('--name',
                                   required=True,
                                   help="Name of the certificate")
        ns_cfg_parser.add_argument('--certificate',
                                   required=True,
                                   help="PEM Encoded certificate file")
        ns_cfg_parser.add_argument('--key',
                                   required=False,
                                   default=None,
                                   help="PEM encoded private key file")
        ns_cfg_parser.add_argument('--passphrase',
                                   required=False,
                                   default=None,
                                   help="Passphrase for the certificate")
        ns_cfg_parser.add_argument('--description',
                                   required=False,
                                   default=None,
                                   help="Description for the certificate")

    if 'excludelist_api' in cmds:
        restTypeOP = argparse.ArgumentParser(add_help=False)
        restTypeOP.add_argument('--targetType', default='NSGroup',
            choices=['NSGroup', 'LogicalSwitch', 'LogicalPort'], help='Target Type')
        ns_cfg_parser = ns_sub_parsers.add_parser('list',   parents=[restTypeOP, ng_pp])
        ns_cfg_parser = ns_sub_parsers.add_parser('jq',     parents=[restTypeOP, ng_pp])
        ns_cfg_parser = ns_sub_parsers.add_parser('add',    parents=[restTypeOP, npp])
        ns_cfg_parser = ns_sub_parsers.add_parser('remove', parents=[restTypeOP, ngpp])
        ns_cfg_parser = ns_sub_parsers.add_parser('check',  parents=[restTypeOP, ngpp])


    if 'fw_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('services')
        ns_fwservices_subparser=ns_cfg_parser.add_subparsers(dest="fwservice")
        ns_fwservices_parser = ns_fwservices_subparser.add_parser('list')
        ns_fwservices_parser.add_argument('--brief',required=False,
                                          action='store_true')

        ns_fwservices_parser = ns_fwservices_subparser.add_parser('find')
        ns_fwservices_parser.add_argument('--name',required=False)
        ns_fwservices_parser.add_argument('--id',required=False)

        ns_cfg_parser = ns_sub_parsers.add_parser('section')
        ns_fwsection_subparser=ns_cfg_parser.add_subparsers(dest="fwsection")
        ns_fwsection_parser = ns_fwsection_subparser.add_parser('find')
        ns_fwsection_parser.add_argument('--name',required=True)
        ns_fwsection_parser.add_argument('--type',
                                         choices=['LAYER2','LAYER3'],
                                         default='LAYER3',
                                         help='FW section type: LAYER2 or LAYER3 (default)')
        ns_fwsection_parser = ns_fwsection_subparser.add_parser('list')
        ns_fwsection_parser.add_argument('--type',
                                         choices=['LAYER2','LAYER3'],
                                         default='LAYER3',
                                         help='FW section type: LAYER2 or LAYER3 (default)')
        ns_fwsection_parser.add_argument('--brief',
                                   required=False,
                                   action='store_true',
                                   help = "Brief display")
        ns_fwsection_parser = ns_fwsection_subparser.add_parser('jq')
        ns_fwsection_parser = ns_fwsection_subparser.add_parser('delete')
        ns_fwsection_parser.add_argument('--name',required=True)
        ns_fwsection_parser.add_argument('--type',
                                         choices=['LAYER2','LAYER3'],
                                         default='LAYER3',
                                         help='FW section type: LAYER2 or LAYER3 (default)')
        
        ns_fwsection_parser = ns_fwsection_subparser.add_parser('add')
        ns_fwsection_parser.add_argument('--name',required=True)
        ns_fwsection_parser.add_argument('--desc',default=None)
        ns_fwsection_parser.add_argument('--type',
                                         choices=['LAYER2','LAYER3'],
                                         default='LAYER3',
                                         help='FW section type: LAYER2 or LAYER3 (default)')
        ns_fwsection_parser.add_argument('--op',
                                         default='insert_top',
                                         choices=['insert_top',
                                                  'insert_bottom',
                                                  'insert_before',
                                                  'insert_after'],
                                         help="Where to insert,default is top")
        ns_fwsection_parser.add_argument('--opsection',
                                         default=None,
                                         help="Name of section when using insert before/after")
        ns_fwsection_parser.add_argument('--stateful',
                                         action='store_false',
                                         help="Specifiy for non-stateful,default is stateful")
        ns_fwsection_parser.add_argument('--tags',
                                         default=None,
                                         nargs='+',
                                         help="List of tag names to apply")
        ns_fwsection_parser.add_argument('--update',
                                         action='store_true',
                                         help="Update existing section with same name if exists")

        ns_fwsection_parser = ns_fwsection_subparser.add_parser('apply',
                                                                help='Apply-to operations')

        ns_applyto_subparser=ns_fwsection_parser.add_subparsers(dest='applyto')
        ns_applyto_parser = ns_applyto_subparser.add_parser('add')
        ns_applyto_parser.add_argument('--name', required=True,
                                       help="Name of the section")
        ns_applyto_parser.add_argument('--target', required=True,
                                       help="Name of the target")
        ns_applyto_parser.add_argument('--type', required=True,
                                       choices=['NSGroup',
                                                'LogicalSwitch',
                                                'LogicalPort'],
                                       help="Resource Type of target")

        ns_applyto_parser.add_argument('--fwtype',
                                         choices=['LAYER2','LAYER3'],
                                         default='LAYER3',
                                         help='FW section type: LAYER2 or LAYER3 (default)')
        ns_applyto_parser = ns_applyto_subparser.add_parser('delete')
        ns_applyto_parser.add_argument('--name', required=True,
                                       help="Name of the section")
        ns_applyto_parser.add_argument('--all', required=False,
                                       action='store_true',
                                       help="Remove all applied to if specified")
        ns_applyto_parser.add_argument('--target',
                                       help="Name of the target")
        ns_applyto_parser.add_argument('--type',
                                       choices=['NSGroup',
                                                'LogicalSwitch',
                                                'LogicalPort'],
                                       help="Resource Type of target")
        ns_applyto_parser.add_argument('--fwtype',
                                         choices=['LAYER2','LAYER3'],
                                         default='LAYER3',
                                         help='FW section type: LAYER2 or LAYER3 (default)')

        ns_fwsection_parser = ns_fwsection_subparser.add_parser("rule")
        ns_fwrule_subparser = ns_fwsection_parser.add_subparsers(dest="dfwrules")
        ns_fwrule_parser = ns_fwrule_subparser.add_parser('list')
        ns_fwrule_parser.add_argument('--section',
                                      required=True,
                                      help='Name of the section')
        ns_fwrule_parser.add_argument('--brief',
                                   required=False,
                                   action='store_true',
                                   help = "Brief display")
        ns_fwrule_parser = ns_fwrule_subparser.add_parser('delete')
        ns_fwrule_parser.add_argument('--section',
                                      required=True,
                                      help='Name of the section')
        ns_fwrule_parser.add_argument('--type',
                                      choices=['LAYER2','LAYER3'],
                                      default='LAYER3',
                                      help="Default LAYER3")
        ns_fwrule_parser.add_argument('--name',
                                      default=None,
                                      help="Name of the rule, id takes priority")
        ns_fwrule_parser.add_argument('--id',
                                      default=None,
                                      help="ID of the rule in the section")
        ns_fwrule_parser = ns_fwrule_subparser.add_parser('addsrcdst')
        ns_fwrule_parser.add_argument('--section',
                                     required=True,
                                     help="Name of the section")
        ns_fwrule_parser.add_argument('--id',
                                      required=True,
                                      help="Rule ID")
        ns_fwrule_parser.add_argument('--sources',
                                      default=None,
                                      nargs='*',
                                      help="Sources.  Format: list of type:value:exclude \
                                      Default: None which translates to Any. \
                                      Value can be comma seperated list of same type")
        ns_fwrule_parser.add_argument('--destinations',
                                      default=None,
                                      nargs='*',
                                      help="Destinations.  Format: list of type:value:exclude \
                                      Default: None which translates to Any.\
                                      Value can be comma seperated list of same type")
        ns_fwrule_parser.add_argument('--type',
                                      default='LAYER3',
                                      choices=['LAYER2','LAYER3'],
                                      help='Rule type. Default is LAYER3')

        ns_fwrule_parser = ns_fwrule_subparser.add_parser('addservice')
        ns_fwrule_parser.add_argument('--services',
                                      required=True,
                                      nargs='*',
                                      help="List of service names")
        ns_fwrule_parser.add_argument('--type',
                                      default='LAYER3',
                                      choices=['LAYER2','LAYER3'],
                                      help='Rule type. Default is LAYER3')

        ns_fwrule_parser = ns_fwrule_subparser.add_parser('add')
        ns_fwrule_parser.add_argument('--section',
                                      required=True,
                                      help='Name of the section')
        ns_fwrule_parser.add_argument('--name',
                                      default=None,
                                      help='Name of the rule')
        ns_fwrule_parser.add_argument('--description',
                                      default=None,
                                      help='Description of the rule')

        ns_fwrule_parser.add_argument('--direction',
                                      choices=["IN","OUT","IN_OUT"],
                                      default="IN_OUT",
                                      help='Direction of the rule, default IN_OUT')
        ns_fwrule_parser.add_argument('--protocol',
                                      choices=["IPV4","IPV6","IPV4_IPV6"],
                                      default="IPV4",
                                      help="IP version, default IPV4")
        ns_fwrule_parser.add_argument('--sources',
                                      default=None,
                                      nargs='*',
                                      help="Sources.  Format: list of type:value:exclude \
                                      Default: None which translates to Any. \
                                      Value can be comma seperated list of same type. \
                                      Exclude is a boolean of true/false.  Second colon \
                                      must not be specified if exclude is not required.\
                                      Supported Resource Types: IPv4Address, IPSet, \
                                      LogicalPOrt, LogicalSwitch, NSGroup")
        ns_fwrule_parser.add_argument('--destinations',
                                      default=None,
                                      nargs='*',
                                      help="Destinations.  Format: list of type:value:exclude \
                                      Default: None which translates to Any.\
                                      Value can be comma seperated list of same type")
        ns_fwrule_parser.add_argument('--services',
                                      default=None,
                                      nargs='*',
                                      help="List of service names")
        ns_fwrule_parser.add_argument('--log',required=False,
                                       choices=['True','False'],
                                       #action='store_true',
                                       help="Enable log?  Default=False")
        ns_fwrule_parser.add_argument('--insert',
                                      default='insert_top',
                                      choices=['insert_top',
                                               'insert_bottom',
                                               'insert_before',
                                               'insert_after'],

                                      help='Where to insert.  Defalt is insert_top.\
                                      If before/after, must specified id with reference')
        ns_fwrule_parser.add_argument('--reference',
                                      default=None,
                                      help='Rule ID when specifying insert_before/after')
        ns_fwrule_parser.add_argument('--action',
                                      required=True,
                                      choices=['ALLOW','DROP','REJECT'])
        ns_fwrule_parser.add_argument('--type',
                                      default='LAYER3',
                                      choices=['LAYER2','LAYER3'],
                                      help='Rule type. Default is LAYER3')
        ns_fwrule_parser.add_argument('--update',
                                   required=False,
                                   action='store_true',
                                   help = "Update existing rule by name, if it exist")
        ns_fwrule_parser.add_argument('--dupcheck',
                                   required=False,
                                   action='store_true',
                                   help = "If set, will quit if exiting rule with name exist unless --update is set")
        


    if 'syslog_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('props')
        ns_cfg_parser = ns_sub_parsers.add_parser('list')
        ns_cfg_parser = ns_sub_parsers.add_parser('find')
        ns_cfg_parser.add_argument('target')
        ns_cfg_parser = ns_sub_parsers.add_parser('delete')
        ns_cfg_parser.add_argument('target')
        ns_cfg_parser = ns_sub_parsers.add_parser('status')
        ns_cfg_parser = ns_sub_parsers.add_parser('config')
        ns_cfg_parser.add_argument('--name',
                                   required=True,
                                   help="Name of Syslog Exporter")
        ns_cfg_parser.add_argument('--server',
                                   required=True,
                                   help="Syslog server")
        ns_cfg_parser.add_argument('--level',
                                   choices=['EMERG','ALERT','CRIT','ERR',
                                            'WARNING','NOTICE','INFO',
                                            'DEBUG'],
                                   default='NOTICE',
                                   help="Syslog severity level")
        ns_cfg_parser.add_argument('--facility',
                                   nargs="+",
                                   default=None,
                                   choices=['KERN','USER','MAIL','DAEMON',
                                            'AUTH','SYSLOG','LPR','NEWS',
                                            'UUCP','AUTHPRIV','FTP',
                                            'LOGALERT','CRON','LOCAL0',
                                            'LOCAL1','LOCAL2','LOCAL3',
                                            'LOCAL4','LOCAL5','LOCAL6',
                                            'LOCAL7'],
                                   help="Syslog facility, default is LOCAL0")
        ns_cfg_parser.add_argument('--protocol',
                                   default='UDP',
                                   choices=['UDP','TCP','TLS'],
                                   help='Exporter protocol')
        ns_cfg_parser.add_argument('--port',
                                   type=int,
                                   default=514,
                                   help="Syslog server port, default 514")
        ns_cfg_parser.add_argument('--cert',
                                   required=False,
                                   help="Certificate of server, if protocol TLS")

    if 'lb_api' in cmds:
        # LB Service
        ns_cfg_parser = ns_sub_parsers.add_parser('service')
        ns_lbservicens_parser = ns_cfg_parser.add_subparsers(dest='lbservice')

        ns_lbservice_parser = ns_lbservicens_parser.add_parser('list')

        ns_lbservice_parser = ns_lbservicens_parser.add_parser('jq', parents=[ng_pp])
        ns_lbservice_parser=ns_lbservicens_parser.add_parser('create')
        ns_lbservice_parser.add_argument('--name',required=True)
        ns_lbservice_parser.add_argument('--desc', default=None,
                                   help='Description of LB Service')
        ns_lbservice_parser.add_argument('--size', default="SMALL",
                                   choices=['SMALL', 'MEDIUM', 'LARGE'])
        ns_lbservice_parser.add_argument('--log', default="INFO",
                                   choices=["DEBUG", "INFO", "WARNING",
                                            "ERROR", "CRITICAL", "ALERT",
                                            "EMERGENCY"])
        ns_lbservice_parser = ns_lbservicens_parser.add_parser('attach')
        ns_lbservice_parser.add_argument('--action', required=True, choices=['add','del'],
                                      help='del or add attachment')
        ns_lbservice_parser.add_argument('--lbname', required=True, help='LB service name')
        ns_lbservice_parser.add_argument('--lr', default=None,
                                         help="Name of LR to attach, required for action add")

        ns_lbservice_parser = ns_lbservicens_parser.add_parser('vipattach')
        ns_lbservice_parser.add_argument('--action', required=True, choices=['add','del'],
                                      help='del or add VIP attachment')
        ns_lbservice_parser.add_argument('--lbname', required=True, help='LB service name')
        ns_lbservice_parser.add_argument('--vip', default=None, nargs='+',
                                         help="List of of VIPs to attach")



        # LB Pool
        ns_cfg_parser = ns_sub_parsers.add_parser('pool')
        ns_lbpool = ns_cfg_parser.add_subparsers(dest='lbpool')
        ns_lbpool_parser = ns_lbpool.add_parser('list')
        ns_lbpool_parser = ns_lbpool.add_parser('jq', parents=[ng_pp])
        ns_lbpool_parser = ns_lbpool.add_parser('create')
        ns_lbpool_parser.add_argument('--name', required=True)
        ns_lbpool_parser.add_argument('--desc', default=None)
        ns_lbpool_parser.add_argument('--algorithm', default="ROUND_ROBIN",
                                      choices=['ROUND_ROBIN', 'WEIGHTED_ROUND_ROBIN',
                                           'LEAST_CONNECTION', 'WEIGHTED_LEAST_CONNECTION',
                                           'IP_HASH'])
        ns_lbpool_parser.add_argument('--minMem', default=1,
                                      help='Minimum number of members, default=1')
        ns_lbpool_parser.add_argument('--multiplex', action='store_true',
                                     help='Enable TCP multiplex, default=False')
        ns_lbpool_parser.add_argument('--multicount', default=6,
                                      help='# of connections for multiplexing, default=6')
        ns_lbpool_parser.add_argument('--nat', default=None,
                                      choices=[None, 'LbSnatAutoMap','LbSnatIpPool'],
                                      help="SNAT type: none=transparent")
        ns_lbpool_parser.add_argument('--overload', default=1, choices=[1,2,4,8,16,32],
                                      help='Default is 1')
        ns_lbpool_parser.add_argument('--addr', nargs='+',
        help='One or more address or range, format: single ip, range of ip with seperator -, or CIDR')

        ns_lbpool_parser = ns_lbpool.add_parser('member')
        ns_lbpool_parser.add_argument('--pool', required=True,
                                      help="Pool name")
        ns_lbpool_parser.add_argument('--action', required=True, choices=['add','del'],
                                      help='del or add')
        ns_lbpool_parser.add_argument('--ip', nargs='+', required=True,
                                      help="IP Address of the member")
        ns_lbpool_parser.add_argument('--name', required=False, nargs='+',
                                      help="Name of the IP, defaults to IP.  If supplied, must match # of IPs specified")
        ns_lbpool_parser.add_argument('--disable', required=False,
                                      action='store_false', help="Disable state?")
        ns_lbpool_parser.add_argument('--backup', required=False,
                                      action='store_true', help='Backups?')
        ns_lbpool_parser.add_argument('--maxcon', required=False, default=None, type=int,
                                      help='Max connections: 1-255, default=unlimited')
        ns_lbpool_parser.add_argument('--port', required=False, default=None,
                                      help="Port to use, default is to use client connect port")
        ns_lbpool_parser.add_argument('--weight', required=False, type=int, default=1,
                                      help='Weight when used in respective weighted hashes, default is 1. Range 1-2555')

        ns_lbpool_parser = ns_lbpool.add_parser('group', help='Dynamic membership')
        ns_lbpool_parser.add_argument('--pool', required=True,
                                      help='Pool Name')
        ns_lbpool_parser.add_argument('--action', required=True, choices=['add','del'],
                                      help='del or add')
        ns_lbpool_parser.add_argument('--nsgroup', default=None,
                                      help='Name of nsgroup')
        ns_lbpool_parser.add_argument('--ipfilter', default='IPV4',
                                      choices=['IPV4','IPV6','IPV4_IPV6'])
        ns_lbpool_parser.add_argument('--port', required=False, default=None,
                                      help="Port to use, default is to use client connect port")

        ns_lbpool_parser = ns_lbpool.add_parser('monitor',
                                                help="Update health monitor")
        ns_lbpool_parser.add_argument('--pool', required=True,
                                      help='Pool Name')
        ns_lbpool_parser.add_argument('--action', required=True, choices=['add','del'],
                                      help='del or add. Delete deletes all')
        ns_lbpool_parser.add_argument('--active', nargs='+', default=None,
                                      help="Names of active monitors. Specify 'true' to delete all")
        ns_lbpool_parser.add_argument('--passive', default=None,
                                      help="Name of passive monitor.  Specify true to delete")
        # LB Monitor
        ns_cfg_parser = ns_sub_parsers.add_parser('monitor')
        ns_lbmon = ns_cfg_parser.add_subparsers(dest='lbmonitor')
        ns_lbmon_parser = ns_lbmon.add_parser('list')
        ns_lbmon_parser = ns_lbmon.add_parser('jq', parents=[ng_pp])
        ns_lbmon_parser = ns_lbmon.add_parser('create')
        ns_lbmon_cfg = ns_lbmon_parser.add_subparsers(dest='lbmoncreate')
        lbmon_cfg_parser = ns_lbmon_cfg.add_parser('icmp')
        lbmon_cfg_parser.add_argument('--name')
        lbmon_cfg_parser.add_argument('--fall', type=int, default=3,
                       help='number of consecutive checks must fail to mark down')
        lbmon_cfg_parser.add_argument('--rise', type=int, default=3,
                       help='number of consecutive checks must succed to mark up')
        lbmon_cfg_parser.add_argument('--interval', type=int, default=5,
                       help='Monitor check frequency, in seconds')
        lbmon_cfg_parser.add_argument('--desc', required=False, default=None,
                       help='Description of this monitor')


                                      
        lbmon_cfg_parser = ns_lbmon_cfg.add_parser('tcp')
        lbmon_cfg_parser.add_argument('--name')
        lbmon_cfg_parser.add_argument('--fall', type=int, default=3,
                       help='number of consecutive checks must fail to mark down')
        lbmon_cfg_parser.add_argument('--rise', type=int, default=3,
                       help='number of consecutive checks must succed to mark up')
        lbmon_cfg_parser.add_argument('--interval', type=int, default=5,
                       help='Monitor check frequency, in seconds')
        lbmon_cfg_parser.add_argument('--timeout', type=int, default=15,
                       help='Number of seconds to wait for reply')
        lbmon_cfg_parser.add_argument('--port', required=False, default=None,
                       help='Port or port range, override pool membe port if provided')
        lbmon_cfg_parser.add_argument('--receive', required=False, default=None,
                       help='If provided, string in response body to match')
        lbmon_cfg_parser.add_argument('--send', required=False, default=None,
                       help='If provided, string to send after TCP establish')
        lbmon_cfg_parser.add_argument('--desc', required=False, default=None,
                       help='Description of this monitor')

        
        lbmon_cfg_parser = ns_lbmon_cfg.add_parser('passive')
        lbmon_cfg_parser.add_argument('--name')
        lbmon_cfg_parser.add_argument('--fails', type=int, default=5,
                       help='Max fails')
        lbmon_cfg_parser.add_argument('--timeout', type=int, default=5,
                       help='Timeout in seconds to make member availalbe after failed')
        lbmon_cfg_parser.add_argument('--desc', required=False, default=None,
                       help='Description of this monitor')
        
        
        lbmon_cfg_parser = ns_lbmon_cfg.add_parser('http')
        lbmon_cfg_parser.add_argument('--name')
        lbmon_cfg_parser.add_argument('--fall', type=int, default=3,
                       help='number of consecutive checks must fail to mark down')
        lbmon_cfg_parser.add_argument('--rise', type=int, default=3,
                       help='number of consecutive checks must succed to mark up')
        lbmon_cfg_parser.add_argument('--interval', type=int, default=5,
                       help='Monitor check frequency, in seconds')
        lbmon_cfg_parser.add_argument('--timeout', type=int, default=15,
                       help='Number of seconds to wait for reply')
        lbmon_cfg_parser.add_argument('--port', type=int, default=None,
                       help='Port, override pool membe port if provided')
        lbmon_cfg_parser.add_argument('--body', required=False, default=None,
                       help='Request body to send for methods like POST')
        lbmon_cfg_parser.add_argument('--headername', nargs='+', required=False,
                       help="List of HTTP request Header names")
        lbmon_cfg_parser.add_argument('--headervalue', nargs='+', required=False,
                       help="List of HTTP reqeust header values")
        lbmon_cfg_parser.add_argument('--method', required=False, default="GET",
                                      choices=['GET', 'OPTIONS',
                                               'POST', 'HEAD', 'PUT'],
                       help="HTTP Request Method")
        lbmon_cfg_parser.add_argument('--url', default=None, required=False,
                       help="URL to use, if provided")
        lbmon_cfg_parser.add_argument('--version', required=False,
                                      default='HTTP_VERSION_1_1',
                                      choices=['HTTP_VERSION_1_0',
                                               'HTTP_VERSION_1_1',
                                               'HTTP_VERSION_2_0'],
                       help="HTTP Request version")
        lbmon_cfg_parser.add_argument('--responsebody', default=None, required=False,
                       help="String in response body to match, if provided")
        lbmon_cfg_parser.add_argument('--responsecode', type=int, nargs='+',
                                      required=True,
                       help="List of HTTP response code to accept as good status")
        lbmon_cfg_parser.add_argument('--desc', required=False, default=None,
                       help='Description of this monitor')

        
        lbmon_cfg_parser = ns_lbmon_cfg.add_parser('https')
        lbmon_cfg_parser.add_argument('--name')
        lbmon_cfg_parser.add_argument('--fall', type=int, default=3,
                       help='number of consecutive checks must fail to mark down')
        lbmon_cfg_parser.add_argument('--rise', type=int, default=3,
                       help='number of consecutive checks must succed to mark up')
        lbmon_cfg_parser.add_argument('--interval', type=int, default=5,
                       help='Monitor check frequency, in seconds')
        lbmon_cfg_parser.add_argument('--timeout', type=int, default=15,
                       help='Number of seconds to wait for reply')
        lbmon_cfg_parser.add_argument('--port', type=int, default=None,
                       help='Port, override pool membe port if provided')
        lbmon_cfg_parser.add_argument('--body', required=False, default=None,
                       help='Request body to send for methods like POST')
        lbmon_cfg_parser.add_argument('--headername', nargs='+', required=False,
                       help="List of HTTP request Header names")
        lbmon_cfg_parser.add_argument('--headervalue', nargs='+', required=False,
                       help="List of HTTP reqeust header values")
        lbmon_cfg_parser.add_argument('--method', required=False, default="GET",
                                      choices=['GET', 'OPTIONS',
                                               'POST', 'HEAD', 'PUT'],
                       help="HTTP Request Method")
        lbmon_cfg_parser.add_argument('--url', default=None, required=False,
                       help="URL to use, if provided")
        lbmon_cfg_parser.add_argument('--version', required=False,
                                      default='HTTP_VERSION_1_1',
                                      choices=['HTTP_VERSION_1_0',
                                               'HTTP_VERSION_1_1',
                                               'HTTP_VERSION_2_0'],
                       help="HTTP Request version")
        lbmon_cfg_parser.add_argument('--responsebody', default=None, required=False,
                       help="String in response body to match, if provided")
        lbmon_cfg_parser.add_argument('--responsecode', type=int, nargs='+',
                                      required=True,
                       help="List of HTTP response code to accept as good status")

        allCiphers = ['TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256',
                      'TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384',
                      'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA',
                      'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA',
                      'TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA',
                      'TLS_ECDH_RSA_WITH_AES_256_CBC_SHA',
                      'TLS_RSA_WITH_AES_256_CBC_SHA',
                      'TLS_RSA_WITH_AES_128_CBC_SHA',
                      'TLS_RSA_WITH_3DES_EDE_CBC_SHA',
                      'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA',
                      'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256',
                      'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384',
                      'TLS_RSA_WITH_AES_128_CBC_SHA256',
                      'TLS_RSA_WITH_AES_128_GCM_SHA256',
                      'TLS_RSA_WITH_AES_256_CBC_SHA256',
                      'TLS_RSA_WITH_AES_256_GCM_SHA384',
                      'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA',
                      'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256',
                      'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256',
                      'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384',
                      'TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384',
                      'TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA',
                      'TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256',
                      'TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256',
                      'TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384',
                      'TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384',
                      'TLS_ECDH_RSA_WITH_AES_128_CBC_SHA',
                      'TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256',
                      'TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256',
                      'TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384',
                      'TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384']
        lbmon_cfg_parser.add_argument('--ciphers', nargs='+',
                                      default=allCiphers,
                                      choices=allCiphers,
                       help="Support list of ciphers to servers")
                                      
        lbmon_cfg_parser.add_argument('--clientcert', default=None,required=False,
                       help="Client verification cert, if provided")
                                      
        lbmon_cfg_parser.add_argument('--certdepth', default=3,
                       help="Certificate depth traversal")
        lbmon_cfg_parser.add_argument('--serverauth', default="IGNORE",
                                      choices=['IGNORE','REQUIRED'],
                       help="Server authentication mode")
        lbmon_cfg_parser.add_argument('--ca', default=None, nargs='+',
                       help="List of CA Certificates")
        lbmon_cfg_parser.add_argument('--crl', default=None, nargs='+',
                       help="List of CRL, must use IDs from NSX")
        lbmon_cfg_parser.add_argument('--protocols', nargs='+',
                                      default=['TLS_V1_1', 'TLS_V1_2'],
                                      choices=['TLS_V1_1', 'TLS_V1_2',
                                               'TLS_V1', 'SSL_V3',
                                               'SSL_V2'],
                       help="List of support SSL protocols to servers")
        
        
        lbmon_cfg_parser.add_argument('--desc', required=False, default=None,
                       help='Description of this monitor')

        
        

        

        # LB VIP - no support for server side yet SSL yet
        ns_cfg_parser = ns_sub_parsers.add_parser('vip')
        ns_lbvip = ns_cfg_parser.add_subparsers(dest='lbvip')
        ns_lbvip_parser = ns_lbvip.add_parser('list')
        ns_lbvip_parser = ns_lbvip.add_parser('jq', parents=[ng_pp])
        ns_lbvip_parser = ns_lbvip.add_parser('config')
        ns_lbvip_parser.add_argument('--name', required=True)
        ns_lbvip_parser.add_argument('--appProfile', 
                                     default="nsx-default-lb-fast-tcp-profile",
                                     help="Application profile determines L4 or L7 LB.\n"
                                     "Prebuilt choices are: \n"
                                     " nsx-default-lb-fast-tcp-profile (*default)\n"
                                     " nsx_default-lb-fast-udp-profile\n"
                                     " nsx_default-lb-http-profile")
        ns_lbvip_parser.add_argument('--vip', required=True,
                                     help="LB VIP IP Address")
        ns_lbvip_parser.add_argument('--ports', nargs='+', required=True, default=None,
                                     help='Up to 14 ports or ort ranges for the VIP')
        ns_lbvip_parser.add_argument('--pool', required=False,default=None,
                                     help="Name of server pool to use")
        ns_lbvip_parser.add_argument('--maxConcurrent', default=None, type=int,
                                     required=False,
                                     help="If specified, Max concurrent connections."
                                     "Unlimited when not specified")
        ns_lbvip_parser.add_argument('--maxNewConnRate', default=None, type=int,
                                     required=False,
                                     help="Max new connection rate "
                                     "Unlimited when not specified")
        ns_lbvip_parser.add_argument('--desc', default=None,
                                     help="Description")
        ns_lbvip_parser.add_argument('--persistenceProfile', default=None,
                                     required=False,
                                     help="Persistence Profile.  Built in profiles are "
                                     "nsx-default-cookie-persistence-profile "
                                     "nsx-default-source-ip-persistence-profile. "
                                     "Use source-ip for L4 LB")
        ns_lbvip_parser.add_argument('--clientSslProfile', default=None,
                                     required=False,
                                     help="Client SSL Profile when terminating L7"
                                     "Built in: nsx-default-client-ssl-profile")
        ns_lbvip_parser.add_argument('--sslCert', default=None,
                                     required=False,
                                     help="Name of SSL Certificate when terminating L7")
        ns_lbvip_parser.add_argument('--sniCerts', default=None, nargs='+',
                                     required=False,
                                     help="List of SNI certificates when terminating multiple names")
        ns_lbvip_parser.add_argument('--tags', default=None, nargs='+')
        
        # add support for client authentication
        # add support for Server side SSL
        
                                     


    if 'ipam_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('list')
        ns_cfg_parser = ns_sub_parsers.add_parser('config')
        ns_cfg_parser.add_argument('--name',
                                   required=True,
                                   help="Name of of IPAM")
        ns_cfg_parser.add_argument('--desc',
                                   required=False,
                                   default=None,
                                   help="Description")
        ns_cfg_parser.add_argument('--cidr',
                                   required=True,
                                   help="CIDR for the IPAM")
        ns_cfg_parser.add_argument('--tags',
                                   required=False,
                                   default=None,
                                   nargs='+',
                                   help="Space seperated list of tags in format of 'scope:tagname''")
                                   
        

    if 'global_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('list')
        ns_cfg_parser = ns_sub_parsers.add_parser('jq')

    if 'vidm_api' in cmds:
        ns_cfg_parser = ns_sub_parsers.add_parser('list')
        ns_cfg_parser = ns_sub_parsers.add_parser('jq')

    if 'policy_api' in cmds:
        dom_op = argparse.ArgumentParser(add_help=False)
        dom_op.add_argument('--domain', help='domain name')
        dom_orp = argparse.ArgumentParser(add_help=False)
        dom_orp.add_argument('--domain', required=True, help='domain name')
        cat_orp = argparse.ArgumentParser(add_help=False)
        cat_orp.add_argument('--category', required=True,
            choices=['application', 'emergency', 'environment', 'infrastructure', 'ethernet'])
        namep = argparse.ArgumentParser(add_help=False)
        namep.add_argument('name')
        nameGlobp = argparse.ArgumentParser(add_help=False)
        nameGlobp.add_argument('nameGlob')


        ''' policy enforcementpoint '''
        ns_ep_parser = ns_sub_parsers.add_parser('enforcementpoint')
        ns_ep_parsers = ns_ep_parser.add_subparsers(dest="ns2")
        ns_epLst_parser = ns_ep_parsers.add_parser('list', parents=[ng_pp])
        ns_epJq_parser = ns_ep_parsers.add_parser('jq', parents=[ng_pp])

        ns_dom_parser = ns_sub_parsers.add_parser('service')
        ns_dom_parsers = ns_dom_parser.add_subparsers(dest="ns2")
        ns_domLst_parser = ns_dom_parsers.add_parser('list', parents=[ng_pp])
        ns_domJq_parser = ns_dom_parsers.add_parser('jq', parents=[ng_pp])
        ns_cre_parser = ns_dom_parsers.add_parser('create', parents=[namep],
            formatter_class=argparse.RawTextHelpFormatter)
        ns_cre_parser.add_argument('--spec', help=textAlign(PM_Service.createPMService.__doc__))
        ns_del_parser = ns_dom_parsers.add_parser('delete', parents=[nameGlobp])


        ''' policy deploymentzone '''
        ns_dz_parser = ns_sub_parsers.add_parser('deploymentzone')
        ns_dz_parsers = ns_dz_parser.add_subparsers(dest="ns2")
        ns_dzLst_parser = ns_dz_parsers.add_parser('list')
        ns_dzJq_parser = ns_dz_parsers.add_parser('jq', parents=[ng_pp])

        ns_dz_parser = ns_sub_parsers.add_parser('site')
        ns_dz_parsers = ns_dz_parser.add_subparsers(dest="ns2")
        ns_dzLst_parser = ns_dz_parsers.add_parser('list')
        ns_dzJq_parser = ns_dz_parsers.add_parser('jq', parents=[ng_pp])

        ns_dom_parser = ns_sub_parsers.add_parser('domain')
        ns_dom_parsers = ns_dom_parser.add_subparsers(dest="ns2")
        ns_domLst_parser = ns_dom_parsers.add_parser('list', parents=[ng_pp])
        ns_domJq_parser = ns_dom_parsers.add_parser('jq', parents=[ng_pp])
        ns_cre_parser = ns_dom_parsers.add_parser('create', parents=[namep])
        ns_del_parser = ns_dom_parsers.add_parser('delete', parents=[nameGlobp])


        ''' policy deploymentmap '''
        ns_dm_parser = ns_sub_parsers.add_parser('deploymentmap')
        ns_dm_parsers = ns_dm_parser.add_subparsers(dest="ns2")
        ns_dmLst_parser = ns_dm_parsers.add_parser('list', parents=[dom_op,ng_pp])
        ns_dmJq_parser = ns_dm_parsers.add_parser('jq', parents=[dom_op,ng_pp])
        ns_dmCr_parser = ns_dm_parsers.add_parser('create')
        ns_dmCr_parser.add_argument('--domain', required=True, help='domain name')
        ns_dmCr_parser.add_argument('--enforcementpoint', required=True, help='enforcement point name')
        ns_dmCr_parser = ns_dm_parsers.add_parser('delete')
        ns_dmCr_parser.add_argument('--domain', required=True, help='domain name')
        ns_dmCr_parser.add_argument('--enforcementpoint', required=True, help='enforcement point name')


        ''' policy group '''
        ns_grp_parser = ns_sub_parsers.add_parser('group')
        ns_grp_parsers = ns_grp_parser.add_subparsers(dest="ns2")
        ns_grpLst_parser = ns_grp_parsers.add_parser('list', parents=[dom_op,ng_pp])
        ns_grpJq_parser = ns_grp_parsers.add_parser('jq', parents=[dom_op,ng_pp])
        ns_grpCr_parser = ns_grp_parsers.add_parser('create', parents=[dom_orp],
            formatter_class=argparse.RawTextHelpFormatter)
        ns_grpCr_parser.add_argument('--spec', help=textAlign(PM_Group.create.__doc__))
        ns_grpCr_parser.add_argument('name', help='policy group name')
        ns_grpDel_parser = ns_grp_parsers.add_parser('delete', parents=[dom_orp,forcep,ng1pp])


        ''' policy communicationprofile '''
        ns_cp_parser = ns_sub_parsers.add_parser('communicationprofile')
        ns_cp_parsers = ns_cp_parser.add_subparsers(dest="ns2")
        ns_cpLst_parser = ns_cp_parsers.add_parser('list', parents=[ng_pp])
        ns_cpJq_parser = ns_cp_parsers.add_parser('jq', parents=[ng_pp])
        ns_cpCr_parser = ns_cp_parsers.add_parser('create', parents=[namep],
            formatter_class=argparse.RawTextHelpFormatter)
        ns_cpCr_parser.add_argument('--spec', help=textAlign(PM_CommunicationProfile.create.__doc__))
        ns_cpDel_parser = ns_cp_parsers.add_parser('delete', parents=[ng1op])


        ''' policy communicationmap '''
        ns_cm_parser = ns_sub_parsers.add_parser('communicationmap')
        ns_cm_parsers = ns_cm_parser.add_subparsers(dest="ns2")
        ns_cmLst_parser = ns_cm_parsers.add_parser('list', parents=[dom_op,ng_pp])
        ns_cmJq_parser = ns_cm_parsers.add_parser('jq', parents=[dom_op,ng_pp])
        ns_cmCr_parser = ns_cm_parsers.add_parser('create', parents=[namep,dom_orp],
            formatter_class=argparse.RawTextHelpFormatter)
        ns_cmCr_parser.add_argument('--precedence', type=int)
        ns_cmCr_parser.add_argument('--category', default='emergency',
            choices=['application', 'emergency', 'environmental', 'infrastructure'])
        ns_cmCr_parser.add_argument('--entriesSpec',    help=pmPolicyRulesSpecHelp)
        ns_cmCr_parser.add_argument('--applicationSpec',    help=pmPolicyApplicationSpecHelp)
        ns_cmCr_parser.add_argument('--emergencySpec',      help=pmPolicyEmergencySpecHelp)
        ns_cmCr_parser.add_argument('--environmentalSpec',  help=pmPolicyEnvironmentalSpecHelp)
        ns_cmCr_parser.add_argument('--infrastructureSpec', help=pmPolicyInfrastructureSpecHelp)
        ns_cmDel_parser = ns_cm_parsers.add_parser('delete', parents=[dom_orp,cat_orp,forcep,ng1pp])


        ''' policy realization '''
        ns_r_parser = ns_sub_parsers.add_parser('realization')
        ns_r_parsers = ns_r_parser.add_subparsers(dest="ns2")
        ns_r_parser = ns_r_parsers.add_parser('list', parents=[dom_op,ng_pp])
        ns_r_parser = ns_r_parsers.add_parser('jq', parents=[dom_op,ng_pp])
        ns_r_parser.add_argument('--rtype', choices=[None, "vm", "vif"],
            help='realization object type')


        ''' policy about '''
        ns_ab_parser = ns_sub_parsers.add_parser('about')
        ns_ab_parsers = ns_ab_parser.add_subparsers(dest="ns2")

        ns_fe_parser = ns_ab_parsers.add_parser('policyManager')
        ns_fe_parser.add_argument('feature', nargs='?')


        #Vipin
        ns_pfw_parser = ns_sub_parsers.add_parser('firewall')
        ns_pfw_subparser = ns_pfw_parser.add_subparsers(dest="ns2")
        ns_ppolicy_parser = ns_pfw_subparser.add_parser('securitypolicy')
        ns_ppolicy_subparser = ns_ppolicy_parser.add_subparsers(dest="ns3")

        ns_pseclist_parser = ns_ppolicy_subparser.add_parser('list', formatter_class=argparse.RawTextHelpFormatter)
        ns_pseclist_parser.add_argument('--domain', default='default', help="Domain name")

        ns_pseclist_parser = ns_ppolicy_subparser.add_parser('jq', formatter_class=argparse.RawTextHelpFormatter)
        ns_pseclist_parser.add_argument('--domain', default='*', help="Domain name")
        ns_pseclist_parser.add_argument('--listrules', action='store_true')
        ns_pseclist_parser.add_argument('spNameGlob', default='*', nargs='?', help="Security Policy name")

        ns_psecFd_parser = ns_ppolicy_subparser.add_parser('find', formatter_class=argparse.RawTextHelpFormatter)
        ns_psecFd_parser.add_argument('name', help='Policy firewall policy name')
        ns_psecFd_parser.add_argument('--domain', default='default', help="Domain name")

        ns_psecCr_parser = ns_ppolicy_subparser.add_parser('create', parents=[cat_orp],
            formatter_class=argparse.RawTextHelpFormatter)
        ns_psecCr_parser.add_argument('name', help='Policy firewall policy name')
        ns_psecCr_parser.add_argument('--domain', default='default', help="Domain name")
        ns_psecCr_parser.add_argument('--desc', default=None, help="Description")

        ns_psecCr_parser = ns_ppolicy_subparser.add_parser('delete', formatter_class=argparse.RawTextHelpFormatter,
                                                            parents=[nameGlobp])
        ns_psecCr_parser.add_argument('--domain', default='default', help="Domain name")
        ns_prule_parser = ns_ppolicy_subparser.add_parser("rule")
        ns_prule_subparser = ns_prule_parser.add_subparsers(dest="ns4")

        ns_pruleadd_parser = ns_prule_subparser.add_parser("add")
        ns_pruleadd_parser.add_argument('--spolicy',
                                      required=True,
                                      help='Name of the policy')
        ns_pruleadd_parser.add_argument('--domain',
                                      required=True,
                                      help='Name of the domain')
        ns_pruleadd_parser.add_argument('--name',
                                      default="New Rule",
                                      help='Name of the rule')
        ns_pruleadd_parser.add_argument('--description',
                                      default=None,
                                      help='Description of the rule')

        ns_pruleadd_parser.add_argument('--direction',
                                      choices=["IN", "OUT", "IN_OUT"],
                                      default="IN_OUT",
                                      help='Direction of the rule, default IN_OUT')
        ns_pruleadd_parser.add_argument('--protocol',
                                      choices=["IPV4", "IPV6", "IPV4_IPV6"],
                                      default="IPV4",
                                      help="IP version, default IPV4")
        ns_pruleadd_parser.add_argument('--sources',
                                      default=None,
                                      nargs='*',
                                      help="Sorces. List of groups\
                                           Default: None which translates to Any.")
        ns_pruleadd_parser.add_argument('--destinations',
                                      default=None,
                                      nargs='*',
                                      help="Destinations. List of groups\
                                           Default: None which translates to Any.")
        ns_pruleadd_parser.add_argument('--scope',
                                        default=None,
                                        nargs='*',
                                        help="Scope. List of groups, should be from sources and destination\
                                            Default: None which translates to Any.")
        ns_pruleadd_parser.add_argument('--services',
                                      default=None,
                                      nargs='*',
                                      help="List of service names")
        ns_pruleadd_parser.add_argument('--log',
                                      choices=['True', 'False'],
                                      default=False,
                                      # action='store_true',
                                      help="Enable log?  Default=False")
        ns_pruleadd_parser.add_argument('--action',
                                      required=True,
                                      choices=['ALLOW', 'DROP', 'REJECT'])
        ns_pruleadd_parser.add_argument('--disable', action='store_true', help="Flag to create the rule disabled")
        ns_pruleadd_parser.add_argument('--tag',
                                        default="",
                                        help="Give Tag for the rule")

        ns_prulemodify_parser = ns_prule_subparser.add_parser('modify')
        ns_prulemodify_subparser = ns_prulemodify_parser.add_subparsers(dest='ns5')
        ns_prulemodifyadd_parser = ns_prulemodify_subparser.add_parser('add')
        ns_prulemodifyadd_parser.add_argument('--name',
                                              default='New Rule',
                                              help="Enter the rule name")
        ns_prulemodifyadd_parser.add_argument('--spolicy',
                                             required=True,
                                             help='Name of the policy')
        ns_prulemodifyadd_parser.add_argument('--domain',
                                             required=True,
                                             help='Name of the domain')
        ns_prulemodifyadd_parser.add_argument('--sources',
                                             default=[],
                                             nargs='*',
                                             help="Sorces. List of groups\
                                             Will be add in existing")
        ns_prulemodifyadd_parser.add_argument('--destinations',
                                             default=[],
                                             nargs='*',
                                             help="Destinations. List of groups\
                                             Will be add in existing")
        ns_prulemodifyadd_parser.add_argument('--scope',
                                             default=[],
                                             nargs='*',
                                             help="Scope. List of groups, should be\
                                             from sources and destination")
        ns_prulemodifyadd_parser.add_argument('--services',
                                             default=[],
                                             nargs='*',
                                             help="List of service names want\
                                                  to add in existing")

        ns_prulemodifyupdate_parser = ns_prulemodify_subparser.add_parser("update")
        ns_prulemodifyupdate_parser.add_argument('--spolicy',
                                                 required=True,
                                                 help='Name of the policy')
        ns_prulemodifyupdate_parser.add_argument('--domain',
                                                 required=True,
                                                 help='Name of the domain')
        ns_prulemodifyupdate_parser.add_argument('--name',
                                                 default="New Rule",
                                                 help='Name of the rule')
        ns_prulemodifyupdate_parser.add_argument('--description',
                                                 default=None,
                                                 help='Description of the rule')
        ns_prulemodifyupdate_parser.add_argument('--direction',
                                                 choices=["IN", "OUT", "IN_OUT"],
                                                 default=None,
                                                 help='Direction of the rule, default IN_OUT')
        ns_prulemodifyupdate_parser.add_argument('--protocol',
                                                 choices=["IPV4", "IPV6", "IPV4_IPV6"],
                                                 default=None,
                                                 help="IP version, default IPV4")
        ns_prulemodifyupdate_parser.add_argument('--sources',
                                                 default=[],
                                                 nargs='*',
                                                 help="Sorces. List of groups\
                                                 It will modify the original sources.")
        ns_prulemodifyupdate_parser.add_argument('--destinations',
                                                 default=[],
                                                 nargs='*',
                                                 help="Destinations. List of groups\
                                                 It will modify the original destinations.")
        ns_prulemodifyupdate_parser.add_argument('--scope',
                                                 default=[],
                                                 nargs='*',
                                                 help="Scope. List of groups, should be from sources and destination\
                                                      It will modify the original scope.")
        ns_prulemodifyupdate_parser.add_argument('--services',
                                                 default=[],
                                                 nargs='*',
                                                 help="List of service names\
                                                       It will modify the original srvices.")
        ns_prulemodifyupdate_parser.add_argument('--log',
                                                 choices=['True', 'False'],
                                                 default=None,
                                                 # action='store_true',
                                                 help="Enable log?  Default=False")
        ns_prulemodifyupdate_parser.add_argument('--action',
                                                 default=None,
                                                 choices=['ALLOW', 'DROP', 'REJECT'])
        ns_prulemodifyupdate_mparser = ns_prulemodifyupdate_parser.add_mutually_exclusive_group(required=False)
        ns_prulemodifyupdate_mparser.add_argument('--disable', action='store_true',
                                                  help="Flag to change the rule to disable state")
        ns_prulemodifyupdate_mparser.add_argument('--enable', action='store_true',
                                                  help="Flag to change the rule to enable state")
        ns_prulemodifyupdate_parser.add_argument('--tag',
                                                 default=None,
                                                 help="Give Tag for the rule")

        ns_prulemodifyadd_parser = ns_prulemodify_subparser.add_parser('delete')
        ns_prulemodifyadd_parser.add_argument('--name',
                                             default='New Rule',
                                             help="Enter the rule name")
        ns_prulemodifyadd_parser.add_argument('--spolicy',
                                             required=True,
                                             help='Name of the policy')
        ns_prulemodifyadd_parser.add_argument('--domain',
                                             required=True,
                                             help='Name of the domain')
        ns_prulemodifyadd_parser.add_argument('--sources',
                                             default=[],
                                             nargs='*',
                                             help="Sorces. List of groups\
                                             Will be add in existing")
        ns_prulemodifyadd_parser.add_argument('--destinations',
                                             default=[],
                                             nargs='*',
                                             help="Destinations. List of groups\
                                             Will be add in existing")
        ns_prulemodifyadd_parser.add_argument('--scope',
                                             default=[],
                                             nargs='*',
                                             help="Scope. List of groups, should be\
                                             from sources and destination")
        ns_prulemodifyadd_parser.add_argument('--services',
                                             default=[],
                                             nargs='*',
                                             help="List of service names want\
                                                  to add in existing")

        ns_prulelist_parser = ns_prule_subparser.add_parser('list', parents=[dom_orp])
        ns_prulelist_parser.add_argument('--spolicy',
                                              required=True,
                                              help='Name of the policy')

        ns_prulejq_parser = ns_prule_subparser.add_parser('jq', parents=[dom_orp])
        ns_prulejq_parser.add_argument('--spolicy', required=True, help='Name of the policy')

        ns_prulefind_parser = ns_prule_subparser.add_parser('find', parents=[dom_orp])
        ns_prulefind_parser.add_argument('--name', default='New Rule', help='Name of the rule')
        ns_prulefind_parser.add_argument('--spolicy', required=True, help='Name of the policy')

        ns_pruledelete_parser = ns_prule_subparser.add_parser('delete', parents=[ngpp, dom_orp])
        ns_pruledelete_parser.add_argument('--spolicy',
                                         required=True,
                                         help='Name of the policy')


        ''' policy segment '''
        ns_grp_parser = ns_sub_parsers.add_parser('segment')
        ns_grp_parsers = ns_grp_parser.add_subparsers(dest="ns2")
        ns_grpLst_parser = ns_grp_parsers.add_parser('list', parents=[dom_op,ng_pp])
        ns_grpJq_parser = ns_grp_parsers.add_parser('jq', parents=[dom_op,ng_pp])
        ns_grpJq_parser = ns_grp_parsers.add_parser('delete', parents=[dom_op,ng_pp])


        ''' policy role '''
        ns_role_parser = ns_sub_parsers.add_parser('role')
        ns_role_parsers = ns_role_parser.add_subparsers(dest="ns2")
        ns_roleLst_parser = ns_role_parsers.add_parser('list', parents=[dom_op,ng_pp])
        ns_roleJq_parser = ns_role_parsers.add_parser('jq', parents=[dom_op,ng_pp])
        ns_roleJq_parser.add_argument('--binding', action='store_true')


        ''' policy tier0 '''
        ns_role_parser = ns_sub_parsers.add_parser('tier0')
        ns2_parsers = ns_role_parser.add_subparsers(dest="ns2")
        ns2_lst_parser = ns2_parsers.add_parser('list', parents=[dom_op,ng_pp])
        ns2_Jq_parser = ns2_parsers.add_parser('jq', parents=[dom_op,ng_pp])

        ''' policy tier1 '''
        ns_role_parser = ns_sub_parsers.add_parser('tier1')
        ns2_parsers = ns_role_parser.add_subparsers(dest="ns2")
        ns2_lst_parser = ns2_parsers.add_parser('list', parents=[dom_op,ng_pp])
        ns2_Jq_parser = ns2_parsers.add_parser('jq', parents=[dom_op,ng_pp])


        ''' policy dhcpRelay '''
        ns_role_parser = ns_sub_parsers.add_parser('dhcpRelay')
        ns2_parsers = ns_role_parser.add_subparsers(dest="ns2")
        ns2_lst_parser = ns2_parsers.add_parser('list', parents=[dom_op,ng_pp])
        ns2_Jq_parser = ns2_parsers.add_parser('jq', parents=[dom_op,ng_pp])


        ''' policy prefixList '''
        ns_role_parser = ns_sub_parsers.add_parser('prefixList')
        ns2_parsers = ns_role_parser.add_subparsers(dest="ns2")
        ns2_lst_parser = ns2_parsers.add_parser('list', parents=[dom_op,ng_pp])
        ns2_Jq_parser = ns2_parsers.add_parser('jq', parents=[dom_op,ng_pp])


        #ns_enp_parser = ns_sub_parsers.add_parser('enforcementpoint')
        #ns_brclusterns_parser = ns_dom_parser.add_subparsers(dest='brcluster')

        #ns_parser = ns_sub_parsers.add_parser('list')
        #ns_parser = ns_sub_parsers.add_parser('jq', parents=[ng_pp])

    return r


def parseParameters():
    parser = argparse.ArgumentParser()

    parser.add_argument('nsxmgr')
    parser.add_argument('-u', '--nuser', default='admin')
    parser.add_argument('-p', '--npass', default='CptWare12345!', help='NSX manager password')
    parser.add_argument('--rootpass',    default='CptWare12345!', help='NSX manager root password')
    parser.add_argument('-U', '--pmuser', default='admin')
    parser.add_argument('-P', '--pmpass', default='ptWare12345!', help='NSX policy manager password')
    parser.add_argument('--PM', help='Policy Manager, defalt=nsxmgr')
    parser.add_argument('--promptForPassword', action='store_true', help='Prompt for Password')
    parser.add_argument('--useSessCookieFile', help='Authenticate using session file')
    parser.add_argument('--certFile', help='Authenticate using certificate file. '
        'CertFile can be in single .p12 format or commma serperated .crt,.key files. '
        'E.g.: "myCert.p12" OR "myCert.crt,myCert.key"')
    #parser.add_argument('--vuser', default='Administrator@vsphere.local')
    parser.add_argument('--useSearchAPI', action='store_true', help='make use of search API whenever possible')
    parser.add_argument('--safe', action='store_true', help='Do not send non-safe http requests (POST, PUT, DELETE)')
    parser.add_argument('--loglevel', default='INFO', type=lambda s:s.upper(),
        metavar=cptutil.cptLogLevelMetavar,
        choices=cptutil.cptLogLevels, help="Set the logging level")

    parser.add_argument('--nthread', type=int, default=20)

    subparsers = parser.add_subparsers(dest="ns")

    mkArgParsers(subparsers, 'api', ['api_api'])
    mkArgParsers(subparsers, 'cert', ['cert_api'])
    mkArgParsers(subparsers, 'cluster',  ['cluster_api'])
    mkArgParsers(subparsers, 'computeManager', ['computeManager_api'])
    mkArgParsers(subparsers, 'eula', ['eula_api'], crNsSubparsers=False)
    mkArgParsers(subparsers, 'pools',  ['pools_api'])
    mkArgParsers(subparsers, 'manager',  ['manager_api'])
    mkArgParsers(subparsers, 'controller',  ['controller_api'])
    mkArgParsers(subparsers, 'edge', ['edgenode_api'])
    mkArgParsers(subparsers, 'edgecluster', ['edgecluster_api'])
    mkArgParsers(subparsers, 'tz', ['tz_api'])
    mkArgParsers(subparsers, 'service', ['service_api'])
    mkArgParsers(subparsers, 'nsservice', ['nsservice_api'])
    mkArgParsers(subparsers, 'nsservicegroup', ['nsservicegroup_api'])
    mkArgParsers(subparsers, 'uplink', ['uplink_api'])
    mkArgParsers(subparsers, 'host', ['host_api'])
    mkArgParsers(subparsers, 'lsp', ['lsp_api'])
    mkArgParsers(subparsers, 'hswProf', ['hswProf_api'])
    mkArgParsers(subparsers, 'switch', ['switch_api'])
    mkArgParsers(subparsers, 'kvm', ['kvm_api'])
    mkArgParsers(subparsers, 'tn', ['tn_api'])
    mkArgParsers(subparsers, 'node', ['node_api'])
    mkArgParsers(subparsers, 'lr', ['lr_api'])
    mkArgParsers(subparsers, 'dhcp', ['dhcp_api'])
    mkArgParsers(subparsers, 'ipset', ['ipset_api'])
    mkArgParsers(subparsers, 'nsgroup', ['nsgroup_api'])
    mkArgParsers(subparsers, 'syslog', ['syslog_api'])
    mkArgParsers(subparsers, 'bridge', ['br_api'])
    mkArgParsers(subparsers, 'principal', ['principal_api'])
    mkArgParsers(subparsers, 'firewall', ['fw_api'])
    mkArgParsers(subparsers, 'excludelist', ['excludelist_api'])
    mkArgParsers(subparsers, 'vm', ['vm_api'])
    mkArgParsers(subparsers, 'vif', ['vif_api'])
    mkArgParsers(subparsers, 'session', ['session_api'])
    mkArgParsers(subparsers, 'search', ['search_api'], crNsSubparsers=False)
    mkArgParsers(subparsers, 'tag', ['tag_api'])
    mkArgParsers(subparsers, 'about', ['about_api'], crNsSubparsers=False)
    mkArgParsers(subparsers, 'try', ['try_api'], crNsSubparsers=False)
    mkArgParsers(subparsers, 'ipam', ['ipam_api'])
    mkArgParsers(subparsers, 'global', ['global_api'])
    mkArgParsers(subparsers, 'vidm', ['vidm_api'])

    mkArgParsers(subparsers, 'policy', ['policy_api'])
    mkArgParsers(subparsers, 'lb', ['lb_api'])

    args = parser.parse_args()
    args.loglevel = args.loglevel.upper()
    args.loglevel = getattr(logging, args.loglevel.upper())

    if args.promptForPassword:
        args.npass =  getpass.getpass('NSX Manager password: ')
        if args.PM:
            args.pmpass =  getpass.getpass('NSX Policy Manager password: ')

    return args

def loadJsonFromFile(filename):
    fp  = open(filename).read()
    return json.loads(fp)

def main():
    args = parseParameters()
    argsNs = vars(args)

    crSessCookieFile=''
    if args.ns=='session' and argsNs['session']=='create':
        crSessCookieFile=args.sessCookieFile

    mp = ManagerNode(host=args.nsxmgr,
                     adminuser=args.nuser,
                     adminpassword=args.npass,
                     rootpassword=args.rootpass,
                     verify=False,
                     loglevel=args.loglevel,
                     certFile=args.certFile,
                     sessCookieFile=args.useSessCookieFile,
                     thumbprint=False,
                     crSessCookieFile=crSessCookieFile
                     )
                     
    mgr = mp.getMgr()
    mgr.useSearchAPI = args.useSearchAPI
    mgr.logger.debug(pformat(mgr.__dict__))

    if args.PM:
        policyMgr = restlib.RestConnect('https://%s' % args.PM, user=args.pmuser,
            password=args.pmpass, verify=False, content_type="application/json",
            accept='application/json',
            logLevel=args.loglevel, logger=mgr.logger, nsxtAuth=True,
            certFiles=args.certFile, sessCookieFile=args.useSessCookieFile)
        mgr.policyMgr = policyMgr
    else:
        policyMgr = mgr
    #policyMgr.version = Manager(mgr=mgr).about(display=False)['node_version']

    if args.safe:
        ''' disable PUT and POST rest request '''
        mgr.setVerbOp('post', None)
        mgr.setVerbOp('patch', None)
        mgr.setVerbOp('put', None)

    mLogger = mgr.logger

    #if args.sessCookieFile:
    #    sCookie = SessionCookie(mgr, sessCookieFile=args.sessCookieFile)
    #    sCookie.useSessFile()

    if args.ns == 'cluster':                                # cluster_api
        cluster = Cluster(mp=mp)
        if argsNs['cluster'] == 'info':
            cluster.info()
        elif argsNs['cluster'] == 'nodes':
            cluster.nodes()
        elif argsNs['cluster'] == 'status':
            cluster.status()
        elif argsNs['cluster'] == 'join':
            primary=ManagerNode(host=args.primary, adminpassword=args.npass,
                                loglevel=args.loglevel)
            secondaries=[]
            for s in args.secondaries:
                smp=ManagerNode(host=s, adminpassword=args.npass,loglevel=args.loglevel)
                secondaries.append(smp)
            cluster.createCluster(primary=primary,secondaries=secondaries)
        elif argsNs['cluster'] == 'jq':
            cluster.jq(args.jqType)
            
        

    elif args.ns == 'manager':                              # manager_api
        if argsNs['manager'] == 'info':
            #cluster = Cluster(mgr=mgr)
            cluster = Cluster(mp=mp)
            cluster.info()
            manager=ManagerNode(host=args.nsxmgr)
            print args.nsxmgr + " api thumbprint: " + manager.getThumbprint()

    elif args.ns == 'host':                                 # host_api
        if argsNs['host'] == 'joinmp':
            manager=ManagerNode(host=args.nsxmgr)
            for h in argsNs['targets']:
                host = EsxiHost(mgr=mgr,host = h)
                host.joinmp(mgr = args.nsxmgr, thumbprint=manager.thumbprint, password=args.npass)
        elif argsNs['host'] == 'apijoinmp':
            manager=ManagerNode(host=args.nsxmgr)
            for h in argsNs['targets']:
                host = EsxiHost(mgr=mgr,host = h)
                host.apiJoinmp(mgr = args.nsxmgr)
        elif argsNs['host'] == 'thumbprint':
            for h in argsNs['targets']:
                host = EsxiHost(mgr=mgr, host = h)
                host.getThumbprint()
        elif argsNs['host'] == 'detachmp':
            manager=ManagerNode(host=args.nsxmgr)
            for h in argsNs['targets']:
                host=EsxiHost(mgr=mgr,host=h)
                host.detachmp(mgr.args.nsxmgr, thumbprint=mananager.thumbprint)
        elif argsNs['host'] == 'clearmp':
            for h in argsNs['targets']:
                host=EsxiHost(mgr=None,host=h)
                host.clearmp()
        elif argsNs['host'] == 'delete':
            for h in argsNs['targets']:
                print(mgr)
                host=EsxiHost(mgr=mgr,host=None)
                host.deleteHost(host=h,unprep=args.unprep,display=False)
        elif argsNs['host'] == 'find':
            pass
        elif argsNs['host'] == 'list':
            host = EsxiHost(mgr)
            host.list()
        elif argsNs['host'] == 'jq':
            host = EsxiHost(mgr)
            host.jqTable()

    elif args.ns == 'controller':                           # controller_api
        if argsNs['controller'] == 'info':
            cluster = Cluster(mp)
            cluster.info()
        elif argsNs['controller'] == 'join':
            controllers = Controller(hosts=argsNs['targets'],
                    manager=argsNs['manager'])
            controllers.joinMp()
            controllers.joinCp()
        elif argsNs['controller'] == 'joincp':
            controllers = Controller(hosts=argsNs['targets'])
            controllers.joinCp()
        elif argsNs['controller'] == 'secret':
            controllers = Controller(hosts=argsNs['targets'])
            controllers.setSecret()
        elif argsNs['controller'] == 'joinmp':
            controllers = Controller(hosts=argsNs['targets'],
                    manager=argsNs['manager'])
            controllers.joinMp()
        elif argsNs['controller'] == 'initialize':
            controllers = Controller(hosts=argsNs['target'])
            controller.initializeCluster(controllers[0])
        elif argsNs['controller'] == 'joinCluster':
            frm = Controller(hosts=[argsNs['from']])
            nodes = Controller(hosts=argsNs['targets'])
            nodes.getThumbprint()
            nodes.joinCluster(frm=frm.controllers[0],
                    nodes = nodes.controllers)
        elif argsNs['controller'] == 'activate':
            nodes = Controller(hosts=argsNs['targets'])
            nodes.activateCluster(nodes = nodes.controllers)

    elif args.ns == 'edge':                                 # edgenode_api
        if argsNs['edge'] == 'joinmp':
            edgeNode = EdgeNode(host=argsNs['targets'])
            manager=ManagerNode(host=argsNs['manager'], thumbprint=True)
            edgeNode.joinmp(mgr=argsNs['manager'],
                    thumbprint = manager.thumbprint,
                    user=manager.adminuser,
                    password=manager.adminpassword)
        edgeNode = Edge(mgr=mgr)
        if argsNs['edge'] == 'list':
            edgeNode.list()
        elif argsNs['edge'] == 'jq':
            #edgeNode.jqTable(nameGlob=args.nameGlob)
            edgeNode.jqTable()

    elif args.ns == 'edgecluster':                          # edgecluster_api
        ec = EdgeCluster(mgr=mgr)
        if argsNs['edgecluster'] == 'list':
            ec.selflist(display=True)
        elif argsNs['edgecluster'] == 'jq':
            ec.jqTable(display=True)
        elif argsNs['edgecluster'] == 'config':
            ec.config(name=argsNs['name'], members=argsNs['members'])
        elif argsNs['edgecluster'] == 'delete':
            ec.delete(name=args.name)

    elif args.ns=='service':                                # service_api
        service = DhcpRelayServices(mgr=mgr)
        if argsNs['service'] == 'list':
            service.list()
        elif argsNs['service'] == 'jq':
            service.jqTable(nameGlob=args.nameGlob)

    elif args.ns=='nsservice':                              # nsservice_api
        nsservice = NSServices(mgr=mgr)
        if argsNs['nsservice'] == 'list':
            nsservice.list()
        elif argsNs['nsservice']== 'find':
            nsservice.findByName(name=args.name, display=True)
        elif argsNs['nsservice'] == 'jq':
            nsservice.jqTable(nameGlob=args.nameGlob)
        elif argsNs['nsservice'] == 'create':
            nsservice.createNSService(args.nsserviceSpec, update=args.update)
        elif argsNs['nsservice'] == 'delete':
            nsservice.delete(namesGlob=args.namesGlob, ids=args.ids)

    elif args.ns=='nsservicegroup':                         # nsservicegroup_api
        nssg = NSServiceGroups(mgr=mgr)
        if argsNs['nsservicegroup'] == 'list':
            nssg.list()
        elif argsNs['nsservicegroup']== 'find':
            nssg.findByName(name=args.name, display=True)
        elif argsNs['nsservicegroup'] == 'jq':
            nssg.jqTable(nameGlob=args.nameGlob)
        elif argsNs['nsservicegroup'] == 'create':
            nssg.createNSServiceGroup(args.nsservicegroupSpec, update=args.update)
        elif argsNs['nsservicegroup'] == 'delete':
            nssg.delete(namesGlob=args.namesGlob, ids=args.ids)

    elif args.ns=='tz':                                     # tz_api
        tz = Transportzone(mgr=mgr)
        if argsNs['tz'] == 'list':
            tz.list()
        elif argsNs['tz'] == 'jq':
            tz.jqTable(nameGlob=args.nameGlob)
        elif argsNs['tz'] == 'config':
            cfgInput = loadJsonFromFile(argsNs['jsonFile'])
            if 'transportzones' in cfgInput:
                newtz = cfgInput['transportzones']
                for p in newtz:
                    if len(argsNs['targets']) > 0:
                        if p['display_name'] not in argsNs['targets']:
                            continue
                    print "TZ name: " + p['display_name']
                    tz.config(data=p)
        elif argsNs['tz'] == 'find':
            tz.find(name=argsNs['target'])
        elif argsNs['tz'] == 'delete':
            tz.delete(namesGlob=args.namesGlob, ids=args.ids)
        elif argsNs['tz'] == 'create':
            tz.createTZ(name=args.name, desc=args.desc, swName=args.swName, tzType=args.type)

    elif args.ns=='uplink':                                 # uplink_api
        up = Uplinkprofile(mgr=mgr)
        if argsNs['uplink'] == 'list':
            #up.list()
            up.list(display=True)
        elif argsNs['uplink'] == 'jq':
            up.jqTable(nameGlob=args.nameGlob)

        elif argsNs['uplink'] == 'find':
            up.findByName(name=argsNs['target'])
        elif argsNs['uplink'] == 'config':
            cfgInput = loadJsonFromFile(argsNs['jsonFile'])
            if 'uplinks' in cfgInput:
                newuplinks = cfgInput['uplinks']
                for p in newuplinks:
                    if len(argsNs['targets']) > 0:
                        if p['display_name'] not in argsNs['targets']:
                            continue
                    print "Uplink name: " + p['display_name']
                    up.config(data=p)
        elif argsNs['uplink'] == 'delete':
            hspIds = [n['id'] for n in up.findByNamesGlob(argsNs['targetGlob'])]
            for hspId in hspIds:
                up.doRestApi('delete', _hspId=hspId)

    elif args.ns == 'hswProf':                              # hswProf_api
        hswProfObj =Uplinkprofile(mgr)
        if argsNs['hswProf'] == 'list':
            hswProfObj.list()
        elif argsNs['hswProf'] == 'jq':
            hswProfObj.jqTable(nameGlob=args.nameGlob)

    elif args.ns == 'switch':                               # switch_api
        switch=Switch(mgr)
        if argsNs['switch'] == 'list':
            #switch.list(short=False, table=args.table)
            switch.list()
        elif argsNs['switch'] == 'jq':
            switch.jqTable(nameGlob=args.nameGlob)
        elif argsNs['switch'] == 'getvni':
            switch.getVni(swname=args.target, display=True)
        elif argsNs['switch'] == 'getid':
            switch.getId(swname=args.target, display=True)
        elif argsNs['switch'] == 'ports':
            switch.getPorts(swname=args.name, swId=args.id)
        elif argsNs['switch'] == 'delport':
            switch.deletePort(name=args.name, switchname=args.swname)
        elif argsNs['switch'] == 'deldownports':
            switch.delDownPorts(swid=args.id)
        elif argsNs['switch'] == 'delunattachports':
            switch.delNotAttachedPorts(swid=args.id)
        elif argsNs['switch'] == 'delopdownports':
            switch.delOperDownPorts(swid=args.id)
        elif argsNs['switch'] == 'addport':
            switch.createPort(switchname=args.swname,
                              vif=args.vifuuid,name=args.name,
                              tn=args.tnname, unblocked=args.unblocked,display=False)
        elif argsNs['switch'] == 'addtag':
            if not args.name and not args.id:
                print("Must provide either switch name or switch id")
            else:
                switch.tag(tags=args.tags, scope=args.scope,
                           name=args.name,id=args.id,display=False)
        elif argsNs['switch'] == 'delzero':
            switch.delZeroPorts(switchname=args.target)
        elif argsNs['switch'] == 'config':
            switch.config(name=argsNs['name'], tzname=argsNs['tzname'],
                          vlan=argsNs['vlan'], replication=argsNs['replication'],
                          teaming=argsNs['teaming'])
        elif argsNs['switch'] == 'teaming':
            switch.updateTeaming(name=argsNs['name'], teaming=argsNs['policy'])
        elif argsNs['switch'] == 'delete':
            switch.deleteByName(name=args.name)

        elif argsNs['switch'] == 'profile':
            swp = SwitchProfile(mgr=mgr)
            if argsNs['switchprofile'] == 'list':
                swp.list(display=True)
            elif argsNs['switchprofile'] == 'delete':
                swp.deleteByName(name=args.name)
            elif argsNs['switchprofile'] == 'qos':
                if argsNs['QosNs'] == 'config':
                    swp.configQos(name=args.name, cos=args.cos,
                                  dscpMode=args.dscpMode, dscp=args.dscp,
                                  shapers=args.shapers, desc=args.desc,
                                  tags=args.tags)
            elif argsNs['switchprofile'] == 'mirror':
                if argsNs['MirrorNs'] == 'config':
                    swp.configPortMirror(name=args.name, dest=args.dest,
                                         direction=args.direction,
                                         snap=args.snap, key=args.key,
                                         desc=args.desc, tags=args.tags)
            elif argsNs['switchprofile'] == 'security':
                if argsNs['SwitchSecurityNs'] == 'config':
                    swp.configSwitchSecurity(name=args.name, bpdu=args.bpdu,
                                             bpduMacs=args.bpduMac,
                                             blockdhcpserver=args.blockDhcpServer,
                                             blockdhcpclient=args.blockDhcpClient,
                                             blockNonIp = args.blockNonIp,
                                             ratelimit=args.rateLimit,
                                             rxbroadcast=args.rxbroadcast,
                                             rxmulticast=args.rxmulticast,
                                             txbroadcast=args.txbroadcast,
                                             txmulticast=args.txmulticast,
                                             desc=args.desc, tags=args.tags)
            elif argsNs['switchprofile'] == 'discovery':
                if argsNs['IpDiscoveryNs'] == 'config':
                    swp.configIpDiscovery(name=args.name,
                                          arpsnoop=args.arpSnoop,
                                          arplimit=args.arpLimit,
                                          dhcpsnoop=args.dhcpSnoop,
                                          vmtools=args.vmtools, tags=args.tags)
            elif argsNs['switchprofile'] == 'mac':
                if argsNs['MacManagementNs'] == 'config':
                    swp.configMacManagement(name=args.name,
                                            macChange=args.macChange,
                                            macAge=args.macAge,
                                            macLearn=args.macLearn,
                                            macLimit=args.macLimit,
                                            macLimitPolicy=args.macLimitPolicy,
                                            uflood=args.uflood,
                                            desc=args.desc, tags=args.tags)
                                          
            elif argsNs['switchprofile'] == 'spoofguard':
                if argsNs['spoofguardNs'] == 'config':
                    swp.configSpoofGuard(name=args.name,
                                         bindings=args.bindings,
                                         desc=args.desc,
                                         tags=args.tags)
                                         
                
    elif args.ns == 'lsp':                                  # lsp_api
        lsp=SwitchPorts(mgr)
        if argsNs['lsp'] == 'list':
            lsp.list(SwitchPorts.api['list'].url)
        elif argsNs['lsp'] == 'jq':
            lsp.jqTable(nameGlob=args.nameGlob)
        elif argsNs['lsp'] == 'delete':
            #lsp.delete(namesGlob=args.namesGlob)
            super(SwitchPorts, lsp).delete(namesGlob=args.namesGlob, ids=None)

    elif args.ns == 'tn':                                   # tn_api
        tn = TransportNode(mgr=mgr, fill=False)
        if argsNs['tn'] == 'list':
            tn.list(display=True)
        elif argsNs['tn'] == 'jq':
            tn.jqOp(feature=argsNs['feature'], nameGlob=args.nameGlob)
        elif argsNs['tn'] == 'find':
            if args.id:
                tn.findById(id=argsNs['id'],display=True)
            elif args.ip:
                tn.findByIp(ip=argsNs['ip'],display=True)
            elif args.name:
                tn.findByName(name=argsNs['name'],display=True)
            else:
                print("Must provide ID, IP, or Name")


        elif argsNs['tn'] == 'state':
            if args.bond:
                tn.getBondStatus(name=args.name,tnid=args.id,ip=args.ip,display=True)
            else:
                tn.getState(name=args.name,tnid=args.id,ip=args.ip,detail=args.detail,
                            display=True,jq=args.jq)
        elif argsNs['tn'] == 'status':
            tn.getStatus(name=args.name,detail=args.detail, display=True,jq=args.jq)
        elif argsNs['tn'] == 'delete':
            tn.delete(name=args.name)

        elif argsNs['tn'] == 'addtz':
            tn.addTz(tnname=args.node, tzname=args.tz,display=False)
        elif argsNs['tn'] == 'migrateVmk':
            tn = TransportNode(mgr=mgr, fill=False)
            tn.migrateVmk(tnname=args.node, vss=args.pg,vmk=args.vmk,display=True)
        elif argsNs['tn'] == 'config':
            tn.config(nodename=args.node,
                    swname=args.hswname,
                    vlansw=args.vlansw,
                    nics=args.nics,
                    vnics=args.vnics,
                    uplink=args.uplinkprofile,
                    lldp=args.lldpprofile,
                    ippool=args.ippool,
                    tzname=args.tzname)
        elif argsNs['tn'] == 'update':
            tn.update(nodename=args.node,
                      swname=args.hswname,
                      nics=args.nics,
                      uplink=args.uplinkprofile,
                      lldp=args.lldpprofile,
                      ippool=args.ippool,
                      vmklist=args.srcvmk,
                      targets=args.targets,)

    elif args.ns == 'dhcp':                                 # dhcp_api
        svc = DhcpRelayServices(mgr=mgr)
        if argsNs['dhcp'] == 'list':
            svc.list(display=True)
        elif argsNs['dhcp'] == 'find':
            svc.find(name=argsNs['target'],display=True)
        elif argsNs['dhcp'] == 'delete':
            svc.delete(name=argsNs['target'],display=True)
        elif argsNs['dhcp'] == 'config':
            svc.configDhcpRelayService(name=args.name,
                                       profile=args.profile,
                                       display=True)
        elif argsNs['dhcp'] == 'listprofile':
            svc.listDhcpProfile(display=True)
        elif argsNs['dhcp'] == 'findprofile':
            svc.findDhcpProfile(name=argsNs['target'],display=True)
        elif argsNs['dhcp'] == 'delprofile':
            svc.deleteDhcpProfile(name=argsNs['target'],display=True)
        elif argsNs['dhcp'] == 'configprofile':
            svc.createDhcpProfile(name=args.name,
                                  servers=args.servers,
                                  display=True)
        #elif argsNs['dhcp'] == 'relay':
        #    dhcpRelayObj = PM_DhcpRelay(mgr=mgr)
        #    if argsNs['ns2'] == 'list':
        #        dhcpRelayObj.list()
        #    elif argsNs['ns2'] == 'jq':
        #        dhcpRelayObj.jqTable(apiKey='list')

    elif args.ns == 'bridge':                               # bridge_api
        br = Bridge(mgr=mgr)
        if argsNs['bridge'] == 'cluster':
            if argsNs['brcluster'] == 'list':
                br.list(restUrl='/api/v1/bridge-clusters')
            elif argsNs['brcluster'] == 'show':
                br.findByName(restUrl='/api/v1/bridge-clusters',name=args.name)
            elif argsNs['brcluster'] == 'create':
                br.createBridgeCluster(name=args.name, nodes=args.tn)
            elif argsNs['brcluster'] == 'delete':
                br.deleteBridgeCluster(name=args.name)
        if argsNs['bridge'] == 'brendpoint':
            if argsNs['bep'] == 'list':
                br.list(restUrl='/api/v1/bridge-endpoints')
            elif argsNs['bep'] == 'delete':
                br.deleteBridgePoint(name=args.name,id=args.id)

        elif argsNs['bridge'] == 'list':
            br.listBridges(switch=args.switchname)
        elif argsNs['bridge'] == 'create':
            br.create(brcluster=args.brcluster, vlan=args.vlan,
                                 switch=args.switchname, display=True)
        elif argsNs['bridge'] == 'delete':
            br.delete(name=args.name, id=args.id)

    elif args.ns == 'lr':                                   # lr_api
        lr = LogicalRouter(mgr=mgr)
        if argsNs['lr'] == 'list':
            lr.routerList(display=True, table=args.table)
        elif argsNs['lr'] == 'find':
            lr.find(name=args.target,display=True)
        elif argsNs['lr'] == 'jq':
            lr.jqTable(nameGlob=args.nameGlob)

        elif argsNs['lr'] == 'config':
            lr.config(name=args.name,
                    tier=args.tier,
                    edgecluster=args.edgecluster,
                    ha=args.ha,
                    tier0=args.tier0,
                    display=True)
        elif argsNs['lr'] == 'delete':
            lr.deleteRouter(name=args.name)

        elif argsNs['lr'] == 'bfd':
            if argsNs['bfd'] == 'show':
                lr.getBfd(router=args.router,display=True)
            elif argsNs['bfd'] == 'config':
                lr.configureBfd(router=args.router,
                                rx = args.rx,
                                tx = args.tx,
                                multi=args.multi,
                                enable=args.enable)

        elif argsNs['lr'] == 'link':
            lrp = LogicalRouterPort(mgr=mgr)
            if argsNs['lruplinks'] == 'list':
                lrp.listPorts(display=True)
            elif argsNs['lruplinks'] == 'find':
                lrp.findPort(target=args.name, display=True)
            elif argsNs['lruplinks'] == 'delete':
                lrp.deletePort(name=args.name,display=True)
            elif argsNs['lruplinks'] == 'create':
                lrp.createUplinkPort(name=args.name,
                                     edgecluster=args.edgecluster,
                                     edge=args.edge,
                                     router=args.router,
                                     switch=args.switch,
                                     cidr=args.cidr)
            elif argsNs['lruplinks'] == 'createdownlink':
                lrp.createDownLinkPort(router=args.router,
                                       switch=args.switch,
                                       cidr=args.cidr,
                                       services=args.services,
                                       display=True)

        elif argsNs['lr'] == 'bgp':
            lrd=lr
            if argsNs['bgpns'] == 'list':
                if args.routers:
                    for router in args.routers:
                        lrd.listBgpNeighbor(router=router, table=args.table)
                else:
                    lrs = lrd.list(display=False)
                    if lrs['result_count'] == 0:
                        return
                    for lr in lrs['results']:
                        lrd.listBgpNeighbor(router=lr['display_name'], table=args.table)

            elif argsNs['bgpns'] == 'bfd':
                lrd.configureBgpBfd(router = args.router,
                                   neighbor = args.neighbor,
                                   rx = args.rx,
                                   tx = args.tx,
                                   multi = args.multi,
                                   enable = args.enable)
            elif argsNs['bgpns'] == 'routemap':
                lrd.configureBgpRouteMap(router=args.router,
                                      neighbor=args.neighbor,
                                      inbound=args.inbound,
                                      outbound=args.outbound,
                                      ip=args.addr)
            elif argsNs['bgpns'] == 'neighbor':
                lrd.createBgpNeighbor(router=args.router,
                                     peer=args.peer,
                                     localip=args.localip,
                                     remoteas=args.remoteas,
                                     secret=args.secret,
                                     keepalive=args.keepalive,
                                     holdtimer=args.holdtimer,
                                     display=True)
            elif argsNs['bgpns'] == 'update':
                lrd.updateBgp(router=args.router,
                             localas=args.localas,
                             status=args.enable,
                             ecmp=args.ecmp,
                             gr=args.gr,
                             display=True)

        elif argsNs['lr'] == 'addvip':
            lrd=lr
            lrd.addHaVip(name=args.router, cidr=args.cidr,
                         uplink1=args.uplink1, uplink2=args.uplink2)

        elif argsNs['lr'] == 'route':
            if argsNs['route'] == 'advertise':
                if argsNs['advertise'] == 'show':
                    lr.getAdvertisement(name=args.router,display=True)
                elif argsNs['advertise'] == 'update':
                    lr.updateAdvertisement(name=args.router,
                                           enable=args.enable,
                                           nsx=args.nsx,
                                           static=args.static,
                                           nat=args.nat,
                                           lbsnat=args.lbsnat,
                                           lbvip=args.lbvip,
                                           display=True)

            elif argsNs['route'] == 'redist':
                if argsNs['redist'] == 'show':
                    lr.getRedistribution(name=args.router,rules=True,display=True)
                elif argsNs['redist'] == 'update':
                    lr.updateRedistributionRules(router=args.router,
                                    enable=args.enable,
                                    sources=args.sources,
                                    name=args.name,
                                    desc=args.desc,
                                    dest=args.dest,
                                    add=args.append,
                                    routemap=args.routemap,
                                    display=True)

            elif argsNs['route'] == 'static':
                lrd = lr
                if argsNs['static'] == 'add':
                    lrd.addStaticRoute(router = args.router,
                                       cidr = args.prefix,
                                       nexthop = args.nexthop)
                elif argsNs['static'] == 'delete':
                    lrd.delStaticRoute(router = args.router,
                                       cidr = args.prefix,
                                       nexthop = args.nexthop)
                elif argsNs['static'] == 'list':
                    lrd.getStaticRoutes(router = args.router)

        elif argsNs['lr'] == 'prefixlist':
            lrd = lr
            if argsNs['prefixList'] == 'list':
                lrd.listPrefixList(router=args.router, brief=args.brief)
            elif argsNs['prefixList'] == 'config':
                lrd.createPrefixList(router=args.router,
                                     name=args.name,
                                     spec=args.spec,
                                     description=args.desc,
                                     tags=args.tags,
                                     display=False)
            elif argsNs['prefixList'] == 'delete':
                lrd.deletePrefixList(router=args.router,
                                   name=args.name)
            elif argsNs['prefixList'] == 'update':
                lrd.updatePrefixList(router=args.router,
                                     name=args.name,
                                     spec=args.spec,
                                     description=args.desc,
                                     tags=args.tags,
                                     display=False)
        elif argsNs['lr'] == 'route-map':
            lrd = lr
            if argsNs['routemap'] == 'list':
                lrd.listRouteMap(router=args.router, brief=args.brief, display=True)
            elif argsNs['routemap'] == 'find':
                lrd.findRouteMap(router=args.router, name=args.name, display=True)
            elif argsNs['routemap'] == 'config':
                lrd.createRouteMap(router=args.router,
                                   name=args.name,
                                   specList=args.spec,
                                   description=args.description,
                                   tags=args.tags)
            elif argsNs['routemap'] == 'delete':
                lrd.deleteRouteMap(router=args.router,
                                   name=args.name)
        elif argsNs['lr'] == 'nat':
            lrd = lr
            if argsNs['natNs'] == 'list':
                thislr = lrd.find(name=args.router, display=False)
                if thislr:
                    restUrl='/api/v1/logical-routers/%s/nat/rules' %thislr['id']
                    thislr.list(restUrl=restUrl, display=True)
                else:
                    print("Router %s not found" %args.router)
            if argsNs['natNs'] == 'add':
                lrd.addNatRule(router=args.router, action=args.action,
                               name=args.name, match=args.service,
                               source=args.source, dest = args.dest,
                               passfw=args.passfw, priority=args.priority,
                               translated_network=args.natNet,
                               translated_port=args.natPort,
                               enable=args.enable,
                               log=args.log,
                               desc=args.desc,
                               tags=args.tags)
    elif args.ns == 'node':                                 # node_api
        nodes = FabricNode(mgr=mgr)
        if argsNs['node'] == 'list':
            nodes.list(display=True)
        elif argsNs['node'] == 'jq':
            nodes.jqOp(feature=args.feature, nameGlob=args.nameGlob)
        elif argsNs['node'] == 'find':
            nodes.findByName(name=args.target,display=True)
        elif argsNs['node'] == 'state':
            nodes.getState(name=args.name, node=args.id, jq=args.jq)
        elif argsNs['node'] == 'status':
            nodes.getStatus(name=args.name, node=args.id, jq=args.jq)
        elif argsNs['node'] == 'delete':
            nodes.delete(name=args.name,uninstall=args.uninstall)
        elif argsNs['node'] == 'prep':
            node=DiscoveredNode(mgr=mgr)
            node.hostPrep(name=args.name, ip=args.ip)



    elif args.ns == 'kvm':                                  # kvm_api
        if argsNs['kvm'] == 'clone':
            if args.switch:
                switches = []
                for sw in args.switch:
                    switch=Switch(mgr)
                    swid = switch.getId(sw, display=False)
                    if not swid:
                        print "Switch not found: %s " % sw
                        return
                    switches.append(switch)
            else:
                switches = None

            vm = VirtualMachine(macprefix=args.macprefix,
                        nameprefix=args.prefix,
                        vmnum=args.vmnum,
                        niccount=args.nics,
                        dest=args.dest)
            vm.clone(base = args.base, vmnum=args.vmnum,
                        count=args.total, switch=switches)
            #vm.generateXml()
            #vm.generateIface()

    elif args.ns == 'pools':                                # pools_api
        pools = Pools(mgr)
        if argsNs['pools'] == 'info':
            pools.info()
        elif argsNs['pools'] == 'jq':
            pools.jqTable(nameGlob=args.nameGlob)
        elif argsNs['pools'] == 'delete':
            pools.deleteByName(name=args.name)
        elif argsNs['pools'] == 'config':
            cfgInput = loadJsonFromFile(argsNs['jsonFile'])
            if 'ippools' in cfgInput:
                newpools = cfgInput['ippools']
                for p in newpools:
                    if len(argsNs['targets']) > 0:
                        if p['display_name'] not in argsNs['targets']:
                            continue
                    print "Pool name: " + p['display_name']
                    pools.config(data=p)

    elif args.ns == 'ipset':                                # ipset_api
        ipset = IPSet(mgr)
        if argsNs['ipset'] == 'list':
            ipset.list(display=True)
        elif argsNs['ipset'] == 'jq':
            ipset.jqTable(nameGlob=args.nameGlob)
        elif argsNs['ipset'] == 'find':
            ipset.findByName(name=args.target,display=True)
        elif argsNs['ipset'] == 'delete':
            ipset.delete(name=args.target,display=True)
        elif argsNs['ipset'] == 'config':
            ipset.config(name=args.name, ips=args.ips,
                         update=args.update,display=True)

    elif args.ns == 'nsgroup':                              # nsgroup_api
        nsg = NSGroups(mgr)
        if argsNs['nsgroup'] == 'list':
            nsg.list(brief=args.brief,display=True)
        elif argsNs['nsgroup'] == 'jq':
            nsg.jqTable(nameGlob=args.nameGlob)
        elif argsNs['nsgroup'] == 'find':
            nsg.find(name=args.target,display=True)
        elif argsNs['nsgroup'] == 'delete':
            nsg.delete(name=args.target,display=True)
        elif argsNs['nsgroup'] == 'config':
            nsg.config(name=args.name,
                       ips=args.ips,
                       ls=args.ls,
                       nsgroup=args.nsgroups,
                       lp=args.lp,
                       vmcontain=args.vmcontain,
                       vmequal=args.vmequal,
                       vmstart=args.vmstart,
                       lstag=args.lstag,
                       lptag=args.lptag,
                       vmtag=args.vmtag,
                       desc=args.desc,
                       update=args.update,
                       display=True)
        #elif argsNs['nsgroup'] in [
        #        'memberVM', 'memberIP', 'memberLP', 'memberLS', 'memberType']:
        #    mType = re.sub('member', 'mbr', argsNs['nsgroup'])
        #    nsg.member(mType=mType, namesGlob=args.namesGlob, fmt='jq')
        elif argsNs['nsgroup'] == 'member':
            mType = 'mbr'+args.memberType.upper()
            nsg.member(mType=mType, namesGlob=args.namesGlob, fmt='jq')
        elif argsNs['nsgroup'] == 'create':
            nsg.create(args.nsgSpec)

    elif args.ns == 'syslog':                               # syslog_api
        syslog = Syslog(mgr)
        if argsNs['syslog'] == 'list':
            syslog.list(display=True)
        elif argsNs['syslog'] == 'props':
            syslog.getProperties(display=True)
        elif argsNs['syslog'] == 'find':
            syslog.find(name=args.target,display=True)
        elif argsNs['syslog'] == 'delete':
            syslog.delete(name=args.target,display=True)
        elif argsNs['syslog'] == 'status':
            syslog.status(display=True)
        elif argsNs['syslog'] == 'config':
            syslog.config(name=args.name,
                          server=args.server,
                          port=args.port,
                          protocol=args.protocol,
                          level=args.level,
                          facility=args.facility,
                          cert=args.cert)

    elif args.ns == 'principal':                            # principal_api
        principal=Principal(mgr)
        if argsNs['principal'] == 'list':
            principal.list(restUrl=Principal.api['list'].url)
        elif argsNs['principal'] == 'jq':
            principal.jqTable(nameGlob=args.nameGlob)
        elif argsNs['principal'] == 'create':
            principal.createPrincipal(fqName=args.name, certId=args.certId,
                desc=args.desc, perm=args.permission, role=args. role)
        elif argsNs['principal'] == 'delete':
            principal.deletePrincipal(namesGlob=args.namesGlob, ids=args.id)

    elif args.ns == 'cert':                                 # cert_api
        cert=Certificate(mgr)
        if argsNs['cert'] == 'list':
            cert.list(restUrl='/api/v1/trust-management/certificates',
                      display=True,
                      nameGlob=args.nameGlob,
                      brief=args.brief)
        elif argsNs['cert'] == 'jq':
            cert.jqTable(nameGlob=args.nameGlob)
        elif argsNs['cert'] == 'find':
            cert.findByName(name=args.target,
                            restUrl='/api/v1/trust-management/certificates',
                            display=True,
                            brief=args.brief)
        elif argsNs['cert'] == 'import':
            cert.importCertificate(name=args.name,
                        cert=args.certificate,
                        key=args.key,
                        passphrase=args.passphrase,
                        description=args.description)
        elif argsNs['cert'] == 'applyhttp':
            cert.applyHttpCert(name=args.name)
        elif argsNs['cert'] == 'delete':
            cert.delete(name=args.name,
                        id=args.id)

    elif args.ns == 'vm':                                   # vm_api
        vm =VM(mgr)
        if argsNs['vm'] == 'list':
            vm.list(brief=args.brief, display=True)
        elif argsNs['vm'] == 'find':
            vm.findByName(name=args.name,display=True)
        elif argsNs['vm'] == 'jq':
            vm.jqTable(nameGlob=args.nameGlob)
        elif argsNs['vm'] == 'tag':
            vm.tagOp(args.ns2, args.tagsSpec, args.vmNamesGlob)
        elif argsNs['vm'] == 'vifInfo':
            vm =VM(mgr)
            vm.vmIpList(args.vmNameGlob)

    elif args.ns == 'vif':                                  # vif_api
        vif =VirtualNetworkInterface(mgr)
        if argsNs['vif'] == 'list':
            vif.list(display=True)
        elif argsNs['vif'] == 'jq':
            vif.jqTable(nameGlob=args.nameGlob)

    elif args.ns == 'tag':                                  # tag_api
        tag =Tags(mgr)
        if argsNs['tag'] == 'clear':
            tag.tagOp(argsNs['tag'], resType=args.resType, resNamesGlob=args.namesGlob,
                      parentId=args.parentid, parentName=args.parentname)
        else:   # for op in ['add', 'delete', 'set']
            tag.tagOp(argsNs['tag'], args.tagsSpec, args.resType, args.namesGlob,
                      parentId=args.parentid, parentName=args.parentname)
                      

    elif args.ns == 'firewall':                             # firewall_api
        if argsNs['firewall'] == 'section':
            fwSection=Firewall(mgr)
            if argsNs['fwsection'] == 'list':
                fwSection.listSections(fwtype=args.type, brief=args.brief)
            elif argsNs['fwsection'] == 'jq':
                fwSection.jqTable(apiKey='listL3Section')
            elif argsNs['fwsection'] == 'find':
                fwSection.findSection(name=args.name,fwtype=args.type)
            elif argsNs['fwsection'] == 'delete':
                fwSection.deleteSection(name=args.name,
                                        fwtype=args.type)
            elif argsNs['fwsection'] == 'add':
                fwSection.addSection(name=args.name,
                                     desc=args.desc,
                                     op=args.op,
                                     opsection=args.opsection,
                                     fwtype=args.type,
                                     state=args.stateful,
                                     tags=args.tags,
                                     update=args.update)
            elif argsNs['fwsection'] == 'apply':
                if argsNs['applyto'] == 'add':
                    fwSection.addSectionApplyTo(name=args.name,
                                                target=args.target,
                                                targettype=args.type,
                                                fwtype=args.fwtype)
                elif argsNs['applyto'] == 'delete':
                    fwSection.delSectionApplyTo(name=args.name,
                                                target=args.target,
                                                targettype=args.type,
                                                deleteall=args.all,
                                                fwtype=args.fwtype)
            elif argsNs['fwsection'] == 'rule':
                if argsNs['dfwrules'] == 'list':
                    fwSection.listSectionRules(name=args.section, brief=args.brief)
                elif argsNs['dfwrules'] == 'delete':
                    fwSection.delRuleFromSection(sectionName=args.section,
                                                 name=args.name,
                                                 id=args.id,
                                                 fwtype=args.type)
                elif argsNs['dfwrules'] == 'addsrcdst':
                    fwSection.addSrcDstToRule(sectionName=args.section,
                                              ruleId=args.id,
                                              sources=args.sources,
                                              destinations=args.destinations,
                                              fwtype=args.type)
                elif argsNs['dfwrules'] == 'addservice':
                    fwSection.addServiceToRule(sectionName=args.section,
                                               ruleId=args.id,
                                               services=args.services,
                                               fwtype=args.type)
                elif argsNs['dfwrules'] == 'add':
                    fwSection.addRuleToSection(sectionName=args.section,
                                               name=args.name,
                                               description=args.description,
                                               direction=args.direction,
                                               protocol=args.protocol,
                                               sources=args.sources,
                                               destinations=args.destinations,
                                               services=args.services,
                                               log=args.log,
                                               insertType=args.insert,
                                               referenceId=args.reference,
                                               action=args.action,
                                               update=args.update,
                                               dupcheck=args.dupcheck,
                                               fwtype=args.type)

        elif argsNs['firewall'] == 'services':
            fwSvc = NSServices(mgr)
            if argsNs['fwservice'] == 'list':
                fwSvc.list(brief=args.brief)
            elif argsNs['fwservice'] == 'find':
                if args.name:
                    fwSvc.findByName(name=args.name)
                elif args.id:
                    fwSvc.findById(id=args.id)
                else:
                    print("Must specifiy name or ID, will use name if both specified")

    elif args.ns == 'excludelist':                          # excludelist_api
        exl = ExcludeList(mgr)
        if argsNs['excludelist'] == 'list':
            exl.list(exl.api['list'].url, nameGlob=args.nameGlob)
        elif argsNs['excludelist'] == 'jq':
            exl.jqTable(nameGlob=args.nameGlob, nameTag='target_display_name')
        elif argsNs['excludelist'] == 'add':
            exl.excludeListOp(argsNs['excludelist'], args.name, targetType=args.targetType, fmt='brief')
        elif argsNs['excludelist'] in ['remove', 'check']:
            exl.excludeListOp(argsNs['excludelist'], args.nameGlob, targetType=args.targetType, fmt='brief')


    elif args.ns == 'session':                              # session_api
        sCookie = SessionCookie(mgr, sessCookieFile=args.sessCookieFile)
        if argsNs['session']=='logout':
            sCookie.logout()
        #elif argsNs['session'] == 'create':
        #    sCookie.create()

    elif args.ns == 'eula':                                 # eula_api
        eula = Eula(mgr)
        if args.eulaOp in ['accept', 'acceptance', 'content']:
            eula.eulaOp(args.eulaOp)

    elif args.ns == 'computeManager':                       # computeManager_api
        computeManager = ComputeManager(mgr)
        cmOp = argsNs['computeManager']
        if cmOp == 'list':
            computeManager.list(computeManager.api['list'].url)
        elif cmOp == 'jq':
            computeManager.jqTable(nameGlob=args.nameGlob)
        elif cmOp in ['register', 'update']:
            computeManager.register(cmOp, args.server, args.type,
                username=args.username, password=args.password,
                svrName=args.name, svrThumbprint=args.thumbprint)
        elif cmOp == 'unregister':
            computeManager.cmOp(cmOp, args.nameGlob)
        elif cmOp in ['get', 'state', 'status']:
            computeManager.cmOp(cmOp, args.namesGlob)

    elif args.ns == 'search':                               # search_api
        search = Search(mgr)
        search.query(args.query, args.jqFilter)

    elif args.ns == 'try':                                  # try_api
        vm =VM(mgr)
        vm.vmIpList(args.feature)

    elif args.ns == 'about':                                # about_api
        if args.feature == 'api':
            fname = '%s/../lib/nsxtlib.py' % os.path.dirname(sys.argv[0])
            cmd = '''awk -F'(' '/Api/{print$2}' %s |sed "s/['),]//g" |sed 's/ "/ /g; s/  */\t/' |sort''' % fname
            print(cmd)
            print(commands.getoutput(cmd))
        else:
            #Manager(mgr=mgr).about()
            mp.about()

    elif args.ns == 'api':                                  # api_api
        restOp = argsNs['api']
        headers = kwargs = {}
        if hasattr(args, 'accept') and args.accept:
            headers.update({'Accept':'*/*' if args.accept in ['ANY', '*/*']
                else 'application/'+args.accept})
            kwargs = {'headers':headers}

        mLogger.info1('HTTP %s %s', restOp.upper(), args.url)
        if restOp in ['get', 'delete', 'head', 'options']:
            r = getattr(mgr, restOp)(args.url, **kwargs)
            if restOp == 'head':
                pprint(dict(r.headers), indent=4)
            elif restOp == 'options':
                print(r.headers['allow'])
        elif restOp in ['put', 'post']:
            if args.ctype:
                headers.update({'Content-type':'application/%s'%args.ctype})
                kwargs = {'headers':headers}
            if args.dataFile:
                with open(args.dataFile) as f:
                    data = f.read()
            else:
                data = args.data
            r = getattr(mgr, restOp)(args.url, data, **kwargs)
        #mgr.dumpResquestsResponse(r)
        mLogger.info1('STATUS_CODE: %d %s' % (r.status_code, restlib.statusCode[r.status_code]))
        #print('RESPONSE(r.text):\n%s' % cptutil.StringData(r.text))

        if restOp not in ['head', 'options']:
            if   args.format=='raw':    print(r.text)
            elif args.format=='yaml':   cptutil.pprint_yaml(r.json())
            elif args.format=='json':   cptutil.pprint_json(r.json())
            elif args.format=='xml':    cptutil.pprint_xml(r.text)
            elif args.format=='html':   cptutil.pprint_html(r.text)

        mLogger.info1('RESPONSE(r.headers):\n%s' % pformat(dict(r.headers), indent=4, depth=10))

    elif args.ns == 'policy':                                                   # policy_api
        ns, ns2 = argsNs[args.ns], args.ns2
        if ns == 'deploymentmap':                                               # policy/deploymentmap
            dm = PM_DeploymentMap(policyMgr)
            if ns2 in ['jq', 'list']:
                dm.jqListDeploymentMap(nameGlob=args.nameGlob, op=ns2, domain=args.domain)
            elif ns2 == 'create':
                dm.create(args.domain, args.enforcementpoint)
            elif ns2 == 'delete':
                dm.delete(args.domain, args.enforcementpoint)
        elif ns == 'deploymentzone':                                            # policy/deploymentzone
            dz = PM_DeploymentZone(policyMgr)
            if ns2 == 'list':
                dz.list()
            elif ns2 == 'jq':
                dz.jqDeploymentZone(nameGlob=args.nameGlob)
        elif ns == 'site':                                                      # policy/site
            dz = PM_Site(policyMgr)
            if ns2 == 'list':
                dz.list()
            elif ns2 == 'jq':
                dz.jqDeploymentZone(nameGlob=args.nameGlob)
        elif ns == 'enforcementpoint':                                          # policy/enforcementpoint
            ep = PM_EnforcementPoint(policyMgr)
            if ns2 in ['jq', 'list']:
                ep.jqListEnforcementPoint(nameGlob=args.nameGlob, op=ns2)
        elif ns == 'service':
            service = PM_Service(policyMgr)
            if ns2 == 'list':
                service.list(nameGlob=args.nameGlob)
            elif ns2 == 'jq':
                service.jqTable(nameGlob=args.nameGlob)
            elif ns2 == 'create':
                service.createPMService(args.name, args.spec)
            elif ns2 == 'delete':
                service.deletePMService(args.nameGlob)
        elif ns == 'domain':                                                    # policy/domain
            domain = PM_Domain(policyMgr)
            if ns2 == 'list':
                domain.list(nameGlob=args.nameGlob)
            elif ns2 == 'jq':
                domain.jqDomain(nameGlob=args.nameGlob)
            elif ns2 == 'create':
                domain.create(args.name)
            elif ns2 == 'delete':
                domain.delete(nameGlob=args.nameGlob)
        elif ns == 'group':                                                     # policy/group
            grp = PM_Group(policyMgr)
            if ns2 in ['jq', 'list']:
                grp.jqListGroup(nameGlob=args.nameGlob, op=ns2, domain=args.domain)
            elif ns2 == 'create':
                grp.create(args.name, args.spec, domain=args.domain)
            elif ns2 == 'delete':
                grp.delete(nameGlob=args.namesGlob, domain=args.domain)
        elif ns == 'communicationprofile':                                      # policy/communicationprofile
            commProf = PM_CommunicationProfile(policyMgr)
            if ns2 == 'jq':
                commProf.jqTable(nameGlob=args.nameGlob)
            elif ns2 == 'list':
                commProf.list(nameGlob=args.nameGlob)
            elif ns2 == 'create':
                commProf.create(args.name, args.spec)
            elif ns2 == 'delete':
                commProf.delete(nameGlob=args.nameGlob)
        elif ns == 'communicationmap':                                          # policy/communicationmap
            cm = PM_CommunicationMap(policyMgr)
            if ns2 in ['jq', 'list']:
                cm.jqListCommunicationmap(nameGlob=args.nameGlob, op=ns2, domain=args.domain)
            elif ns2 == 'create':
                cm.create(domain=args.domain, name=args.name,
                    precedence=args.precedence,
                    category=args.category,
                    entriesSpec=args.entriesSpec,
                    applicationSpec=args.applicationSpec,
                    emergencySpec=args.emergencySpec,
                    environmentSpec=args.environmentSpec,
                    infrastructureSpec=args.infrastructureSpec,
                )
            elif ns2 == 'delete':
                cm.delete(domain=args.domain,
                    category=args.category, nameGlob=args.namesGlob)
        elif ns == 'realization':                                               # policy/realization
            realization = PM_Realization(policyMgr)
            if ns2 == 'jq':
                if args.rtype == None:
                    realization.jqTable(nameGlob=args.nameGlob)
                elif args.rtype == 'vm':
                    realization.jqTable(nameGlob=args.nameGlob, apiKey='listVm')
                elif args.rtype == 'vif':
                    realization.jqTable(nameGlob=args.nameGlob, apiKey='listVif')
            elif ns2 == 'list':
                realization.list(nameGlob=args.nameGlob)
        elif ns == 'about':                                                     # policy/about
            if ns2 == 'policyManager':
                Manager(mgr=policyMgr).about(display=True)
        elif ns == 'firewall':                                                  # policy/firewall
            ns3 = args.ns3
            fw = PM_Firewall(policyMgr)
            if ns2 == 'securitypolicy':
                if ns3 == 'create':
                    fw.createpolicy(name=args.name, category=args.category, domain=args.domain, desc=args.desc)
                elif ns3 == 'find':
                    fw.findPolicyByName(policy=args.name, domain=args.domain)
                elif ns3 == 'list':
                    fw.listpolicy(domain=args.domain)
                elif ns3 == 'jq':
                    fw.jqListSecurityPolicy(args.spNameGlob, domain=args.domain, op='jq', listrules=args.listrules)
                elif ns3 == 'delete':
                    fw.deletepolicy(domain=args.domain, nameGlob=args.nameGlob)
                elif ns3 == 'rule':
                    ns4 = args.ns4
                    if ns4 == 'add':
                        fw.addruletopolicy(policyName=args.spolicy,
                                            domain=args.domain,
                                            name=args.name,
                                            description=args.description,
                                            direction=args.direction,
                                            protocol=args.protocol,
                                            sources=args.sources,
                                            destinations=args.destinations,
                                            scopes=args.scope,
                                            services=args.services,
                                            log=args.log,
                                            action=args.action,
                                            disable_state=args.disable,
                                            tag=args.tag)
                    elif ns4 == 'modify':
                        ns5 = args.ns5
                        if ns5 == 'add':
                            fw.modifyrule(type='add',
                                          policy=args.spolicy,
                                          domain=args.domain,
                                          ruleName=args.name,
                                          sources=args.sources,
                                          destinations=args.destinations,
                                          scopes=args.scope,
                                          services=args.services)
                        elif ns5 == 'update':
                            if args.enable is False and args.disable is False:
                                disable = None
                            elif args.enable is True:
                                disable = False
                            else:
                                disable = True
                            fw.modifyrule(type='update',
                                          policy=args.spolicy,
                                          domain=args.domain,
                                          ruleName=args.name,
                                          description=args.description,
                                          direction=args.direction,
                                          protocol=args.protocol,
                                          sources=args.sources,
                                          destinations=args.destinations,
                                          scopes=args.scope,
                                          services=args.services,
                                          log=args.log,
                                          action=args.action,
                                          disable_state=disable,
                                          tag=args.tag)
                        elif ns5 == 'delete':
                            fw.modifyrule(type='delete',
                                          policy=args.spolicy,
                                          domain=args.domain,
                                          ruleName=args.name,
                                          sources=args.sources,
                                          destinations=args.destinations,
                                          scopes=args.scope,
                                          services=args.services)
                    elif ns4 in ['list', 'jq']:
                        fw.listrules(domain=args.domain, policy=args.spolicy,
                                     op=ns4, display=True)

                    elif ns4 == 'find':
                        fw.findRuleByName(ruleName=args.name, policy=args.spolicy, domain=args.domain)
                    elif ns4 == 'delete':
                        fw.deleterule(domain=args.domain, policy=args.spolicy, nameGlob=args.nameGlob)
        elif ns == 'segment':                                                   # policy/segment
            segd = PM_Segment(policyMgr)
            if ns2 == 'list':
                segd.list(nameGlob=args.nameGlob)
            elif ns2 == 'jq':
                segd.jq_PM_Segment(args.nameGlob)
            elif ns2 == 'delete':
                segd.delete_PM_Segment(args.nameGlob)

        elif ns == 'role':                                                      # policy/role
            roled = PM_Role(policyMgr)
            if ns2 == 'list':
                roled.list(nameGlob=args.nameGlob)
            elif ns2 == 'jq':
                if args.binding:
                    roled.jqTable(apiKey='getBinding', nameGlob=args.nameGlob)
                else:
                    roled.jqTable(nameGlob=args.nameGlob)

        elif ns == 'dhcpRelay':                                                 # policy/dhcpRelay
            dhcpRelayObj = PM_DhcpRelay(mgr=mgr)
            if argsNs['ns2'] == 'list':
                dhcpRelayObj.list()
            elif argsNs['ns2'] == 'jq':
                dhcpRelayObj.jqTable(apiKey='list')

        elif ns == 'tier0':                                                     # policy/tier0
            t0Obj = PM_Tier0(policyMgr)
            if ns2 == 'list':
                t0Obj.list()
            elif ns2 == 'jq':
                t0Obj.jqTable()

        elif ns == 'tier1':                                                     # policy/tier1
            t0Obj = PM_Tier1(policyMgr)
            if ns2 == 'list':
                t0Obj.list()
            elif ns2 == 'jq':
                t0Obj.jqTable()

        elif ns == 'prefixList':                                                # policy/prefixList
            t0Obj = PM_Tier0(policyMgr)
            t0s = t0Obj.findByNamesGlob(['*'])
            t0Names = [t0['display_name'] for t0 in t0s]
            pfxlObj = PM_PrefixList(policyMgr)
            if ns2 == 'list':
                for t0Name in t0Names:
                    restUrl = eval(pfxlObj.api['list'].url)
                    pfxlObj.list(restUrl=restUrl)
            elif ns2 == 'jq':
                for t0Name in t0Names:
                    print('Tier0: %s' % t0Name)
                    restUrl = eval(pfxlObj.api['list'].url)
                    t0Dict = pfxlObj.list(restUrl=restUrl, display=False)
                    pfxlObj.jqTable(jsonStr=t0Dict)

    elif args.ns == 'lb':                                   # lb_api
        if argsNs['lb'] == 'service':
            lb = LbService(mgr)
            if argsNs['lbservice'] == 'list':
                print("doing list")
                lb.list(display=True)
            elif argsNs['lbservice'] == 'jq':
                lb.jqTable(nameGlob=args.nameGlob)
            elif argsNs['lbservice'] == 'create':
                lb.createLbService(name=args.name, size=args.size, desc=args.desc,
                                   logLevel=args.log)
            elif argsNs['lbservice'] == 'attach':
                lb.attachment(action=args.action, lbname=args.lbname, lrname=args.lr)
            elif argsNs['lbservice'] == 'vipattach':
                lb.attachVip(lbname=args.lbname, action=args.action, vips=args.vip)

        elif argsNs['lb'] == 'pool':
            lp = LbPool(mgr)
            if argsNs['lbpool'] == 'list':
                lp.list(display=True)
            elif argsNs['lbpool'] == 'jq':
                lp.jqTable(nameGlob=args.nameGlob)
            elif argsNs['lbpool'] == 'create':
                lp.createLbPool(name=args.name, desc=args.desc, algorithm=args.algorithm,
                                minMem=args.minMem,
                                multiplex=args.multiplex,
                                multiCount=args.multicount,
                                nat=args.nat, overload=args.overload,
                                addr=args.addr)
            elif argsNs['lbpool'] == 'member':
                lp.updateMembers(pool=args.pool, action=args.action, ip=args.ip,
                                 name=args.name, state=args.disable,
                                 backup=args.backup, maxCon=args.maxcon,
                                 port=args.port, weight=args.weight)

            elif argsNs['lbpool'] == 'group':
                lp.updateDynamicMember(pool=args.pool,action=args.action,
                                       nsgroup=args.nsgroup,
                                       ipfilter=args.ipfilter,
                                       port=args.port)
            elif argsNs['lbpool'] == 'monitor':
                lp.updateMonitor(pool=args.pool, action=args.action,
                                 active=args.active,passive=args.passive)


        elif argsNs['lb'] == 'monitor':
            lm = LbMonitor(mgr)
            if argsNs['lbmonitor'] == 'list':
                lm.list(display=True)
            elif argsNs['lbmonitor'] == 'jq':
                lm.jqTable(nameGlob=args.nameGlob)
            elif argsNs['lbmonitor'] == 'create':
                if argsNs['lbmoncreate'] == 'icmp':
                    lm.configIcmp(name=args.name, fall=args.fall,
                                  rise=args.rise, interval=args.interval,
                                  timeout=args.timeout, size=args.size,
                                  desc=args.desc)
                elif argsNs['lbmoncreate'] == 'tcp':
                    lm.configTcp(name=args.name, fall=args.fall,
                                 rise=args.rise, port=args.port,
                                 interval=args.interval,
                                 receive=args.receive, send=args.send,
                                 timeout=args.timeout, desc=args.desc)
                elif argsNs['lbmoncreate'] == 'passive':
                    lm.configPassive(name=args.name, fails=args.fails,
                                     timeout=args.timeout, desc=args.desc)
                elif argsNs['lbmoncreate'] == 'http':
                    lm.configHttp(name=args.name, port=args.port,
                                  fall=args.fall, rise=args.rise,
                                  interval=args.interval, body=args.body,
                                  headerName=args.headername,
                                  headerValue=args.headervalue,
                                  reqMethod=args.method,
                                  url=args.url,
                                  version=args.version,
                                  responsebody=args.responsebody,
                                  responseCode=args.responsecode,
                                  timeout=args.timeout,
                                  desc=args.desc)
                elif argsNs['lbmoncreate'] == 'https':
                    lm.configHttps(name=args.name, port=args.port,
                                   fall=args.fall, rise=args.rise,
                                   interval=args.interval,
                                   body=args.body,
                                   headerName=args.headername,
                                   headerValue=args.headervalue,
                                   reqMethod=args.method,
                                   url=args.url,
                                   certDepth=args.certdepth,
                                   ciphers=args.ciphers,
                                   clientCert=args.clientcert,
                                   protocols=args.protocols,
                                   serverAuth=args.serverauth,
                                   ca=args.ca,crl=args.crl,
                                   version=args.version,
                                   responseBody=args.responsebody,
                                   responseCode=args.responsecode,
                                   timeout=args.timeout,
                                   desc=args.desc)
                                   


        elif argsNs['lb'] == 'vip':
            vip=LbVip(mgr)
            if argsNs['lbvip'] == 'list':
                vip.list(display=True)
            elif argsNs['lbvip'] == 'jq':
                vip.jqTable(nameGlob=args.nameGlob)
            elif argsNs['lbvip'] == 'config':
                vip.config(name=args.name, vip=args.vip,
                           ports=args.ports,
                           pool=args.pool,
                           appProfile=args.appProfile,
                           clientSslCert=args.sslCert,
                           clientSslProfile=args.clientSslProfile,
                           maxConcurrent=args.maxConcurrent,
                           maxNewConnRate=args.maxNewConnRate,
                           persistenceProfile=args.persistenceProfile,
                           desc=args.desc, tags=args.tags)
                           
    elif args.ns == 'ipam':                                 # ipam_api
        ipam = Ipam(mgr)
        if argsNs['ipam'] == 'list':
            ipam.list(display=True)
        elif argsNs['ipam'] == 'config':
            ipam.config(name=args.name, cidr=args.cidr,
                        desc=args.desc, tags=args.tags)
            
    elif args.ns == 'global':                               # global_api
        glob = Global(mgr)
        if argsNs['global'] == 'list':
            glob.list(display=True)
        elif argsNs['global'] == 'jq':
            glob.jqTable()

    elif args.ns == 'vidm':                                 # vidm_api
        vidmObj = Vidm(mgr)
        if argsNs['vidm'] == 'list':
            vidmObj.list(display=True)
        elif argsNs['vidm'] == 'jq':
            vidmObj.jqTable()


def createCommonParsers(parser, names=[], arguments=None):
    '''
    arguments should be a list, if specified
    '''
    if 'jq' in names:
        p = parser.add_parser('jq')
        if arguments:
            for i in arguments:
                arg='--'+i
                p.add_argument(arg)

if __name__ == "__main__":
    main()
