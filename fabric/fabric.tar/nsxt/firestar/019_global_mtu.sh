#!/usr/bin/bash
 ~/cpt/nsxp/nsxp.py tmgr global switch --mtu 8000
