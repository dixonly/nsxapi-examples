#!/usr/bin/bash

~/cpt/nsxp/nsxt.py tmgr1 cluster  fqdn set
