#!/usr/bin/bash

image=$1

# Deploy 2 edges for core
for i in {1..12}; do
    name=te${i}
    hostip=`host ${name}.cptroot.com |awk {'print $4'}`
echo $hostip
ovftool \
--targetType=VI \
--allowExtraConfig \
--name="${name}" \
--datastore='cmgmt' \
--acceptAllEulas \
--net:"Network 0=DVS4-mgmt" --net:"Network 1=DVS4-EdgeTrunk" --net:"Network 2=DVS4-EdgeTrunkLeft" --net:"Network 3=DVS4-EdgeTrunkRight" \
--prop:'nsx_passwd_0=CptWare12345!' \
--prop:'nsx_cli_passwd_0=CptWare12345!' \
--prop:'nsx_cli_audit_passwd_0=CptWare12345!' \
--prop:"nsx_hostname=${name}" \
--prop:'nsx_gateway_0=71.12.31.254' \
--prop:"nsx_ip_0=${hostip}" \
--prop:'nsx_netmask_0=255.255.255.0' \
--prop:'nsx_dns1_0=10.172.106.1' \
--prop:'nsx_domain_0=cptroot.com' \
--prop:'nsx_ntp_0=10.172.106.1' \
--prop:'nsx_isSSHEnabled=True' \
--prop:'nsx_allowSSHRootLogin=True' \
--deploymentOption="large" \
--powerOn \
--noSSLVerify \
--vmFolder='Edges' \
http://sc2-dhcp.cptroot.com/iso/${image} \
vi://sfadmin:'Vmware123!'@sfvc2/SF2/host/MGMT &

done

