~/cpt/nsxp/nsxt.py -u sfadmin@ad.cptroot.com -p 'Vmware123!' tmgr.cptroot.com session create --filename session.txt
~/cpt/nsxp/nsxt.py --cookie session.txt tmgr.cptroot.com tier1 config --name CoreT1 --tier0 CoreT0 --advertisements TIER1_STATIC_ROUTES TIER1_CONNECTED TIER1_NAT TIER1_LB_VIP TIER1_LB_SNAT --dhcprelay sc2dhcp

#~/cpt/nsxp/nsxt.py --cookie session.txt tmgr.cptroot.com  edgecluster --name CoreT1 --cluster ec1

for n in {11..14}; do 
 for i in {1..254}; do
    sw="LS-72.${n}.${i}.0"
    gw="72.${n}.${i}.254/24"
    dhcp="72.${n}.${i}.1-72.${n}.${i}.2"
    gw6="fd00:72:${n}:${i}::254/64"
    echo "Creating ${sw}"
    ~/cpt/nsxp/nsxt.py --cookie session.txt tmgr.cptroot.com segment config --name ${sw} --tz TM-OVERLAY --lr CoreT1 --gw ${gw} ${gw6} --dhcp ${dhcp}
 done
done

