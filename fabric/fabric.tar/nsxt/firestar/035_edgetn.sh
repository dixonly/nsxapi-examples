#!/usr/bin/bash
x=48
#for i in {1806..1809}; do
#    echo "Working on core edges for sfmgr"
#      ~lyd/cpt/nsxt/nsxt-ctl.py  sfmgr tn config --node d${i}-10-172-107-${x}.cptroot.com --hswname hsw --nics fp-eth4 fp-eth5 --uplinkprofile uplink-2033-as --lldpprofile lldp --ippool TEP-71.218.33.0 --tzname SF-OVERLAY
#      #~lyd/cpt/nsxt/nsxt-ctl.py  sfmgr tn update --node d${i}-10-172-107-${x}.cptroot.com --hswname +rtvlan1 --nics fp-eth2 --uplinkprofile uplink-2033-edgevm --lldpprofile lldp
#      #~lyd/cpt/nsxt/nsxt-ctl.py sfmgr tn addtz --node d${i}-10-172-107-${x}.cptroot.com --tz SF-RTVLAN1
#
#      #~lyd/cpt/nsxt/nsxt-ctl.py sfmgr tn update --node d${i}-10-172-107-${x}.cptroot.com --hswname +rtvlan2 --nics fp-eth3 --uplinkprofile uplink-2033-edgevm --lldpprofile lldp
#      #~lyd/cpt/nsxt/nsxt-ctl.py sfmgr tn addtz --node d${i}-10-172-107-${x}.cptroot.com --tz SF-RTVLAN2
#      ~lyd/cpt/nsxt/nsxt-ctl.py  sfmgr tn addtz --node d${i}-10-172-107-${x}.cptroot.com --tz SF-VLAN-BMEdge
#      x=$((x+1))
#done
    

for i in {1..8}; do
      ~lyd/cpt/nsxt/nsxt-ctl.py  tmgr tn config --node te${i} --hswname hsw --nics fp-eth0 --uplinkprofile uplink-2037-edgevm  --ippool ETEP-71.12.37.0 --tzname TM-OVERLAY
      ~lyd/cpt/nsxt/nsxt-ctl.py  tmgr tn update --node te${i} --hswname +rtvlan1 --nics fp-eth1 --uplinkprofile uplink-2037-edgevm
      ~lyd/cpt/nsxt/nsxt-ctl.py tmgr tn addtz --node te${i} --tz TM-RTVLAN1
      ~lyd/cpt/nsxt/nsxt-ctl.py  tmgr tn update --node te${i} --hswname +rtvlan2 --nics fp-eth2 --uplinkprofile uplink-2037-edgevm
      ~lyd/cpt/nsxt/nsxt-ctl.py tmgr tn addtz --node te${i} --tz TM-RTVLAN2
done
