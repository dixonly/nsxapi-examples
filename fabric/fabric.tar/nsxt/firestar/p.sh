#!/usr/bin/bash
image=$1
node=1
host=0
# Number of setups
FIRST=1
LAST=3


ip=`host pmgr.cptroot.com |awk {'print $4'}`
ovftool \
--targetType=VI \
--allowExtraConfig \
--name="pmgr" \
--datastore='c20vsan' \
--acceptAllEulas \
--network='LS0001' \
--X:injectOvfEnv \
--prop:'nsx_passwd_0=CptWare12345!' \
--prop:'nsx_cli_passwd_0=CptWare12345!' \
--prop:'nsx_cli_audit_passwd_0=CptWare12345!' \
--prop:"nsx_hostname=sfmgr${i}" \
--prop:"nsx_role=nsx-manager nsx-controller" \
--prop:'nsx_gateway_0=10.172.165.254' \
--prop:"nsx_ip_0=${ip}" \
--prop:'nsx_netmask_0=255.255.255.0' \
--prop:'nsx_dns1_0=10.172.106.1 10.114.13.7' \
--prop:'nsx_domain_0=cptroot.com' \
--prop:'nsx_ntp_0=10.172.106.1 10.114.13.7' \
--prop:'nsx_isSSHEnabled=True' \
--prop:'nsx_allowSSHRootLogin=True' \
--prop:'nsx_allowSSHRootLogin=True' \
--powerOn \
--noSSLVerify \
--vmFolder='SF' \
http://cpt-linux.cptroot.com/iso/$image \
vi://admin:'Vmware123!'@sc2-infra-vc/SC2/host/C20VSAN&


