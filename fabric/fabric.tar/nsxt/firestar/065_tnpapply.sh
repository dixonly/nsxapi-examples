~lyd/cpt/nsxp/nsxp.py tmgr tncollection config --computecollection Cluster202 --tnprofile TNP_Cluster202
~lyd/cpt/nsxp/nsxp.py tmgr tncollection config --computecollection Cluster203 --tnprofile TNP_Cluster203
~lyd/cpt/nsxp/nsxp.py tmgr tncollection config --computecollection Cluster204 --tnprofile TNP_Cluster204
