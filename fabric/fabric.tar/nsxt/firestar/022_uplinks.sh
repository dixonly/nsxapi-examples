#!/usr/bin/bash

~lyd/cpt/nsxt/nsxt-ctl.py tmgr uplink config uplink.json
