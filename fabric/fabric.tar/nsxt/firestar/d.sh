#!/usr/bin/bash

image=$1

# Deploy 2 edges for core
for i in {17..17}; do
    name=sfe${i}
    hostip=`host ${name}.cptroot.com |awk {'print $4'}`
echo $hostip
ovftool \
--targetType=VI \
--allowExtraConfig \
--name="${name}" \
--datastore='sc2_nfs1' \
--acceptAllEulas \
--X:logFile="tmp/${name}.log" \
--net:"Network 0=DVS4-EdgeMgmt-LS" --net:"Network 1=DVS4-EdgeTrunk-LS" --net:"Network 2=DVS4-EdgeTrunkLeft-LS" --net:"Network 3=DVS4-EdgeTrunkRight-LS" \
--prop:'nsx_passwd_0=CptWare12345!' \
--prop:'nsx_cli_passwd_0=CptWare12345!' \
--prop:'nsx_cli_audit_passwd_0=CptWare12345!' \
--prop:"nsx_hostname=${name}" \
--prop:'nsx_gateway_0=71.218.31.254' \
--prop:"nsx_ip_0=${hostip}" \
--prop:'nsx_netmask_0=255.255.255.0' \
--prop:'nsx_dns1_0=10.172.106.1' \
--prop:'nsx_domain_0=cptroot.com' \
--prop:'nsx_ntp_0=10.172.106.1' \
--prop:'nsx_isSSHEnabled=True' \
--prop:'nsx_allowSSHRootLogin=True' \
--deploymentOption="large" \
--powerOn \
--noSSLVerify \
--vmFolder='Edges' \
http://sc2-dhcp.cptroot.com/iso/${image} \
vi://sfadmin:'Vmware123!'@sfvc1/SF1/host/Cluster103 &

done

