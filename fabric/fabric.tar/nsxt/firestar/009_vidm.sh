../../nsxp/nsxp.py 10.172.165.172  vidm config  --vidmhost sc2-vidm.cptroot.com --client sfmgr --secret 'Vmware123!' --host tmgr.cptroot.com --enable --lb
