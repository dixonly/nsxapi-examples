#!/usr/bin/bash

# Create DHCP profile and services for LR consumption later
echo "Creating DHCP profile and relay services"
~/cpt/nsxp/nsxt.py tmgr dhcprelay   config --name sc2dhcp --servers 10.172.106.4
~/cpt/nsxp/nsxp.py tmgr global routing --l3mode IPV4_AND_IPV6
#create the Tier0
~/cpt/nsxp/nsxt.py tmgr  tier0 config --name CoreT0 --ha ACTIVE_ACTIVE --dhcprelay sc2dhcp
~/cpt/nsxp/nsxt.py tmgr tier0 locale edgecluster --name CoreT0 --cluster ec1
~/cpt/nsxp/nsxt.py tmgr tier0 locale  redist --name CoreT0 --types TIER0_STATIC TIER0_SEGMENT TIER0_SERVICE_INTERFACE TIER1_NAT TIER1_STATIC TIER1_LB_VIP TIER1_LB_SNAT TIER1_CONNECTED

#create uplink segments
~/cpt/nsxp/nsxt.py tmgr segment config --name Edge2034 --tz TM-RTVLAN1 --vlan 2034
~/cpt/nsxp/nsxt.py tmgr segment config --name Edge2035 --tz TM-RTVLAN2 --vlan 2035


for i in {1..8}; do
        ~/cpt/nsxp/nsxt.py tmgr tier0 interface config --name CoreT0 --int te${i}-1 --cidr 71.12.34.5${i}/24 fd00:71:12:34::5${i}/64 --edge te${i} --type EXTERNAL --segment Edge2034 --desc "Uplink from te${i} to left switch"
        ~/cpt/nsxp/nsxt.py tmgr tier0 interface config --name CoreT0 --int te${i}-2 --cidr 71.12.35.5${i}/24 fd00:71:12:35::5${i}/64 --edge te${i} --type EXTERNAL --segment Edge2035 --desc "Uplink from te${i} to right switch"
done


~/cpt/nsxp/nsxt.py tmgr  prefixlist config --t0 CoreT0 --name no_self --prefix 72.0.0.0/8,8,,DENY 0.0.0.0/0,,32,permit
~/cpt/nsxp/nsxt.py tmgr prefixlist config --t0 CoreT0 --name no_self6 --prefix fd00:72::/32,64,,DENY ::/0,,128,permit

~/cpt/nsxp/nsxt.py tmgr tier0 bgp config --name CoreT0 --local_as 1065000 --enable_intersr --enable_ecmp --enable_gr
~/cpt/nsxp/nsxt.py tmgr tier0 bgp neighbor config --name CoreT0 --peer N9k-b12-1 --remoteAs 4000 --address 71.12.34.252 --keepalive 2 --holdtime 8 --secret 'Vmware123!' --inprefixlist no_self --gr GR_AND_HELPER
~/cpt/nsxp/nsxt.py tmgr tier0 bgp neighbor config --name CoreT0 --peer N9k-b12-2 --remoteAs 4000 --address 71.12.35.253 --keepalive 2 --holdtime 8 --secret 'Vmware123!' --inprefixlist no_self --gr GR_AND_HELPER


~/cpt/nsxp/nsxt.py tmgr tier0 bgp neighbor config --name CoreT0 --peer N9k-b12-1-v6 --remoteAs 4000 --address fd00:71:12:34::252 --keepalive 2 --holdtime 8 --secret 'Vmware123!' --inprefixlist no_self6 --gr GR_AND_HELPER --ipv6
~/cpt/nsxp/nsxt.py tmgr tier0 bgp neighbor config --name CoreT0 --peer N9k-b12-2-v6 --remoteAs 4000 --address fd00:71:12:35::253 --keepalive 2 --holdtime 8 --secret 'Vmware123!' --inprefixlist no_self6 --gr GR_AND_HELPER --ipv6
