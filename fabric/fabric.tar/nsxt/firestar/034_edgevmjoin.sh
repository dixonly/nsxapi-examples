#!/usr/bin/bash

# first and last tenants

# Corporate site
for i in {1..12}; do 
    echo "Joining te${i} to tmgr"
    ~lyd/cpt/nsxt/nsxt-ctl.py -u admin -p 'CptWare12345!' tmgr edge joinmp tmgr te${i} &
done



