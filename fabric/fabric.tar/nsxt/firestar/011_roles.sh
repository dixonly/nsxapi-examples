../../nsxp/nsxp.py -u admin -p 'CptWare12345!' tmgr  role bindings add --name sfadmin@ad.cptroot.com --type remote_user --roles enterprise_admin
../../nsxp/nsxp.py -u admin -p 'CptWare12345!' tmgr  role bindings add --name lyd@ad.cptroot.com --type remote_user --roles enterprise_admin
../../nsxp/nsxp.py -u admin -p 'CptWare12345!' tmgr  role bindings add --name sfread@ad.cptroot.com --type remote_user --roles auditor
