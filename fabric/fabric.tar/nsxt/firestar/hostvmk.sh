for i in {13..28}; do ~/cpt/vm/addVmkToHost.py -u sfadmin -v sfvc2 -p 'Vmware123!' -d SF2  -s b12${i}.cptroot.com -w DVS4 -g DVS4-Vmotion -t vmotion; done
for i in {13..24}; do ~/cpt/vm/addVmkToHost.py -u sfadmin -v sfvc2 -p 'Vmware123!' -d SF2  -s b12${i}.cptroot.com -w DVS4 -g DVS4-VSAN -t vsan; done

for i in {37..40}; do ~/cpt/vm/addVmkToHost.py -u sfadmin -v sfvc2 -p 'Vmware123!' -d SF2  -s c24${i}-70-0-24-${i}.cptroot.com -w DVS3 -g DVS3-Vmotion -t vmotion; done
for i in {37..40}; do ~/cpt/vm/addVmkToHost.py -u sfadmin -v sfvc2 -p 'Vmware123!' -d SF2 -s c24${i}-70-0-24-${i}.cptroot.com -w DVS3 -g DVS3-VSAN -t vsan; done
