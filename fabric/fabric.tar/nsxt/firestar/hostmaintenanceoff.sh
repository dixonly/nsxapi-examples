~/cpt/vm/maintenanceMode.py  -s sfvc2 -u sfadmin -d SF2 -p 'Vmware123!' -c Cluster202 -a off
~/cpt/vm/maintenanceMode.py  -s sfvc2 -u sfadmin -d SF2 -p 'Vmware123!' -c Cluster203 -a off
~/cpt/vm/maintenanceMode.py  -s sfvc2 -u sfadmin -d SF2 -p 'Vmware123!' -c Cluster204 -a off
