#!/usr/bin/bash

~/cpt/nsxp/nsxp.py   tmgr1 cluster  join --primary 71.12.31.1 --secondaries 71.12.31.2 71.12.31.3

