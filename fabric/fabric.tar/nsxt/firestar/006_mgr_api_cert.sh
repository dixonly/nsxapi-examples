#!/usr/bin/bash


~lyd/cpt/nsxt/nsxt-ctl.py -p 'CptWare12345!' tmgr1 cert applyhttp --name tmgr
~lyd/cpt/nsxt/nsxt-ctl.py -p 'CptWare12345!' tmgr2 cert applyhttp --name tmgr
~lyd/cpt/nsxt/nsxt-ctl.py -p 'CptWare12345!' tmgr3 cert applyhttp --name tmgr
