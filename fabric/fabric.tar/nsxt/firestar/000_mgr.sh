#!/usr/bin/bash
image=$1
node=1
host=0
# Number of setups
FIRST=1
LAST=3

for i in `seq ${FIRST} ${LAST}`; do

ip=`host tmgr${i}.cptroot.com |awk {'print $4'}`
ovftool \
--targetType=VI \
--allowExtraConfig \
--name="tmgr${i}" \
--datastore='cmgmt' \
--acceptAllEulas \
--network='DVS4-mgmt' \
--X:injectOvfEnv \
--prop:'nsx_passwd_0=CptWare12345!' \
--prop:'nsx_cli_passwd_0=CptWare12345!' \
--prop:'nsx_cli_audit_passwd_0=CptWare12345!' \
--prop:"nsx_hostname=tmgr${i}" \
--prop:"nsx_role=NSX Manager" \
--prop:'nsx_gateway_0=71.12.31.254' \
--prop:"nsx_ip_0=${ip}" \
--prop:'nsx_netmask_0=255.255.255.0' \
--prop:'nsx_dns1_0=10.172.106.1' \
--prop:'nsx_domain_0=cptroot.com' \
--prop:'nsx_ntp_0=10.172.106.1' \
--prop:'nsx_isSSHEnabled=True' \
--prop:'nsx_allowSSHRootLogin=True' \
--prop:'nsx_allowSSHRootLogin=True' \
--powerOn \
--noSSLVerify \
--vmFolder='Mgmt' \
http://cpt-linux.cptroot.com/iso/$image \
vi://sfadmin:'Vmware123!'@sfvc2/SF2/host/MGMT&


done

