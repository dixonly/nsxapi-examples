for i in {13..16}; do ~/cpt/nsxv/vs-ctl.py -u sfadmin sfvc2 cluster moveinto Cluster202 b12${i}.cptroot.com; done
for i in {17..20}; do ~/cpt/nsxv/vs-ctl.py -u sfadmin sfvc2 cluster moveinto Cluster203 b12${i}.cptroot.com; done
for i in {21..24}; do ~/cpt/nsxv/vs-ctl.py -u sfadmin sfvc2 cluster moveinto Cluster204 b12${i}.cptroot.com; done
