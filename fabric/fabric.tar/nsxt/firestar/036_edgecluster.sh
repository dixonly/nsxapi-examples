#!/usr/bin/bash

#~lyd/cpt/nsxt/nsxt-ctl.py tmgr edgecluster config --name ec1 --members d1806-10-172-107-48.cptroot.com d1807-10-172-107-49.cptroot.com d1808-10-172-107-50.cptroot.com d1809-10-172-107-51.cptroot.com 
~lyd/cpt/nsxt/nsxt-ctl.py tmgr edgecluster config --name ec1 --members te1 te2 te3 te4 te5 te6 te7 te8
~/cpt/nsxp/nsxt.py tmgr enforce reload
