#!/usr/bin/python

~/cpt/nsxp/nsxp.py tmgr segment config  --name MGMT-VLAN3000-Native --tz TM-VLAN --vlans 0
~/cpt/nsxp/nsxp.py tmgr segment config  --name VMOTION-VLAN2032 --tz TM-VLAN --vlans 2032
~/cpt/nsxp/nsxp.py tmgr segment config  --name VSAN-VLAN2033 --tz TM-VLAN --vlans 2033
