#!/usr/bin/bash


~lyd/cpt/nsxp/nsxp.py -p 'CptWare12345!' tmgr1 cluster vip set --ip 10.172.165.172
