#!/usr/bin/bash
~lyd/cpt/nsxt/nsxt-ctl.py tmgr pools config ip.json
