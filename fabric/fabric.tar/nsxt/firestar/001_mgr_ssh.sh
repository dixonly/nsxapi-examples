#!/usr/bin/bash

~lyd/cpt/vm/ssh_pub_linuxcopy.py -u root -p 'CptWare12345!' --rsafile public_rsa.pub  -e tmgr1
~lyd/cpt/vm/ssh_pub_linuxcopy.py -u root -p 'CptWare12345!' --rsafile public_rsa.pub  -e tmgr2
~lyd/cpt/vm/ssh_pub_linuxcopy.py -u root -p 'CptWare12345!' --rsafile public_rsa.pub  -e tmgr3

scp  -q -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null public_rsa.pub root@tmgr1:/home/admin/.ssh/authorized_keys
scp -q -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null  public_rsa.pub root@tmgr2:/home/admin/.ssh/authorized_keys
scp  -q -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null public_rsa.pub root@tmgr3:/home/admin/.ssh/authorized_keys

ssh  -q -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null root@tmgr1 chown admin /home/admin/.ssh/authorized_keys
ssh  -q -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null root@tmgr2 chown admin /home/admin/.ssh/authorized_keys
ssh  -q -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null root@tmgr3 chown admin /home/admin/.ssh/authorized_keys

ssh  -q -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null root@tmgr1 chmod 600 /home/admin/.ssh/authorized_keys
ssh  -q -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null root@tmgr2 chmod 600 /home/admin/.ssh/authorized_keys
ssh  -q -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/nullroot@tmgr3 chmod 600 /home/admin/.ssh/authorized_keys

 ~lyd/cpt/nsxt/nsxt-ctl.py tmgr1 syslog config --name sc2dhcp --server sc2-dhcp.cptroot.com --level INFO --protocol UDP --port 514
 ~lyd/cpt/nsxt/nsxt-ctl.py tmgr2 syslog config --name sc2dhcp --server sc2-dhcp.cptroot.com --level INFO --protocol UDP --port 514
 ~lyd/cpt/nsxt/nsxt-ctl.py tmgr3 syslog config --name sc2dhcp --server sc2-dhcp.cptroot.com --level INFO --protocol UDP --port 514
