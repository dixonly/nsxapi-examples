#!/usr/bin/bash


#    ~lyd/cpt/nsxt/nsxt-ctl.py -u admin -p 'CptWare12345!' tmgr1 cert import --certificate ~lyd/cpt/nsxt/sfflash/cpt-linux.pem --name cptlinux --description "CPT CA - cpt-linux.cptroot.com"
#    ~lyd/cpt/nsxt/nsxt-ctl.py -u admin -p 'CptWare12345!' tmgr1 cert import --certificate ~lyd/cpt/nsxt/sfflash/cptlinux2.cert --name cptlinux2 --description "CPT intermediate CA - cpt-linux2.cptroot.com"
#    ~lyd/cpt/nsxt/nsxt-ctl.py -u admin -p 'CptWare12345!' tmgr1 cert import --certificate ~lyd/cpt/nsxt/sfflash/intermediate.chain --name cptintermediate --description "CPT intermediate CA Chain"
    ~lyd/cpt/nsxt/nsxt-ctl.py -u admin -p 'CptWare12345!' tmgr1 cert import --certificate ~lyd/cpt/nsxt/certs/tmgr.chain --key ~lyd/cpt/nsxt/certs/tmgr.key --name tmgr --description "NSX Manager - tmgr.ptroot.com"



