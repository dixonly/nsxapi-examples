~/cpt/vm/maintenanceMode.py  -s sfvc2 -u sfadmin -d SF2 -p 'Vmware123!' -c TMP -a on
