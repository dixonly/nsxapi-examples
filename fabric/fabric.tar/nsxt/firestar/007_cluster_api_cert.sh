#!/usr/bin/bash

~lyd/cpt/nsxp/nsxp.py  tmgr cluster cert set --name tmgr
