#!/usr/bin/bash

~/cpt/nsxt/nsxt-ctl.py  tmgr tz config tz.json
~/cpt/nsxp/nsxt.py tmgr enforce reload
