~/cpt/nsxt/nsxt-ctl.py tmgr computeManager register --username sfadmin --password 'Vmware123!' --name sfvc2 sfvc2.cptroot.com

