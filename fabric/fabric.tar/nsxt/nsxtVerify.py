#!/usr/bin/env python
from __future__ import print_function
import pinit
import subprocess, platform, ast, datetime
import cptutil, nsxtlib
import subprocess, sys, os, platform
import commands, time, commands, ssl, OpenSSL.crypto, socket, argparse, inspect
import logging, re, json, pyjq, prettytable
import paramiko, paramikolib
from pprint import pprint, pformat
from testResult import TestResult
from cptutil import listify, strifyDictKV, pprint_json

############################## UTILITY FUNCTIONS ##############################
def myCurFunc(curFrame=None):
    '''myCurFunc here refers to the colling function'''
    # https://stackoverflow.com/questions/4492559/how-to-get-current-function-into-a-variable
    curFrame = curFrame or inspect.currentframe()
    parFrame = curFrame.f_back
    #parFnName = inspect.getframeinfo(parFrame)[2]
    parFnName = inspect.getframeinfo(parFrame).function
    myFunc = parFrame.f_locals.get(
        parFnName, parFrame.f_globals.get(parFnName))
    return myFunc

def myCurFuncDoc():
    '''myCurFunc here refers to the colling function'''
    return myCurFunc(inspect.currentframe()).__doc__.strip()

def myCurFuncName():
    '''myCurFunc here refers to the colling function'''
    return myCurFunc(inspect.currentframe()).__name__

def pingable(host, retry=1, timeout=2):
    try:
        pingCmd = "ping -nc %s -W %s %s" % (retry+1, timeout, host)
        output = subprocess.check_output(pingCmd, shell=True)
    except Exception, e:
        return False
    return True

############################ VERIFICATION FUNCTIONS ############################
def verify_managerNode(mp, mgrVersion):
    '''node is Pingable, check API service, node version'''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())

    nodeIp = mp.host
    nodePingable = pingable(nodeIp)
    mp.testResult.addVerify('%s pingable: %s' % (nodeIp, nodePingable))

    if nodePingable:
        vUrl = mp.api['about'].url
        r = mp.rest_api(mp.api['about'].url)

        apiDict = {'url':vUrl, 'response':r.json()}
        mp.testResult.appendAttr('steps', '', {'api': apiDict})
        if r.ok:
            mgrAbout = r.json()
            #pprint(mgrAbout)
            nodeHostname = mgrAbout['hostname']
            if mgrAbout['node_version'] == mgrVersion:
                mp.testResult.addVerify('manager node %s versions correct: %s' % (nodeIp, mgrVersion))
            else:
                mp.testResult.addError('ERROR: manager node  %s version(%s) != config version(%s)' % (
                    nodeIp, mgrAbout['node_version'], mgrVersion))
        else:
            mp.testResult.addError('ERROR: Problem accessing manager node %s API service' % nodeIp)
    else:
        mp.testResult.addError('ERROR: Manager node %s not pingable' % nodeIp)

    mp.testResult.epilogue()

def verify_managerClusterHealth(mp, mgrNodes=[]):
    '''Check groups stability, group membership, group member up/down status'''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())

    mgrIps = [cptutil.host2ip(h) for h in mgrNodes]
    mp.logger.debug(mgrIps)
    mc = nsxtlib.ManagerCluster(mp=mp)
    jqTableDict = mc.jqTable(apiKey='status', display=False)
    cmDicts = jqTableDict['rows']
    apiDict = {'url':jqTableDict['restUrl'], 'response':jqTableDict['restRespJson']}
    mp.testResult.appendAttr('steps', '', {'api': apiDict})

    for cmDict in cmDicts:
        #pprint(cmDict)
        if cmDict['group_status']=='STABLE':
            mp.testResult.addVerify('cluster group %s is stable' % cmDict['group_type'])
        else:
            mp.testResult.addError('ERROR: GROUP:%s STATUS:%s' % (cmDict['group_type'], cmDict['group_status']))

        if cmDict['members']:
            allMemberUp = True
            tbMgrIps = [n['ip'] for n in cmDict['members']]
            mgrDiff = list(set(mgrIps)-set(tbMgrIps))
            mp.logger.debug(tbMgrIps)
            if mgrDiff:
                mp.testResult.addError('ERROR: GROUP:%s Missing manager node %s from testbed'
                    % (cmDict['group_type'], mgrDiff))
            else:
                mp.testResult.addVerify('cluster group %s: all nodes are memeber' % cmDict['group_type'])
            for m in cmDict['members']:
                if m['status']!='UP':
                    allMemberUp = False
                    mp.testResult.addError('ERROR: GROUP:%s STATUS:%s MEMBER_IP:%s MEMBER_STATUS:%s' % (
                        cmDict['group_type'], cmDict['group_status'], m['ip'], m['status']))
                else:
                    mp.testResult.addVerify('cluster group %s: %s:%s' % (
                        cmDict['group_type'], m['ip'], m['status']))

    mp.testResult.epilogue()

def verify_managerVip(mp, vip):
    ''' manager cluster VIP match configured VIP '''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())

    vip = cptutil.host2ip(vip)
    cluster = nsxtlib.Cluster(mp=mp)
    jqTableDict = cluster.jq('vip', display=False)
    cVipDicts = jqTableDict['rows']
    apiDict = {'url':jqTableDict['restUrl'], 'response':jqTableDict['restRespJson']}
    mp.testResult.appendAttr('steps', '', {'api': apiDict})
    if cVipDicts[0]['vip']!=vip:
        mp.testResult.addError('ERROR: testbed manager VIP(%s) != config manager VIP(%s)' % (
            cVipDicts[0]['vip'], vip))
    else:
        mp.testResult.addVerify('manager VIP verified: %s' % vip)

    mp.testResult.epilogue()

def verify_switchingGlobalConfig(mp, cfgName, cfgDesc, cfgMtu, cfgReplication):
    ''' switchingGlobalConfigMtu '''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())

    globObj = nsxtlib.Global(mp.mgr)
    r = globObj.doRestApi('getSwitchingConfig')
    mSwCfg = r.json()
    apiDict = {'url':apiEp(r.request.url), 'response':mSwCfg,
        'purpose':'get Switching Global Config'}
    mp.testResult.appendAttr('steps', '', {'api': apiDict})

    if cfgMtu!=None:
        mMtu = mSwCfg['physical_uplink_mtu']
        mp.testResult.addVerify('Verify global switch config MTU "%s" is "%s"'%
            (mMtu,cfgMtu), (mMtu==cfgMtu))
    if cfgName!=None:
        mName = mSwCfg['display_name']
        mp.testResult.addVerify('Verify global switch Config Name "%s" is "%s"'%
            (mName,cfgName), (mName==cfgName))
    if cfgDesc!=None:
        descFound = ('description' in mSwCfg)
        mp.testResult.addVerify('Verify global switch Config DESCRIPTION attribute is configured',
            descFound)
        if descFound:
            mDesc = mSwCfg['description']
            mp.testResult.addVerify('Verify global switch config DESCRIPION "%s" is "%s"'%
                (mDesc,cfgDesc), (mDesc==cfgDesc))
    if cfgReplication!=None:
        cfgReplication = cfgReplication.upper() == 'TRUE'
        mRepl = mSwCfg['global_replication_mode_enabled']
        mp.testResult.addVerify('Verify global switch config global_replication_mode_enabled (%s) is %s'%
            (mRepl,cfgReplication), (mRepl==cfgReplication))

    mp.testResult.epilogue()

def verify_switchTeaming(mp, swName, swPolicy):
    ''' switchingGlobalConfigTeaming '''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())

    swObj = nsxtlib.Switch(mp.mgr)
    mSwDict = swObj.findByName(swName, display=False)
    mSwTeamingPolicy = mSwDict['uplink_teaming_policy_name']

    if mSwDict:
        mp.testResult.addVerify(
            'Verify SWITCH "%s" exist: PASS' % swName)
        checkCondition(mp, swPolicy, '==', mSwTeamingPolicy,
            'SWITCH TEAMING POLICY')
    else:
        mp.testResult.addError('ERROR: SWITCH "%s" not configured' % swName)

    mp.testResult.epilogue()

def verify_certImport(mp, certPath, certName='', certDesc=''):
    ''' certImport '''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())

    # analyze imported cert file
    with open(certPath) as fcert:
        iCertPem = fcert.read()
        iCertCrypto = OpenSSL.crypto.load_certificate(OpenSSL.crypto.FILETYPE_PEM, iCertPem)
        iCertSha1 = iCertCrypto.digest('sha1')

    # file cert in manager which matches imported cert
    certObj = nsxtlib.Certificate(mp=mp)
    certList = certObj.list(display=False)

    apiDict = {'url':certObj.api['list'].url, 'response':certList}
    mp.testResult.appendAttr('steps', '', {'api': apiDict})

    for rCert in certList['results']:
        rCertCrypto = OpenSSL.crypto.load_certificate(OpenSSL.crypto.FILETYPE_PEM, rCert['pem_encoded'])
        rCertSha1 = rCertCrypto.digest('sha1')
        if rCertSha1 == iCertSha1:
            #pprint(rCert)
            rCertName = rCert['display_name']
            rCertId = rCert['id']
            rCertType = rCert['resource_type']
            rCertDesc = rCert['description'] if 'description' in rCert else ''
            mp.testResult.addVerify('Certificate %s found in manager certificate store' % certPath)
            #print(rCertName, rCertType, rCertSha1, rCertId)
            if certName and certName != rcertName:
                mp.testResult.addError('Certificate found, but name not matching: %s != %s' % (certName, rCertName))
            if certDesc and certDesc != rCertDesc:
                mp.testResult.addError('Certificate found, but desc not matching: %s != %s' % (certDesc, rCertDesc))
            break
    else:
        mp.testResult.addError('Certificate %s not found in manager certificate store' % certPath)

    mp.testResult.epilogue()


def verify_certApply(mp, certName, nodeName, services=['API']):
    ''' certApply '''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())

    vResult = {'name':inspect.getframeinfo(inspect.currentframe()).function, 'status':False}

    clusterObj = nsxtlib.Cluster(mp=mp)
    mNode = clusterObj.findByName(nodeName, restUrl=clusterObj.api['clusterNodes'].url, display=False)
    nodeFound = (not not mNode)
    mp.testResult.addVerify('Verify CLUSTER_NODE "%s" exist'%nodeName, nodeFound)
    if nodeFound:
        mNodeId = mNode['id']
        nodeId = mNodeId

        r = clusterObj.doRestApi('clusterNode', nodeId=nodeId)
        mNode = r.json()
        apiDict = {'url':apiEp(r.request.url), 'response':mNode,
            'purpose':'verify node exist in cluster'}
        mp.testResult.appendAttr('steps', '', {'api': apiDict})

        certObj = nsxtlib.Certificate(mp=mp)
        mCert = certObj.findByName(certName, display=False)
        certFound = (not not mCert)
        mp.testResult.addVerify('Verify CERT "%s" exist'%certName, certFound)
        if certFound:
            certId=mCert['id']
            r = certObj.doRestApi('get', certId=certId)
            mCert = r.json()
            apiDict = {'url':apiEp(r.request.url), 'response':mCert,
                'purpose':'get cert info'}
            mp.testResult.appendAttr('steps', '', {'api': apiDict})

            mCertUsedBy = mCert['used_by'] if 'used_by' in mCert else []
            for service in mCertUsedBy:
                if 'API' in service['service_types'] and service['node_id']==nodeId:
                    mp.testResult.addVerify('cert %s applied to manager node %s for API service' %
                        (certName, nodeName))

                    mCertPem = mCert['pem_encoded']
                    mCertCrypto = OpenSSL.crypto.load_certificate(OpenSSL.crypto.FILETYPE_PEM, mCertPem)
                    mCertSha256 = mCertCrypto.digest('sha256')

                    nCertPem = ssl.get_server_certificate((nodeName, 443))
                    nCertCrypto = OpenSSL.crypto.load_certificate(OpenSSL.crypto.FILETYPE_PEM, nCertPem)
                    nCertSha256 = nCertCrypto.digest('sha256')
                    pyFnDict = {'function': 'ssl.get_server_certificate((%s,433))'%nodeName,
                        'response': {
                            #'applyedCertSha256': mCertSha256,
                            'nodeCertSha256': nCertSha256,
                        },
                        'purpose':'get cert via HTTPS'
                    }
                    mp.testResult.appendAttr('steps', '', {'python': pyFnDict})

                    mp.testResult.addVerify('Verify CERT used is the same as cert applied (sha256 %s == %s)' %
                        (nCertSha256,mCertSha256), (nCertSha256==mCertSha256) )
                    break
            else:
                mp.testResult.addError('cert %s not applied to manager node %s for API service' %
                    (certName, nodeName))

    mp.testResult.epilogue()

def isSubDictOf(subDict, superDict):
    return all(item in superDict.items() for item in subDict.items())
def isSuperDictOf(superDict, subDict):
    return all(item in superDict.items() for item in subDict.items())
def isSubDictsOf(subDicts, superDicts, key='display_name'):
    rDict = {}
    subDicts = listify(subDicts)
    superDicts = listify(superDicts)
    for subDict in subDicts:
        subDictKey = subDict[key]
        matchedSuperDict = [d for d in superDicts if d[key]==subDictKey]
        foundSuperDict = (not not matchedSuperDict)
        rDict[subDictKey] = {'found':foundSuperDict}
        if foundSuperDict:
            superDict = matchedSuperDict[0]
            isSub = isSubDictOf(subDict, superDict)
            rDict[subDictKey]['status'] = isSub
    return rDict
def isSuperDictsOf(superDicts, subDicts, key='display_name'):
    return isSubDictsOf(subDicts, superDicts, key=key)


def verify_tz(mp, jsonfile):
    ''' tz '''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())
    errMsgs, verMsgs = [], []

    with open(jsonfile) as ftz:
        iTzDicts = json.loads(ftz.read())
        iTzDicts = iTzDicts['transportzones']
        iTzNames = [tz['display_name'] for tz in iTzDicts]
    tzObj = nsxtlib.Transportzone(mp.mgr)
    mTzDicts = tzObj.list(display=False)
    mTzDicts = mTzDicts['results']

    tzResults = isSuperDictsOf(mTzDicts, iTzDicts)
    for rTz in tzResults.items():
        rTzName, rTzRes = rTz
        tzFound = (not not rTzRes['found'])
        mp.testResult.addVerify('Verifying TZ "%s" exist'%rTzName, tzFound )

        if tzFound:
            tzIds = [tz['id'] for tz in mTzDicts if tz['display_name']==rTzName]
            tzId = tzIds[0]
            r = tzObj.doRestApi('get', objId=tzId)
            apiDict = {'url':apiEp(r.request.url), 'response':r.json(),
                'purpose':'get TZ "%s" info'%rTzName}
            mp.testResult.appendAttr('steps', '', {'api': apiDict})

            if tzFound:
                mp.testResult.addVerify('Verifying TZ "%s" is configured correctly'%rTzName,
                    rTzRes['status'])

    mp.testResult.epilogue()

def verify_uplink(mp, jsonfile):
    ''' ######################## '''
    ''' config uplink profiles'''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())
    errMsgs, verMsgs = [], []

    vResult = {'name':inspect.getframeinfo(inspect.currentframe()).function, 'status':False}
    with open(jsonfile) as fuplink:
        iUlDicts = json.loads(fuplink.read())
        pprint(iUlDicts)
        iUlDicts = iUlDicts['uplinks']
        iUlNames = [tz['display_name'] for tz in iUlDicts]
    ulObj = nsxtlib.Uplinkprofile(mp.mgr)
    mUlDicts = ulObj.list(display=False)
    mUlDicts = mUlDicts['results']
    pprint(mUlDicts); exit()

    mUlNames = [e['display_name'] for e in mUlDicts]
    iUlNames = [e['display_name'] for e in iUlDicts]
    ulNamesMissing = list(set(iUlNames)-set(mUlNames))
    if ulNamesMissing:
        mp.testResult.addVerify('Verifying all uplink profile entries configured: PASS')
    else:
        mp.testResult.addError('Verifying all uplink profile entries configured: FAIL')
    for iUlDict in iUlDicts:
        #pprint(iUlDict)
        iUlName = iUlDict['display_name']
        if iUlName in ulNamesMissing:
            continue

        mUlDict = [e for e in mUlDicts if iUlName==e['display_name']][0]
        #pprint(mUlDict)
        ulStatus = isDictSubset(mUlDict, iUlDict)
        print(ulStatus, iUlName)
    exit()




    pprint(iUlDicts)
    #ulStatus = isDictsSubset(mUlDicts, iUlDicts)
    ulStatus = isSuperDictOf(mUlDicts, iUlDicts)
    pprint(ulStatus); exit()
    if ulStatus['notFound']:
        mp.logger.error('Uplink not configured: %s' % ', '.join(ulStatus['notFound']))
    if ulStatus['failed']:
        mp.logger.error('Uplink compare failed: %s' % ', '.join(ulStatus['failed']))
    vResult['status'] = ulStatus['status']

    mp.testResult.epilogue()
    return vResult

def verify_poolConfig(mp, jsonfile):
    ''' Pools '''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())

    with open(jsonfile) as fpool:
        iPools = json.loads(fpool.read())
        iPools = iPools['ippools']
    poolObj = nsxtlib.Pools(mp.mgr)
    mPoolLists = poolObj.list(display=False)
    mPools = {p['display_name']:p for p in mPoolLists['results']}

    for iPool in iPools:
        iPoolName = iPool['display_name']
        poolFound = (iPoolName in mPools)
        mp.testResult.addVerify('Verifying IP pools "%s" exist'%iPoolName, poolFound )
        if poolFound:
            mPool = mPools[iPoolName]
            r = poolObj.doRestApi('get', objId=mPool['id'])
            apiDict = {'url':apiEp(r.request.url), 'response':r.json(),
                'purpose':'get IP Pool "%s" info'%iPoolName}
            mp.testResult.appendAttr('steps', '', {'api': apiDict})
            if poolFound:
                mp.testResult.addVerify('Verifying IP pools "%s" is configured correctly'%iPoolName,
                    isSuperDictOf(mPool, iPool))

    mp.testResult.epilogue()

def verify_edgeDeploy(mp, edgeNames, edgeVersion):
    ''' edge deploy '''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())

    edgeNames = listify(edgeNames)
    for edgeName in edgeNames:
        try:
            c = paramikolib.ParamikoSsh(edgeName, 'admin', 'CptWare12345!', timeout=mp.timeout)
        except paramiko.ssh_exception.AuthenticationException:
            errMsg = '%s: Authentication failed'%edgeName
            mp.logger.error(errMsg)
            mp.testResult.addError(errMsg)
        except Exception as errMsg:
            errMsg = '%s: %s' % (edgeName,str(errMsg))
            mp.logger.error(errMsg)
            mp.testResult.addError(errMsg)
        else:
            edgeVersionOut = c.execute('get version')
            reo = re.search(', Version +(\S+)', edgeVersionOut)
            mEdgeVersion = reo.group(1)
            mp.testResult.addVerify('Verify Edge node "%s" version "%s" is "%s"'%
                (edgeName, mEdgeVersion, edgeVersion), edgeVersion==mEdgeVersion)
            mp.testResult.appendAttr('steps', '', {'cli': edgeVersionOut})

    mp.testResult.epilogue()

def verify_someObject(mp, objame, objMembers):
    ''' verification of object '''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())

    """
    ecObj = nsxtlib.EdgeCluster(mgr=mp.mgr)
    mEc = ecObj.findByName(ecName, display=False)
    apiDict = {'url':ecObj._findByNameRest['url'], 'response':ecObj._findByNameRest['response']}
    mp.testResult.appendAttr('steps', '', {'api': apiDict})

    ecFound = (not not mEc)
    mp.testResult.addVerify('Verify EdGE_CLUSTER "%s" exist'%ecName, ecFound)
    tnObj = nsxtlib.TransportNode(mgr=mp.mgr, fill=False)
    if ecFound:
        mEcTnMbrIds = [m['transport_node_id'] for m in mEc['members']]
        for tnName in ecMembers:
            tn = tnObj.findByName(tnName, display=False)
            tnFound = (not not tn)
            mp.testResult.addVerify('Verify TN "%s" found'%tnName, tnFound)
            if tnFound:
                tnIsEcMember = (tn['id'] in mEcTnMbrIds)
                mp.testResult.addVerify(
                    'Verify EdGE_CLUSTER "%s" contains member TN "%s"'%
                    (ecName,tnName), tnFound)
    """
    mp.testResult.epilogue()

def verify_prefixlistConfig(mp, t0Name, pfxlName, pfxlSpecs, pfxlDesc):
    ''' Tier0 PrefixList Configuration '''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())

    t0Obj = nsxtlib.PM_Tier0(mgr=mp.mgr)
    mT0 = t0Obj.findByName(t0Name, display=False)
    apiDict = {'url':t0Obj._findByNameRest['url'], 'response':strifyDictKV(t0Obj._findByNameRest['response'])}
    mp.testResult.appendAttr('steps', '', {'api': apiDict})

    t0Found = (not not mT0)
    mp.testResult.addVerify('Verify Tier0 "%s" exist'%t0Name, t0Found)
    if t0Found:
        pfxlObj = nsxtlib.PM_PrefixList(mgr=mp.mgr)
        pfxListUrl = eval(pfxlObj.api['list'].url)
        mPfxList = pfxlObj.list(restUrl=pfxListUrl, display=False)
        apiDict = {'url':pfxListUrl, 'response':strifyDictKV(mPfxList)}
        mp.testResult.appendAttr('steps', '', {'api': apiDict})
        #pprint(mPfxList)

        mPfxl = pfxlObj.findByName(name=pfxlName, data=mPfxList, display=False)
        mPfxl = strifyDictKV(mPfxl)

        pfxlFound = (not not mPfxl)
        mp.testResult.addVerify('Verify TIER0 "%s" PREFIX_LIST "%s" exist'%
            (t0Name,pfxlName), pfxlFound)

        #print('>>>>>>>>>>>>', t0Name, pfxlName, pfxlSpecs, pfxlDesc)
        mPrefixes = mPfxl['prefixes']
        #pprint(mPrefixes)
        mPrefixeTuples = [sorted(d.items()) for d in mPrefixes]
        #print(mPrefixeTuples)

        for pfxlSpec in pfxlSpecs:
            #print('>>>', pfxlSpec)
            pfxNet,pfxGe,pfxLe,pfxAction = pfxlSpec.split(',')
            #print(pfxNet,pfxGe,pfxLe,pfxAction)
            pfxNet = pfxNet.upper()
            if pfxGe: pfxGe = int(pfxGe)
            if pfxLe: pfxLe = int(pfxLe)
            pfxAction = pfxAction.upper()

            pDict = {'action':pfxAction,'network':pfxNet}
            if pfxGe!='': pDict['ge'] = pfxGe
            if pfxLe!='': pDict['le'] = pfxLe
            #print('>>>', pfxNet,pfxGe,pfxLe,pfxAction)
            #pprint(pDict)
            pfxlTuple = sorted(pDict.items())
            #print(pfxlTuple, '<<==>>', mPrefixeTuples)
            #print(pfxlTuple in mPrefixeTuples)
            mp.testResult.addVerify('Verify PREFIX "%s" is configured in PREFIXLIST "%s" (%s)'%
                (pfxlSpec,pfxlName,mPrefixeTuples), (pfxlTuple in mPrefixeTuples))
        if pfxlDesc:
            attr = 'description'
            vDesc = 'Verify Tier0 "%s" PREFIXLIST %s'%(t0Name,attr.upper())
            if checkAttrExist(mp.testResult, mPfxl, attr, vDesc):
                mp.testResult.addVerify('%s "%s" is "%s"'%
                    (vDesc,mPfxl[attr],nbrDesc), (mPfxl[attr]==pfxlDesc))

    mp.testResult.epilogue()

def verify_t0Config(mp, t0Name, t0Failover, t0Ha, t0Transit, t0Dhcprelay, t0Desc):
    ''' Tier0 config '''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())

    t0Obj = nsxtlib.PM_Tier0(mgr=mp.mgr)
    t0Found, _, mT0 = __findVerifyObjByName(mp, t0Obj, t0Name, 'TIER0')

    #mT0 = t0Obj.findByName(t0Name, display=False)
    #t0Path = t0Obj.getPathByName(t0Name)
    #r = t0Obj.getPolicyObjectByPath(t0Path)
    #apiDict = {'url':r.request.url, 'response':r.json(),
    #    'purpose':'get Tier0 "%s" info'%t0Name}
    #mp.testResult.appendAttr('steps', '', {'api': apiDict})
    #t0Found = (not not mT0)
    #mp.testResult.addVerify('Verify Tier0 "%s" exist'%t0Name, t0Found)

    #tnObj = nsxtlib.TransportNode(mgr=mp.mgr, fill=False)
    if t0Found:
        if t0Failover:
            mp.testResult.addVerify('Verify Tier0 "%s" FAILOVER_MODE "%s" is "%s"'%
                (t0Name,mT0['failover_mode'],t0Failover), (mT0['failover_mode']==t0Failover))
        if t0Ha:
            mp.testResult.addVerify('Verify Tier0 "%s" HA_MODE "%s" is "%s"'%
                (t0Name,mT0['ha_mode'],t0Ha), (mT0['ha_mode']==t0Ha))
        if t0Transit:
            mp.testResult.addVerify('Verify Tier0 "%s" TRANSIT_SUBNETS "%s" is "%s"'%
                (t0Name,mT0['transit_subnets'],t0Transit), (mT0['transit_subnets']==t0Transit))
        if t0Dhcprelay:
            mDhcprelays = [r.split('/')[-1] for r in mT0['dhcp_config_paths']]
            mp.testResult.addVerify('Verify Tier0 "%s" DHCP_CONFIG "%s" includes "%s"'%
                (t0Name,mDhcprelays,t0Dhcprelay), (t0Dhcprelay in mDhcprelays))
        if t0Desc:
            #mp.testResult.addVerify('Verify Tier0 "%s" DESC "%s" is "%s"'%
            #    (t0Name,mT0['description']), (mT0['description']==t0Desc))
            pass

    mp.testResult.epilogue()

def checkAttrExist(testResult, obj, attr, vDesc):
    attrExist = (attr in obj)
    if not attrExist and testResult:
        testResult.addError(vDesc+' attribute exists: Fail')
    return attrExist

def verify_t0BgpNeighborConfig(mp,
        t0Name, t0Locale, bgpNbr, nbrAddress,
        nbrIpv6, nbrRemoteAs, nbrHoldtime, nbrKeepalive,
        nbrSecret, nbrEnablebfd, nbrDisablebfd, nbrBfdmultiple,
        nbrInprefixlist, nbrSourceip, nbrGr, nbrDesc):
    ''' verification of T0 BGP config '''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())
    localeDefault = 'default'

    t0Obj = nsxtlib.PM_Tier0(mgr=mp.mgr)
    #mT0 = t0Obj.findByName(t0Name, display=False)
    #apiDict = {'url':t0Obj._findByNameRest['url'], 'response':t0Obj._findByNameRest['response']}
    #mp.testResult.appendAttr('steps', '', {'api': apiDict})
    #t0Found = (not not mT0)
    #mp.testResult.addVerify('Verify TIER0 "%s" exist'%t0Name, t0Found)
    t0Found, _, mT0 = __findVerifyObjByName(mp, t0Obj, t0Name, 'TIER0')

    if t0Found:
        mT0Path = mT0['path']
        nbrApiUrl = '/policy/api/v1%s/locale-services/%s/bgp/neighbors/%s' % (
            mT0Path,(t0Locale or localeDefault),bgpNbr)
        nbrApiResp = mp.mgr.get(nbrApiUrl).json()
        apiDict = {'url':nbrApiUrl, 'response':nbrApiResp}
        mp.testResult.appendAttr('steps', '', {'api': apiDict})

        nbrFound = (nbrApiResp.get('display_name') == bgpNbr)
        mp.testResult.addVerify('Verify TIER0 "%s" BGP NEIGHBOR "%s" exist in LOCALE "%s"'%(
            t0Name,bgpNbr,(t0Locale or localeDefault)), nbrFound)
        if nbrFound:
            mNbr = nbrApiResp
            if nbrAddress:
                mp.testResult.addVerify('Verify Tier0 "%s" BGP NEIGHBOR ADDRESS "%s" is "%s"'%
                    (t0Name,mNbr['neighbor_address'],nbrAddress), (mNbr['neighbor_address']==nbrAddress))
            if nbrRemoteAs:
                mp.testResult.addVerify('Verify Tier0 "%s" BGP NEIGHBOR AS "%s" is "%s"'%
                    (t0Name,mNbr['remote_as_num'],nbrRemoteAs), (mNbr['remote_as_num']==nbrRemoteAs))
            if nbrHoldtime:
                mp.testResult.addVerify('Verify Tier0 "%s" BGP NEIGHBOR HOLD_DOWN_TIMNE %d is %d'%
                    (t0Name,mNbr['hold_down_time'],nbrHoldtime), (mNbr['hold_down_time']==nbrHoldtime))
            if nbrKeepalive:
                mp.testResult.addVerify('Verify Tier0 "%s" BGP NEIGHBOR KEEP_ALIVE_TIME %d is %d'%
                    (t0Name,mNbr['keep_alive_time'],nbrKeepalive), (mNbr['keep_alive_time']==nbrKeepalive))
            #if nbrSecret: pass
            if nbrEnablebfd:
                '''
                    'bfd': [
                        'enabled': True,
                        'interval': 10000,
                        'multiple': 3,
                    }
                '''
                #mNbr.update({'bfd':{'enabled':True}})
                if 'bfd' in mNbr and 'enabled' in mNbr['bfd']:
                    mp.testResult.addVerify('BGP NEIGHBOR BFD ENAABLED "%s" is "%s"' %
                        (mNbr['bfd']['enabled'],nbrEnablebfd), (mNbr['bfd']['enabled']==nbrEnablebfd))
                else:
                    mp.testResult.addError('BGP NEIGHBOR BFD or BFD/ENABLED not set')
            if nbrDisablebfd:
                #mNbr.update({'bfd':{'enabled':True}})
                if 'bfd' in mNbr and 'enabled' in mNbr['bfd']:
                    mp.testResult.addVerify('BGP NEIGHBOR BFD ENAABLED "%s" is "%s"' %
                        (mNbr['bfd']['enabled'],not nbrDisablebfd),(mNbr['bfd']['enabled']==(not nbrDisablebfd)))
                else:
                    mp.testResult.addError('BGP NEIGHBOR BFD or BFD/ENABLED not set')
            if nbrBfdmultiple:
                #mNbr.update({'bfd':{'multiple':3}})
                if 'bfd' in mNbr and 'multiple' in mNbr['bfd']:
                    mp.testResult.addVerify('BGP NEIGHBOR BFD MULTIPLE %s is %s' %
                        (mNbr['bfd']['multiple'],nbrBfdmultiple),(mNbr['bfd']['multiple']==nbrBfdmultiple))
                else:
                    mp.testResult.addError('BGP NEIGHBOR BFD or BFD/MULTIPLE not set')
            if nbrInprefixlist:
                '''
                    route_filtering: [
                        {
                            'address_family': 'IPV4',
                            'enabled': True,
                            'in_route_filters': [
                                '/infra/tier-0s/CoreT0/prefix-lists/no_self',
                            ]

                    ]
                '''
                #import nsxobjects
                #pfx=nsxobjects.PrefixList(mp=mp, tier0=None, t0Path=mT0Path)
                #rmp=nsxobjects.RouteMap(mp=mp, tier0=None, t0Path=mT0Path)

                pfxlObj = nsxtlib.PM_PrefixList(mgr=mp.mgr)
                pfxListUrl = eval(pfxlObj.api['list'].url)
                pfxList = pfxlObj.list(restUrl=pfxListUrl)
                #pprint(pfxList)

                mInRouteFilterPaths = []
                #mOutRouteFilterPaths = []
                for rFilter in mNbr['route_filtering']:
                    if 'in_route_filters' in rFilter:
                        mInRouteFilterPaths = rFilter['in_route_filters']
                        if nbrIpv6:
                            nbrAddrType = 'IPV6' if nbrIpv6 else 'IPV4'
                            mp.testResult.addVerify('Verify BGP IN_ROUTE_FILTERS ADDRESS_FAMILY "%s" is "%s"'%
                                (rFilter['address_family'],nbrAddrType),
                                (rFilter['address_family']==nbrAddrType))

                    #elif 'out_route_filters' in rFilter:
                    #    mOutRouteFilterPaths = rFilter['out_route_filters']
                    #    print('out_route_filters: %s' % rFilter['out_route_filters'])
                mInRouteFilterNames = [p.split('/')[-1] for p in mInRouteFilterPaths]
                #mOutRouteFilterNames = [p.split('/')[-1] for p in mOutRouteFilterPaths]

                nbrInprefixPaths = []
                for nbrInprefixName in nbrInprefixlist:
                    pfxDict = pfxlObj.findByName(name=nbrInprefixName, data=pfxList)
                    nbrInprefixPaths.append(pfxDict['path'])
                    mp.testResult.addVerify(
                        'Verify INPREFIXPREFIX "%s" contains "%s"' %
                            (mInRouteFilterNames, nbrInprefixName),
                            (pfxDict['path'] in mInRouteFilterPaths))

                #nbrOutprefixPaths = []
                #for nbrOutprefixName in nbrOutprefixlist:
                #    pfxDict = pfxlObj.findByName(name=nbrOutprefixName, data=pfxList)
                #    nbrOutprefixPaths.append(pfxDict['path'])
                #    print('>>>>', nbrOutprefixName, pfxDict['path'], mOutRouteFilterPaths)
                #    mp.testResult.addVerify(
                #        'Verify INPREFIXPREFIX "%s" contains "%s"' %
                #            (mOutRouteFilterNames, nbrOutprefixName),
                #            (pfxDict['path'] in mOutRouteFilterPaths))

                #if nbrIpv6:
                #    print('>>>>route_filtering:'); pprint(mNbr['route_filtering'])
                #    mNgrAddrType = mNbr['route_filtering']['address_family']
                #    nbrAddrType = 'IPV6' if nbrIpv6 else 'IPV4'
                #    mp.testResult.addVerify('Verify Tier0 "%s" BGP NEIGHBOR ROUTE_FILTER_ADDR_FAMILYs "%s" is "%s"'%
                #        (t0Name,mNgrAddrType,nbrIpv6), (mNgrAddrType==nbrAddrType))
            if nbrSourceip:         ############### NEED TO REVISIT ###############
                attr = 'source_addresses'
                vDesc = 'Verify Tier0 "%s" BGP NEIGHBOR %s'%(t0Name,attr.upper())
                #mNbr[attr] = ['2.1.1.1','2.2.2.2']
                if attr in mNbr:
                    srcIpDiff = list(set(nbrSourceip)-set(mNbr[attr]))
                    srcIpConfigured = (not srcIpDiff)
                    mp.testResult.addVerify('%s "%s" is "%s"'%
                        (vDesc,mNbr[attr],nbrSourceip), srcIpConfigured)
                else:
                    mp.testResult.addError(vDesc+' attribute exist: Fail')
            if nbrGr:
                mp.testResult.addVerify('Verify Tier0 "%s" BGP NEIGHBOR GRACEFUL_RESTART_MODE "%s" includes "%s"'%
                    (t0Name,mNbr['graceful_restart_mode'],nbrGr), (mNbr['graceful_restart_mode']==nbrGr))
            if nbrDesc:
                attr = 'description'
                vDesc = 'Verify Tier0 "%s" BGP NEIGHBOR %s'%(t0Name,attr.upper())
                if checkAttrExist(mp.testResult, mNbr, attr, vDesc):
                    mp.testResult.addVerify('%s "%s" is "%s"'%
                        (vDesc,mNbr[attr],nbrDesc), (mNbr[attr]==nbrDesc))

    mp.testResult.epilogue()

def verify_t0BgpConfig(mp, t0Name, t0Locale, t0Local_as,
        t0Enable_multipathrelax, t0Disable_multipathrelax,
        t0Enable_intersr, t0Disable_intersr, t0Enable_ecmp,
        t0Disable_ecmp, t0Enable_gr, t0Disable_gr):
    ''' verification of T0 BGP config '''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())
    localeDefault = 'default'

    t0Obj = nsxtlib.PM_Tier0(mgr=mp.mgr)
    t0Found, _, mT0 = __findVerifyObjByName(mp, t0Obj, t0Name, 'TIER0')

    #mT0 = t0Obj.findByName(t0Name, display=False)
    #apiDict = {'url':t0Obj._findByNameRest['url'], 'response':t0Obj._findByNameRest['response']}
    #mp.testResult.appendAttr('steps', '', {'api': apiDict})
    #t0Found = (not not mT0)
    #mp.testResult.addVerify('Verify TIER0 "%s" exist'%t0Name, t0Found)

    if t0Found:
        mT0Path = mT0['path']
        bgpApiUrl = '/policy/api/v1%s/locale-services/%s/bgp' % (
            mT0Path,(t0Locale or localeDefault))
        bgpApiResp = mp.mgr.get(bgpApiUrl).json()
        apiDict = {'url':bgpApiUrl, 'response':bgpApiResp}
        mp.testResult.appendAttr('steps', '', {'api': apiDict})

        bgpFound = (bgpApiResp.get('display_name') == 'bgp')
        mp.testResult.addVerify('Verify TIER0 "%s" BGP configured in locale "%s"'%(
            t0Name,(t0Locale or localeDefault)), bgpFound)
        if bgpFound:
            mT0Bgp = bgpApiResp
            if t0Local_as:
                mp.testResult.addVerify('Verify Tier0 "%s" BGP LOCAL_AS "%s" is "%s"'%
                    (t0Name,mT0Bgp['local_as_num'],t0Local_as), (mT0Bgp['local_as_num']==t0Local_as))
            if t0Enable_multipathrelax:
                mp.testResult.addVerify('Verify Tier0 "%s" BGP MULTIPATHRELAX_ENABLE "%s" is "%s"'%
                    (t0Name,mT0Bgp['multipath_relax'],t0Enable_multipathrelax), (mT0Bgp['multipath_relax']==t0Enable_multipathrelax))
            if t0Disable_multipathrelax:
                mp.testResult.addVerify('Verify Tier0 "%s" BGP MULTIPATHRELAX_ENABLE "%s" is "%s"'%
                    (t0Name,mT0Bgp['multipath_relax'],not t0Disable_multipathrelax), (mT0Bgp['multipath_relax']!=t0Disable_multipathrelax))
            if t0Enable_intersr:
                mp.testResult.addVerify('Verify Tier0 "%s" BGP INTER_SR_ENABLE "%s" is "%s"'%
                    (t0Name,mT0Bgp['inter_sr_ibgp'],t0Enable_intersr), (mT0Bgp['inter_sr_ibgp']==t0Enable_intersr))
            if t0Disable_intersr:
                mp.testResult.addVerify('Verify Tier0 "%s" BGP INTER_SR_ENABLE "%s" is "%s"'%
                    (t0Name,mT0Bgp['inter_sr_ibgp'],not t0Disable_intersr), (mT0Bgp['inter_sr_ibgp']!=t0Disable_intersr))
            if t0Enable_ecmp:
                mp.testResult.addVerify('Verify Tier0 "%s" BGP ECMP_ENABLE "%s" is "%s"'%
                    (t0Name,mT0Bgp['ecmp'],t0Enable_ecmp), (mT0Bgp['ecmp']==t0Enable_ecmp))
            if t0Disable_ecmp:
                mp.testResult.addVerify('Verify Tier0 "%s" BGP ECMP_ENABLE "%s" is "%s"'%
                    (t0Name,mT0Bgp['ecmp'],not t0Disable_ecmp), (mT0Bgp['ecmp']!=t0Disable_ecmp))
            if t0Enable_gr:
                mp.testResult.addVerify('Verify Tier0 "%s" BGP GRACEFUL_RESTART "%s" is "%s"'%
                    (t0Name,mT0Bgp['graceful_restart'],t0Enable_gr), (mT0Bgp['graceful_restart']==t0Enable_gr))
            if t0Disable_gr:
                mp.testResult.addVerify('Verify Tier0 "%s" BGP GRACEFUL_RESTART "%s" is "%s"'%
                    (t0Name,mT0Bgp['graceful_restart'],not t0Disable_gr), (mT0Bgp['graceful_restart']!=t0Disable_gr))

    mp.testResult.epilogue()

def verify_t0InterfaceConfig(mp, t0Name, t0Int, intSegment,
        intCidr, intMtu, t0EdgeName, t0Locale, intDesc, intType):
    ''' verification of Tier0 interface '''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())

    t0Obj = nsxtlib.PM_Tier0(mgr=mp.mgr)
    t0Found, _, mT0 = __findVerifyObjByName(mp, t0Obj, t0Name, 'TIER0')

    if t0Found:
        localeDefault = 'default'
        mT0Path = mT0['path']
        intApiUrl = '/policy/api/v1%s/locale-services/%s/interfaces' % (
            mT0Path,(t0Locale or localeDefault))

        r = mp.doRestApi('get '+intApiUrl)
        intApiResp = r.json()

        mInts = [i for i in intApiResp['results'] if i['display_name']==t0Int] \
            if 'results' in intApiResp else []
        intFound = (not not mInts)
        mp.testResult.addVerify('Verify TIER0 "%s" INTERFACE "%s" exist in locale "%s"'%(
            t0Name,t0Int,(t0Locale or localeDefault)), intFound)
        if intFound:
            #mInt = [i for i in intApiResp['results'] if i['display_name']==t0Int]
            #mInt = mInt[0]
            mInt = mInts[0]
            mIntPath = mInt['path']
            r = t0Obj.getPolicyObjectByPath(mIntPath)
            apiDict = {'url':apiEp(r.request.url), 'response':r.json(),
                'purpose':'get Tier0 "%s" info'%t0Name}
            mp.testResult.appendAttr('steps', '', {'api': apiDict})

            if t0Locale:
                mp.testResult.addVerify('Verify Tier0 "%s" INTERFACES in LOCALE "%s"'%(
                    t0Name,t0Locale), True)
            if intSegment:
                mT0Segment = mInt['segment_path'].split('/')[-1]
                mp.testResult.addVerify('Verify Tier0 "%s" INTERFACE "%s" SEGMENT "%s" is "%s"'%
                    (t0Name,t0Int,mT0Segment,intSegment), (mT0Segment==intSegment))
            if intCidr:
                t0Cidrs = [tuple(cidr.split('/')) for cidr in intCidr]
                mCidrs = [(str(ip), str(c['prefix_len'])) for c in mInt['subnets'] for ip in c['ip_addresses'] ]
                cidrDiff = list(set(t0Cidrs)-set(mCidrs))
                cidrConfigured = (not cidrDiff)
                mp.testResult.addVerify('Verify Tier0 "%s" INTERFACE "%s" SUBNET "%s" is "%s"'%
                    (t0Name,t0Int,mCidrs,intCidr), cidrConfigured)
            if intMtu:
                mp.testResult.addVerify('Verify Tier0 "%s" INTERFACE "%s" MTU "%s" is "%s"'%
                    (t0Name,t0Int,mInt['mtu'],intMtu), (mInt['mtu']==intMtu))
            if t0EdgeName:
                mT0EdgePath = '/policy/api/v1'+mInt['edge_path']
                mT0Edge = mp.mgr.get(mT0EdgePath).json()
                apiDict = {'url':mT0EdgePath, 'response':mT0Edge}
                mp.testResult.appendAttr('steps', '', {'api': apiDict})

                pprint(mT0Edge )
                mT0EdgeName = mT0Edge['display_name']
                pprint(mT0Edge )
                mp.testResult.addVerify('Verify Tier0 "%s" INTERFACE "%s" EDGE "%s" is "%s"'%
                    (t0Name,t0Int,mT0EdgeName,t0EdgeName), (mT0EdgeName==t0EdgeName))
            if intType:
                mp.testResult.addVerify('Verify Tier0 "%s" INTERFACE "%s" TYPE "%s" is "%s"'%
                    (t0Name,t0Int,mInt['type'],intType), (mInt['type']==intType))
            if intDesc:
                attr = 'description'
                vDesc = 'Verify Tier0 "%s" INTERFACE "%s" %s'%(t0Name,t0Int,attr.upper())
                if checkAttrExist(mp.testResult, mInt, attr, vDesc):
                    mp.testResult.addVerify('%s "%s" is "%s"'%
                        (vDesc,mInt[attr],intDesc), (mInt[attr]==intDesc))

    mp.testResult.epilogue()


def apiEp(url):
    return re.sub('https*://[^/]*', '', url)

def verify_t0LocaleRedist(mp, t0Name, t0Types, t0Locale):
    ''' verification of Tier0 Route Distribution Types '''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())

    t0Obj = nsxtlib.PM_Tier0(mgr=mp.mgr)
    t0Found, _, mT0 = __findVerifyObjByName(mp, t0Obj, t0Name, 'TIER0')

    #mT0 = t0Obj.findByName(t0Name, display=False)
    #t0Found = (not not mT0)
    #mp.testResult.addVerify('Verify TIER0 "%s" exist'%t0Name, t0Found)

    if t0Found:
        #t0Path = t0Obj.getPathByName(t0Name)
        #r = t0Obj.getPolicyObjectByPath(t0Path)
        #apiDict = {'url':apiEp(r.request.url), 'response':r.json(),
        #    'purpose':'get Tier0 "%s" info'%t0Name}
        #mp.testResult.appendAttr('steps', '', {'api': apiDict})

        t0Locale = t0Locale or 'default'
        mT0Path = mT0['path']
        lsApiUrl = '/policy/api/v1%s/locale-services/%s' % (mT0Path,t0Locale)
        mLs = mp.mgr.get(lsApiUrl).json()
        apiDict = {'url':lsApiUrl, 'response':mLs}
        mp.testResult.appendAttr('steps', '', {'api': apiDict})

        t0RRedistTypes = mLs['route_redistribution_types']
        lsTypeDiff = list(set(t0Types)-set(t0RRedistTypes))
        lsConfigured = (not lsTypeDiff)

        mp.testResult.addVerify('Verify TIER0 "%s" ROUTE REDISTRIBUTION TYPES configuration "%s"' %
            (t0Name,','.join(t0Types)), lsConfigured)
        if  not lsConfigured:
            mp.testResult.addError('Missing TIER0 "%s" ROUTE REDISTRIBUTION TYPES: "%s"' %
                (t0Name,','.join(lsTypeDiff)))

    mp.testResult.epilogue()


def verify_t0LocaleEdgeCluster(mp, t0Name, t0EdgeClusterName, t0Locale):
    ''' verification Tire0 EdgeCluster  '''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())

    t0Obj = nsxtlib.PM_Tier0(mgr=mp.mgr)
    t0Found, _, mT0 = __findVerifyObjByName(mp, t0Obj, t0Name, 'TIER0')

    #mT0 = t0Obj.findByName(t0Name, display=False)
    #t0Found = (not not mT0)
    #mp.testResult.addVerify('Verify TIER0 "%s" exist'%t0Name, t0Found)

    if t0Found:
        t0Locale = t0Locale or 'default'
        mT0Path = mT0['path']
        #lsApiUrl = '%s%s/locale-services/%s'%(mp.policyObjPathPrefix,mT0Path,t0Locale)
        lsApiUrl = '/policy/api/v1%s/locale-services/%s'%(mT0Path,t0Locale)
        r = t0Obj.getPolicyObjectByPath(lsApiUrl)
        apiDict = {'url':apiEp(r.request.url), 'response':r.json(),
            'purpose':'get Tier0 "%s" LOCALE_SERVICES "%s"'%(t0Name, t0Locale)}
        lsApiResp = mp.mgr.get(lsApiUrl).json()
        apiDict = {'url':lsApiUrl, 'response':lsApiResp}
        mp.testResult.appendAttr('steps', '', {'api': apiDict})


        ecPath = lsApiResp['edge_cluster_path']
        r = t0Obj.getPolicyObjectByPath(ecPath)
        apiDict = {'url':apiEp(r.request.url), 'response':r.json(),
            'purpose':'get Tier0 "%s" EDGE_CLUSTER info'%t0Name}
        mp.testResult.appendAttr('steps', '', {'api': apiDict})
        mEc = r.json()
        mEcName = mEc['display_name']

        ecFound = (not not mEc)
        mp.testResult.addVerify('Verify EDGE_CLUSTER "%s" exist'%t0EdgeClusterName, ecFound)

        mp.testResult.addVerify('Verify TIER0 "%s" EDGE_CLUSTER "%s" is "%s"' %
            (t0Name,mEcName,t0EdgeClusterName), (mEcName==t0EdgeClusterName))
    else:
        apiDict = {'url':t0Obj._findByNameRest['url'], 'response':t0Obj._findByNameRest['response']}
        mp.testResult.appendAttr('steps', '', {'api': apiDict})

    mp.testResult.epilogue()



def verify_edgeClusterConfig(mp, ecName, ecMembers):
    ''' edge cluster config '''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())

    ecObj = nsxtlib.EdgeCluster(mgr=mp.mgr)
    mEc = ecObj.findByName(ecName, display=False)

    apiDict = {'url':ecObj._findByNameRest['url'], 'response':ecObj._findByNameRest['response']}
    mp.testResult.appendAttr('steps', '', {'api': apiDict})

    ecFound = (not not mEc)
    mp.testResult.addVerify('Verify EdGE_CLUSTER "%s" exist'%ecName, ecFound)
    tnObj = nsxtlib.TransportNode(mgr=mp.mgr, fill=False)
    if ecFound:
        mEcTnMbrIds = [m['transport_node_id'] for m in mEc['members']]
        for tnName in ecMembers:
            tn = tnObj.findByName(tnName, display=False)
            tnFound = (not not tn)
            mp.testResult.addVerify('Verify TN "%s" found'%tnName, tnFound)
            if tnFound:
                tnIsEcMember = (tn['id'] in mEcTnMbrIds)
                mp.testResult.addVerify(
                    'Verify EdGE_CLUSTER "%s" contains member TN "%s"'%
                    (ecName,tnName), tnFound)

    mp.testResult.epilogue()

def verify_someObject(mp, objame, objMembers):
    ''' verification of object '''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())

    """
    ecObj = nsxtlib.EdgeCluster(mgr=mp.mgr)
    mEc = ecObj.findByName(ecName, display=False)
    apiDict = {'url':ecObj._findByNameRest['url'], 'response':ecObj._findByNameRest['response']}
    mp.testResult.appendAttr('steps', '', {'api': apiDict})

    ecFound = (not not mEc)
    mp.testResult.addVerify('Verify EdGE_CLUSTER "%s" exist'%ecName, ecFound)
    tnObj = nsxtlib.TransportNode(mgr=mp.mgr, fill=False)
    if ecFound:
        mEcTnMbrIds = [m['transport_node_id'] for m in mEc['members']]
        for tnName in ecMembers:
            tn = tnObj.findByName(tnName, display=False)
            tnFound = (not not tn)
            mp.testResult.addVerify('Verify TN "%s" found'%tnName, tnFound)
            if tnFound:
                tnIsEcMember = (tn['id'] in mEcTnMbrIds)
                mp.testResult.addVerify(
                    'Verify EdGE_CLUSTER "%s" contains member TN "%s"'%
                    (ecName,tnName), tnFound)
    """
    mp.testResult.epilogue()

def verify_dhcprelayConfig(mp, drName, drServers):
    ''' DHCP relay configration '''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())

    drObj = nsxtlib.PM_DhcpRelay(mgr=mp.mgr)
    mDr = drObj.findByName(drName, display=False)
    apiDict = {'url':drObj._findByNameRest['url'], 'response':drObj._findByNameRest['response']}
    mp.testResult.appendAttr('steps', '', {'api': apiDict})

    drFound = (not not mDr)
    mp.testResult.addVerify('Verify DHCP_RELAY "%s" exist'%drName, drFound)
    if drFound:
        #pprint(mDr['server_addresses'])
        checkCondition(mp, set(mDr['server_addresses']), '==', set(drServers),
            'DHCP RELAY "%s" servers'%drName)

    mp.testResult.epilogue()

def verify_edgeJoin(mp, edgeNames):
    ''' edge join '''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())

    tnObj = nsxtlib.TransportNode(mgr=mp.mgr)
    mTnList = tnObj.list(display=False)
    mTnList = mTnList['results']
    mTnNames = [e['display_name'] for e in mTnList]
    #pprint(mTnList); 
    mTnDict = {e['display_name']:e['node_deployment_info']['ip_addresses'] for e in mTnList}
    mTnIps = cptutil.flatten(mTnDict.values())

    edgeNames = listify(edgeNames)
    for edgeName in edgeNames:
        edgeIp = cptutil.host2ip(edgeName)
        mTnMatched = [e for e in mTnList if (edgeName in mTnNames or edgeIp in mTnIps)]
        tnFound = (not not mTnMatched)
        mp.testResult.addVerify('Verify TN "%s" exist'%edgeName, tnFound)
        if tnFound:
            mTn = mTnMatched[0]

            r = tnObj.doRestApi('status', _tnId=mTn['id'])
            apiDict = {'url':apiEp(r.request.url), 'response':r.json(),
                'purpose':'get TN "%s" status'%edgeName}
            mp.testResult.appendAttr('steps', '', {'api': apiDict})

            edgeHasJointMP = (r.json()['node_status']['mpa_connectivity_status']=='UP')
            mp.testResult.addVerify('Verify EDGE "%s" joint MP successfully'%edgeName, edgeHasJointMP)

    mp.testResult.epilogue()

def verify_tnConfig(mp, nodeName,
        tzName='', hswName='', pnicNames='', uplinkProfName='',
        ipPool='', cVlanSwName='', cVnics='', cLldpProfName=''):
    ''' TN Config'''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())
    errMsgs, verMsgs = [], []
    #mp.logger.warning('nodeName:%s tzName=%s hswName=%s pnicNames=%s uplinkProfName=%s ipPool=%s'
    #    % (nodeName, tzName, hswName, pnicNames, uplinkProfName, ipPool))

    vResult = {'name':inspect.getframeinfo(inspect.currentframe()).function, 'status':False}
    mp.logger.info1(vResult['name'])

    tnObj = nsxtlib.TransportNode(mgr=mp.mgr, fill=False)

    tnList = tnObj.list(display=False)
    tnDicts = tnList['results']
    mTnNames = [e['display_name'] for e in tnDicts]

    #apiDict = {'url':tnObj.api['list'].url, 'response':tnList}
    #mp.testResult.appendAttr('steps', '', {'api': apiDict})

    tnFound = (nodeName in mTnNames)
    mp.testResult.addVerify('Verify TN "%s" configuration exist'%nodeName, tnFound)
    if tnFound:
        hswFound, hsw = False, None
        mTn = [tn for tn in tnDicts if tn['display_name']==nodeName][0]
        mTnName = mTn['display_name']

        r = tnObj.doRestApi('get', _tnId=mTn['id'])
        apiDict = {'url':apiEp(r.request.url), 'response':r.json(),
            'purpose':'get TN "%s" config'%mTnName}
        mp.testResult.appendAttr('steps', '', {'api': apiDict})

        if hswName:
            mHsws = [hsw for hsw in mTn['host_switches'] if hswName==hsw['host_switch_name']]
            hswFound = (not not mHsws)
            mp.testResult.addVerify('Verify TN "%s" is member of HSW "%s"'%(nodeName, hswName), hswFound)
            if hswFound:
                hsw = mHsws[0]
        if tzName:
            #mp.logger.alert('GOT tzName: %s' % tzName)
            tzObj = nsxtlib.Transportzone(mp.mgr)
            mTz = tzObj.findByName(tzName, display=False)
            mTzName = mTz['display_name']

            #apiDict = {'url':tzObj._findByNameRest['url'], 'response':tzObj._findByNameRest['response']}
            #mp.testResult.appendAttr('steps', '', {'api': apiDict})
            r = tzObj.doRestApi('get', objId=mTz['id'])
            apiDict = {'url':apiEp(r.request.url), 'response':r.json(),
                'purpose':'get TZ "%s" config'%mTzName}
            mp.testResult.appendAttr('steps', '', {'api': apiDict})

            tzFound = (not not mTz)
            mp.testResult.addVerify('Verify TZ "%s" exist'%tzName, tzFound)
            if tzFound:
                mTzIds = [tz['transport_zone_id'] for tz in mTn['transport_zone_endpoints']]
                tzId = mTz['id']
                tzConfigured =  (tzId in mTzIds)
                mp.testResult.addVerify('Verify TN "%s" is member of TZ "%s"' % (nodeName, tzName), tzConfigured)
        if pnicNames:
            #mp.logger.alert('GOT pnicNames: %s' % pnicNames)
            if hswFound:
                mPnics = hsw['pnics']
                mPnicNames = [n['device_name'] for n in mPnics]
                for pnicName in pnicNames:
                    pnicFound = (pnicName in mPnicNames)
                    mp.testResult.addVerify('Verify PNIC "%s" configured on HSW "%s"'
                        % (pnicName, hswName), pnicFound)
        if uplinkProfName:
            mp.logger.alert('GOT uplinkProfName: %s' % uplinkProfName)
            profType = 'UplinkHostSwitchProfile'
            ulpObj = nsxtlib.Uplinkprofile(mp.mgr)

            mUlp = ulpObj.findByName(uplinkProfName, display=False)
            mUlp = mUlp if mUlp and mUlp['resource_type']==profType else None
            ulpFound = (not not mUlp)
            mp.testResult.addVerify('Verify UPLINK_PROFILE "%s" exist'%uplinkProfName, ulpFound)

            if ulpFound and hswFound:
                mUlpId = mUlp['id']


                r = ulpObj.doRestApi('get', _hspId=mUlpId)
                apiDict = {'url':apiEp(r.request.url), 'response':r.json(),
                    'purpose':'get HOST_SWITCH_PROFILE'}
                mp.testResult.appendAttr('steps', '', {'api': apiDict})


                mUlpIds = [p['value'] for p in hsw['host_switch_profile_ids'] if p['key']==profType]
                ulpUsed = (mUlpId in mUlpIds)
                mp.testResult.addVerify('Verify HSW "%s" is using UPLINK_PROFILE "%s"'%(hswName,uplinkProfName), ulpUsed)

        if cLldpProfName:
            mp.logger.alert('GOT lldpProfile: %s' % cLldpProfName)
            profType = 'LldpHostSwitchProfile'
            ulpObj = nsxtlib.Uplinkprofile(mp.mgr)

            ulProf = ulpObj.findByName(cLldpProfName, display=False)
            ulProf = ulProf if ulProf and ulProf['resource_type']==profType else None
            ulpFound = (not not ulProf)
            mp.testResult.addVerify('Verify LLDP_PROFILE "%s" exist'%cLldpProfName, ulpFound)

            if ulpFound and hswFound:
                #mUlpName = ulProf['display_name']
                mUlpId = ulProf['id']

                r = ulpObj.doRestApi('get', _hspId=mUlpId)
                apiDict = {'url':apiEp(r.request.url), 'response':r.json(),
                    'purpose':'get HOST_SWITCH_PROFILE'}
                mp.testResult.appendAttr('steps', '', {'api': apiDict})

                mUlpIds = [p['value'] for p in hsw['host_switch_profile_ids'] if p['key']==profType]
                ulpUsed = (mUlpId in mUlpIds)
                #print(ulpUsed, mUlpId, mUlpIds)
                mp.testResult.addVerify('Verify HSW "%s" is using LLDP_PROFILE "%s"'%(hswName,cLldpProfName), ulpUsed)
        if ipPool:
            mp.logger.alert('GOT ipPool: %s' % ipPool)
            ippObj = nsxtlib.Pools(mp.mgr)
            ippDicts = ippObj.list(display=False)['results']
            ippDicts = [ipp for ipp in ippDicts if ipp['display_name']==ipPool]
            ippDict = ippDicts[0]
            ippFound = (not not  ippDicts)
            mp.testResult.addVerify('Verify IPPOOL "%s" configured'%ipPool, ippFound)
            if ippFound:
                ippId = ippDict['id']
                ippCfgEqual = (hsw['static_ip_pool_id']==ippId)
                mp.testResult.addVerify('Verify HSW "%s" is using IPPOOL "%s"'%(hswName,ipPool), ippCfgEqual)
        if cVlanSwName and cVnics:
            matchedHsw = [hsw for hsw in mTn['host_switch_spec']['host_switches']
                if hsw['host_switch_name']==cVlanSwName]
            hswFound = (not not matchedHsw)
            mp.testResult.addVerify('Verify VLAN_SWITCH "%s" exist'%cVlanSwName, hswFound)
            if hswFound:
                mHsw = matchedHsw[0]
                #print([n['device_name'] for n in mHsw['pnics']])
                #print(cVnics)
                #print([n['device_name'] for n in mHsw['pnics']] == cVnics)
                mp.testResult.addVerify('Verify VNICS "%s" configured on HSW "%s"'%
                    (cVnics,cVlanSwName), ([n['device_name'] for n in mHsw['pnics']] == cVnics))

        if (cVlanSwName or cVnics) and not (cVlanSwName and cVnics):
            mp.logger.warning('NOT VERIFYING VNICS "%s"' % cVnics)

    mp.testResult.epilogue(errMsgs, verMsgs)
    #return vResult

def verify_tnProfileConfig(mp,
                    name,
                    uplinkprofile,
                    pnics,
                    uplinknames,
                    hswname,
                    tz,
                    lldp,
                    vmks,
                    vmknets,
                    vmkuninstall,
                    vmkuninstnets,
                    pnicuninstalls,
                    ippool,
                    desc):
    #tnpName, tnpUlprofName, tnpPnicNames, tnpUlNames, tnpHswName, tnpTzNames, tnpVmks, tnpVmkNets, tnpVmksUninstall, tnpVmkNetsUninstall, tpnPnicUninstalls, tnpDesc, tnpLldp, tnpIppool):
    pass

def _findVerifyObjByName(mp, obj, objName, objTypeName):
    mObjDict = obj.findByName(objName, display=False)
    objFound = (not not mObjDict)
    mp.testResult.addVerify('Verify %s "%s" exist'%(objTypeName,objName), objFound)
    return objFound, mObjDict
def _getLogObjByPath(mp, objUrl):
    objApiResp = mp.mgr.get(objUrl).json()
    apiDict = {'url':objUrl, 'response':objApiResp}
    mp.testResult.appendAttr('steps', '', {'api': apiDict})
    return objApiResp

def __findVerifyObjByName(mp, obj, objName, objTypeName):
    mObjListDict = obj.findByName(objName, display=False)
    listApiResp = obj._findByNameRest['response']
    objFound = (not not mObjListDict)
    mp.testResult.addVerify('Verify %s "%s" exist'%(objTypeName,objName), objFound)
    if objFound:
        objUrl = obj.policyObjPathPrefix+mObjListDict['path']
        objApiResp = mp.mgr.get(objUrl).json()
        apiDict = {'url':objUrl, 'response':objApiResp,
            'purpose':'get %s "%s" info'%(objTypeName,objName)}
        mp.testResult.appendAttr('steps', '', {'api': apiDict})
        return objFound, listApiResp, objApiResp
    else:
        apiDict = {'url':obj._findByNameRest['url'], 'response':listApiResp,
            'purpose':'get full list of %s to find "%s"'%(objTypeName,objName)}
        mp.testResult.appendAttr('steps', '', {'api': apiDict})
        return objFound, listApiResp, None

def verify_segmentConfig(mp, segName, segTz, segLr, segGw, segDhcp, segVlans, segDesc):
    ''' Segment Config'''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())

    segObj = nsxtlib.PM_Segment(mp.mgr)
    #mSegDict = segObj.findByName(segName, display=False)
    #segFound = (not not mSegDict)
    #mp.testResult.addVerify('Verify SEGMENT "%s" exist'%segName, segFound)
    segFound, mSegDict = _findVerifyObjByName(mp, segObj, segName, 'SEGMENT')

    if segFound:
        segUrl = segObj.policyObjPathPrefix+mSegDict['path']
        #segApiResp = mp.mgr.get(segUrl).json()
        #apiDict = {'url':segUrl, 'response':segApiResp}
        #mp.testResult.appendAttr('steps', '', {'api': apiDict})
        _getLogObjByPath(mp, segUrl)

        tzObj = nsxtlib.Transportzone(mp.mgr)

        tzUrl = tzObj.policyObjPathPrefix+mSegDict['transport_zone_path']
        #tzApiResp = mp.mgr.get(tzUrl).json()
        #apiDict = {'url':tzUrl, 'response':tzApiResp}
        #mp.testResult.appendAttr('steps', '', {'api': apiDict})
        tzApiResp = _getLogObjByPath(mp, tzUrl)

        mSegTzName = tzApiResp['display_name']
        if mSegDict:
            checkCondition(mp, set(segVlans), '==', set(mSegDict['vlan_ids']),
                'SEGMENT %s VLANs'%segName)
            checkCondition(mp, mSegTzName, '==', segTz,
                'SEGMENT %s TZ'%segName)
        else:
            mp.testResult.addError('ERROR: segment "%s" not configured' % segName)

    mp.testResult.epilogue()

def verify_cm(mp, cmName):
    ''' Computemanager Config'''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())

    cmObj = nsxtlib.ComputeManager(mp.mgr)
    mCmList = cmObj.list(display=False)
    mCmDicts = mCmList['results']
    mCmNames = [cm['display_name'] for cm in mCmDicts]

    apiDict = {'url':cmObj.api['list'].url, 'response':mCmList, 'purpose':'get CM info'}
    mp.testResult.appendAttr('steps', '', {'api': apiDict})

    cmFound = (cmName in mCmNames)
    mp.testResult.addVerify('Verify ComputeManger "%s" configuration'%cmName, cmFound)
    #pprint(mCmDicts)
    if cmFound:
        mCm = [cm for cm in mCmDicts if cm['display_name']==cmName][0]
        r = cmObj.doRestApi('status', cmId=cm['id'])
        apiDict = {'url':apiEp(r.request.url), 'response':r.json(),
            'purpose':'get CM status'}
        mp.testResult.appendAttr('steps', '', {'api': apiDict})
        cmStatus = r.json()
        mp.testResult.addVerify('Verify Conneciton Status "%s"=="UP"' %
            cmStatus['connection_status'], cmStatus['connection_status']=='UP')
        mp.testResult.addVerify('Verify registration Status "%s"=="REGISTERED"' %
            cmStatus['registration_status'], cmStatus['registration_status']=='REGISTERED')

    mp.testResult.epilogue()

def verify_role(mp, userName, userType, userRoles):
    ''' User Role Config'''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())

    roleObj = nsxtlib.PM_Role(mp.mgr)
    r = roleObj.doRestApi('getBinding')
    apiDict = {'url':apiEp(r.request.url), 'response':r.json(),
        'purpose':'get Role Binding'}
    mp.testResult.appendAttr('steps', '', {'api': apiDict})
    roleBindings = r.json()['results']
    bindingUsers = [b for b in roleBindings if b['name']==userName]
    mp.testResult.addVerify('Verify user name "%s" exist'%userName,
        (len(bindingUsers)==1))
    if len(bindingUsers)==1:
        bindingUser = bindingUsers[0]
        mp.testResult.addVerify('Verify user type "%s" is "%s"'%
            (bindingUser['type'],userType), (bindingUser['type']==userType))
        bindingRoles = [r['role'] for r in bindingUser['roles']]
        missingRoles = set(userRoles)-set(bindingRoles)
        if missingRoles:
            mp.testResult.addError('ERROR: some user role(s) missing "%s"' % missingRoles)
        else:
            mp.testResult.addVerify('Verify user roles "%s": Pass' % userRoles)

    mp.testResult.epilogue()

def checkCondition(mp, v1, op, v2, objName):
    if  op == '==': condition = (v1 == v2)
    elif  op == 'in': condition = (v1 in v2)

    mp.testResult.addVerify(
        'Verify %s "%s" "%s" "%s"' % (objName, v1, op, v2), condition)
    #if condition:
    #    mp.testResult.addVerify(
    #        'Verify %s "%s" "%s" "%s": PASS' % (objName, v1, op, v2))
    #else:
    #    mp.testResult.addError(
    #        'Verify %s "%s" "%s" "%s": FAIL' % (objName, v1, op, v2))

def verify_vidmConfig(mp, vidmHost, client, secret, host, enable, lb):
    ''' vidm Config'''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())

    vidmObj = nsxtlib.Vidm(mp.mgr)
    mVidmDict = vidmObj.list(display=False)

    apiDict = {'url':vidmObj.api['list'].url, 'response':mVidmDict,
        'purpose':'get VIDM config'}
    mp.testResult.appendAttr('steps', '', {'api': apiDict})

    checkCondition(mp, mVidmDict['host_name'],      '==', vidmHost, 'VIDM host')
    checkCondition(mp, mVidmDict['client_id'],      '==', client,   'Client ID')
    checkCondition(mp, mVidmDict['node_host_name'], '==', host,     'Client Name')
    checkCondition(mp, mVidmDict['vidm_enable'],    '==', enable,   'VIDM Enable')
    checkCondition(mp, mVidmDict['lb_enable'],      '==', lb,       'LB Enalble')

    mp.testResult.epilogue()

def verify_clusterCert(mp, certName):
    ''' cluster cert Config'''
    mp.testResult.prologue(myCurFuncName(), myCurFuncDoc())

    custerObj = nsxtlib.Cluster(mp)
    mCulsterCert = custerObj.doRestApi('getCert').json()
    culsterCertId = mCulsterCert['certificate_id']

    apiDict = {'url':custerObj.api['getCert'].url, 'response':mCulsterCert,
        'purpose':'get cluster cert ID'}
    mp.testResult.appendAttr('steps', '', {'api': apiDict})

    certObj = nsxtlib.Certificate(mp=mp)
    r = certObj.doRestApi('get', certId=culsterCertId)
    mCertDict = r.json()
    apiDict = {'url':apiEp(r.request.url), 'response':mCertDict,
        'purpose':'get cluster cert by certID'}
    mp.testResult.appendAttr('steps', '', {'api': apiDict})
    if mCertDict['display_name']==certName:
        mp.testResult.addVerify('Verify cluster is using cert %s' % certName)
    else:
        mp.testResult.addError('ERROR: cluster is NOT using cert "%s"' % certName)
        mp.testResult.addError('ERROR: cluster is using cert "%s"' % mCertDict['display_name'])

    mp.testResult.epilogue()

def mkArgParsers(elemSubparsers, ns, cmds, crNsSubparsers=True):
    ns_parser = elemSubparsers.add_parser(ns)
    ns_sub_parsers = ns_parser.add_subparsers(dest='%s' % ns) if crNsSubparsers else None

    if 'about_ns' in cmds:
        pass
    elif 'cert_ns' in cmds:
        ns_mgr_parser = ns_sub_parsers.add_parser('import')
        ns_mgr_parser.add_argument('certPath')
        ns_mgr_parser.add_argument('--name')
        ns_mgr_parser.add_argument('--desc')
        ns_mgr_parser = ns_sub_parsers.add_parser('applyapi')
        ns_mgr_parser.add_argument('--certname')
        ns_mgr_parser.add_argument('--managernode')
        ns_mgr_parser = ns_sub_parsers.add_parser('applyhttp')
        ns_mgr_parser.add_argument('--certname')
        ns_mgr_parser.add_argument('--managernode')
    elif 'cluster_ns' in cmds:
        ns_seg_parser = ns_sub_parsers.add_parser('cert')
        ns_seg_parser.add_argument('--name', required=True)
    elif 'computeManager_ns' in cmds:
        ns_parser.add_argument('--name', required=True)
    elif 'edge_ns' in cmds:
        ns_edd_parser = ns_sub_parsers.add_parser('deploy')                     # edge/deploy
        ns_edd_parser.add_argument('-v', '--version')
        ns_edd_parser.add_argument('edgenames', nargs='+')
        ns_edj_parser = ns_sub_parsers.add_parser('join')                       # edge/join
        ns_edj_parser.add_argument('edgenames', nargs='+')
        ns_edc_parser = ns_sub_parsers.add_parser('cluster')                    # edge/cluster
        ns_edc_parsers = ns_edc_parser.add_subparsers(dest='ns2')
        ns2_edc_parser = ns_edc_parsers.add_parser('config')                    # edge/cluster/config
        ns2_edc_parser.add_argument('--name', required=True)
        ns2_edc_parser.add_argument('--members', nargs='+')
    elif 'dhcprelay_ns' in cmds:
        ns_parser = ns_sub_parsers.add_parser('config')                         # dhcprelay/config
        ns_parser.add_argument('--name', required=True)
        ns_parser.add_argument('--servers', required=True, nargs='+')
    elif 'manager_ns' in cmds:
        ns_mgr_parser = ns_sub_parsers.add_parser('vip')
        ns_mgr_parser.add_argument('vipValue')
        ns_mgr_parser = ns_sub_parsers.add_parser('cluster')
        ns_mgr_parser.add_argument('-n', '--nodes', nargs='+')
        ns_mgr_parser = ns_sub_parsers.add_parser('node')
        ns_mgr_parser.add_argument('-v', '--version')
    elif 'pool_ns' in cmds:
        ns_parser = ns_sub_parsers.add_parser('config')                         # pool/config
        ns_parser.add_argument('jsonfile')
    elif 'role_ns' in cmds:
        ns_parser.add_argument('--name', help='Username, including domain if applicable')
        ns_parser.add_argument('--type',
                                    default='remote_user',
                                    choices=['remote_user', 'remote_group',
                                             'local_user', 'principal_identity'],
                                    help='Type of user')
        ns_parser.add_argument('--roles',
                                    nargs='*',
                                    required=True,
                                    choices=['enterprise_admin',
                                             'network_engineer',
                                             'lb_admin',
                                             'security_engineer',
                                             'gi_partner_admin',
                                             'network_op',
                                             'vpn_admin',
                                             'auditor',
                                             'security_op',
                                             'lb_auditor',
                                             'netx_partner_admin'],
                                    help="List of roles to bind")
    elif 'segment_ns' in cmds:
        ns_seg_parser = ns_sub_parsers.add_parser('config')
        ns_seg_parser.add_argument('--name', required=True)
        ns_seg_parser.add_argument('--tz', required=True)
        ns_seg_parser.add_argument('--lr')
        ns_seg_parser.add_argument('--gw')
        ns_seg_parser.add_argument('--dhcp')
        #ns_seg_parser.add_argument('--vlans')
        ns_seg_parser.add_argument('--vlans', nargs='+')
        ns_seg_parser.add_argument('--desc')
    elif 'global_ns' in cmds:                                                   # global
        ns_glb_parser = ns_sub_parsers.add_parser('switch')                     # global/switch
        ns_glb_parser.add_argument('--name')
        ns_glb_parser.add_argument('--desc')
        ns_glb_parser.add_argument('--mtu', type=int)
        ns_glb_parser.add_argument('--replication',
            choices=['True', 'False'], help='True or False')

    if 'switch_ns' in cmds:                                                     # switch
        #ns_sw_parser = ns_sub_parsers.add_parser('mtu')
        #ns_sw_parser.add_argument('mtuValue', type=int)
        ns_sw_parser = ns_sub_parsers.add_parser('teaming')                     # switch/teaming
        ns_sw_parser.add_argument('--name')
        ns_sw_parser.add_argument('--policy')

    elif 'tier0_ns' in cmds:
        t0_parser = ns_sub_parsers.add_parser('config')                         # tier0/config
        t0_parser.add_argument('--name', required=True)
        t0_parser.add_argument('--failover', choices=['PREEMPTIVE', 'NON_PREEMPTIVE'])
        t0_parser.add_argument('--ha', choices=['ACTIVE_ACTIVE', 'ACTIVE_STANDBY'])
        t0_parser.add_argument('--transit', nargs='*')
        t0_parser.add_argument('--dhcprelay')
        t0_parser.add_argument('--desc')

        ns_t0_parser = ns_sub_parsers.add_parser('locale')                      # tier0/locale
        ns2_t0_subparsers = ns_t0_parser.add_subparsers(dest='ns2')

        ns2_locEc_parser = ns2_t0_subparsers.add_parser('edgecluster')          # tier0/locale/edgecluster
        ns2_locEc_parser.add_argument('--name', required=True)
        ns2_locEc_parser.add_argument('--cluster', required=True)
        ns2_locEc_parser.add_argument('--locale')

        ns2_locRd_parser = ns2_t0_subparsers.add_parser('redist')               # tier0/locale/redist
        ns2_locRd_parser.add_argument('--name', required=True)
        ns2_locRd_parser.add_argument('--types', required=True, nargs='*',
                            choices=['TIER0_STATIC',
                                     'TIER0_CONNECTED',
                                     'TIER0_EXTERNAL_INTERFACE',
                                     'TIER0_SEGMENT',
                                     'TIER0_ROUTER_LINK',
                                     'TIER0_SERVICE_INTERFACE',
                                     'TIER0_DNS_FORWARDER_IP',
                                     'TIER0_IPSEC_LOCAL_IP',
                                     'TIER0_NAT',
                                     'TIER1_NAT',
                                     'TIER1_STATIC',
                                     'TIER1_LB_VIP',
                                     'TIER1_LB_SNAT',
                                     'TIER1_DNS_FORWARDER_IP',
                                     'TIER1_CONNECTED'] )
        ns2_locRd_parser.add_argument('--locale')

        ns_t0_parser = ns_sub_parsers.add_parser('interface')                   # tier0/interface
        ns2_t0_subparsers = ns_t0_parser.add_subparsers(dest='ns2')

        ns2_intCfg_parser = ns2_t0_subparsers.add_parser('config')              # tier0/interface/config
        ns2_intCfg_parser.add_argument('--name',    required=True)
        ns2_intCfg_parser.add_argument('--int',     required=True)
        ns2_intCfg_parser.add_argument('--segment', required=True)
        ns2_intCfg_parser.add_argument('--cidr',    required=True, nargs="*")
        ns2_intCfg_parser.add_argument('--mtu', type=int)
        ns2_intCfg_parser.add_argument('--edge')
        ns2_intCfg_parser.add_argument('--locale')
        ns2_intCfg_parser.add_argument('--desc')
        ns2_intCfg_parser.add_argument('--type',    default="EXTERNAL",
                            choices=['EXTERNAL', 'SERVICE'])

        ns_t0_parser = ns_sub_parsers.add_parser('bgp')                         # tier0/bgp
        ns2_t0_subparsers = ns_t0_parser.add_subparsers(dest='ns2')

        ns2_bgpCfg_parser = ns2_t0_subparsers.add_parser('config')              # tier0/bgp/config
        ns2_bgpCfg_parser.add_argument('--name',                   required=True)
        ns2_bgpCfg_parser.add_argument('--locale')
        ns2_bgpCfg_parser.add_argument('--local_as',               required=True)
        ns2_bgpCfg_parser.add_argument('--enable_multipathrelax',  action='store_true')
        ns2_bgpCfg_parser.add_argument('--disable_multipathrelax', action='store_true')
        ns2_bgpCfg_parser.add_argument('--enable_intersr',         action='store_true')
        ns2_bgpCfg_parser.add_argument('--disable_intersr',        action='store_true')
        ns2_bgpCfg_parser.add_argument('--enable_ecmp',            action='store_true')
        ns2_bgpCfg_parser.add_argument('--disable_ecmp',           action='store_true')
        ns2_bgpCfg_parser.add_argument('--enable_gr',              action='store_true')
        ns2_bgpCfg_parser.add_argument('--disable_gr',             action='store_true')

        ns2_bgpCfg_parser = ns2_t0_subparsers.add_parser('neighbor')            # tier0/bgp/neighbor/config

        ns3_bgpNbr_subparsers = ns2_bgpCfg_parser.add_subparsers(dest='ns3')

        ns3_bgpNbrCfg_parser = ns3_bgpNbr_subparsers.add_parser('config')       # tier0/bgp/neighbor/config
        ns3_bgpNbrCfg_parser.add_argument('--name',      required=True)
        ns3_bgpNbrCfg_parser.add_argument('--locale')
        ns3_bgpNbrCfg_parser.add_argument('--peer',      required=True)
        ns3_bgpNbrCfg_parser.add_argument('--address',   required=True)
        ns3_bgpNbrCfg_parser.add_argument('--ipv6',          action='store_true')
        ns3_bgpNbrCfg_parser.add_argument('--remoteAs',  required=True)
        ns3_bgpNbrCfg_parser.add_argument('--holdtime',      type=int)
        ns3_bgpNbrCfg_parser.add_argument('--keepalive',     type=int)
        ns3_bgpNbrCfg_parser.add_argument('--secret')
        ns3_bgpNbrCfg_parser.add_argument('--enablebfd',     action='store_true')
        ns3_bgpNbrCfg_parser.add_argument('--disablebfd',    action='store_true')
        ns3_bgpNbrCfg_parser.add_argument('--bfdmultiple',   type=int)
        ns3_bgpNbrCfg_parser.add_argument('--inprefixlist',  nargs='*')
        ns3_bgpNbrCfg_parser.add_argument('--sourceip',      nargs='*')
        ns3_bgpNbrCfg_parser.add_argument('--gr',    choices=["DISABLE", "GR_AND_HELPER", "HELPER_ONLY"])
        ns3_bgpNbrCfg_parser.add_argument('--desc')

    elif 'prefixlist_ns' in cmds:
        ns_pfxl_parser = ns_sub_parsers.add_parser('config')                     # prefixlist/config
        ns_pfxl_parser.add_argument('--t0',     required=True)
        ns_pfxl_parser.add_argument('--name',   required=True)
        ns_pfxl_parser.add_argument("--prefix", required=True, nargs="*",
                                help="List of prefixes, format: CIDR,GE,LE,ACTION, \
                                GE and LE can be blank, ACTION must be PERMIT/DENY")
        ns_pfxl_parser.add_argument('--desc')

    elif 'tn_ns' in cmds:
        ns_tnc_parser = ns_sub_parsers.add_parser('config')                     # tn/config
        ns_tnc_parser.add_argument('--node')
        ns_tnc_parser.add_argument('--hswname')
        ns_tnc_parser.add_argument('--nics', nargs='*')
        ns_tnc_parser.add_argument('--vlansw')
        ns_tnc_parser.add_argument('--vnics', nargs='*')
        ns_tnc_parser.add_argument('--uplinkprofile')
        ns_tnc_parser.add_argument('--lldpprofile')
        ns_tnc_parser.add_argument('--ippool')
        ns_tnc_parser.add_argument('--tzname')

        ns_tnz_parser = ns_sub_parsers.add_parser('addtz')                      # tn/addtz
        ns_tnz_parser.add_argument('--node')
        ns_tnz_parser.add_argument('--tzname')


        ns_tn_parser = ns_sub_parsers.add_parser('profile')                     # tn/prfofile
        ns_tnp_parsers = ns_tn_parser.add_subparsers(dest='ns2')
        ns2_tnpc_parser = ns_tnp_parsers.add_parser('config')                   # tn/prfofile/config
        ns2_tnpc_parser.add_argument('--name', required=True,
                                help='Name of the TransportNode Profile')
        ns2_tnpc_parser.add_argument('--uplinkprofile',
                                help='Name of uplink profile')
        ns2_tnpc_parser.add_argument('--pnics', nargs='*',
                                help='One or more pnics to map')
        ns2_tnpc_parser.add_argument('--uplinknames', nargs='*',
                                help='One or more uplink names to map pnics, '
                                        'names should match uplink profile names')
        ns2_tnpc_parser.add_argument('--hswname',
                                help='Name of the NVDS host switch')
        ns2_tnpc_parser.add_argument('--lldp',
                                help='Name of the LLDP profile')
        ns2_tnpc_parser.add_argument('--tz', nargs='*',
                                help='List of transport zones')
        ns2_tnpc_parser.add_argument('--vmks', nargs='*',
                                help='list of VMKernel interfaces to migrate')
        ns2_tnpc_parser.add_argument('--vmknets', nargs='*',
                                help='List of destinations for vmk migraiton')
        ns2_tnpc_parser.add_argument('--vmkuninstall', nargs='*',
                                help='list of vmkernel interfaces to migrate from NVDS at uninstall')
        ns2_tnpc_parser.add_argument('--vmkuninstnets', nargs='*',
                                help='List of destinations for vmk migration from NVDS at uninstall')
        ns2_tnpc_parser.add_argument('--pnicuninstalls', action='store_true',
                                help='Migrate pnics from NVDS at uninstall?')
        ns2_tnpc_parser.add_argument('--ippool', required=False,
                                help='Name of IP Pool, DHCP if not specified')
        ns2_tnpc_parser.add_argument('--desc', required=False,
                                help='Description of this TN Profile')





    elif 'tz_ns' in cmds:
        ns_parser = ns_sub_parsers.add_parser('config')                         # tz/config
        ns_parser.add_argument('jsonfile')
    elif 'uplink_ns' in cmds:
        ns_parser.add_argument('jsonfile')
    elif 'vidm_ns' in cmds:
        ns_vidm_parser = ns_sub_parsers.add_parser('config')
        ns_vidm_parser.add_argument('--vidmhost', required=True,
            help='VIDM host or IP')
        ns_vidm_parser.add_argument('--client', required=True,
            help='VIDM Oauth2 client ID')
        ns_vidm_parser.add_argument('--secret', required=True,
            help='Oauth client secret')
        ns_vidm_parser.add_argument('--host', required=True,
            help='Node name for redirect to VIDM')
        ns_vidm_parser.add_argument('--enable', action='store_true',
            help='Enable VIDM?')
        ns_vidm_parser.add_argument('--lb', action='store_true',
            help='Enable External LB')


def parseParameters():
    parser = argparse.ArgumentParser()

    parser.add_argument('nsxmgr')
    parser.add_argument('-u', '--nuser',    default='admin')
    parser.add_argument('-p', '--npass',    default='CptWare12345!', help='NSX manager password')
    parser.add_argument('--testid',         required=False, default='TestID-0')
    parser.add_argument('--taskid',         required=False, default='TaskID-0')
    parser.add_argument('--timeoutRetry',   required=False, type=int, default=0)
    parser.add_argument('--timeout',        required=False, type=int, default=2)
    parser.add_argument('--httpRetry',      required=False, type=int, default=0)
    parser.add_argument('--maxVerify',      required=False, type=int, default=2,
                                            help='Number of verification attemtps before return failure')
    parser.add_argument('--verifyInterval',   required=False, type=int, default=10,
                                            help='Interval in seconds after failed verification')
    parser.add_argument('--logfile',        required=False)
    parser.add_argument('--loglevel',       default='WARNING', type=lambda s:s.upper(),
                                            metavar=cptutil.cptLogLevelMetavar,
                                            choices=cptutil.cptLogLevels, help='Set the logging level')
    parser.add_argument('-X',               action='store_true')
    parser.add_argument('--jsonOutputFile', type=argparse.FileType('a'))
    parser.add_argument('--jsonStdout',     action='store_true')

    subparsers = parser.add_subparsers(dest='ns')

    mkArgParsers(subparsers, 'about',       ['about_ns'], crNsSubparsers=False)
    mkArgParsers(subparsers, 'cert',        ['cert_ns'])
    mkArgParsers(subparsers, 'cluster',     ['cluster_ns'])
    mkArgParsers(subparsers, 'computeManager',  ['computeManager_ns'], crNsSubparsers=False)
    mkArgParsers(subparsers, 'dhcprelay',   ['dhcprelay_ns'])
    mkArgParsers(subparsers, 'edge',        ['edge_ns'])
    mkArgParsers(subparsers, 'global',      ['global_ns'])
    mkArgParsers(subparsers, 'manager',     ['manager_ns'])
    mkArgParsers(subparsers, 'pool',        ['pool_ns'])
    mkArgParsers(subparsers, 'prefixlist',  ['prefixlist_ns'])
    mkArgParsers(subparsers, 'role',        ['role_ns'], crNsSubparsers=False)
    mkArgParsers(subparsers, 'segment',     ['segment_ns'])
    mkArgParsers(subparsers, 'switch',      ['switch_ns'])
    mkArgParsers(subparsers, 'tier0',       ['tier0_ns'])
    mkArgParsers(subparsers, 'tn',          ['tn_ns'])
    mkArgParsers(subparsers, 'tnprofile',   ['tnprofile_ns'])
    mkArgParsers(subparsers, 'tz',          ['tz_ns'])
    mkArgParsers(subparsers, 'uplink',      ['uplink_ns'], crNsSubparsers=False)
    mkArgParsers(subparsers, 'vidm',        ['vidm_ns'])

    args = parser.parse_args()
    args.loglevel = getattr(logging, args.loglevel)
    return args

def main():
    args = parseParameters()
    argsNs = vars(args)
    vState = {'status': False}
    cmdln = ' '.join(sys.argv)
    fdRJson  = args.jsonOutputFile or open(os.devnull,'w')

    for vCnt in range(1,args.maxVerify+1):
        logTag = 'TEST[%s] TASK[%s]' % (args.testid, args.taskid)

        #if vCnt>1: args.nsxmgr = 'tmgr1'
        mgrPingable =  pingable(args.nsxmgr, retry=args.timeoutRetry, timeout=args.timeout)
        testResult = TestResult(cmdln, args.testid, args.taskid, vCnt)
        testResult.addVerify('manager pingable', mgrPingable)

        if  mgrPingable:
            mp = None
            try:
                mp = nsxtlib.ManagerNode(
                    loglevel=args.loglevel,
                    logfile=args.logfile,
                    logtag=logTag,
                    host=args.nsxmgr, adminuser=args.nuser, adminpassword=args.npass)
            except ValueError:
                mLogger = cptutil.cptLogger(logLevel=args.loglevel, logFile=args.logfile, logTag=logTag)
                mLogger.info1(cmdln)
                mLogger.error('Cannot connect to manager API service')
            apiServiceUp = (not not mp)
            testResult.addVerify('manager API service UP', apiServiceUp)
        else:
            mLogger = cptutil.cptLogger(logLevel=args.loglevel, logFile=args.logfile, logTag=logTag)
            mLogger.info1(cmdln)
            mLogger.error('Cannot ping "%s"' % args.nsxmgr)

        tResultDict = testResult.rDict

        if mgrPingable and apiServiceUp:
            mp.timeout = args.timeout
            mp.fdRJson = fdRJson
            mp.logger.info1(cmdln)

            mp.testResult = testResult

            if args.ns == 'about':                                              # about_ns
                mp.about()
                vState['status'] = True
                tResultDict['result']['pass'] = True
            elif args.ns == 'manager':                                          # manager_ns
                if argsNs['manager'] == 'vip':                                  # manager_ns/vip
                    verify_managerVip(mp, args.vipValue)
                elif argsNs['manager'] == 'node':                               # manager_ns/node
                    verify_managerNode(mp, args.version)
                elif argsNs['manager'] == 'cluster':                            # manager_ns/cluster_ns
                    verify_managerClusterHealth(mp, args.nodes)
            elif args.ns == 'global':                                           # switch_ns
                if argsNs['global'] == 'switch':                                # switch_ns/mtu
                    verify_switchingGlobalConfig(mp, args.name, args.desc, args.mtu, args.replication)
            elif args.ns == 'switch':                                           # switch_ns
                if argsNs['switch'] == 'teaming':                               # switch_ns/teaming
                    verify_switchTeaming(mp, args.name, args.policy)
            elif args.ns == 'cert':                                             # cert_ns
                if argsNs['cert'] == 'import':                                  # cert_ns/import
                    verify_certImport(mp, args.certPath, args.name, args.desc)
                elif argsNs['cert'] in ['applyapi','applyhttp']:                # cert_ns/api
                    verify_certApply(mp, args.certname, (args.managernode or args.nsxmgr), ['API'])
            elif args.ns == 'tz':                                               # tz_ns
                if argsNs[args.ns] == 'config':                                 # tz_ns/config
                    verify_tz(mp, args.jsonfile)
            elif args.ns == 'uplink':                                           # uplink_ns
                verify_uplink(mp, args.jsonfile)
            elif args.ns == 'pool':                                             # pool_ns
                if argsNs[args.ns] == 'config':                                 # pool_ns/config
                    verify_poolConfig(mp, args.jsonfile)
            elif args.ns == 'edge':                                             # edge_ns
                if argsNs['edge'] == 'deploy':                                  # edge_ns/deploy
                    verify_edgeDeploy(mp, args.edgenames, args.version)
                elif argsNs['edge'] == 'join':                                  # edge_ns/join
                    verify_edgeJoin(mp, args.edgenames)
                elif argsNs['edge'] == 'cluster':                               # edge_ns/cluster
                    if argsNs['ns2'] == 'config':                               # edge_ns/cluster/config
                        verify_edgeClusterConfig(mp, args.name, args.members)
            elif args.ns == 'dhcprelay':                                        # dhcprelay_ns
                if argsNs['dhcprelay'] == 'config':                             # dhcprelay_ns/config
                    verify_dhcprelayConfig(mp, args.name, args.servers)

            elif args.ns == 'prefixlist':                                       # prefixlist_ns
                if argsNs['prefixlist'] == 'config':                            # prefixlist_ns/config
                    verify_prefixlistConfig(mp, args.t0, args.name, args.prefix, args.desc)

            elif args.ns == 'tier0':                                            # tier0_ns
                if argsNs['tier0'] == 'config':                                 # tier0_ns/config
                    verify_t0Config(mp, args.name, args.failover,
                        args.ha, args.transit, args.dhcprelay, args.desc)
                    pass
                elif argsNs['tier0'] == 'locale':                               # tier0_ns/locale
                    if argsNs['ns2'] == 'edgecluster':                          # tier0_ns/locale/edgecluster
                        verify_t0LocaleEdgeCluster(mp, args.name, args.cluster, args.locale)
                    elif argsNs['ns2'] == 'redist':                             # tier0_ns/locale/redist
                        verify_t0LocaleRedist(mp, args.name, args.types, args.locale)
                elif argsNs['tier0'] == 'interface':                            # tier0_ns/interface
                    verify_t0InterfaceConfig(mp, args.name, args.int, args.segment,
                        args.cidr, args.mtu, args.edge, args.locale, args.desc, args.type)
                elif argsNs['tier0'] == 'bgp':                                  # tier0_ns/bgp
                    if argsNs['ns2'] == 'config':                               # tier0_ns/bgp/config
                        verify_t0BgpConfig(mp, args.name, args.locale, args.local_as,
                            args.enable_multipathrelax, args.disable_multipathrelax,
                            args.enable_intersr, args.disable_intersr, args.enable_ecmp,
                            args.disable_ecmp, args.enable_gr, args.disable_gr)
                    elif argsNs['ns2'] == 'neighbor':                           # tier0_ns/bgp/neighbor
                        if argsNs['ns3'] == 'config':                           # tier0_ns/bgp/neighbor/config
                            verify_t0BgpNeighborConfig(mp,
                                args.name, args.locale, args.peer, args.address,
                                args.ipv6, args.remoteAs, args.holdtime, args.keepalive,
                                args.secret, args.enablebfd, args.disablebfd, args.bfdmultiple,
                                args.inprefixlist, args.sourceip, args.gr, args.desc)

            elif args.ns == 'tn':                                               # tn_ns
                if argsNs['tn'] == 'config':                                    # tn_ns/config
                    verify_tnConfig(mp, args.node,
                        args.tzname, args.hswname, args.nics, args.uplinkprofile,
                        args.ippool, args.vlansw, args.vnics, args.lldpprofile)
                elif argsNs['tn'] == 'addtz':                                   # tn_ns/addtz
                    verify_tnAddTz(mp, args.node, args.tzname)
                elif argsNs['tn'] == 'profile':                                 # tn_ns/profile
                    verify_tnProfileConfig(mp,
                        name = args.name,
                        uplinkprofile=args.uplinkprofile,
                        pnics=args.pnics,
                        uplinknames=args.uplinknames,
                        hswname=args.hswname,
                        tz=args.tz,
                        lldp=args.lldp,
                        vmks=args.vmks,
                        vmknets=args.vmknets,
                        vmkuninstall=args.vmkuninstall,
                        vmkuninstnets=args.vmkuninstnets,
                        pnicuninstalls=args.pnicuninstalls,
                        ippool=args.ippool,
                        desc=args.desc)

            elif args.ns == 'segment':                                          # segment_ns
                # segment config  --name MGMT-VLAN3000-Native --tz SF-VLAN --vlans 0
                if argsNs['segment'] == 'config':                               # segment_ns/config
                    verify_segmentConfig(mp, args.name, args.tz, args.lr,
                        args.gw, args.dhcp, args.vlans, args.desc)
            elif args.ns == 'cluster':                                          # custer_ns
                if argsNs['cluster'] == 'cert':                                 # custer_ns/cert
                    verify_clusterCert(mp, args.name)
            elif args.ns == 'computeManager':                                   # computeManager_ns
                verify_cm(mp, args.name)
            elif args.ns == 'role':                                             # role_ns
                verify_role(mp, args.name, args.type, args.roles)
            elif args.ns == 'vidm':                                             # vidm_ns
                # vidm config  --vidmhost sc2-vidm.cptroot.com --client sfmgr --secret 'Vmware123!' --host sfmgr.cptroot.com --enable --lb
                if argsNs['vidm'] == 'config':                                  # vidm_ns/config
                    verify_vidmConfig(mp, args.vidmhost, args.client, args.secret,
                        args.host, args.enable, args.lb)
            else:
                mp.logger.warning('sub-command not processed: %s' % args.ns)

        tResultDict['endTime'] = str(datetime.datetime.now())
        tResultDict_s = json.dumps(tResultDict, indent=4)
        if args.jsonStdout:
            print(tResultDict_s)
        print(tResultDict_s, file=fdRJson)

        testPass = tResultDict['result']['pass']
        #print(vCnt, vState, vState['status'] if vState else tResultDict['result']['pass'] )
        if testPass:
            break
        elif vCnt < args.maxVerify:
            time.sleep(args.verifyInterval)

    return testPass
    #return vState['status'] if vState else mp.testResult.rDict['result']['pass']

if __name__ == "__main__":
    r = main()
    exit(0 if r else 100)

