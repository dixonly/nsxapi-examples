#!/usr/bin/env python
import pinit
import os, sys
import time, datetime
import getpass
import commands
import string
import json
#import yaml
import restlib
import argparse
import logging
import pprint
from pprint import pformat
from cptutil import pprint_od, expandArgFile, textAlign
import cptutil

import collections
from toasterlib import Toaster
from collections import OrderedDict as OD
from random import shuffle
import math
#import pexpect
import nsxplib
import requests, urllib3
requests.packages.urllib3.disable_warnings()                        # for older requests package
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning) # for new requests package


def get_vcenter_config(mgr, results=['ipAddress', 'userName']):
    url = '/api/2.0/services/vcconfig'
    r = mgr.get(url)
    if r.status_code >= 400:
        mgr.responseError(r)
    vcInfo = xmltodict.parse(r.text)['vcInfo']
    #print format_find_result(vcInfo, results=results)
    return format_find_result(vcInfo, results=results)

def parseParameters():
    parser = argparse.ArgumentParser()

    parser.add_argument('nsxmgr')
    parser.add_argument('-u', '--nuser', default='admin')
    parser.add_argument('-p', '--npass', default='CptWare12345!', help='NSX manager password')
    parser.add_argument('--PM', help='Policy Manager, defalt=nsxmgr')
    parser.add_argument('--promptForPassword', action='store_true', help='Prompt for Password')
    parser.add_argument('--timeout', default=None,help='Time for REST calls in seconds')
    parser.add_argument('--useSessCookieFile', help='Authenticate using session file')
    parser.add_argument('--certFile', help='Authenticate using certificate file. '
        'CertFile can be in single .p12 format or commma serperated .crt,.key files. '
        'E.g.: "myCert.p12" OR "myCert.crt,myCert.key"')
    #parser.add_argument('--vuser', default='Administrator@vsphere.local')
    parser.add_argument('--useSearchAPI', action='store_true', help='make use of search API whenever possible')
    parser.add_argument('--safe', action='store_true', help='Do not send non-safe http requests (POST, PUT, DELETE)')
    parser.add_argument('--loglevel', default='INFO', type=lambda s:s.upper(),
        metavar=cptutil.cptLogLevelMetavar,
        choices=cptutil.cptLogLevels, help="Set the logging level")

    parser.add_argument('--nthread', type=int, default=20)
    parser.add_argument('--policysite', default='default',
                        help="Site - default is: default")
    parser.add_argument('--enforcement', default='default',
                        help="Enforcement point, default: default")

    subparsers = parser.add_subparsers(dest="ns")



    mkArgParsers(subparsers, 'cluster',  ['cluster_api'])
    mkArgParsers(subparsers, 'global', ['global_api'])
    mkArgParsers(subparsers, 'tnprofile', ['tnprofile_api'])
    mkArgParsers(subparsers, 'tncollection', ['transport-node-collections_api'])
    mkArgParsers(subparsers, 'site', ['site_api'])
    mkArgParsers(subparsers, 'enforce', ['enforce_api'])
    mkArgParsers(subparsers, 'tz', ['tz_api'])
    mkArgParsers(subparsers, 'ippool', ['ippool_api'])
    mkArgParsers(subparsers, 'segment', ['segment_api'])
    mkArgParsers(subparsers, 'cert', ['cert_api'])
    mkArgParsers(subparsers, 'realizealarms', ['realization_api'])
    mkArgParsers(subparsers, 'realize', ['realizations_api'])
    mkArgParsers(subparsers, 'tier0', ['tier0_api'])
    mkArgParsers(subparsers, 'tier1', ['tier1_api'])
    mkArgParsers(subparsers, 'trust', ['trust_api'])
    mkArgParsers(subparsers, 'role', ['role_api'])
    mkArgParsers(subparsers, 'vidm', ['vidm_api'])
    mkArgParsers(subparsers, 'edgecluster', ['edgecluster_api'])
    mkArgParsers(subparsers, 'edge', ['edge_api'])
    mkArgParsers(subparsers, 'dhcprelay', ['dhcprelay_api'])
    mkArgParsers(subparsers, 'prefixlist', ['prefixlist_api'])
    mkArgParsers(subparsers, 'routemap', ['routemap_api'])
    
    args = parser.parse_args()
    args.loglevel = args.loglevel.upper()
    args.loglevel = getattr(logging, args.loglevel.upper())

    if args.promptForPassword:
        args.npass =  getpass.getpass('NSX Manager password: ')
        if args.PM:
            args.pmpass =  getpass.getpass('NSX Policy Manager password: ')

    return args

def createCommonParsers(parser, names=[], arguments=None):
    '''
    arguments should be a list, if specified
    '''
    if 'list' in names:
        p = parser.add_parser('list')
        if arguments:
            for i in arguments:
                arg='--'+i
                p.add_argument(arg)

    if 'find' in names:
        p = parser.add_parser('find')
        p.add_argument('--name')
        p.add_argument('--id')
        if arguments:
            for i in arguments:
                arg='--'+i
                p.add_argument(arg)

    if 'path' in names:
        p = parser.add_parser('path')
        p.add_argument('--name')
        p.add_argument('--id')
        if arguments:
            for i in arguments:
                arg='--'+i
                p.add_argument(arg)

    if 'realization' in names:
        r = parser.add_parser('realization')
        rns = r.add_subparsers(dest="realizationns")
        if arguments:
            for i in arguments:
                arg='--'+i
                r.add_argument(arg)

        p = rns.add_parser('entities')
        p.add_argument('--name', required=True)

        p = rns.add_parser('status')
        p.add_argument('--name', required=True)

        
def mkArgParsers(elemSubparsers, ns, cmds, crNsSubparsers=True):
    ns_parser = elemSubparsers.add_parser(ns)
    ns_sub_parsers = ns_parser.add_subparsers(dest='%s' % ns) if crNsSubparsers else None

    r = {
        'parser':       ns_parser,
        'subparsers':   ns_sub_parsers,
    }

    if 'cluster_api' in cmds:
        '''
        '''
        cluster_parser = ns_sub_parsers.add_parser('info')
        '''
        '''
        cluster_parser = ns_sub_parsers.add_parser('nodes')
        '''
        '''
        cluster_parser = ns_sub_parsers.add_parser('status')
        '''
        '''
        cluster_parser = ns_sub_parsers.add_parser('health')
        '''
        '''
        cluster_parser = ns_sub_parsers.add_parser('join')
        cluster_parser.add_argument('--primary', required=True,
                                   help='IP/hostname of current cluster member')
        cluster_parser.add_argument('--secondaries', required=True, nargs='+',
                                   help='IP/hostname of one more secondary node')
        cluster_parser = ns_sub_parsers.add_parser('vip')
        '''
        '''
        cluster_vipns = cluster_parser.add_subparsers(dest='clustervip')
        cluster_vipns_parser = cluster_vipns.add_parser('get')
        cluster_vipns_parser = cluster_vipns.add_parser('clear')
        cluster_vipns_parser = cluster_vipns.add_parser('set')
        cluster_vipns_parser.add_argument('--ip', required=True)

        '''
        '''
        cluster_parser = ns_sub_parsers.add_parser('cert')
        cluster_certns = cluster_parser.add_subparsers(dest='clustercert')
        cluster_certns_parser = cluster_certns.add_parser('get')
        cluster_certns_parser = cluster_certns.add_parser('set')
        cluster_certns_parser.add_argument('--name', required=True,
                                            help="Name of certificate")
        cluster_certns_parser = cluster_certns.add_parser('clear')
        cluster_certns_parser.add_argument('--name', required=True,
                                            help="Name of certificate")
    elif 'global_api' in cmds:
        '''
        '''
        createCommonParsers(parser=ns_sub_parsers,
                            names=['list'])
        '''
        '''
        global_parser = ns_sub_parsers.add_parser('switch')
        global_parser.add_argument('--desc',
                                   help="Set the description")
        global_parser.add_argument('--name',
                                   help='Set the display name')
        global_parser.add_argument('--mtu',
                                   help='Set the MTU')
        global_parser.add_argument('--replication',
                                   choices=[True, False],
                                   help="Enable the global replication mode")
        
        global_parser = ns_sub_parsers.add_parser('routing')
        global_parser.add_argument('--desc',
                                   help="Set the description")
        global_parser.add_argument('--name',
                                   help='Set the display name')
        global_parser.add_argument('--mtu',
                                   help='Set the MTU')
        global_parser.add_argument('--l3mode',
                                   choices=['IPV4_ONLY', 'IPV4_AND_IPV6', 'IPV4_ONLY'],
                                   help='Set the MTU')
        
        
    elif 'tnprofile_api' in cmds:
        '''
        '''
        createCommonParsers(parser=ns_sub_parsers,
                            names=['list', 'find'])
        '''
        '''
        tnp_parser = ns_sub_parsers.add_parser('delete')
        tnp_parser.add_argument('--name', required=True,
                                help="Name of the TransportNode Profile")
        tnp_parser = ns_sub_parsers.add_parser('update')
        tnp_parser.add_argument('--name', required=True,
                                help="Name of the TransportNode Profile")
        tnp_parser.add_argument('--desc', required=False, default=None,
                                help="Description of the TransportNode Profile")

        '''
        '''
        tnp_parser = ns_sub_parsers.add_parser('config')
        tnp_parser.add_argument('--name', required=True,
                                help="Name of the TransportNode Profile")
        tnp_parser.add_argument('--uplinkprofile',
                                help='Name of uplink profile')
        tnp_parser.add_argument('--pnics', nargs='*',
                                help="One or more pnics to map")
        tnp_parser.add_argument('--uplinknames', nargs='*',
                                help="One or more uplink names to map pnics, names should match uplink profile names")
        tnp_parser.add_argument('--hswname',
                                help='Name of the NVDS host switch')
        tnp_parser.add_argument('--lldp',
                                help='Name of the LLDP profile')
        tnp_parser.add_argument('--tz', nargs="*",
                                help='List of transport zones')
        tnp_parser.add_argument('--vmks', nargs="*",
                                help="list of VMKernel interfaces to migrate")
        tnp_parser.add_argument('--vmknets', nargs="*",
                                help="List of destinations for vmk migraiton")
        tnp_parser.add_argument('--vmkuninstall', nargs="*",
                                help="list of vmkernel interfaces to migrate from NVDS at uninstall")
        tnp_parser.add_argument('--vmkuninstnets', nargs="*",
                                help="List of destinations for vmk migration from NVDS at uninstall")
        tnp_parser.add_argument('--pnicuninstalls', action='store_true',
                                help="Migrate pnics from NVDS at uninstall?")
        tnp_parser.add_argument('--ippool', required=False,
                                help="Name of IP Pool, DHCP if not specified")
        tnp_parser.add_argument('--desc', required=False,
                                help="Description of this TN Profile")
        '''
        '''
    elif 'site_api' in cmds:
        '''
        '''
        createCommonParsers(parser=ns_sub_parsers,
                            names=['list', 'find', 'path'])
        '''
        '''

    elif 'enforce_api' in cmds:
        '''
        '''
        createCommonParsers(parser=ns_sub_parsers,
                            names=['list', 'find', 'path'])
        '''
        '''

    elif 'tz_api' in cmds:
        '''
        '''
        createCommonParsers(parser=ns_sub_parsers,
                            names=['list', 'find', 'path'])
        '''
        '''

    elif 'segment_api' in cmds:
        '''
        '''
        createCommonParsers(parser=ns_sub_parsers,
                            names=['list', 'find', 'path', 'realization'])
        '''
        '''
        seg_parser = ns_sub_parsers.add_parser('config')
        seg_parser.add_argument('--name', required=True)
        seg_parser.add_argument('--tz', required=True,help="Name of TZ")
        seg_parser.add_argument('--lr', required=False, default=None,
                                help="Logical router to connect to, default none")
        seg_parser.add_argument('--gw', required=False, default=None, 
                                help='CIDR of gateway, means LR interface IP')
        seg_parser.add_argument('--dhcp', required=False, default=None, 
                                help="DHCP range")
        seg_parser.add_argument('--vlans', required=False, default=None, nargs='*', help="List of vlans")
        seg_parser.add_argument('--desc', required=False)
        '''
        '''
    elif 'ippool_api' in cmds:
        createCommonParsers(parser=ns_sub_parsers,
                            names=['list', 'find', 'path', 'realization'])
        '''
        '''
    elif 'transport-node-collections_api' in cmds:
        '''
        '''
        createCommonParsers(parser=ns_sub_parsers,
                           names=['list', 'find', 'path', 'realization'])
        '''
        '''
        tnc_parser = ns_sub_parsers.add_parser('config')
        tnc_parser.add_argument('--name', required=False,
                                help="Name of the TransportNode Collection")
        tnc_parser.add_argument('--computecollection', required=True,
                                help='Name of compute-collection')
        tnc_parser.add_argument('--tnprofile', required=True,
                                help="Name of TN Profile to map to compute-collection")
        tnc_parser.add_argument('--desc', required=False,
                                help="Description of this Transport Node Collection")
    elif 'cert_api' in cmds:
        '''
        '''
        createCommonParsers(parser=ns_sub_parsers,
                            names=['list', 'find', 'path', 'realization'])
        '''
        '''
        cert_parser = ns_sub_parsers.add_parser('import')
        cert_parser.add_argument('--name', required=True)
        cert_parser.add_argument('--certificate', required=True)
        cert_parser.add_argument('--key', required=False, default=None)
        cert_parser.add_argument('--desc', required=False, default=None)
        cert_parser.add_argument('--passphrase', required=False, default=None)
        
    elif 'realization_api' in cmds:
        '''
        '''
        createCommonParsers(parser=ns_sub_parsers,
                            names=['list'] )
        '''
        '''
        alarm_parser = ns_sub_parsers.add_parser('cleanup')
        alarm_parser.add_argument('--path', required=True,
                                  help="Actual path of alarm, see policy logs, or combined alarm's source_reference with relative_path")
        '''
        '''
    elif 'realizations_api' in cmds:
        realize_parser = ns_sub_parsers.add_parser('get')
        '''
        '''
    elif 'prefixlist_api' in cmds:
        '''
        '''
        createCommonParsers(parser=ns_sub_parsers,
                            names=['list', 'find', 'path', 'realization'], arguments=['t0'])
        '''
        '''
        pfx_parser = ns_sub_parsers.add_parser('config')
        pfx_parser.add_argument('--t0',
                                required=True,
                                help="Policy ID of the Tier0 router")
        pfx_parser.add_argument('--name',
                                required=True,
                                help="Prefix list name")
        pfx_parser.add_argument("--prefix",
                                required=True,
                                nargs="*",
                                help="List of prefixes, format: CIDR:GE:LE:ACTION, \
                                GE and LE can be blank, ACTION must be PERMIT/DENY")
        pfx_parser.add_argument('--desc', default=None)

        pfx_parser = ns_sub_parsers.add_parser('delete')
        pfx_parser.add_argument('--t0',
                                required=True,
                                help="Policy ID of the Tier0 router")
        pfx_parser.add_argument('--name',
                                required=True,
                                help="Prefix list name")
    elif 'routemap_api' in cmds:
        '''
        '''
        createCommonParsers(parser=ns_sub_parsers,
                            names=['list', 'find', 'path', 'realization'], arguments=['t0'])
        '''
        '''
        
    elif 'tier0_api' in cmds:
        '''
        '''
        createCommonParsers(parser=ns_sub_parsers,
                            names=['list', 'find', 'path', 'realization'] )
        '''
        '''
        t0_parser = ns_sub_parsers.add_parser('config')
        t0_parser.add_argument('--name', required=True,
                               help="Name or Policy ID of Tier0 to update or add")
        t0_parser.add_argument('--failover', required=False, default=None,
                               choices=['PREEMPTIVE', 'NON_PREEMPTIVE'],
                               help="Failover mode, defaults to non preemptive on create")
        t0_parser.add_argument('--ha', required=False, default=None,
                               choices=['ACTIVE_ACTIVE', 'ACTIVE_STANDBY'],
                               help="HA mode, defaults to active/active on new create")
        t0_parser.add_argument('--transit', required=False, default=None,
                               nargs='*',
                               help="List of CIDR address for Tier0-Tier1 links")
        t0_parser.add_argument('--dhcprelay', required=False, default=None,
                               help="DHCP relay service name")
        t0_parser.add_argument('--desc', required=False, default=None,
                               help="Description of the Tier0")

        t0_parser = ns_sub_parsers.add_parser('interface')
        t0_intNs = t0_parser.add_subparsers(dest='t0intNs')
        t0_int = t0_intNs.add_parser('get')
        t0_int.add_argument('--name', required=True,
                            help="Name of the Tier0 router")
        t0_int.add_argument('--locale', default='default',
                            help="Locale, default is 'default'")
        t0_int.add_argument('--int', default=None,
                            help="Specific interface name")
        
        t0_int = t0_intNs.add_parser('config')
        t0_int.add_argument('--name', required=True,
                            help="Name of the Tier0 router")
        t0_int.add_argument('--int', required=True,
                            help="Interface Name, should be unique")
        t0_int.add_argument('--segment', required=True,
                            help="Name of the segment to connect interface")
        t0_int.add_argument('--cidr', required=True,
                            nargs="*",
                            help="CIDR for interface, 1 or more")
        t0_int.add_argument('--mtu', required=False,
                            default=1500,
                            help="MTU of the interface, default 1500")
        t0_int.add_argument('--edge',
                            required=False,
                            help="Name of the edge if type external")
        t0_int.add_argument('--locale', default='default')
        t0_int.add_argument('--desc', default=None)
        t0_int.add_argument('--type', default="EXTERNAL",
                            choices=['EXTERNAL', 'SERVICE'])

        t0_int = t0_intNs.add_parser('delete')
        t0_int.add_argument('--name', required=True)
        t0_int.add_argument('--int', required=True)
        t0_int.add_argument('--locale', default='default')
        t0_int = t0_intNs.add_parser('status')
        t0_int.add_argument('--name', required=True)
        t0_int.add_argument('--int', required=True)
        t0_int.add_argument('--locale', default='default')
        t0_int = t0_intNs.add_parser('entities')
        t0_int.add_argument('--locale', default='default')
        t0_int.add_argument('--name', required=True)
        t0_int.add_argument('--int', required=True)

        t0_parser = ns_sub_parsers.add_parser('locale')
        t0_localeNs = t0_parser.add_subparsers(dest='t0localens')
        t0_localeP = t0_localeNs.add_parser('get')
        t0_localeP.add_argument('--name', required=True,
                                help="Name of the Tier0")

        t0_localeP = t0_localeNs.add_parser('edgecluster')
        t0_localeP.add_argument('--name', required=True,
                                help="name of the Tier0")
        t0_localeP.add_argument('--cluster', required=True,
                                help="Name of the edge cluster")
        t0_localeP.add_argument('--locale', required=False,
                                default='default')
        
        t0_localeP = t0_localeNs.add_parser('redist')
        t0_localeP.add_argument('--name', required=True,
                                help="name of the Tier0")
        t0_localeP.add_argument('--types', required=True,
                                           nargs='*',
                                           choices=['TIER0_STATIC',
                                                    'TIER0_CONNECTED',
                                                    'TIER0_EXTERNAL_INTERFACE',
                                                    'TIER0_SEGMENT',
                                                    'TIER0_ROUTER_LINK',
                                                    'TIER0_SERVIcE_INTERFACE',
                                                    'TIER0_DNS_FORWARDER_IP',
                                                    'TIER0_IPSEC_LOCAL_IP',
                                                    'TIER0_NAT',
                                                    'TIER1_NAT',
                                                    'TIER1_STATIC',
                                                    'TIER1_LB_VIP',
                                                    'TIER1_LB_SNAT',
                                                    'TIER1_DNS_FORWARDER_IP',
                                                    'TIER1_CONNECTED'],
                                           help='Set Route Redistribution types')
        t0_localeP.add_argument('--locale', required=False,
                                default='default')
        t0_localeP = t0_localeNs.add_parser('preferredEdge')
        t0_localeP.add_argument('--name', required=True,
                                help="name of the Tier0")
        t0_localeP.add_argument('--edges', required=True,
                                nargs='*',
                                help="List of preferred edge names")
        t0_localeP.add_argument('--locale', required=False,
                                default='default')
        t0_parser = ns_sub_parsers.add_parser('bgp')
        t0_bgpNs = t0_parser.add_subparsers(dest='bgpns')
        t0_bgp = t0_bgpNs.add_parser('get')
        t0_bgp.add_argument('--name', required=True,
                            help="Name of the Tier0 router")
        t0_bgp.add_argument('--locale', default='default',
                            help='Name of locale, default is "default"')
                            
        t0_bgp = t0_bgpNs.add_parser('config')
        t0_bgp.add_argument('--name', required=True,
                            help="Name of the Tier0 router")
        t0_bgp.add_argument('--locale', default='default',
                            help='Name of locale, default is "default"')
        t0_bgp.add_argument('--local_as', required=True, type=int,
                            help="Local AS number")
        t0_bgp.add_argument('--enable_multipathrelax',
                            action='store_true',
                            help="Enable BGP multipath relax, default is enabled")
        t0_bgp.add_argument('--disable_multipathrelax',
                            action='store_true',
                            help="Disable BGP multipath relax, takes precedence over enable")
        t0_bgp.add_argument('--enable_intersr',
                            action='store_true',
                            help="Enable Tier0 Inter-SR routing, default is enabled")
        t0_bgp.add_argument('--disable_intersr',
                            action='store_true',
                            help="Disable inter-SR routing, takes precedence over enable")
        t0_bgp.add_argument('--enable_ecmp',
                            action='store_true',
                            help="Enable BGP ECMP, default is enabled")
        t0_bgp.add_argument('--disable_ecmp',
                            action='store_true',
                            help="Disable BGP ECMP, takes precedence over enable")

        t0_bgp = t0_bgpNs.add_parser('neighbor')
        t0_bgpNeighborNs = t0_bgp.add_subparsers(dest='bgpNeighborNs')
        t0_neighbor = t0_bgpNeighborNs.add_parser('get')
        t0_neighbor.add_argument('--name', required=True,
                                 help="name of Tier0 router")
        t0_neighbor.add_argument('--locale', default='default',
                                 help="Tier0 locale, default is 'default'")

        t0_neighbor = t0_bgpNeighborNs.add_parser('config')
        t0_neighbor.add_argument('--name', required=True,
                                 help="name of Tier0 router")
        t0_neighbor.add_argument('--locale', default='default',
                                 help="Tier0 locale, default is 'default'")

        t0_neighbor.add_argument('--peer', required=True,
                                 help="Peer name")
        t0_neighbor.add_argument('--address', required=True,
                                 help="Neighbor IP address")
        t0_neighbor.add_argument('--remoteAs', required=True,
                                 help="Neighbor AS number")
        t0_neighbor.add_argument('--holdtime', required=False,
                                 default=None,
                                 help="BGP hold down time, default 180s")
        t0_neighbor.add_argument('--keepalive', required=False,
                                 default=None,
                                 help="BGP keepalive timer, default 60s")
        t0_neighbor.add_argument('--password', required=False,
                                 default=None,
                                 help="Neighbor password, use empty value '' to clear")
        t0_neighbor.add_argument('--enablebfd', required=False,
                                 action='store_true',
                                 help="Enable BFD")
        t0_neighbor.add_argument('--disablebfd', required=False,
                                 action='store_true',
                                 help="Disable BFD, will take precedence over enable")
        t0_neighbor.add_argument('--bfdinterval', required=False,
                                 default=None,
                                 help="BFD interval in ms, default 1000ms")
        t0_neighbor.add_argument('--bfdmultiple', required=False,
                                 default=None,
                                 help="BFD Multiplier, default 3")

        t0_neighbor.add_argument('--desc', required=False,
                                 default=None,
                                 help="Neighbor description")
        t0_neighbor = t0_bgpNeighborNs.add_parser('delete')                            
        t0_neighbor.add_argument('--name', required=True,
                                 help="name of Tier0 router")
        t0_neighbor.add_argument('--locale', default='default',
                                 help="Tier0 locale, default is 'default'")

        t0_neighbor.add_argument('--peer', required=True,
                                 help="Peer name")

    elif 'prefixlist_api' in cmds:
        '''
        '''
        createCommonParsers(parser=ns_sub_parsers,
                            names=['list', 'find', 'path'])
        '''
        '''
        
    elif 'tier1_api' in cmds:
        '''
        '''
        createCommonParsers(parser=ns_sub_parsers,
                            names=['list', 'find', 'path', 'realization'] )
        '''
        '''
    elif 'trust_api' in cmds:
        '''
        '''
        createCommonParsers(parser=ns_sub_parsers,
                            names=['list','find'])
        '''
        '''
        pi_parser = ns_sub_parsers.add_parser('create')
        pi_parser.add_argument('--name', required=True,
                               help="Name of the PI")
        pi_parser.add_argument('--nodeid', required=False,
                               default=None,
                               help="Node identifier, defaults to node name if not provided")
        pi_parser.add_argument('--cert', required=True,
                               help="Name of imported certificate")
        pi_parser.add_argument('--protected', default=False,
                               action='store_true',
                               help="Defaults to false, objects created by PI will be protected if true")
        pi_parser.add_argument('--role', required=True,
                               help="Role to assign, use role list to see valid roles")
        pi_parser.add_argument('--desc', required=False,
                               help="Description of the PI")

        pi_parser = ns_sub_parsers.add_parser('delete')
        pi_parser.add_argument('--name', required=True,
                               help="Name of the PI")
        

    elif 'role_api' in cmds:
        '''
        '''
        createCommonParsers(parser=ns_sub_parsers,
                            names=['list'])
        '''
        '''
        bindings = ns_sub_parsers.add_parser('bindings')
        bindingsNs = bindings.add_subparsers(dest='bindingsns')
        bindingsParser = bindingsNs.add_parser('add')
        bindingsParser.add_argument('--name',
                                    help='Username, including domain if applicable')
        bindingsParser.add_argument('--type',
                                    default='remote_user',
                                    choices=['remote_user', 'remote_group',
                                             'local_user', 'principal_identity'],
                                    help='Type of user')
        bindingsParser.add_argument('--roles',
                                    nargs='*',
                                    required=True,
                                    choices=['enterprise_admin',
                                             'network_engineer',
                                             'lb_admin',
                                             'security_engineer',
                                             'gi_partner_admin',
                                             'network_op',
                                             'vpn_admin',
                                             'auditor',
                                             'security_op',
                                             'lb_auditor',
                                             'netx_partner_admin'],
                                    help="List of roles to bind")
        bindingsParser = bindingsNs.add_parser('list')
        
        
                                             
    
        
        
    elif 'vidm_api' in cmds:
        '''
        '''
        createCommonParsers(parser=ns_sub_parsers,
                            names=['list'])
        '''
        '''
        idp_parser = ns_sub_parsers.add_parser('config')
        idp_parser.add_argument('--vidmhost', required=True,
                              help="VIDM host or IP")
        idp_parser.add_argument('--client', required=True,
                              help='VIDM Oauth2 client ID')
        idp_parser.add_argument('--secret', required=True,
                                help="Oauth client secret")
        idp_parser.add_argument('--host', required=True,
                                help="Node name for redirect to VIDM")
        idp_parser.add_argument('--enable', action='store_true',
                                help="Enable VIDM?")
        idp_parser.add_argument('--lb', action='store_true',
                                help="Enable External LB")

        idp_parser = ns_sub_parsers.add_parser('status')
        idp_parser = ns_sub_parsers.add_parser('state')
        
    elif 'edgecluster_api' in cmds:
        '''
        '''
        createCommonParsers(parser=ns_sub_parsers,
                            names=['list', 'find', 'path'])
                 
        '''
        '''
    elif 'edge_api' in cmds:
        '''
        '''
        createCommonParsers(parser=ns_sub_parsers,
                            names=['list', 'find', 'path'])
        '''
        '''
    elif 'dhcprelay_api' in cmds:
        '''
        '''
        createCommonParsers(parser=ns_sub_parsers,
                            names=['list', 'find', 'path'])
        '''
        '''
                                
        
    return r


def loadJsonFromFile(filename):
    fp  = open(filename).read()
    return json.loads(fp)


def createNsxpObject(objName, mp, args):
    '''
    For every object that inherits from Policy_object to be used from nsxplib, create it here
    '''

    if objName=='cluster':
        return nsxplib.Cluster(mp=mp)
    elif objName=='global':
        return nsxplib.GlobalConfigs(mp=mp)
    elif objName=='tnprofile':
        return nsxplib.TNProfile(mp=mp)
    elif objName=='site':
        return nsxplib.Sites(mp=mp)
    elif objName=='enforce':
        return nsxplib.EnforcementPoints(mp=mp)
    elif objName=='tz':
        return nsxplib.TransportZone(mp=mp)
    elif objName=='segment':
        return nsxplib.Segments(mp=mp)
    elif objName=='ippool':
        return nsxplib.IpPool(mp=mp)
    elif objName=='tncollection':
        return nsxplib.TNCollections(mp=mp)
    elif objName=='computecollection':
        return nsxplib.ComputeCollections(mp=mp)
    elif objName=='cert':
        return nsxplib.Certificate(mp=mp)
    elif objName=='realizealarms':
        return nsxplib.Realization(mp=mp)
    elif objName=='realize':
        return nsxplib.Realization(mp=mp)
    elif objName=='tier0':
        return nsxplib.Tier0(mp=mp)
    elif objName=='tier1':
        return nsxplib.Tier1(mp=mp)
    elif objName=='trust':
        return nsxplib.PrincipalIdentity(mp=mp)
    elif objName=='role':
        return nsxplib.Roles(mp=mp)
    elif objName=='vidm':
        return nsxplib.Vidm(mp=mp)
    elif objName=='edgecluster':
        return nsxplib.EdgeCluster(mp=mp)
    elif objName=='edge':
        return nsxplib.Edge(mp=mp)
    elif objName=='dhcprelay':
        return nsxplib.DhcpRelay(mp=mp)
    elif objName=='prefixlist':
        if not args.t0:
            raise ValueError("Prefixlist must specify Tier0 router")
        return nsxplib.PrefixList(mp=mp, tier0=args.t0)
    elif objName=='routemap':
        if not args.t0:
            raise ValueError("RouteMap must specify Tier0 router")
        return nsxplib.RouteMap(mp=mp, tier0=args.t0)
        
    '''
    elif objectName=='':
        return nsxplib.(mp=mp)
    '''
    return None


def commonHandlers(obj, argsNs, args):
    if argsNs[args.ns] == 'path':
        if not args.name and not args.id:
            print("Must provide either name or id, ID takes precedence")
            return
        if not obj.listUrl:
            d=obj.list(display=False)
        else:
            d=None
            
        if args.id:
            obj.getPathById(id=args.id, data=d,display=True)
        else:
            obj.getPathByName(name=args.name,data=d,display=True)

    elif argsNs[args.ns] == 'list':
        obj.list(display=True)
    elif argsNs[args.ns] == 'find' or argsNs[args.ns] == 'show':
        if not args.name and not args.id:
            print("Must provide either name or id, ID takes precedence")
            return

        if not obj.listUrl:
            d=obj.list(display=False)
        else:
            d=None

        if args.id:
            obj.findById(id=args.id,data=d,display=True)
        else:
            obj.findByName(name=args.name,data=d,display=True)
    elif argsNs[args.ns] == 'realization':
        if argsNs['realizationns'] == 'entities':
            obj.getRealizationEntities(name=args.name,display=True)
        elif argsNs['realizationns'] == 'status':
            obj.getRealizationStatus(name=args.name,display=True)
        
def main():
    args = parseParameters()
    argsNs = vars(args)

    mp = nsxplib.PolicyNode(host=args.nsxmgr,
                            adminuser=args.nuser,
                            adminpassword=args.npass,
                            rootpassword=args.npass,
                            site=args.policysite,
                            enforce=args.enforcement,
                            verify=False,
                            loglevel=args.loglevel,
                            certFile=args.certFile,
                            sessCookieFile=args.useSessCookieFile,
                            timeout=args.timeout,
                            thumbprint=False)
                     
    mgr = mp.getMgr()
    mgr.useSearchAPI = args.useSearchAPI
    mgr.logger.debug(pformat(mgr.__dict__))

    if args.safe:
        ''' disable PUT and POST rest request '''
        mgr.setVerbOp('post', None)
        mgr.setVerbOp('patch', None)
        mgr.setVerbOp('put', None)

    mLogger = mgr.logger

    #if args.sessCookieFile:
    #    sCookie = SessionCookie(mgr, sessCookieFile=args.sessCookieFile)
    #    sCookie.useSessFile()


    obj = createNsxpObject(objName=args.ns, mp = mp, args=args)
    if not obj:
        print("Object name %s not handled by createNsxpObject()" %args.ns)
        return
    commonHandlers(obj=obj, argsNs=argsNs, args=args)
    
    if args.ns == 'cluster':
        if argsNs['cluster'] == 'info':
            obj.info()
        elif argsNs['cluster'] == 'nodes':
            obj.nodes()
        elif argsNs['cluster'] == 'status':
            obj.status()
        elif argsNs['cluster'] == 'health':
            obj.health()
        elif argsNs['cluster'] == 'join':
            primary=nsxplib.PolicyNode(host=args.primary, rootpassword=args.npass,
                                adminpassword=args.npass,
                                loglevel=args.loglevel)
            secondaries=[]
            for s in args.secondaries:
                smp=nsxplib.PolicyNode(host=s, adminpassword=args.npass,loglevel=args.loglevel)
                secondaries.append(smp)
            obj.createCluster(primary=primary,secondaries=secondaries)

        elif argsNs['cluster'] == 'vip':
            if argsNs['clustervip'] == 'get':
                obj.getClusterIp()
            elif argsNs['clustervip'] == 'clear':
                obj.clearClusterIp()
            elif argsNs['clustervip'] == 'set':
                obj.setClusterIp(addr=args.ip)
        elif argsNs['cluster'] == 'cert':
            if argsNs['clustercert'] == 'get':
                obj.getCertificate()
            elif argsNs['clustercert'] == 'clear':
                obj.clearCertificate(certName=args.name)
            elif argsNs['clustercert'] == 'set':
                obj.setCertificate(certName=args.name)
                
    elif args.ns == 'global':
        if argsNs['global'] == 'switch':
            obj.updateSwitchingConfig(name=args.name, desc=args.desc,
                                    mtu=args.mtu,
                                    replication=args.replication)
        elif argsNs['global'] == 'routing':
            obj.updateRoutingConfig(name=args.name, desc=args.desc,
                                    mtu=args.mtu,
                                    l3mode=args.l3mode)
    elif args.ns == 'tnprofile':
        if argsNs['tnprofile'] == 'config':
            obj.config(name = args.name,
                       uplinkprofile=args.uplinkprofile,
                       pnics=args.pnics,
                       uplinknames=args.uplinknames,
                       hswname=args.hswname,
                       tz=args.tz,
                       lldp=args.lldp,
                       vmks=args.vmks,
                       vmknets=args.vmknets,
                       vmkuninstall=args.vmkuninstall,
                       vmkuninstnets=args.vmkuninstnets,
                       pnicuninstalls=args.pnicuninstalls,
                       ippool=args.ippool,
                       desc=args.desc)
    elif args.ns == 'tncollection':
        if argsNs['tncollection'] == 'config':
            obj.config(computecollection=args.computecollection,
                        tnprofile=args.tnprofile,
                        name=args.name,
                        desc=args.desc)    
        
        '''
        '''
    elif args.ns == 'tier0':
        if argsNs['tier0'] == 'config':
            obj.config(name=args.name, failover=args.failover,
                       ha=args.ha, transit=args.transit,
                       dhcprelay=args.dhcprelay, desc=args.desc)
            
        elif argsNs['tier0'] == 'interface':
            if argsNs['t0intNs'] == 'get':
                obj.getInterfaces(name=args.name, locale=args.locale,
                                  interface=args.int, display=True)
            elif argsNs['t0intNs'] == 'config':
                obj.createInterface(name=args.name, interface=args.int,
                                    segment=args.segment, cidr=args.cidr,
                                    mtu=args.mtu, intType=args.type,
                                    edge=args.edge, desc=args.desc,
                                    locale=args.locale)
            elif argsNs['t0intNs'] == 'delete':
                obj.deleteInterface(name=args.name, interface=args.int,
                                    locale=args.locale, display=True)
            elif argsNs['t0intNs'] == 'status':
                i = obj.getInterfaces(name=args.name, interface=args.int,
                                      locale=args.locale, display=False)
                if i:
                    obj.getRealizationStatus(path=i['path'], display=True)
            elif argsNs['t0intNs'] == 'entities':
                i = obj.getInterfaces(name=args.name, interface=args.int,
                                      locale=args.locale, display=False)
                if i:
                    obj.getRealizationEntities(path=i['path'], display=True)
            
        elif argsNs['tier0'] == 'locale':
            if argsNs['t0localens'] == 'get':
                obj.getLocale(name=args.name,display=True)
            elif argsNs['t0localens'] == 'redist':
                obj.setRouteDistribution(name=args.name, locale=args.locale,
                                         redist=args.types)
            elif argsNs['t0localens'] == 'edgecluster':
                obj.setEdgeCluster(name=args.name, locale=args.locale,
                                   cluster=args.cluster)
            elif argsNs['t0localens'] == 'preferredEdge':
                obj.setPreferredEdges(name=args.name, edges=args.edge, locale=args.locale)
                
        elif argsNs['tier0'] == 'bgp':
            if argsNs['bgpns'] == 'get':
                obj.getBgpConfig(name=args.name, locale=args.locale,display=True)
            elif argsNs['bgpns'] == 'config':
                obj.configBgp(name=args.name, locale=args.locale, localas=args.local_as,
                              enable_multipathrelax=args.enable_multipathrelax,
                              disable_multipathrelax=args.disable_multipathrelax,
                              enable_intersr=args.enable_intersr,
                              disable_intersr=args.disable_intersr,
                              enable_ecmp=args.enable_ecmp,
                              disable_ecmp=args.disable_ecmp,
                              display=True)
            elif argsNs['bgpns'] == 'neighbor':
                if argsNs['bgpNeighborNs'] == 'get':
                    obj.getBgpNeighbors(name=args.name, locale=args.locale,display=True)
                elif argsNs['bgpNeighborNs'] == 'config':
                    obj.configBgpNeighbor(name=args.name, neighborAddr = args.address,
                                          remoteAs=args.remoteAs, neighborName = args.peer,
                                          neighborDesc=args.desc, holdtime=args.holdtime,
                                          keepalive=args.keepalive,
                                          password=args.password,
                                          locale=args.locale,
                                          enablebfd=args.enablebfd,
                                          disablebfd=args.disablebfd,
                                          bfdInterval=args.bfdinterval,
                                          bfdMultiple=args.bfdmultiple,
                                          display=True)
                elif argsNs['bgpNeighborNs'] == 'delete':
                    obj.deleteBgpNeighbor(name=args.name, locale=args.locale,
                                          neighborName=args.peer, display=True)
                              
        '''
        '''

    elif args.ns == 'prefixlist':
        if argsNs['prefixlist'] == 'config':
            obj.config(t0=args.t0,
                       name=args.name,
                       prefix=args.prefix,
                       desc=args.desc, display=True)
        elif argsNs['prefixlist'] == 'delete':
            obj.deletePrefixList(t0=args.t0, name=args.name, display=True)
            
    elif args.ns == 'segment':
        if argsNs['segment'] == 'config':
            obj.config(name=args.name,
                       tz=args.tz,
                       connectPath=args.lr,
                       gw=args.gw,
                       dhcp=args.dhcp,
                       vlans=args.vlans,
                       desc=args.desc)

        '''
        '''

    elif args.ns == 'cert':
        if argsNs['cert'] == 'import':
            obj.importCertificate(name=args.name,
                       cert=args.certificate,
                       key=args.key,
                       passphrase=args.passphrase,
                       description=args.desc)
                       
        '''
        '''

    elif args.ns == 'realizealarms':
        if argsNs['realizealarms'] == 'cleanup':
            obj.cleanup(path=args.path)
            
        '''
        '''
    elif args.ns == 'realize':
        if argsNs['realize'] == 'get':
            obj.systemList()
            
        '''
        '''

    elif args.ns == 'trust':
        if argsNs['trust'] == 'create':
            if not args.nodeid:
                args.nodeid=args.name
                
            obj.create(name=args.name, nodeid=args.nodeid,
                       role=args.role, cert=args.cert,
                       desc=args.desc, isprotected=args.protected)

        elif argsNs['trust'] == 'delete':
            obj.deletePi(name=args.name, display=True)

    elif args.ns == 'vidm':
        if argsNs['vidm'] == 'config':
            obj.config(vidmhost=args.vidmhost, client=args.client,
                       secret=args.secret, nodename=args.host,
                       enable=args.enable, lb=args.lb)
        elif argsNs['vidm'] == 'status':
            obj.getStatus()
        elif argsNs['vidm'] == 'state':
            if obj.getState():
                print("Online")
            else:
                print("Not Online")
    elif args.ns == 'role':
        if argsNs['role'] == 'bindings':
            if argsNs['bindingsns'] == 'add':
                obj.bind(name=args.name, roles=args.roles,
                         utype=args.type, display=True)

            elif argsNs['bindingsns'] == 'list':
                obj.list(restUrl='/policy/api/v1/aaa/role-bindings',display=True)
                         
                
if __name__ == "__main__":
    main()
