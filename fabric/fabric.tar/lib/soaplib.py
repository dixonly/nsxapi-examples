"""
adopted from Michael Rice
Github: https://github.com/michaelrice
Website: https://michaelrice.github.io/
Blog: http://www.errr-online.com/
This code has been released under the terms of the Apache 2.0 licenses
http://www.apache.org/licenses/LICENSE-2.0.html
"""
from __future__ import print_function

__author__ = 'michael rice <michael@michaelrice.org>'

import logging
import requests

class Soap(object):
    def _send_request(self, payload=None, session=None):
        """
        Using requests we send a SOAP envelope directly to the
        vCenter API to reset an alarm to the green state.

        :param payload:
        :param session:
        :return:
        """
        stub = session
        host_port = stub.host
        # Ive seen some code in pyvmomi where it seems like we check for http vs
        # https but since the default is https do people really run it on http?
        url = 'https://{0}/sdk'.format(host_port)
        logging.debug("Sending {0} to {1}".format(payload, url))
        # I opted to ignore invalid ssl here because that happens in pyvmomi.
        # Once pyvmomi validates ssl it wont take much to make it happen here.
        res = requests.post(url=url, data=payload, headers={
            'Cookie': stub.cookie,
            'SOAPAction': 'urn:vim25',
            'Content-Type': 'application/xml'
        }, verify=False)
        if res.status_code != 200:
            logging.debug("Failed to reset alarm. HTTP Status: {0}".format(
                res.status_code))
            return False
        return True
