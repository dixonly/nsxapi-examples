#!/usr/bin/env python

import pinit
#import Queue
try:
    from Queue import Queue
except:
    from queue import Queue
import threading
import time
import logging
import copy
import pprint
import types
import itertools
#import commands
import subprocess
from cptutil import flatten

class ToasterSlot(threading.Thread):
    def __init__(self, queue, logger):
        threading.Thread.__init__(self)
        self.queue = queue
        self.logger = logger

    def run(self):
        ''' each ToasterSlot monitors the queue to process job '''
        while True:
            job = self.queue.get()
            self.logger.debug('%s STARTED', job['_threadName'])
            self.queue.pending += 1;

            workload = job['_workload']
            if isinstance(workload, types.StringType):
                #print(commands.getoutput(workload))
                print(subprocess.check_output(workload.split(' ')))

            elif isinstance(workload, (types.FunctionType, types.MethodType)):

                '''
                kwargs = {}
                for k in job['kwargs']:
                    if k.startswith('_'):
                        kwargs[k[1:]] = job['kwargs'][k]
                    else:
                        kwargs[k] = job['kwargs'][k]

                print('run(): args=%s, kwargs=%s' % (job['args'], kwargs))

                if kwargs and 'args' in job and job['args']:
                    workload(*job['args'], **kwargs)
                elif 'args' in job and job['args']:
                    workload(*job['args'])
                elif kwargs:
                    workload(**kwargs)
                else:
                    workload()

                '''
                if 'kwargs' in job and job['kwargs'] and 'args' in job and job['args']:
                    workload(*job['args'], **job['kwargs'])
                elif 'args' in job and job['args']:
                    workload(*job['args'])
                elif 'kwargs' in job and job['kwargs']:
                    #pprint.pprint(job); exit()
                    workload(**job['kwargs'])
                else:
                    workload()

            self.queue.pending -= 1;
            self.logger.debug('%s DONE', job['_threadName'])
            self.queue.task_done()

class Toaster(object):
    def __init__(self, nSlot, logLevel=logging.WARNING, logger=None):
        ''' create toster object which contains: nSlot ThreadWorkers, logger, queue '''
        if logger:
            self.logger = logger
        else:
            logging.basicConfig(
                datefmt='%T',
                format='%(asctime)s (%(threadName)-9s) %(message)s')
            self.logger = logging.getLogger('Toaster')
            self.logger.setLevel(logLevel)

        #self.queue = Queue.Queue()
        self.queue = Queue()
        self.queue.pending = 0
        self.lock = threading.Lock()
        for i in range(nSlot):
            t = ToasterSlot(self.queue, self.logger)
            t.setDaemon(True)
            t.start()


    def load(self, threadName, workload, *args, **kwargs):
        ''' package up job description into jobDesc, put job on the queue '''
        jobDesc = {
            '_threadName' : threadName,
            '_workload' : workload,
            'args' : args,
            'kwargs' : kwargs
            }
        self.queue.put(jobDesc)

    def qsize(self):
        return self.queue.qsize()

    def wait(self, loop=False):
        if loop:
            ''' this is to allow keyboard interrup '''
            while not self.queue.empty() or self.queue.pending > 0:
                self.logger.debug('%d slice waiting, %d slice toasting' % (self.queue.qsize(), self.queue.pending))
                time.sleep(1)
            self.logger.debug('%d jobs in queue, DONE WAITING' % self.queue.qsize())
        else:
            self.queue.join()

    def wait2(self):
        self.wait(loop=True)

    def _mkTaskList(self, jobDict):
        #order = {'fifo', 'lifo', 'roundrobin', 'random'}
        order = jobDict['order'] if 'order' in jobDict else 'fifo'
        tasks = []      # this is a nested list
        #import pprint; pprint.pprint(jobDict)
        for jobId,job in enumerate(jobDict['jobs']):
            fnKwargs = job['fnKwargs'] if 'fnKwargs' in job else {}
            nTask = job['nTask'] if 'nTask' in job else 1
            #batchSize = job['batchSize'] if 'batchSize' in job else nTask

            subTasks = []
            for taskId in range(nTask):
                taskName = 'TASK%04d'%taskId
                '''
                fnKwargsTmp = copy.deepcopy(fnKwargs)
                for k in fnKwargsTmp:
                    if isinstance(fnKwargsTmp[k],str) and '%' in fnKwargsTmp[k]:
                        fnKwargsTmp[k] = eval(fnKwargsTmp[k])
                subTasks.append([jobId, taskId, job['fn'], fnKwargsTmp])
                '''
                fnKwargsTmp = {}
                for k in fnKwargs:
                    fnKwargsTmp[k] = eval(fnKwargs[k]) if isinstance(fnKwargs[k],str) and '%' in fnKwargs[k] else fnKwargs[k]
                #fnKwargsTmp = {
                #    k: eval(fnKwargs[k]) if isinstance(fnKwargs[k],str) and '%' in fnKwargs[k] else fnKwargs[k] for k in fnKwargs
                #}
                subTasks.append([jobId, taskId, job['fn'], fnKwargsTmp])
            tasks.append(subTasks)
        if order=='lifo':
            tasks = reversed(flatten(tasks))
        elif order=='random':
            tasks = flatten(tasks)
            random.shuffle(tasks)
        elif order=='roundrobin':
            tasks = flatten(itertools.izip_longest(*tasks))
            tasks = filter(lambda x:x, tasks)
        else:   # fifo
            tasks = flatten(tasks)
        #print([t[:2] for t in tasks])
        return tasks

    def schedule(self, jobDict):
        '''
        jobDict = {
            'nWorker': 2,       # number of threads to create
            'batchSize': 3,     # number of tasks to submit each jInterval period
            'jInterval': 10,    # interval between submiting tasks
            'jIntSlack': 1,     # random slack for each jInterval
            'order': 'fifo',    # 'fifo'|'random'|'roundrobin'|'lifo'
            'jobs': [
                {
                    'fn': workloadFn    # REQUIRED
                    'fnKwargs': {
                        'jobName': '"TASK-%d-%d"%(jobId,taskId)',
                        'memSize': 1024000
                    },
                    'nTask': 3,
                },
            ]
        }
        '''
        #nWorker = jobDict['nWorker'] if 'nWorker' in jobDict else 2
        batchSize = jobDict['batchSize'] if 'batchSize' in jobDict else nWorker
        jInterval = jobDict['jInterval'] if 'jInterval' in jobDict else 0
        jIntSlack = jobDict['jIntSlack'] if 'jIntSlack' in jobDict else 0
        if 'order' not in jobDict: jobDict['order'] = 'fifo'


        #toaster = Toaster(nWorker)
        #print('%d worker threads created, job ordering: %s' % (nWorker, jobDict['order']))
        self.logger.info('Main + %d threads active, job ordering: %s' % (threading.active_count()-1, jobDict['order']))

        startTime = time.time()
        tasks = self._mkTaskList(jobDict)
        nTask = len(tasks)
        for taskIdx,task in enumerate(tasks):
            jobId,taskId,fn,fnKwargs = task
            self.load('crWF%04d'%taskId, fn, **fnKwargs)
            #print('%s loaded %s %s' % (now(), 'JOB%04d'%jobId,'TASK%04d'%taskId))
            if (jInterval and taskIdx and (taskIdx+1)%batchSize==0 and taskIdx<nTask-1):
                #print('%s SLEEPING...taskIdx=%d, batchSize=%d, nTask=%d' % (now(), taskIdx, batchSize, nTask))
                time.sleep(jInterval+random.randint(-jIntSlack,jIntSlack))
        self.wait()
        doneTime = time.time()
        self.logger.info('%s DONE' % time.strftime('%T'))
        return doneTime - startTime

###################################### MAIN ####################################
import random, datetime
def toasterWorkloadFn(msg='MSG', jobName='', delay=0):
    if delay == 0:
        delay = random.randint(1,10)/10.0
    print('%s %s, %s delay=%s' % (datetime.datetime.now().strftime('%H:%M:%S'),
        msg, jobName, str(delay)))
    time.sleep(delay)

class ToasterWorkload():
    def workload(self, msg='MSG', jobName='JOBNAME', delay=0, lock=None):
        toasterWorkloadFn(msg, jobName, delay)

def toasterlib_test_fn():
    hosts = ["yahoo.com", "google.com", "amazon.com", 'vmware.com', 'cisco.com']
    toaster = Toaster(2, logging.DEBUG)
    for i in xrange(0,2):
        for host in hosts:
            jobName = 'Job-'+host
            kwargs = {'msg':host, 'delay':0}
            toaster.load(jobName, toasterWorkloadFn, msg=host, delay=0)
            toaster.load(jobName, toasterWorkloadFn, **kwargs)
            args = [host, 0]
            toaster.load(jobName, toasterWorkloadFn, host, 0)
            toaster.load(jobName, toasterWorkloadFn, *args)
            args = [host]
            kwargs = {'delay':0}
            toaster.load(jobName, toasterWorkloadFn, host, delay=0)
            toaster.load(jobName, toasterWorkloadFn, *args, **kwargs)
            import time
            while toaster.qsize()>=10:
                print('Qsize =', toaster.qsize())
                time.sleep(1)
    toaster.wait()

def toasterlib_test_cmd():
    toaster = Toaster(2, logging.DEBUG)
    for i in xrange(0, 10):
        jobName = 'command-%d' % i
        toaster.load(jobName, 'x=$(($RANDOM*5/32768)); echo sleep $x; sleep $x', {})
    toaster.wait()

def toasterlib_test_method():
    twl = ToasterWorkload()
    toaster = Toaster(2, logging.DEBUG)
    for i in xrange(0, 10):
        jobName = 'ToasterClass-%d' % i
        toaster.load(jobName, twl.workload(msg=jobName, delay=0))
        
    toaster.wait()

def main():
    toasterlib_test_fn()
    #toasterlib_test_cmd()
    #toasterlib_test_method()

if __name__ == '__main__':
    import time
    import random
    start = time.time()
    main()
    print("Elapsed Time: %s" % (time.time() - start))
