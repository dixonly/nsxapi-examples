#!/usr/bin/env python
# -*- coding: utf-8 -*-

secPolFwAppSpecsHelp = '''\
    semi-colon separated list of Application FW specs (<fwAppSpecs>)
    Example <fwAppSpecs>:
        ':intra:allow:ICMP Echo,ICMP Echo Reply;  :outbound:allow:HTTP,HTTPS;  :inbound:block:HTTP,HTTPS'
'''

secPolFwAgSpecsHelp = '''\
    semi-colon separated list of Application-Group FW specs (<fwAgSpecs>)
    Example <fwAgSpecs>:
        ':intra:allow::Microsoft Exchange 2010;  :outbound:block:test:vCenter5.x,Oracle Database'
'''

secGrpModSpecsHelp = '''\
    semi-colon separated list of (+/-) Member, ExcludedMember, DynamicMember
        -M: A|vApp-test,C|cluster-test;
        !M: A|vApp-test,C|cluster-test;
        ~M: A|vApp-test,C|cluster-test;
        +M: A|vApp-test,C|cluster-test;
        ~E: I|IPSET-192.168.0.0/24;
        +E: I|IPSET-192.168.0.0/24
        +D1, V:=:DEF, E::C|cluster4; -D2, V:=:ABC, E::A|vApp-test;
        +D1:AND, AND:T:=:T|ST_FUNC_FUNC12
        -D1:AND, AND:T:=:T|ST_FUNC_FUNC12
    Note: use '+' for adding members
          use '!', '~' or '-' for removing members, however, '-' need to be prefixed by '--'
'''

secGrpSpecsHelp = '''\
    semi-colon separated list of Member, ExcludedMember, DynamicMember
        sgMemberGrps ::= sgMemberGrp {";", sgMemberGrp}
        sgMemberGrp  ::= sgMemberSpec | sgExcludedMemberGrp | sgDynamicMemberGrp

        sgMemberSpec        ::= "M:", groupsSpec
        sgExcludedMemberGrp ::= "E:", groupsSpec
        sgDynamicMemberGrp  ::= "D:", dynMemberCriterias

        dynMemberCriterias  ::= dynMemberCriteria {",", dynMemberCriteria}
        dynMemberCriteria   ::= "=", logicOp, ",", logicOp, ",", object, operator, operant

        rulesSpec  ::= ruleSpec {";", rulesSpec}
        ruleSpec   ::= name, ":", direction, ":", action, ":", applyTo, ":", srcs, ":", dsts, ":", apps, ":", ags
        direction  ::= "inout" | "in" | "out"
        action     ::= "allow" | "block" | "reject"
        applyTo    ::= groupsSpec
        srcs       ::= groupsSpec
        dsts       ::= groupsSpec
        groupsSpec ::= groupSpec {"," groupSpec}
        groupSpec  ::=
            "C|" clusterName |
            "D|" datacenterName |
            "P|" dvPortgroupName |
            "I|" ipsetName |
            "N|" networkName |
            "G|" securityGroupName |
            "A|" vAppName |
            "V|" vmName |
            "L|" logicalSwitchName |
            "n|" vnicName
        object  ::=
            "V" | "VM.NAME"
            "T" | "VM.SECURITY_TAG"
            "H" | "VM.GUEST_HOST_NAME"
            "O" | "VM.GUEST_OS_FULL_NAME"
            "E" | "ENTITY" | ""
        operator  ::=
            "=" |
            "!" | "!="
            "C" | "contains"
            "S" | "starts_with"
            "E" | "ends_with"
            "R" | "similar_to"
            "B" | "belongs_to" | ""
        logicOp       ::= "OR" | "AND"
    Summary:
        <secGrpSpecs> = 'M:<groupSpec>,<groupSpec>...; M:<groupSpec>,<groupSpec>...; D:
    Example:
      M:I|IPSET-192.168.0.0/24,G|testSG-100,V|vlan2026-vm0902;
      E:I|IPSET-192.168.0.0/24,G|testSG-101,V|vlan2026-vm0902;
      D:
        +OR,
          AND:VM.NAME:=:ABC,
          AND:VM.NAME:!=:ABC,
          AND:VM.NAME:contains:ABC,
          AND:VM.NAME:starts_with:ABC,
          AND:VM.NAME:ends_with:ABC,
          AND:VM.NAME:similar_to:ABC,
          AND:VM.SECURITY_TAG:starts_with:st,
          AND:VM.GUEST_HOST_NAME:ends_with:computer,
          AND:VM.GUEST_OS_FULL_NAME:contains:Linux,
        +OR,
          AND:ENTITY:belongs_to:A|vApp-test,
          AND:ENTITY:belongs_to:C|cluster-test,
          AND:ENTITY:belongs_to:DG|Administrators,
          AND:ENTITY:belongs_to:D|dc,
          AND:ENTITY:belongs_to:G|testSG-100,
          AND:ENTITY:belongs_to:I|IPSET-192.168.0.0/24,
          AND:ENTITY:belongs_to:L|App1,
          AND:ENTITY:belongs_to:M|MacSet001,
          AND:ENTITY:belongs_to:N|VM Network,
          AND:ENTITY:belongs_to:P|vlan2023,
          AND:ENTITY:belongs_to:T|testST-100,
          AND:ENTITY:belongs_to:V|vlan2026-vm-test-0918,
          AND:ENTITY:belongs_to:VN|vlan2026-vm0100 - Network adapter 2,
'''

#dfwFwRuleSpecsHelp = '''\
#    semi-colon separated list of dfwRuleSpec
#        <dfwRulesSpec> = <dfwRuleSpec> | <dfwRuleSpec> ";" <dfwRulesSpec>
#        <dfwRuleSpec> = '<name>:<direction>:<action>:<logFlag>:<applyTo>:<srcs>:<dsts>:<apps>:<ags>; ...'
#        <direction>  ::= "inout" | "in" | "out"
#        <action>     ::= "allow" | "block" | "reject"
#        <logFlag>    ::= "T" | "F"  | ""
#        <applyTo>    ::= <groupsSpec>
#        <srcs>       ::= <groupsSpec>
#        <dsts>       ::= <groupsSpec>
#        <groupsSpec> ::= <groupSpec> | <groupSpec> "," <groupsSpec>
#        <groupSpec>  ::=
#            "C|" <clusterName> |
#            "D|" <datacenterName> |
#            "P|" <dvPortgroupName> |
#            "I|" <ipsetName> |
#            "N|" <networkName> |
#            "G|" <securityGroupName> |
#            "A|" <vAppName> |
#            "M|" <vmName> |
#            "L|" <logicalSwitchName> |
#            "n|" <vnicName>
#        <apps>       ::= <appName> | <appName> "," <apps>
#        <ags>        ::= <agName> | <agName> "," <ags>
#    Summary:
#        <dfwRulesSpec> = '<name>:<direction>:<action>:<logFlag>:<applyTo>:<srcs>:<dsts>:<apps>:<ags>; ...'
#    Example:
#        <dfwRulesSpec> = '<name>:<direction>:<action>:<logFlag>:<applyTo>:<srcs>:<dsts>:<apps>:<ags>; ...'
#        'apiSec999-000:in:allow:F:I|IPSET-192.168.0.0/24:C|cluster1,C|mgmt:G|testSG-100:HTTP,HTTPS:testAG-100;
#         apiSec999-001:out:allow:F:C|cluster-test:C|cluster-test:G|testSG-100:HTTP:testAG-100'
#
#'''
#dfwRuleSpecsHelp = '''\
#    <dfwRulesSpec>   ::= <dfwFwRulesSpec> | <dfwNiRulesSpec> | <dfwL2RulesSpec>
#
#    <dfwFwRulesSpec> ::= <dfwFwRuleSpec> { ";" <dfwFwRuleSpec> }
#    <dfwFwRuleSpec>  ::= "fw:" <name> ":" <direction> ":" <action> ":" <logFlag> ":" <applyTo> ":" <srcs> ":" <dsts> ":" <apps> ":" <ags>
#
#    <dfwL2RulesSpec> ::= <dfwL2RuleSpec> { ";" <dfwL2RuleSpec> }
#    <dfwL2RuleSpec>  ::= "l2:" <name> ":" <direction> ":" <action> ":" <logFlag> ":" <applyTo> ":" <srcs> ":" <dsts> ":" <apps> ":" <ags>
#
#    <dfwNiRulesSpec> ::= <dfwNiRuleSpec> { ";" <dfwNiRuleSpec> }
#    <dfwNiRuleSpec>  ::= 'ni:" <name> ":" <direction> ":" <siPro> ":" <logFlag> ":" <applyTo> ":" <srcs> ":" <dsts> ":" <apps> ":" <ags>
#
#        <direction>  ::= "inout" | "in" | "out"
#        <action>     ::= "allow" | "block" | "reject"
#        <logFlag>    ::= "T" | "F"  | ""
#        <applyTo>    ::= <groupsSpec>
#        <srcs>       ::= <groupsSpec>
#        <dsts>       ::= <groupsSpec>
#        <groupsSpec> ::= ["!"|"~"] <groupSpec> { "," ["!"|"~"]<groupSpec> }
#        <groupSpec>  ::=
#            "A|"  <vApp Name> |
#            "AP|" <Application Name> |
#            "AG|" <ApplicationGroup Name> |
#            "C|"  <Cluster Name> |
#            "D|"  <Datacenter Name> |
#            "DG|" <DirectoryGroup
#            "E|"  <Edge Name> |
#            "G|"  <SecurityGroup Name> |
#            "H|"  <Host Name> |
#            "I|"  <IPset Name> |
#            "L|"  <LogicalSwitch Name> |
#            "M|"  <MacSet Name> |
#            "N|"  <Nework (PG) Name> |
#            "NO|" <OS Name> |
#            "NV|" <VM Name> |
#            "NC|" <Computer Name> |
#            "NT|" <SecurityTag Name> |
#            "P|"  <dvPg Name> |
#            "SIP|"<SIProfile
#            "T|"  <SecurityTag Name> |
#            "V|"  <VirtualMachine Name> |
#            "VN|" <VNic Name> |
#            "R|"  <ResourcePool Name> |
#            "EN|" <entity Name> |
#
#        <apps>       ::= <appName> { "," <apps> }
#        <ags>        ::= <agName> { "," <ags> }
#
#    Summary:
#        <dfwFwRuleSpec>  ::= 'fw:<name>:<direction>:<action>:<logFlag>:<applyTo>:<srcs>:<dsts>:<apps>:<ags>; ...'
#        <dfwNiRuleSpec>  ::= 'ni:<name>:<direction>:<siPro>:<logFlag>:<applyTo>:<srcs>:<dsts>:<apps>:<ags>; ...'
#    Example:
#        <dfwRulesSpec> = '<name>:<direction>:<action>:<logFlag>:<applyTo>:<srcs>:<dsts>:<apps>:<ags>; ...'
#        'fw:apiSec999-000:in:allow:F:I|IPSET-192.168.0.0/24:C|cluster1,C|mgmt:G|testSG-100:HTTP,HTTPS:testAG-100;
#         fw:apiSec999-001:out:allow:F:C|cluster-test:C|cluster-test:G|testSG-100:HTTP:testAG-100'
#        'ni::in:siprof:T:::::;
#         ni:ni-000:in:siprof:T::::LDAP:;
#         ni:ni-001:out:siprof:T::::SNMP:Heartbeat;
#         ni:ni-002:inout:siprof:F:IGNORE:G|SG_WF_0002:G|SG_WF_0003:SNMP:Heartbeat'
#
#
#'''
#dfwRuleModSpecsHelp = '''\
#    semi-colon separated list of dfwModRuleSpec
#        <dfwModRulesSpec> ::= "+" <dfwRuleSpec> |
#                              "=" <dfwRuleModSpec> |
#                              ">" <dfwRuleModSpec> |
#                              ("-" | "!" | "~") <dfwDelRuleSpec>
#        <dfwRuleSpec> : SEE dfwRuleSpecsHelp for details
#        <dfwRuleModSpec> ::=
#            "fw:" <name> ":" <id> ":" <direction> ":" <action> ":" <logFlag> ":" <applyTo> ":" <srcs> ":" <dsts> ":" <apps> ":" <ags> |
#            "ni:" <name> ":" <id> ":" <direction> ":" <siPro> ":" <logFlag> ":" <applyTo> ":" <srcs> ":" <dsts> ":" <apps> ":" <ags>
#        <dfwDelRuleSpec> ::= "N|" <dfwRuleName> | "I|" <dfwRuleId> (* deprecated *)
#        <dfwDelRuleSpec> ::= rNames ":" rIds
#    Summary:
#        <dfwModRulesSpec> = '+<rCat>:<rName>:<direction>:<action>:<logFlag>:<applyTo>:<srcs>:<dsts>:<apps>:<ags>;
#                            '=<rCat>:<rName>:<rId>:<direction>:<action>:<logFlag>:<applyTo>:<srcs>:<dsts>:<apps>:<ags>;
#                            '><rCat>:<rName>:<rId>:<direction>:<action>:<logFlag>:<applyTo>:<srcs>:<dsts>:<apps>:<ags>;
#        <dfwDelRuleSpec>  = ~<ruleName>,<ruleName>:;
#                            ~:<ruleId>,<ruleId>;'
#    Example:
#        '+fw:apiSec999-000:in:allow:F:I|IPSET-192.168.0.0/24:C|cluster1,C|mgmt:G|testSG-100:HTTP,HTTPS:testAG-100;
#         +fw:apiSec999-001:out:allow:F:C|cluster-test:C|cluster-test:G|testSG-100:HTTP:testAG-100;
#         =fw:apiSec999-002::out:allow:F:C|cluster-test:C|cluster-test:G|testSG-100:HTTP:testAG-100;
#         >fw:apiSec999-003:::deny:::::SNMP:;
#         -ruleNo1; -:1234,1235;'
#
#'''

secPolFwSpecsHelp = '''\
    semi-colon separated list of Application/Application-Group FW specs (<fwSpecs>)
    <fwSpecs> Format:
        '<fwName> : <direction> : <action> : <secondarySecGrpList> : : <appList>;'...
    <fwSpecs> Example:
        ':intra:allow::Microsoft Exchange 2010;  :outbound:block:testSG:vCenter5.x,Oracle Database'
'''

secPolFwSpecsBNF = '''\
    BNF definitions of fwSpecs, fwAppSpecs, fwAgSpecs used in security policy creation
    White spaces around fwSpecs are being ignored (stripped)
        <fwSpecs>    ::= <fwAppSpecs> | <fwAgSpecs>

        <fwAppSpecs> ::= <fwAppSpec> { ";" <fwAppSpec> }
        <fwAgSpecs>  ::= <fwAgSpec>  { ";" <fwAgSpec> }

        <fwAppSpec>  ::= <fwAppName> ":" <direction>  ":" <action> ":" <sgList> ":" <appList>
        <fwAgSpec>   ::= <fwAgName>  ":" <direction>  ":" <action> ":" <sgList> ":" <agList>

        <sgList>     ::= <sgName>  { "," <sgName> }
        <appList>    ::= <appName> { "," <appName> }
        <agList>     ::= <agName>  { "," <agName> }

        <direction>  ::= "intra" | "inbound" | "outbound"
        <action>     ::= "allow" | "block" | "reject"

        <fwAppName>  ::= <identifier> | ""
        <fwAgName>   ::= <identifier> | ""
        <agName>     ::= <identifier> | ""
        <sgName>     ::= <identifier> | ""
'''

appSpecBNF = '''\
    BNF definitions of appSpec used in application service creation
        <appSpec>  ::= <tcpOrUdp> ":" <portOrPorts> | "icmp:" <icmpV4PortNames> |
            "icmpv6:" <icmpV6PortNames>
        <tcpOrUdp> ::= "tcp" | "udp"
        <ports> ::= <port> | <port> "-" <port> | <ports> "," <ports>
        <port>  ::= <nonNegativeInteger>
        <icmpV4PortNames> := <icmpV4PortName> | <icmpV4PortName> "," <icmpV4PortNames>
        <icmpV6PortNames> := <icmpV6PortName> | <icmpV6PortName> "," <icmpV6PortNames>
        <icmpV4PortName> ":= "destination-unreachable" | "echo-reply" |
            "echo-request" | "redirect" | "router-advertisement" |
            "router-solicitation" | "source-quench" | "time-exceeded"
        <icmpV6PortName> ":= <icmpV4PortName> | "multicast-listener-done" |
            "multicast-listener-query" | "multicast-listener-report" |
            "neighbor-advertisement" | "neighbor-solicitation" |
            "packet-too-big" | "parameter-problem"
    Exampe: 'tcp:80,443; udp:80; icmp:echo-request,echo-reply'

'''
mAppNamesBNF = '''\
    BNF definitions of member App Names  used in application group creation
        <mAppNames> ::= <appName> | <appName> ";" <mAppNames>
    Exampe: 'appName1', 'appName1;appName2'
'''
mAgNamesBNF = '''\
    BNF definitions of member Applicaiton Group  used in application Group creation
        <mAgNames> ::= <agName> | <agName> ";" <mAgNames>
    Exampe: 'agName1', 'agName1;agName2'
'''
mNamesBNF = '''\
    BNF definitions of member names used in application group creation
        <mNames> ::= <appOrAgName> | <appOrAgName> ";" <mNames>
        <appOrAgName>  ::= <appName> | <agName>
    Exampe: 'agName1', 'appName1', 'appName1;agName1'
'''
spSpecHelp = '''\
    def create(self, spSpec, spRulesSpec):             # Security_policy

    spSpec       ::= name, ":", precedence, ":", pSgs
    precedence   ::= 1..2147483647

    pSgs        ::= sgs
    sgs         ::= [sg], {sg}
    name        ::= IDENTIFIER
    sg          ::= IDENTIFIER

    SUMARY:
        <spSpec>       <name>:<precedence>:<pSgs>
    EXAMPLE:
        'simon-sp-14159265:14159265:panimod1_sg0,panimod1_sg1'
'''

spRulesOptsHelp = '''\
    specifiy one of more the the following 3 options: stateless, tcpStrict, useSid
    Support options for:
        fw: stateless, tcpStrict, useSid
        ni: stateless, tcpStrict
    Examples:
        fw:stateless,tcpStrict,useSid
        fw:useSid
        ni:stateless,tcpStrict
        fw:useSid; ni:tcpStrict
'''

spRulesSpecHelp = '''\
    def create(self, spSpec, spRulesSpec):             # Security_policy
    BNF syntax:
        spRulesSpec  ::= ( spFwRuleSpec | spNiRuleSpec | spGiRuleSpec ) {";", spRulesSpec}
        spFwRuleSpec ::= "fw:", name, ":", action,   ":", enable, ":", log, ":", direction, ":", secondSgs, ":", apps, ":", ags
        spNiRuleSpec ::= "ni:", name, ":", redirect, ":", enable, ":", log, ":", direction, ":", secondSgs, ":", apps, ":", ags, ":", profile
        spGiRuleSpec ::= "gi:", name, ":", action,   ":", enable, ":", log, ":", serviceProf

        apps        ::= [app], {app}
        ags         ::= [ag], {ag}
        sgs         ::= [sg], {sg}
        secondSgs   ::= sgs
        pSgs        ::= sgs
        direction   ::= "inbound" | "I" | "outbound" | "O" |"intra" | "X"
        enable      ::= trueOrFalse
        log         ::= trueOrFalse
        redirect    ::= trueOrFalse
        trueOrFalse ::= "true" | "T" | "false" |"F"
        name        ::= IDENTIFIER
        ap          ::= IDENTIFIER
        ag          ::= IDENTIFIER
        sg          ::= IDENTIFIER
        profile     ::= IDENTIFIER
        serviceProf ::= IDENTIFIER
    SUMARY:
        <spFwRuleSpec> fw:<name>:<action>:<enable>:<log>:<direction>:<secondSgs>:<apps>:<ags>
        <spNiRuleSpec> ni:<name>:<redirect>:<enable>:<log>:<direction>:<secondSgs>:<apps>:<ags>:<profile>
        <spGiRuleSpec> gi:<name>:<action>:<enable>:<log>:<serviceProf>
    EXAMPLE:
        'fw:simon-sp-14159265-000:allow:true:true:inbound:testSG-100:SSH:;
         ni:simon-sp-14159265-001:true:true:true:inbound:panimod1_sg2:LDAP,SSH::panzone;
         ni:simon-sp-14159265-002:true:true:true:intra::LDAP,SSH::panzone;'
'''

spModSpecHelp = '''\
    def modify(self, spModSpec, spRulesModSpec):             # Security_policy
    EBNF syntax:
        spModSpec   ::= [name], ":", [spObjectId], ":", [precedence], ":", [pSgsModSpec]

        precedence  ::= 1..2147483647
        spObjectId  ::= objectId
        pSgsModSpec ::= sgsModSpec
        sgs         ::= [sg], {sg}

        sgsModSpec  ::= ("+"|"-"), sg, {",", ("+"|"-"), sg}
        name        ::= IDENTIFIER
        objectId    ::= IDENTIFIER
        sg          ::= IDENTIFIER
    SUMARY:
        <spModSpec>     <name>:<spObjectId>:<recedence>:<SgsModSpec>
    EXAMPLE:
        'simon-sp-14159265::14159260:-panimod1_sg0,+panimod1_sg2,+panimod1_sg3',
'''

#spRulesModSpecHelp = '''\
#    def modify(self, spModSpec, spRulesModSpec):             # Security_policy
#    EBNF syntax:
#        spRulesModSpec ::= spRuleModSpec, {";", spRuleModSpec}
#        spRuleModSpec ::= ( spFwRulesModSpec | spNiRulesModSpec | spGiRulesModSpec )
#
#        spNiRulesModSpec ::= spNiRuleModSpec, {";", spNiRuleModSpec}
#        spNiRuleModSpec ::= ( addNiRule | delNiRule | modNiRule )
#        addNiRule ::= "+", addNiRuleSpec
#        delNiRule ::= "-", delNiRuleSpec
#        modNiRule ::=      modNiRuleSpec
#        delNiRuleSpec ::= [rName], ":", [rOid]
#        addNiRuleSpec ::= rName, "::", redirect, ":", enable, ":", log, ":", direction,
#                          ":", secondSgs, ":", apps, ":", ags, ":", profile
#        modNiRuleSpec ::= [rName], ":", [rOid,] ":", [redirect], ":", [enable], ":", [log],
#                          ":", [direction], ":", [secondSgsModSpec], ":", [appsModSpec],
#                          ":", [agsModSpec], ":", [profile]
#
#        spFwRulesModSpec ::= spFwRuleModSpec, {";", spFwRuleModSpec}
#        spFwRuleModSpec ::= ( addFwRule | delFwRule | modFwRule )
#        addFwRule ::= "+", addFwRuleSpec
#        delFwRule ::= "-", delFwRuleSpec
#        modFwRule ::=      modFwRuleSpec
#        delFwRuleApec ::= [rName], ":", [rOid]
#        addFwRuleSpec ::= rName, ":", action, ":", enable, ":", log, ":", direction,
#                          ":", secondSgs, ":", apps, ":", ags
#        modFwRuleSpec ::= [rName], ":", [rOid], ":", [action], ":", [enable], ":", [log],
#                          ":", [direction], ":", [secondSgsModSpec], ":", [appsModSpec],
#                          ":", [agsModSpec]
#
#        action    ::= "allow" | "block" | "reject"
#
#        spGiRulesModSpec ::= spGiRuleModSpec, {";", spGiRuleModSpec}
#        spGiRuleModSpec ::= ( addGiRule | delGiRule | modGiRule )
#        addGiRule ::= "+", spGiSpec
#        delGiRule ::= "-", rName, ":", rOid
#        modGiRule ::= rName, ":", rOid, ":", action, ":", enable, ":", log, ":", serviceProf
#
#        addGiRule ::= "+", addGiRuleSpec
#        delGiRule ::= "-", delGiRuleSpec
#        modGiRule ::=      modGiRuleSpec
#        delGiRuleApec ::= [rName], ":", [rOid]
#        addGiRuleSpec ::= [rName], ":", [rOid], ":", [action], ":", [enable], ":", [log], ":", [serviceProf]
#        modGiRuleSpec ::= [rName], ":", [rOid], ":", [action], ":", [enable], ":", [log], ":", [serviceProf]
#
#        apps        ::= [app], {app}
#        ags         ::= [ag], {ag}
#        sgs         ::= [sg], {sg}
#        secondSgs   ::= sgs
#        direction   ::= "inbound" | "I" | "outbound" | "O" |"intra" | "X"
#        enable      ::= trueOrFalse
#        log         ::= trueOrFalse
#        redirect    ::= trueOrFalse
#        trueOrFalse ::= "true" | "T" | "false" |"F"
#        pSgsModSpec ::= sgsModSpec
#        secondSgsModSpec ::= sgsModSpec
#        sgsModSpec  ::= ("+"|"-"), sg, {",", ("+"|"-"), sg}
#        agsModSpec  ::= ("+"|"-"), ag, {",", ("+"|"-"), ag}
#        appsModSpec ::= ("+"|"-"), app, {",", ("+"|"-"), app}
#        name        ::= IDENTIFIER
#        ap          ::= IDENTIFIER
#        ag          ::= IDENTIFIER
#        sg          ::= IDENTIFIER
#        profile     ::= IDENTIFIER
#        serviceProf ::= IDENTIFIER
#    SUMARY:
#        <spRulesModSpec> <spRuleModSpec>, {;<spRuleModSpec>}
#        <spRuleModSpec> (<spFwRulesModSpec>|<spNiRulesModSpec>|<spGiRulesModSpec>)
#
#        <delNiRuleSpec> [<rName>]:[<rOid>]
#        <addNiRuleSpec> <rName>::<redirect>:<nable>:<og>:<irection>:<econdSgs>:<pps>:<gs>:<rofile>
#        <modNiRuleSpec> [<rName>]:[<rOid>]:[<redirect>]:[<enable>]:[<log>]:[<direction>]:\
#                        [<secondSgsModSpec>]:[<appsModSpec>]:[<agsModSpec>]:[<profile>]
#    EXAMPLE:
#        ' ni:simon-sp-14159265-001:::::I:-panimod1_sg2,+panimod1_sg3:+DNS,-SSH,-LDAP:+Heartbeat:panzone;
#          ni:simon-sp-14159265-101:::::I:panimod1_sg2:LDAP,SSH::panzone;
#         +ni:simon-sp-14159265-111::T:F:F:I:panimod1_sg3,panimod1_sg2:LDAP,HTTPS:Heartbeat:panzone;
#         -ni:simon-sp-14159265-102:;
#         +fw:simon-sp-40342-001:allow:true:true:inbound:testSG-100:SSH:;
#         +fw:simon-sp-40342-002::allow:true:true:inbound:testSG-100:SSH:'
#
#'''

agsCreateHelp = '''\
    EBNF syntax:
        agCreateSpecs ::= agCreateSpec, { ";", agCreateSpec }
        agCreateSpec ::= agName, ":", appNames, ":", , agNames
        appNames     ::=  [appName], { ",", [appName] }
        agNames      ::=  [agName], { ",", [agName] }
    EXAMPLE:
        agTest000::                     # create empty AG agTest000
        agTest001:app1:                 # create AG agTest001 with APP app1  as member
        agTest002:app1,app2:            # create AG agTest002 with APP app1,app2  as members
        agTest003::ag1                  # create AG agTest003 with AG ag1 as member
        agTest004:app1,app2:ag1,ag2     # create AG agTest004 with APP app1,app2 and AG ag1,ag2 as members
        agTest005:app1:ag1; agTest006:app2:ag2 # create AG agTest005 and agTest0006
'''

agsModifyHelp = '''\
    EBNF syntax:
        agModifySpecs   ::= agModifySpec, { ";", agModifySpec }
        agModifySpec    ::= agName, ":", appNamesModSpec, ":", , agNamesModSpec
        appNamesModSpec ::=  [("+"|"-"), appName], { ",", [("+"|"-"), appName] }
        agNamesModSpec  ::=  [("+"|"-"), agName], { ",", [("+"|"-"), agName] }
    EXAMPLE:
        agTest000::                                # no modification
        agTest001:+app1:                           # add APP app1
        agTest002:+app1,-app2:                     # add APP app1, remove APP app2
        agTest003::+ag1                            # add AG ag1
        agTest004:+app1,-app2:+g1,-ag2             # add APP app1, remove APP app2. add AG ag1, remove AG ag2
        agTest005:-app1:+ag1; agTest006:+app2:-ag2 # remove APP app1, add AG ag1 to agTest005. add APP app2, remove AG ag2 from agTest006
'''
appCreateHelp= '''\
    EBNF Syntax:
        appCreateSpecs  ::= appCreateSpec, {";", appCreateSpec}
        appCreateSpec   ::= appName, "|", appSpec
        appSpec         ::= (("tcp"|"udp"), ":", ports) | "icmp:", icmpV4PortName | "icmpv6:", icmpV6PortName
        ports           ::= port, {",", port} | port, "-", port}
        port            ::= 1..65535
        icmpV4PortName  := "destination-unreachable" | "echo-reply" |
            "echo-request" | "redirect" | "router-advertisement" |
            "router-solicitation" | "source-quench" | "time-exceeded"
        icmpV6PortName> := "multicast-listener-done" |
            "multicast-listener-query" | "multicast-listener-report" |
            "neighbor-advertisement" | "neighbor-solicitation" |
            "packet-too-big" | "parameter-problem"
    Summary:
        <appName>|<proto>:<ports> [; <appName>|<proto>:<ports>]
    Exampe:
        'appTest000| tcp:80'
        'appTest001| udp:8000,8080-8081'
        'appTest002| icmp:echo-request'
        'appTest003| tcp:53; appTest004| udp:53'

'''
#segCreateHelp= '''\
#    EBNF Syntax:
#        segCreateSpecs  ::= segCreateSpec, {";", segCreateSpec}
#        segCreateSpec   ::= segName, "|", segSpec
#        segSpec         ::= segId, "-", segId
#        segId           ::= 1..16777215
#    Summary:
#        <segName>|<segId>:<segId> [; <segName>|<segId>:<segId>]
#    Exampe:
#        'segTest000:50000-50001'
#        'segTest001:50002-50003; segTest002:50004-50005'
#'''

ipsetNameHelp= '''\
    EBNF Syntax:
        ipsetNameOrOjectId ::= ipsetName | ":", ipsetOjectId
    Summary:
        <ipsetName>
        :<ipsetOjectId>
    Exampe:
        test-ipset-001
        test-ipset-002
        :ipset-1
'''
#ipsetModHelp= '''\
#    EBNF Syntax:
#        ipsetModSpecs ::= ipsetModSpec {";", ipsetModSpec}
#        ipsetModSpec  ::= op, ips
#        op            ::= '+' | '-' | '~' | '!' | '#'
#        ips           ::= ipSpec {",", ipSpec}
#        ipSpec        ::= ip | ip, '/', snMaskLength | ip, '-', ip
#    Summary:
#        <op><ips>
#        <op><ips>
#    Exampe:
#        '+192.168.0.0/24,1.2.1.1; -1.1.1.1,1.1.1.2'
#        '#Replacement; =1.2.3.4,4.3.2.1'
#        '+192.168.0.0/24, +2.2.2.2-2.2.2.254'
#'''
#
