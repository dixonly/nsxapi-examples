#!/usr/bin/python
#from __future__ import print_function
import os, sys
import re, glob
import datetime, time, calendar
import inspect
import json, yaml
import xml.dom.minidom
import xmltodict
import itertools
import random
import string, textwrap
import argparse
from pprint import pformat, pprint
import logging
import pkgutil
import types
import ssl, OpenSSL
import socket
import subprocess
from netaddr import *
from bs4 import BeautifulSoup
from collections import OrderedDict, Mapping, Iterable
from prettytable import PrettyTable
from colorlog import ColoredFormatter
try:                import bsddb
except ImportError: import bsddb3


def pformat_xml(xmlStr):
    return xml.dom.minidom.parseString(xmlStr).toprettyxml(indent='    ').strip()


def pprint_xml(xmlStr):
    print(pformat_xml(xmlStr))


def pformat_xmlInYaml(xmlStr):
    od = xml2Od(xmlStr)
    return pformat_yaml(od)


def pprint_xmlInYaml(xmlStr):
    od = xml2Od(xmlStr)
    pprint_yaml(od)


#def eprint(*args, **kwargs):
#    print(*args, file=sys.stderr, **kwargs)


def od2Dict(od):
    return json.loads(json.dumps(od))


# was xml2Dict()
def xml2Od(xmlStr):
    return byteify(od2Dict(xmltodict.parse(xmlStr)))


def pformat_od(od):
    #return pformatAsJson(od)
    return json.dumps(od, indent=4)
    #return dict_or_OrdDict_to_formatted_str(od)
def pprint_od(od):
    print(pformat_od(od))


def pformat_yaml(d):
    #return pformatAsYaml(d)
    return yaml.safe_dump(d, default_flow_style=False, indent=4)
    #return formatStctureAsYaml(d, indent=4)
def pprint_yaml(d):
    print(pformat_yaml(d))


def pformat_json(d):
    return json.dumps(d, indent=4, sort_keys=True)
def pprint_json(d):
    print(pformat_json(d))
def pprint_jsons(s):
    print(pformat_json(json.loads(s)))


def pformat_html(s):
    return BeautifulSoup(s).prettify()
def pprint_html(s):
    print(pformat_html(s))


class StringData(object):
    def __init__(self, s):
        self.string = s
    def __str__(self):
        s = self.string
        try:
            if '<html>' in s:
                return pformat_html(s)
            elif s.startswith('<?xml '):
                #import codecs
                #UTF8Writer = codecs.getwriter('utf8')
                #sys.stdout = UTF8Writer(sys.stdout)

                #jprint s
                #prin#t(pformat_xml(s))
                return pformat_xml(s)
            elif s.startswith('{'):
                return pformat(byteify(json.loads(s)))
            else:
                return s
        except:
            return s


def merge_dicts(x, y):
    '''Given two dicts, merge them into a new dict as a shallow copy.'''
    z = x.copy()
    z.update(y)
    return z


def nowStr(fmt='%D %T'):
    return time.strftime(fmt)

def nowTimeStr(fmt='%T'):
    return time.strftime(fmt)


def fmtDatetime(dt):
    return dt.strftime('%H:%M:%S') if dt else ''

def fmtDeltaDatetime(startTime, fmt='%0.6f', withNormTime=False):
    ''' startTime: datatime.datetime type '''
    endTime = datetime.datetime.now()
    dTime = endTime-startTime
    result = fmt % (dTime.seconds+dTime.microseconds/1e6)
    if withNormTime:
        result += ' (%s)' % normTime(dTime.seconds)
    return float(result)

# Convert a unix time u to a datetime object d, and vice versa
def ut2utcDt(u): return datetime.datetime.utcfromtimestamp(u)  ;# u->utc dt
def ut2locDt(u): return datetime.datetime.fromtimestamp(u)     ;# u->loc dt
def utcDt2ut(dt): return calendar.timegm(dt.timetuple())         ;#utc-dt-> u
def utNow(): return time.time()

def utcToLocalDatetime( utc_datetime ):
    from dateutil import tz
    from_zone = tz.tzutc()
    to_zone = tz.tzlocal()
    utc_datetime = utc_datetime.replace(tzinfo=from_zone)
    localDt = utc_datetime.astimezone(to_zone)
    return localDt

def makeMeAList(me):
    print('makeMeAList() is deplicated, use listify() instead')
    return listify(me)
def listify(me):
    ''' None is handle as special case '''
    return me if isinstance(me,list) else ([me] if me!=None else [])
def deListify(me):
    return me[0] if isinstance(me,list) and len(me)<=1 else me


def makeMeATuple(me):
    print('makeMeATuple() is deplicated, use tuplify() instead')
    return tuplify(me)
def tuplify(me):
    ''' None is handle as special case '''
    return me if isinstance(me,tuple) else ((me,) if me!=None else ())


def shortUuid(uuid, head=4, tail=4):
    return '%s..%s' % (uuid[0:head+1], uuid[-tail:]) if uuid else ''


def ip2int(ip): return reduce(lambda a, b: (a << 8) + b, map(int, ip.split('.')), 0)
def int2ip(n): return '.'.join([str(n >> (i << 3) & 0xFF) for i in range(0, 4)[::-1]])
def ip2hex(ip): return '{:02X}{:02X}{:02X}{:02X}'.format(*map(int, ip.split('.')))
def hex2ip(h): return ".".join(["%d"%int(n, 16) for n in (h[0:2],h[2:4],h[4:6],h[6:8])])
def ipIncr(ip,n=1): return int2ip(ip2int(ip)+n)
def cidr_to_netmask(n): return '.'.join([str((0xffffffff << (32-n) >> i) & 0xff) for i in [24, 16, 8, 0]])
def netmask_to_cidr(netmask): return sum([bin(int(x)).count('1') for x in netmask.split('.')])
def host2ip(host): return socket.gethostbyname(host)

def ipNetmaskDefault(ip):
    ip0 = int(ip.split('.')[0])
    return '255.0.0.0' if ip0<127 else ('255.255.0.0' if ip0<192 else '255.255.255.0')

def numInStr(s):
    m =  re.search('(\d+)', s)
    return int(m.group(0)) if m else None

def flatten(ll):
    return [item for sl in ll for item in (sl if isinstance(sl,(list,tuple)) else (sl))]

def iflatten_r(ll):
    for sl in ll:
        if isinstance(sl, str):
            yield sl
        else:
            for y in flatten(sl):
                yield y

def iflatten(ll):
    for sl in ll:
        if isinstance(sl, (list,tuple)):
            for y in sl:
                yield y
        else:
            yield sl

def maxSlice(l,nMax=3):
    return l[: max(0,min(nMax,len(l)))]

def isIp(ip):
    return re.match('\d+\.\d+\.\d+\.\d+', ip)

def ipSort(ipList):
    return sorted(ipList, key=lambda ip: ip2hex(ip) if isIp(ip) else '~'+ip)

def ipRange(input_string):
    ''' ip_range('192.168.1-2.1-12') '''
    octets = input_string.split('.')
    chunks = [map(int, octet.split('-')) for octet in octets]
    ranges = [range(c[0], c[1] + 1) if len(c) == 2 else c for c in chunks]
    for address in itertools.product(*ranges):
        yield '.'.join(map(str, address))

def ipSpecExpandGen(ipSpecs, hostOnlyFlag=True):
    ''' 192.168.1.1/28,192.168.1.128/28 '''
    result = ''
    for ipSpec in ipSpecs.split(','):
        if '-' in ipSpec:
            for ip in ipRange(ipSpec):
                #print('0>', ip)
                yield ip
        elif '/' in ipSpec:
            l = len(IPNetwork(ipSpec))
            for ip in ['%s'%ip for ip in IPNetwork(ipSpec)][hostOnlyFlag:-1 if hostOnlyFlag else l]:
            #for ip in ['%s'%ip for ip in IPNetwork(ipSpec)]:
                #print('1>', ip)
                yield ip
        elif ipSpec:
            #print('2>', ipSpec)
            yield ipSpec

def filterListByRE(l, p):
    return filter(lambda s: re.match(p,s), l)

def intListSpecToIntList(spec):
    ''' 1,2,3:          [1, 2, 3]
        1,2,5-7:        [1, 2, 5, 6, 7]
        1-3,5-7,9:      [1, 2, 3, 5, 6, 7, 9]
    '''
    ints = spec.split(',')
    ints = [(range( int(i.split('-')[0]), int(i.split('-')[1])+1) if '-' in i else int(i)) for i in ints]
    ints = list(iflatten(ints))
    return ints

def globToRe(globPat):
    rePat = '^%s$' % globPat
    rePat = rePat.replace('.','\.')
    rePat = rePat.replace('?','.')
    rePat = rePat.replace('*','.*')
    return rePat

#def isGlobMatched(globPat, s):
#    rePat = globToRe(globPat)
#    return re.match(rePat,s)

#def isGlobMatched(globPat, s):
#    globPats = listify(globPat)
#    for globPat in globPats:
#        rePat = globToRe(globPat)
#        if re.match(rePat,s):
#            return True
#    return False

def isGlobMatched(globPats, s):
    ''' globPats: single or list of glob patterns '''
    return reduce(lambda f,g:f or re.match(globToRe(g),s)!=None, [False]+listify(globPats))

def filterListByGlob(l, globPat):
    rePat = globToRe(globPat)
    return filter(lambda s: re.match(rePat,s), l)


def isGlobMatchedInList(globPats, s):
    for p in globPats:
        if isGlobMatched(p, s):
            return True
    return False


def xmlWrap(tags, xml):
    for tag in reversed(tags):
        xml = '<%s>%s</%s>' % (tag, xml, tag)
    return xml


#def toUtf8List(l):
#    return [toUtf8List(x) if isinstance(x, list) else x.encode('UTF8') for x in l]
def toUtf8List(l):
    return [toUtf8Dict(x) if isinstance(x, dict) else toUtf8List(x) if isinstance(x, list) else x.encode('UTF8') if x else x for x in l]
    #return [toUtf8List(x) if isinstance(x, list) else x.encode('UTF8') if x else x for x in l]


def toUtf8Dict(d):
    #return {k:(d[k].encode('UTF8') if d[k] else d[k]) for k in d}
    return {k:toUtf8Dict(d[k]) if isinstance(d[k], dict) else d[k].encode('UTF8') if d[k] else d[k] for k in d}


def unzip(l):
    return zip(*l)


def listReverse(l):
    return l[::-1]

def traverseRmNullEntry(obj):
    """
    traverseRmNullEntry traverse an arbitrary Python object structure (limited to JSON data
    types), rmove any entries with value evaluated to empty ('', None, [], {}) and
    return the resulting object
    """
    if isinstance(obj, dict):
        return {k: traverseRmNullEntry(v) for k, v in obj.items() if v or v==0}
    elif isinstance(obj, list):
        return [traverseRmNullEntry(elem) for elem in obj if elem or v==0]
    else:
        return obj

def compactArgFile(value):
    ''' if value is of longer than 131071 bytes, create a temp file with value as its content,
            return ('@fname', fileHandle)
        otherwise, return (value, None) '''
    f=None
    if len(value)>131071:
        f = tempfile.NamedTemporaryFile(mode='w+t', bufsize=0)
        f.write(value)
        value = '@%s' % f.name
        global _dummy; _dummy = f   # so that ref to f is 1 when function exit
    return value, f

def expandArgFile(arg, sep='\n'):
    ''' if arg is of format '@fileName': return content of return file fileName
        otherwise, return arg itself '''
    if arg == None:
        return None
    val = arg
    if arg.startswith('@'):
        with open(arg[1:]) as f:
            val = f.read()
        if sep:
            val = [e.strip() for e in val.split(sep) if e.strip()]
    return val


def grep(pats, lines, delim='\n', pr=1):
    '''
    pats:  single RE OR list of RE
    lines: single string delimited by $delim OR list of strings
    '''
    if isinstance(pats,str):
        pats = [pats]
    if isinstance(lines,str):
        lines = lines.split(delim)
    r = []
    for line in lines:
        for p in pats:
            if re.search(p,line):
                r.append(line)
                if pr: print(line)
                break
    return r


def byteify(input):
    if isinstance(input, dict):
        return {byteify(key):byteify(value) for key,value in input.iteritems()}
    elif isinstance(input, list):
        return [byteify(element) for element in input]
    elif isinstance(input, tuple):
        return tuple(byteify(list(input)))
    elif isinstance(input, unicode):
        return input.encode('utf-8')
    else:
        return input


def constrainedSumUnequalParts(total, n):
    """
    Return a randomly chosen list of n positive integers summing to total.
    Each such list is equally likely to occur.

    0 1 2 3 4 5 6 7 8 9 10  # The universe.
    |                   |   # Place fixed dividers at 0, 10.
    |   |     |       | |   # Add 4 - 1 randomly chosen dividers in [1, 9]
      a    b      c    d    # Compute the 4 differences: 2 3 4 1
    eg: constrainedSumUnequalParts(10, 100) returns list 10 number totals 100
    """
    dividers = sorted(random.sample(xrange(1, total), n - 1))
    return [a - b for a, b in zip(dividers + [total], [0] + dividers)]

def randAlnum(n=1):
    ''' return string of n random alnum charters '''
    return ''.join([random.choice(string.ascii_letters + string.digits) for i in range(n)])

# define logging level symbolic names
_lNames = ['TRACE', 'DEBUG', 'INFO', 'NOTICE', 'ALERT', 'WARNING']
'''
for i,_lName in enumerate(_lNames):
    setattr(logging, _lName, (i)*5)
    print(logging, _lName, (i)*5)
    for j in range(1,5):
        setattr(logging, '%s%i'%(_lName,j), (i)*5+j)
        print(logging, '%s%i'%(_lName,j), (i)*5+j)
'''
for i,_lName in enumerate(_lNames):
    for j in range(4,0,-1):
        setattr(logging, '%s%i'%(_lName,j), (i+1)*5-j)
        #print(logging, '%s%i'%(_lName,j), (i+1)*5-j)
    setattr(logging, _lName, (i+1)*5)
    #print(logging, _lName, (i+1)*5)

cptLogLevels = flatten([ ['%s%s' % (t,n) for n in flatten([[''], range(1,5)])]
    for t in ['TRACE', 'DEBUG', 'INFO', 'NOTICE', 'ALERT', 'WARNING', 'ERROR', 'CRITICAL'] ])
cptLogLevelMetavar = r'''{TRACE[1-4] ,DEBUG[1-4],INFO[1-4],NOTICE[1-4],ALERT[1-4],WARNING[1-4],ERROR,CRITICAL}'''

def cptLogger(logLevel=logging.INFO, logFile=None, gmt=True, logTag=''):
    """
    Returns a logger with a default ColoredFormatter if possible
    Returns a regular logger if ColoredFormatter is not available
    """
    def log_factory(logger, log_level):
        def custom_log(msg, *args, **kwargs):
            if logger.level > log_level:
               return
            logger._log(log_level, msg, args, kwargs)
        return custom_log

    #print(logLevel, logFile, gmt, logTag)
    logger = logging.getLogger()
    logger.setLevel(logLevel)

    log_colors={
        'CRITICAL': 'red',              # 50  50
        'ERROR':    'red',              # 40  40
        'WARNING':  'yellow',           # 30  30
       #'WARNINGE1                      #     29
       #'WARNINGE2                      #     28
       #'WARNINGE3                      #     27
       #'WARNINGE4                      #     26
        'ALERT':    'fg_bold_yellow',   #     25
       #'ALERT1                         #     24
       #'ALERT2                         #     23
       #'ALERT3                         #     22
       #'ALERT4                         #     21
        'NOTICE':   'fg_bold_yellow',   #     20
       #'NOTICE1                        #     19
       #'NOTICE2                        #     18
       #'NOTICE3                        #     17
       #'NOTICE4                        #     16
        'INFO':     'green',            # 20  15
       #'INFO1                          #     14
       #'INFO2                          #     13
       #'INFO3                          #     12
       #'INFO4                          #     11
        'DEBUG':    'purple',           # 10  10
       #'DEBUG1                         #      9
       #'DEBUG2                         #      8
       #'DEBUG3                         #      7
       #'DEBUG4                         #      6
        'TRACE':    'fg_bold_purple',   #      5
       #'TRACE1                         #      4
       #'TRACE2                         #      3
       #'TRACE3                         #      2
       #'TRACE4                         #      1
    }
    # define new custom log levels, methods and clolors
    colors = ['purple', 'fg_bold_purple', 'green', 'fg_bold_green', 'yellow', 'fg_bold_yellow']
    for i,entry in enumerate(zip(_lNames, colors)):
        lName,color = entry
        log_colors.update({'%s%d'%(lName,i):color for i in range(1,5)})
        log_colors.update({'%s'%lName:color})
        for j in range(1,5):
            logName = ('%s%d'%(lName,5-j))
            level = (i+1)*5-j
            level = i*5+j
            setattr(logger, logName.lower(), log_factory(logger, level))
            logging.addLevelName(level, logName)
            #print(level, logName)
        level = (i+1)*5
        logging.addLevelName(level, lName)
        setattr(logger, lName.lower(), log_factory(logger, level))
        #print(level, lName)

    tzSubfix = 'Z' if gmt else ''
    logTag = '%s '%logTag  if logTag else ''
    fmtStr = '%(asctime)s{0} %(log_color)s%(levelname)-8s {1}%(funcName)s() %(message)s%(reset)s'.format(
        tzSubfix, logTag)
    formatter = ColoredFormatter(fmtStr, datefmt='%T', reset=True, log_colors=log_colors)
    if gmt:
        formatter.converter = time.gmtime

    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    if logFile:
        logfHandler = logging.FileHandler(logFile, mode='w')
        #logfHandler = logging.StreamHandler()
        logfHandler.setFormatter(formatter)
        logger.addHandler(logfHandler)

    return logger


def birthday(probability_exponent, bits, fmt='%g'):
    ''' number of hashes n(p) needed to achieve the given probability of collision '''
    from math import log1p, sqrt
    probability = 10. ** probability_exponent
    outputs     =  2. ** bits
    r = sqrt(2. * outputs * -log1p(-probability))
    return fmt % r

def typeassert(*types):
    ''' decorator to assert parameter type
        eg: @typeassert(int, list)
        eg: @typeassert((bool,types.NoneType), list)
    '''
    def check_accepts(f):
        assert len(types) == f.func_code.co_argcount
        def new_f(*args, **kwds):
            for (a, t) in zip(args, types):
                assert isinstance(a, t), "arg %r does not match %s" % (a,t)
            return f(*args, **kwds)
        new_f.func_name = f.func_name
        return new_f
    return check_accepts


def fmtClassAttrs(c):
    attrs = vars(c)
    return pformat(dict(attrs))


def prClassAttrs(c):
    print('%s attributs:' % c)
    #print(fmtClassAttrs(c))
    attrs = vars(c)
    print(pformat(dict(attrs)))


def fmtExceptionInfo(e):
    exc_type, exc_obj, exc_tb = sys.exc_info()
    exc_fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
    return '%s %s:%s' % (e, exc_fname, exc_tb.tb_lineno)


def listClassMethods(c):
    print('%s Methods:' % c)
    for ent in inspect.getmembers(c, predicate=inspect.ismethod):
        if not ent[0].startswith('_'):
            print('    %s' % str(ent))

def commandsGetoutput(cmd):
    #return commands.getoutput(cmd)
    #return subprocess.check_output(cmd, shell=True).decode('ascii').strip()
    #return subprocess.check_output(cmd.split(),  universal_newlines=True)
    return subprocess.check_output(cmd, shell=True, universal_newlines=True)

def funcArgs(f):
    ''' return list of function argument-name '''
    return f.__code__.co_varnames


def is_connected(host, port):
  try:
    s = socket.create_connection((socket.gethostbyname(host), port), 2)
    return True
  except:
      return False

# UPN (User Principle Name) user@domain
# DLN (Down-Level Logon Name) domain\user
def upn2dln(upn):
    if '@' in upn:
        u, d = upn.split('@')
        return '%s\\%s' % (d, u)
    return upn

def dln2upn(dln):
    if '\\' in dln:
        d, u = dln.split('\\')
        return '%s@%s' % (u, d)
    return dln

def normDiskSize(size):
    KB = size/1024.0
    if 0<KB<1000: return '%.1f KB' % KB
    MB = KB/1024.0
    if 0<MB<1000: return '%.1f MB' % MB
    GB = MB/1024.0
    if 0<GB<1000: return '%.1f GB' % GB
    TB = GB/1024.0
    if 0<TB<1000: return '%.1f TB' % TB
    return '%d byte' % size

def normTime(s0):
    m, s = divmod(int(s0), 60)
    h, m = divmod(m, 60)
    d, h = divmod(h, 24)
    fs = s + s0-int(s0)
    return "%dd %02d:%02d:%02d" % (d,h,m,s) if isinstance(s0, int) \
        else "%dd %02d:%02d:%06.3f" % (d,h,m,fs)

def textWrapCol(text, width=40, break_long_words=True, break_on_hyphens=False):
    ''' text can be simple text of list of text block '''
    if isinstance(text, list):
        text = ', '.join(sorted(text))
    return '\n'.join(textwrap.wrap(text, width,
        break_long_words=break_long_words, break_on_hyphens=break_on_hyphens))

def textAlign(txt):
    indent = sys.maxint
    lines = txt.split('\n')
    for line in lines:
        reo = re.match('^( *)[^ ].+$', line)
        if reo:
            indent = min(indent, len(reo.group(1)))
    if indent == sys.maxint:
        indent = 0
    return '\n'.join([l.replace(' '*indent, '') for l in lines])

def getClassByMethod(meth):
  ''' Return the class where the instance method was defined '''
  for cls in inspect.getmro(meth.im_class):
    if meth.__name__ in cls.__dict__: return cls
  return None

# http://stackoverflow.com/questions/4301069/any-way-to-properly-pretty-print-ordered-dictionaries-in-python
def dict_or_OrdDict_to_formatted_str(OD, mode='dict', s="", indent=' '*4, level=0):
    def is_number(s):
        try:
            float(s)
            return True
        except:
            pass
        return False
    def fstr(s):
        return s if is_number(s) else '"%s"'%s
    if mode != 'dict':
        kv_tpl = '("%s", %s)'
        ST = 'OrderedDict([\n'; END = '])'
    else:
        kv_tpl = '"%s": %s'
        ST = '{\n'; END = '}'
    for i,k in enumerate(OD.keys()):
        if type(OD[k]) in [dict, OrderedDict]:
            level += 1
            s += (level-1)*indent+kv_tpl%(k,ST+dict_or_OrdDict_to_formatted_str(OD[k], mode=mode, indent=indent, level=level)+(level-1)*indent+END)
            level -= 1
        else:
            s += level*indent+kv_tpl%(k,fstr(OD[k]))
        if i!=len(OD)-1:
            s += ","
        s += "\n"
    return s

if sys.version_info < (3, 3):
    class SimpleNamespace:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def __repr__(self):
            keys = sorted(self.__dict__)
            items = ("{}={!r}".format(k, self.__dict__[k]) for k in keys)
            return "{}({})".format(type(self).__name__, ", ".join(items))

        def __eq__(self, other):
            return self.__dict__ == other.__dict__

###############################################################################
# from verifyDfw3.py
###############################################################################
#class newPxssh(pxssh.pxssh):
#    def synch_original_prompt (self):
#        self.sendline()
#        time.sleep(0.5)
#        return super(newPxssh,self)
#pxssh.pxssh = newPxssh
#
#
#def pxsshSendlnExp(s,send,exp):
#    s.sendline (send)
#    s.expect(exp)
#
#def pxsshSendlnPrompt(s, send, **kwargs):
#    s.sendline (send)
#    s.prompt(**kwargs)
#
#
#def sshEsx(esxIp):
#    global esxPrompt
#
#    esxPrompt = '.* # '
#    esxPrompt = '.*\~ *# '
#    esxPrompt = '.*(\~ # |:\~# )'
#
#    s = pexpect.spawn('ssh root@%s' % esxIp, maxread=102400)
#    s.logfile = sys.stdout
#    s.timeout = 60
#    s.expect(esxPrompt)
#    return s
#
#def sendExp(s,send,exp):
#    s.sendline (send)
#    s.expect(exp)
#

def pformatAsYaml(d, level=0, indent=4):
    ''' http://stackoverflow.com/questions/4301069/any-way-to-properly-pretty-print-ordered-dictionaries-in-python '''
    curFn = eval(inspect.stack()[0][3])
    x = ""
    if isinstance(d, Mapping):
        lenk = indent or max(map(lambda x: len(str(x)), d.keys()))
        for k, v in d.items():
            key_text = "\n" + " "*level + " "*(lenk - len(str(k))) + str(k)
            x += key_text + ": " + curFn(v, level=level+lenk, indent=indent)
    elif isinstance(d, Iterable) and not isinstance(d, basestring):
        for e in d:
            x += "\n" + " "*level + "- " + curFn(e, level=level+max(4,indent), indent=indent)
    else:
        x = str(d)
    if level==0:
        x = x.strip()
    return x

def pformatAsJson(d, level=0, indent=4):
    curFn = eval(inspect.stack()[0][3])
    x = ""
    if isinstance(d, Mapping):
        lenk = indent or max(map(lambda x: len(str(x)), d.keys()))
        x += "\n" + " "*level + "{"
        for k, v in d.items():
            key_text = "\n" + " "*(level+indent) + " "*(lenk - len(str(k))) + str(k)
            x += key_text + ": " + curFn(v, level=level+lenk, indent=indent)
        x += "\n" + " "*level + "}"
    elif isinstance(d, Iterable) and not isinstance(d, basestring):
        x += "\n" + " "*level + "["
        for e in d:
            x += curFn(e, level=level+max(4,indent), indent=indent)
        x += "\n" + " "*level + "]"
    else:
        x = str(d)
    if level==0:
        x = x.strip()
    return x

def pprintAsJson(d, indent=4):
    print(pformatAsJson(d, indent=indent))

def pprintAsYaml(d, indent=4):
    print(pformatAsYaml(d, indent=indent))

#def fmtDictsAsPrettytable0(dicts, colSortKeys=[], jqFilter=None):
#    ''' table (dicts): a table is a list of dicts
#        each dict is converted to a prettyTable row
#        table value can be a table (list of dict)
#    '''
#    if not dicts:
#        #print('#### Empty table')
#        return None
#    colSortKeys = colSortKeys or re.findall(r'"([^"]*)"\s*:', jqFilter)
#
#    hdrs = set([])
#    for d in dicts:
#        hdrs |= set(d.keys())
#    hdrs = sorted(list(hdrs), key=colSortKeys.index)
#
#    ptbl = PrettyTable(hdrs, sortby=hdrs[0])
#    ptbl.align = 'l'
#    for row in dicts:
#        ptbl.add_row([fmtDictsAsPrettytable(row[k], colSortKeys=colSortKeys) if isinstance(row[k],list)
#            else row[k] for k in sorted(row, key=hdrs.index)])
#    return ptbl if ptbl.rowcount else None

def fmtDictsAsPrettytable(dicts, colSortKeys=[], jqFilter=None):
    ''' table (dicts): a table is a list of dicts
        each dict is converted to a prettyTable row
        table value can be a table (list of dict)
        colHdr: word(s) or word(s) '|' width
    '''
    if not dicts:
        #print('#### Empty table')
        return None
    colSortKeys = colSortKeys or re.findall(r'"([^"]*)"\s*:', jqFilter)

    hdrs = set([])
    for d in dicts:
        if not isinstance(d, (dict, OrderedDict)):
            print('fmtDictsAsPrettytable(): "%s" must be type dict' % d)
        hdrs |= set(d.keys())
    hdrs = sorted(list(hdrs), key=colSortKeys.index)


    #newHdrs = [s.split('|')[0] for s in hdrs]
    newHdrs, colsWidth = [], {}
    for h in hdrs:
        if '|' in h:
            nHdr, colWidth = h.split('|')
            newHdrs.append(nHdr)
        else:
            newHdrs.append(h)
            colWidth = 0
        colsWidth[h] = int(colWidth)

    ptbl = PrettyTable(newHdrs, sortby=newHdrs[0], sort_key=alnum_keys)
    ptbl.align = 'l'
    for row in dicts:
        ptbl.add_row([fmtDictsAsPrettytable(row[k], colSortKeys=colSortKeys)
            if isinstance(row[k],list)
            else (
                #row[k]
                textWrapCol(row[k], colsWidth[k]) if colsWidth[k] else row[k]
            ) for k in sorted(row, key=hdrs.index)])
    return ptbl if ptbl.rowcount else None

def fmtPrettytableAsJson(ptbl, indent=None):
    def _ptblToDict(ptbl):
        dicts = []
        for r in ptbl._rows:
            rDict = {}
            for k,v in zip(ptbl._field_names,r):
                rDict.update({k:_ptblToDict(v) if isinstance(v, PrettyTable) else v})
            dicts.append(rDict)
        return dicts
    return json.dumps(_ptblToDict(ptbl), indent=indent)


def memoize(function):
    memo = {}
    def wrapper(*args):
        if args in memo:
            print '+',
            return memo[args]
        else:
            print '.',
            rv = function(*args)
            memo[args] = rv
            return rv
    return wrapper

def atoi(text):
    return int(text) if text.isdigit() else text

def alnum_keys(text):
    '''
    alist.sort(key=alnum_keys) sorts in human order
    http://nedbatchelder.com/blog/200712/human_sorting.html
    (See Toothy's implementation in the comments)
    Turn a string into a list of string and number chunks.
    "z23a" -> ["z", 23, "a"]
    '''
    #print('->',[ atoi(c) for c in re.split('(\d+)', str(text)) ])
    return [ atoi(c) for c in re.split('(\d+)', str(text)) ]

def sorted_alnum(l):
    ''' l is not modified, returns newly created, /sorted copy of l '''
    ll = l[:]
    ll.sort(key=alnum_keys)
    return ll

def sort_alnum(l):
    ''' l iself is sorted, None is the returned value '''
    l.sort(key=alnum_keys)


def traceFuncParams(function):
  def wrapper(*args):
      print('traceFuncParams(): %s(%s)' % (function.__name__.split()[0], str(args)))
      #print('traceFuncParams():', sys._getframe(0).f_code.co_name, args)
      #print('traceFuncParams():', sys._getframe(1).f_code.co_name, args)
      #print('traceFuncParams():', sys._getframe(2).f_code.co_name, args)
      rv = function(*args)
      return rv
  return wrapper

def xw(body, tags, incHeader=False):
    xmlHeader = '<?xml version="1.0" encoding="UTF-8"?>'
    xml = body
    for tag in tags:
        xml = '<%s>%s</%s>' % (tag, xml, tag)
    if incHeader:
        xml =  '%s\n%s' % (xmlHeader, xml)
    return xml

def getKeyByValue(d,v):
    return d.keys()[d.values().index(v)]

def certFP(certPem):
    return OpenSSL.crypto.load_certificate(OpenSSL.crypto.FILETYPE_PEM, certPem).digest("sha1")

def serverCertFP(host, port):
    certPem = ssl.get_server_certificate((host, port))
    return certFP(certPem)

def isFileCW_OK(fp):
    return (os.path.isfile(fp) and os.access(fp,os.W_OK)) or (
        not os.path.exists(fp) and os.access(os.path.dirname(fp),os.W_OK) )

def assertWithErrLog(cond, msg, logger):
    logger.error(msg)
    assert cond, msg

def tag_visible(element):
    if element.parent.name in ['style', 'script', 'head', 'title', 'meta', '[document]']:
        return False
    if isinstance(element, Comment):
        return False
    return True


def text_from_html(body):
    soup = BeautifulSoup(body, 'html.parser')
    texts = soup.findAll(text=True)
    visible_texts = filter(tag_visible, texts)
    return u" ".join(t.strip() for t in visible_texts)


def parseNestedParenExpr(expr, parens='()', delims='|&'):
    def tokenize(expr, parens, delims):
        tokens = re.split('([%s%s])'%(parens,delims), expr) \
            if re.search('[%s]'%delims,expr) else [expr]
        tokens = [c.strip() for c in tokens if c.strip()]
        return tokens

    def _helper(iter):
        items = []
        pOpen, pClose = list(parens[:2])
        for item in iter:
            if item == pOpen:
                result, closeparen = _helper(iter)
                if not closeparen:
                    raise ValueError("bad expression -- unbalanced parentheses")
                items.append(result)
            elif item == pClose:
                return items, True
            else:
                items.append(item)
        return items, False
    expr = tokenize(expr, parens, delims)
    return _helper(iter(expr))[0]


def argparser_action(actionType):
    class listifyByComma(argparse.Action):
        def __call__(self, parser, args, values, option_string=None):
            #print('ARGPARSER_ACTION: %s, %s, %s' % (actionType, self.dest, values))
            setattr(args, self.dest, values.split(','))
    class listifyBySemicolon(argparse.Action):
        def __call__(self, parser, args, values, option_string=None):
            #print('ARGPARSER_ACTION: %s, %s, %s' % (actionType, self.dest, values))
            setattr(args, self.dest, values.split(';'))
    if actionType=='listifyByComma':
        return listifyByComma
    elif actionType=='listifyBySemicolon':
        return listifyBySemicolon
    raise Exception('actionType "%s" not supported' % actionType)

from contextlib import contextmanager
from timeit import default_timer
@contextmanager
def elapsed_timer():
    ''' Sample code
        with elapsed_timer() as elapsed:
            ...
            print(elapsed())
            ...
            print(elapsed())
        print(elapsed())
    '''
    start = default_timer()
    elapser = lambda: default_timer() - start
    yield lambda: elapser()
    end = default_timer()
    elapser = lambda: end-start

class def_kv_dict(dict):
    ''' return key as value if missing '''
    def __missing__(self, key):
        return key

# https://stackoverflow.com/questions/1254454/fastest-way-to-convert-a-dicts-keys-values-from-unicode-to-str
# for converting dict key/value intpo string (mostly from unicode)
def strifyDictKV(data):
    if isinstance(data, basestring):
        return str(data)
    elif isinstance(data, Mapping):
        return dict(map(strifyDictKV, data.iteritems()))
    elif isinstance(data, Iterable):
        return type(data)(map(strifyDictKV, data))
    else:
        return data

import shelve
class Cache():
    def write(self, key, value):
        nItem = len(value)
        shelveStart = datetime.datetime.now()
        self[key] = value
        shelveDuration = datetime.datetime.now()-shelveStart
        self.logger.info4('Updated persistent cache cache[%s] (%d items)' % (key, nItem))
        self.logger.info3('shelved %d %s took %ss' % (nItem, key,
            fmtDeltaDatetime(shelveStart, '%0.3f')))

    def read(self, key, rDict=None, rKey=None):
        cacheHit, value = False, None
        if self.get(key):
            cacheHit = True
            value = self.get(key)
            if rDict and rKey:
                rDict[rKey] = value
            self.logger.info4('Read persistent cache cache[%s] (%d items)' % (key, len(value)))
        return (cacheHit, value)

    def __init__(self, sfix, logger=None):
        cacheRoot = '%s/cache' % os.path.dirname(os.path.abspath(sys.argv[0]))
        cacheDir = '%s/%s' % (cacheRoot, sfix)
        scriptName = os.path.splitext(os.path.basename(sys.argv[0]))[0]
        self.logger = logger or logging

        for dir in [cacheRoot, cacheDir]:
            if not os.path.exists(dir):
                try:
                    os.mkdir(dir, 0o755);
                except:
                    self.logger.warning('Failed to create cache directory "%s")' % dir)
                    cacheDir = '/tmp'
                    self.logger.warning('Chaning directory to "/tmp")')
                    import getpass
                    sfix += '-%s' % getpass.getuser()

        self.dbFile = '%s/%s%s.bdb' % (cacheDir, scriptName,
            ':%s' % sfix if sfix else '')
        self.fd = shelve.open(self.dbFile, writeback=False)

    def __del__(self):
        #print('__del__')
        self.fd.sync()
        self.fd.close()

    def __enter__(self):
        #print('__enter__')
        return self

    def __exit__(self, type, value, traceback):
        #print('__exit__')
        self.__del__()

    def __getitem__(self, key):
        return self.fd[key] if key in self.fd else None

    def __setitem__(self, key, value):
        #print('__enter__')
        try:
            self.fd[key] = value
        except bsddb.db.DBPageNotFoundError:
            self.logger.warning('Cache curruption detected, please manually remove file "%s"' % self.dbFile)
        except Exception as ex:
            exClass, exParams, exTraceback =  sys.exc_info()
            exClassName = exClass.__module__ + "." + exClass.__name__
            self.logger.error('Unhandled exception of type %s occurred with arguments: %s' % (
                exClassName, exParams))

    def keys(self):
        return self.fd.keys()

    def delele(self, key):
        del self.fd[key]

    def deleteAll(self):
        #for k in self.fd.keys():
        #    del self.fd[k]
        self.fd.close()
        self.fd = shelve.open(self.dbFile, flag='n')

    get = __getitem__
    set = __setitem__
