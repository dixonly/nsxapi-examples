import paramiko
import os

class ParamikoSsh(object):
    def __init__(self, hostname, username, password, timeout=10):
        c = paramiko.SSHClient()
        c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        #c.load_system_host_keys()  # commented out to ignore host key verification
        c.connect(hostname=hostname, username=username, password=password, look_for_keys=False, timeout=timeout)
        self.sshClient = c

    def execute(self, cmd, output="stdin"):
        _, out, err = self.sshClient.exec_command(cmd)
        status = out.channel.recv_exit_status()
        if err.readlines():
            print(err.readlines())
        return out.read() if output=='stdin' else [str(l).strip() for l in out.readlines()]

def nsxcli(args):
    pass

def tryEsxNsxHost(hostname, username='root', password='Vmware123!'):
    c = ParamikoSsh(hostname, username, password)
    #c = ParamikoSsh('cpt-linux', 'admin', 'Vmware123!')
    #print(c.execute('uname -a'))
    '''
    print(c.execute('nsxcli -c "get manager"'))
    print(c.execute('nsxcli -c "get controllers"'))
    print(c.execute('nsxcli -c "get firewall status"'))
    print(c.execute('nsxcli -c "get lldp config"'))
    print(c.execute('nsxcli -c "get lldp neighbors"'))
    print(c.execute('nsxcli -c "get logical-routers"'))
    print(c.execute('nsxcli -c "get logical-switches"'))
    '''
    print(c.execute('nsxcli -c "get maintenance-mode"'))
    print(c.execute('nsxcli -c "get node-uuid"'))
    print(c.execute('nsxcli -c "get routing-domains"'))
    print(c.execute('nsxcli -c "get service"'))
    print(c.execute('nsxcli -c "get switch-security config <logical-port>"'))
    print(c.execute('nsxcli -c "get switch-security stats <logical-port>"'))
    print(c.execute('nsxcli -c "get version"'))

def tryEsxNsxHost2(hostname, username='admin', password='CptWare12345!'):
    c = ParamikoSsh(hostname, username, password, timeout=1)
    #c = ParamikoSsh('cpt-linux', 'admin', 'Vmware123!')
    #print(c.execute('uname -a'))
    '''
    print(c.execute('get manager"'))
    print(c.execute('get controllers"'))
    print(c.execute('get firewall status"'))
    print(c.execute('get lldp config"'))
    print(c.execute('get lldp neighbors"'))
    print(c.execute('get logical-routers"'))
    print(c.execute('get logical-switches"'))
    '''
    #print(c.execute('get maintenance-mode'))
    #print(c.execute('get node-uuid'))
    #print(c.execute('get routing-domains'))
    #print(c.execute('get service'))
    #print(c.execute('get switch-security config <logical-port>'))
    #print(c.execute('get switch-security stats <logical-port>'))
    print(c.execute('get version'))

def tryEsxNdvs(hostname, username='root', password='Vmware123!'):
    c = ParamikoSsh(hostname, username, password)
    esxcfgVswitch = c.execute('esxcfg-vswitch -l')
    netStats = c.execute('net-stats -l')
    netDvs = c.execute('net-dvs -l')
    print(esxcfgVswitch)
    #print(netStats)
    #rint(netDvs)

def main():
    host = 'c2437'
    host = '70.0.25.1'
    host = 'te1'
    #tryEsxNdvs(host)
    #tryEsxNsxHost2(host)
    tryEsxNsxHost2('www.google.com')

if __name__ == '__main__':
    main()


