#!/usr/bin/env python
from __future__ import print_function
import pinit
import sys, os
import subprocess
import traceback
import itertools
import re
import json
#import yaml
import urllib2
import restlib
from requests.structures import CaseInsensitiveDict
import argparse
import logging
from pprint import pprint, pformat
import collections
import socket
#import xmltodict
import abc
import copy
import cptutil
from cptutil import pprint_od, toUtf8Dict, listify, isGlobMatched, pprint_json
from pyVim import connect
from pyVmomi import vim
from pyVmomi import vmodl
from collections import OrderedDict as OD, namedtuple
from random import shuffle
import time, datetime
import math
import operator
import pdb
import paramiko
from pyVim.connect import SmartConnect
from pyVmomi import vim
from prettytable import PrettyTable
from enum import Enum
import pyjq
import uuid
import tempfile

Api      = namedtuple('Api',     ('method', 'url'))
PtblFmt  = namedtuple('PtblFmt', ('url', 'jqFilter'))
ResTypeMap = namedtuple('ResTypeMap', ('apiResType', 'nsxvClass'))

#------------------------------------------------------------------------------
# https://wiki.python.org/moin/PythonDecoratorLibrary#Memoize
import collections
import functools

class memoized(object):
   '''Decorator. Caches a function's return value each time it is called.
   If called later with the same arguments, the cached value is returned
   (not reevaluated).
   '''
   def __init__(self, func):
      self.func = func
      self.cache = {}
   def __call__(self, *args):
      if not isinstance(args, collections.Hashable):
         # uncacheable. a list, for instance.
         # better to not cache than blow up.
         return self.func(*args)
      if args in self.cache:
         return self.cache[args]
      else:
         value = self.func(*args)
         self.cache[args] = value
         return value
   def __repr__(self):
      '''Return the function's docstring.'''
      return self.func.__doc__
   def __get__(self, obj, objtype):
      '''Support instance methods.'''
      return functools.partial(self.__call__, obj)
#------------------------------------------------------------------------------
def memoize(obj):
    cache = obj.cache = {}

    @functools.wraps(obj)
    def memoizer(*args, **kwargs):
        if args not in cache:
            print('+', end='')
            cache[args] = obj(*args, **kwargs)
        print('.', end='')
        return cache[args]
    return memoizer

memoizeEnable = True
def memoize(obj):
    global memoizeEnable
    cache = obj.cache = {}

    def isEnabled():
        return memoizeEnable

    @functools.wraps(obj)
    def memoizer(*args, **kwargs):
        #print(('.' if args in cache else '*') if isEnabled() else ' ', end='')
        #print('R' if (not isEnabled() or args not in cache) else 'r', end='')
        if not isEnabled() or args not in cache:
            cache[args] = obj(*args, **kwargs)
        return cache[args]
    return memoizer

#------------------------------------------------------------------------------
'''
class SwitchedDecorator(object):
    def __init__(self, enabled_func):
        self._enabled = False
        self._enabled_func = enabled_func

    @property
    def enabled(self):
        print('prop enabled:%s'%self._enabled)
        return self._enabled

    @enabled.setter
    def enabled(self, new_value):
        print('prop enabled set: %s'%new_value)
        if not isinstance(new_value, bool):
            raise ValueError("enabled can only be set to a boolean value")
        self._enabled = new_value

    def __call__(self, target):
        print('prop enabled use: %s' % self.enabled)
        traceback.print_stack()
        if self.enabled:
            return self._enabled_func(target)
        return target
s_memoize = SwitchedDecorator(memoize)
s_memoize.enabled=True; # This is a compiler time flag, not runtime flag!!!!
'''
#------------------------------------------------------------------------------

#---- HELP MSG BEGIN ----------------------------------------------------------
notSupportedMsg = 'FEATURE NOT YET SUPPORTED BY PM'
pmPolicyRulesSpecHelp='''
    policy communication map entries specification (rules Spec):
        ( rName : rSrcs : rDsts : rScope : rAction : rServices [;] )...
    Examples:

'''
pmPolicyApplicationSpecHelp = notSupportedMsg
pmPolicyEmergencySpecHelp = pmPolicyRulesSpecHelp
pmPolicyEnvironmentalSpecHelp = notSupportedMsg
pmPolicyInfrastructureSpecHelp = notSupportedMsg

#---- HELP MSG END ------------------------------------------------------------


class Network_object(object):
    __metaclass__  = abc.ABCMeta

    def __init__(self, mgr=None,listUrl=None, mp=None, **kwargs):
        if mp:
            self.mp=mp
            self.mgr=mp.getMgr()
        elif mgr:
            self.mp = None
            self.mgr=mgr
        else:
            raise ValueError("Network_object init: must provided valid mp or mgr object")

        self.className = self.__class__.__name__
        self.listUrl = listUrl
        self.logger = self.mgr.logger
        self.policyObjPathPrefix = '/policy/api/v1'

        if hasattr(self.__class__, 'listUrl'):
            self.listUrl = self.__class__.listUrl
        for kw in kwargs:
            exec('self.{0} = kwargs["{0}"]'.format(kw))

    def pageHandler(self, baseUrl, mgr=None):
        mgr = mgr or self.mgr
        firstLoop = True
        cursor = None
        respDict = {}

        while firstLoop or cursor:
            firstLoop = False
            #url = '%s?cursor=%s' % (baseUrl, cursor) if cursor else baseUrl
            if '?' in baseUrl:
                url = '%s&cursor=%s' % (baseUrl, cursor) if cursor else baseUrl
            else:
                url = '%s?cursor=%s' % (baseUrl, cursor) if cursor else baseUrl

            r = self.rest_api(url, method='GET', mgr=mgr)
            #r = self.doRestApi('get '+url, retryParams=None)
            rDict = r.json()
            self.logger.info2(pformat(rDict))
            if respDict: respDict['results'].extend(rDict['results'])
            else: respDict = rDict
            if 'cursor' not in rDict:
                #print('RETURING %d'% len(respDict['results']))
                #traceback.print_stack()
                return respDict
            else:
                cursor = rDict['cursor']

    def list(self, restUrl=None, display=True, brief=False, mgr=None, nameGlob=None, useCache=False):   # Network_object
        nameGlob = listify(nameGlob)
        mgr = mgr or self.mgr
        self.logger.info4('restUrl=%s, display=%s, brief=%s, mgr=%s, nameGlob=%s, useCache=%s'%
                (restUrl, display, brief, mgr, nameGlob, useCache))
        if not hasattr(mgr,'cache'): mgr.cache = {}
        if not restUrl:
            if self.listUrl:
                restUrl = self.listUrl
            elif 'list' in self.api:
                restUrl = self.api['list'].url
        if not restUrl:
            self.logger.error("Calling list with no restUrl specified")
            return None

        #self.logger.info3('LIST useCache %s: %s' % (self.resType, useCache))
        if useCache and hasattr(self, 'resType'):
            #self.logger.info3('Caching %s' % self.resType)
            #import traceback; traceback.print_stack()
            rDict = copy.deepcopy(mgr.cache[self.resType]) \
                if useCache and not display and self.resType in mgr.cache \
                else self.pageHandler(restUrl, mgr=mgr)
            if not isinstance(self.resType,list) and self.resType not in mgr.cache:
                mgr.cache[self.resType] = copy.deepcopy(rDict)
        else:
            rDict = self.pageHandler(restUrl, mgr=mgr)

        if nameGlob:
            nameGlob_unquoted = [urllib2.unquote(n) for n in nameGlob]
            if nameGlob_unquoted == nameGlob:
                ''' if nameGlob is not quoted, glob style magic chars are significant '''

                rDict['results'] = [e for e in rDict['results'] if ('display_name' not in e or
                    isGlobMatched(nameGlob, e['display_name']))]
            else:
                ''' if nameGlob is quoted, glob style magic chars are NOT significant '''
                rDict['results'] = [e for e in rDict['results'] if
                    isGlobMatched(nameGlob, urllib2.quote(e['display_name']))]
            rDict['result_count'] = len(rDict['results'])
        if display:
            if brief and not isinstance(self,VM):
                print("Number of results: %d" %(rDict['result_count']))
                i = 0
                for d in rDict['results']:
                    print("%d. Name: %s" %(i,d['display_name']))
                    print("   Id: %s" %(d['id']))
                    i+=1
            elif brief and isinstance(self,VM):
                print("Number of results: %d" %(rDict['result_count']))
                i = 0
                for d in rDict['results']:
                    print("%d. Name: %s" %(i,d['display_name']))
                    print("    ExtId: %s" %(d['external_id']))
                    print("    Power: %s" %(d['power_state']))
                    i+=1
            else:
                self.json_print(data=rDict, convert=False)
        return rDict # type:dictionary

    def jqTable(self, jsonStr='', nameGlob='', jqFilter='', apiKey='', findMethod='list',
            nameTag='display_name', display=True, mgr=None, colSortKeys=[], **kwargs):
        ''' colSortKeys: if present be a list containing all col headers '''
        mgr = mgr or self.mgr
        ''' format json to prettytable  '''
        #print('jqFilter = %s' % jqFilter)
        #print('jsonStr = %s' % jsonStr)
        if isinstance(jsonStr, (dict, OD)):
            jsonStr = json.dumps(jsonStr)
        self.logger.info2('jsonStr=%s\n  nameGlob=%s\n  jqFilter=%s\n  apiKey=%s'
            '\n  findMethod=%s\n  nameTag=%s\n  display=%s'
            '\n  colSortKeys=%s\n  kwargs=%s' % (
            jsonStr, nameGlob, jqFilter, apiKey, findMethod,
            nameTag, display, colSortKeys, kwargs))

        # extract kwargs to local namesapce
        exec('\n'.join('%s=kwargs["%s"]' % (k, k) for k in kwargs.keys()))

        useSearchAPI = findMethod=='search' or (hasattr(mgr, 'useSearchAPI') and mgr.useSearchAPI)
        #print('##### useSearchAPI=%s  #####' % useSearchAPI)

        if isinstance(jsonStr, list):
            jsonStr = json.dumps(jsonStr)

        restUrl = None
        if jsonStr:
            #print('#### jsonStr')
            mgr.logger.info2('Using supplied jsonStr')
            if hasattr(self, 'ptblFmts'):
                jqFilter = jqFilter or self.ptblFmts['list'].jqFilter
            jsonDict = json.loads(jsonStr)
        elif nameGlob and useSearchAPI:
            mgr.logger.info2('Using SEARCH API')
            #print('#### nameGlob and useSearchAPI')
            if hasattr(self, 'ptblFmts'):
                jqFilter = jqFilter or self.ptblFmts['list'].jqFilter
            resTypes = listify(self.resType)
            qResType = ' OR '.join(['resource_type:%s'%t for t in resTypes])
            qResType = '(%s)' % qResType
            qString = '%s AND display_name:%s' % (qResType, nameGlob)
            jsonDict = Search(mgr=mgr).query(qString, display=False)

        elif apiKey:
            mgr.logger.info2('Using apiKey "%s" to make API call' % apiKey)
            #print('#### apiKey: %s' % apiKey)
            if not jqFilter and not hasattr(self, 'ptblFmts'):
                self.logger.error('ptblFmts not defined for class %s' % self.__class__.__name__)
            jqFilter = jqFilter or self.ptblFmts[apiKey].jqFilter
            #print('#### jqFilter: %s' % jqFilter)
            restUrl = self.ptblFmts[apiKey].url
            #print('#### restUrl: %s' % restUrl)
            if restUrl.count('%') >= 2:
                restUrl = eval(restUrl)
            self.logger.info1('RESTURL: %s' % restUrl)
            jsonDict = self.pageHandler(restUrl, mgr=mgr)
            #print(jsonDict)
        else:
            #print('#### else')
            #print('============== call restUrl myself  ==============')
            mgr.logger.info2('============== call restUrl myself  ==============')
            if hasattr(self, 'ptblFmts'):
                jqFilter = jqFilter or self.ptblFmts['list'].jqFilter
                restUrl = self.ptblFmts['list'].url
            else:
                self.logger.warning('jqFilter not defined')
            jsonDict = self.pageHandler(restUrl, mgr=mgr)
        self.logger.info2('API returns: %s' % pformat(jsonDict))

        if nameGlob:
            nameRe = cptutil.globToRe(nameGlob)
            #print(nameRe)
            nameRe = re.sub(r'\\', r'\\\\\\\\', nameRe, count=0)    # due to 2 extra level of substitution
            #print(nameRe)
            #print(jqFilter)
            jqFilter = re.sub(r'(\.%s)'%nameTag, '(\\1|if test("%s") then . else empty end)'%nameRe,
                jqFilter, 1)
            #print(jqFilter)

        #pprint(jsonDict)
        if jqFilter=='.':
            if display:
                pprint(jsonDict)
            rows = jsonDict
        else:
            #print ('jqFilter = %s' % jqFilter)
            #pprint(jsonDict)
            rows = pyjq.all(jqFilter, jsonDict)
            self.logger.info2('%d rows: %s' % (len(rows),cptutil.pformat_od(rows)))
            #print ('jqFilter = %s' % jqFilter)
            colSortKeys = colSortKeys or re.findall(r'"([^"]*)"\s*:', jqFilter)
            ptbl = cptutil.fmtDictsAsPrettytable(rows, colSortKeys=colSortKeys)
            if ptbl:
                if display:
                    print(ptbl)
                if 'result_count' in jsonDict:
                    if display:
                        print('Count: %s (Total:%d)' % ((ptbl.rowcount, jsonDict['result_count'])
                            if ptbl else (0,0)))
                    apiResultCount = len(jsonDict['results'])
                    if (not nameGlob or nameGlob=='*'):
                        if apiResultCount!=jsonDict['result_count']:
                            self.logger.warning(
                                'reported result_count(%d) != actual result_count(%d)'
                                % (jsonDict['result_count'], apiResultCount) )
                        if ptbl.rowcount!=apiResultCount:
                            self.logger.warning(
                                'Something went wrong, got %d entries, %d entries displayed'
                                % (apiResultCount, ptbl.rowcount))
                            jsonDict_s = json.dumps(jsonDict)

                            with tempfile.NamedTemporaryFile() as jfd:
                                jfd.write(jsonDict_s)
                                jq_cmd = "/usr/bin/jq <%s '%s'" % (jfd.name,jqFilter)

                            p = subprocess.Popen(jq_cmd, shell=True, close_fds=True,
                                stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE)
                            #output = p.stdout.read()
                            error = p.stderr.read()
                            self.logger.warning(error)
                else:
                    if display:
                        print('Count: %s' % ptbl.rowcount)
            #else:
            #    if display:
            #        print('Count: 0')

        jqTableDict = {'rows':rows, 'ptbl':ptbl, 'restUrl':restUrl, 'restRespJson':jsonDict }
        return jqTableDict
        return rows, ptbl
        return jsonStr
        return jsonDict

    def findByName(self, name, restUrl=None, data=None, display=True,brief=False):  # Network_object
        #print('name=%s'%name)
        if not data:
            if not restUrl:
                if hasattr(self, 'api') and 'list' in self.api:
                    restUrl = self.api['list'].url
                elif self.listUrl:
                    restUrl=self.listUrl
            #print('restUrl:%s'%restUrl)
            data = self.list(restUrl=restUrl,display=False)
            #print('data:'); pprint(data)
            self._findByNameRest = {'url':restUrl, 'response':data}
        obj = None
        for o in data['results']:
            #print('o:'); pprint(o)
            if o['display_name'] == name:
                obj = o
                break
        if obj and display:
            if brief:
                print("%d. Name: %s" %(i,obj['display_name']))
                print("    Id: %s" %(obj['id']))
            else:
                self.json_print(data=obj, convert=False)
        return obj

    def deleteByName(self, name,listUrl=None, delUrl=None,display=True,brief=False):
        obj = self.findByName(name=name,restUrl=listUrl,display=display,brief=brief)
        if not obj:
            print("Delete: %s not found" % name)
            return None

        if delUrl:
            restUrl= delUrl % obj['id']
        else:
            if listUrl:
                restUrl="%s/%s" %(listUrl,obj['id'])
            elif self.listUrl:
                restUrl="%s/%s" %(self.listUrl,obj['id'])
            else:
                print("Cannot determine delete API for obj %s" %obj['display_name'])
                return None

        print( "RestUrl is %s" %restUrl)
        r = self.rest_api(api=restUrl, method="DELETE")
        if r.status_code != 200:
            print("Object %s delete failed with code %d" %(obj['display_name'],
                                                           r.status_code))
            return None
        else:
            print("Object %s deleted" %obj['display_name'])
            return obj

    def findById(self, id, restUrl=None, data=None, display=True,brief=False):      # Network_object
        if not data:
            if not restUrl:
                if self.listUrl:
                    restUrl=self.listUrl
            if not restUrl:
                print ("Calling list with no API specified")
                return None
        data = self.list(restUrl=restUrl,display=False)
        obj = None
        print(restUrl)
        for o in data['results']:
            if o['id'] == id:
                obj = o
                break
        if obj and display:
            if brief:
                print("%d. Name: %s" %(i,obj['display_name']))
                print("   Id: %s" %(obj['id']))
            else:
                self.json_print(data=obj, convert=False)
        return obj

    def getPathByName(self, name):                                                  # Network_object
        obj = self.findByName(name, display=False)
        return obj['path'] if obj and 'path' in obj else None

    def getIdByName(self, name):                                                    # Network_object
        obj = self.findByName(name, display=False)
        return obj['id'] if obj and 'id' in obj else None

    def getIdsByNamesGlob(self, namesGlob):                                         # Network_object
        objs = self.findByNamesGlob(listify(namesGlob))
        return {o['id']:o['display_name'] for o in objs}

    @memoize
    def getPolicyObjectByPath(self, path):                                          # Network_object
        #traceback.print_stack()
        pfx = self.policyObjPathPrefix
        if not path.startswith(pfx):
            path = pfx + path
        return self.doRestApi('get '+path)

    def json_print(self, data, indent=4, convert=False,desc=None):
        if convert and data:
            data = json.loads(data)
        elif data and not isinstance(data,dict):
            print ("Data not valid, and convert not specified")
            return
        if desc:
            print(desc)
        if data:
            print(json.dumps(data,indent=indent))

    def print_table(self,headers,data):
        '''
        data = array of json dictionaries
        headers = Convert keys in dictionaries to column headers
        '''
        for key,value in headers.iteritems():
            print("%8s |" %(value),end="")
        print("")
        for i in data:
            for key,value in headers.iteritems():
                if key in i:
                    print("%8s |" %i[key],end="")
                else:
                    print("%8s |" %" ",end="")
            print("")

    def rest_api(self, api, method="GET", data=None, convert=True, hdr=None,
                 display=False, mgr=None, timeout=None):
        method = method.upper()

        mgr = mgr or self.mgr

        if convert and data:
            data = json.dumps(data)
        self.logger.info1('%s: %s %s' % (mgr.hostname, method, api))
        headers={'Accept': 'application/json', 'Content-Type': 'application/json'}
        if hdr:
            for h in hdr.keys():
                headers[h] = hdr[h]
        if method == "GET":
            result = mgr.get(api,
                             headers=headers)
            if result.status_code >=400:
               print(str(dir(result)))
               print(result.cookies)
               print(result.headers)
               print(result.content)
               raise ValueError(result.text)
            else:
                if display:
                    self.json_print(data=result.text, convert=True)
                return result
        elif method == "POST":
            if display:
                print ("API: %s" % api)
                self.json_print(data=data,convert=True)
            result = mgr.post(api,
                              data = data,
                              headers=headers)
            if result.status_code >=400:
                raise ValueError(result.text)
            else:
                return result

        elif method == "PUT":
            if display and data:
                print ("API: %s" % api)
                self.json_print(data=data,convert=True)
            result = mgr.put(api,data=data,
                             headers=headers)
            if result.status_code >= 400:
                raise ValueError(result.text)
            else:
                return result

        elif method == "PATCH":
            if display and data:
                print ("API: %s" % api)
                self.json_print(data=data,convert=True)
            result = mgr.patch(api,data=data,
                               headers=headers)
            if result.status_code >= 400:
                raise ValueError(result.text)
            else:
                return result

        elif method == "DELETE":
            result = mgr.delete(url=api,
                                data=data,
                                headers=headers)
            if result.status_code >=400:
                raise ValueError(result.text)
            else:
                if display:
                    print("Successfully deleted: %d" %result.status_code)
                return result
        return None

    def walk_and_replace_dict_keyval(self, d, name, val = None):
        if isinstance(d,dict):
            for key, value in d.items():
                if isinstance(value,dict):
                    self.walk_and_replace_dict_keyval(d = d[key],
                            name=name,val=val)
                else:
                    if key == name:
                        d[key] = val

    def findByNames(self, names, nameTag='display_name', findMethod='list'):        # Network_object
        ''' findMethod:
                list:        gets the complete list of object THEN filter by nameTag locally
                queryString: only VM object is currently known to support query by diaplay_name
        '''
        names = listify(names)
        if findMethod=='list':
            return self.findByNamesGlob(names, nameTag)
        elif findMethod=='queryString':
            baseRestUrl = self.api['list'].url
            rObjs = []
            for name in names:
                restUrl = '%s?display_name=%s' % (baseRestUrl, name)
                jsonDict = self.pageHandler(restUrl)
                if len(jsonDict['results']):
                    rObjs.append(jsonDict['results'][0])
                else:
                    self.logger.warning('%s with display_name %s not found'%(
                        self.__class__.__name__, name))
            return rObjs

    def search(self, qstr, resource=None,name=None):
        '''
        Do a elastic search using qstr.  If resource and name are provided, parse
        output to find specific match based on resource_type and display_name
        I had to add this because of running into multiple instances where the same
        parameter to Search.query() returns different number of results
        Both have to be provided when either is used.
        The return type is normal T style return if no specifics are specifed,
        otherwise, it just returns None or the object itself
        '''
        s = Search(mgr=self.mgr)
        results=s.query(queryStr=qstr,nameGlob=False,display=False)
        if not resource or not name:
            return results

        for r in results['results']:
            if r['resource_type']==resource and r['display_name']==name:
                return r
        return None



    def findByNamesGlob(self, namesGlob, nameTag='display_name', findMethod='list'):# Network_object
        ''' findMethod:
                list:        gets the complete list of object THEN filter by nameTag locally
                queryString: only VM object is currently known to support query by diaplay_name
                search:      use search API to get ONLY objects which satisfies nameTag criteria from mgr
        '''
        useSearchAPI = findMethod=='search' or hasattr(self.mgr, 'useSearchAPI') and self.mgr.useSearchAPI
        namesGlob = listify(namesGlob)
        if namesGlob and useSearchAPI:
            resTypes = listify(self.resType)
            qResType = ' OR '.join(['resource_type:%s'%t for t in resTypes])
            qResType = '(%s)' % qResType
            qName = ' OR '.join(['%s:%s'%(nameTag,t) for t in namesGlob])
            qName = '(%s)' % qName
            qString = '%s AND %s' % (qResType, qName)
            jsonDict = Search(mgr=self.mgr).query(qString, display=False)
            return jsonDict['results']

        # no glob pattern found in any namesGlob
        simpleNames = [name for name in namesGlob if not re.search(r'[?*]', name)]
        #print('simpleNames = %s'%simpleNames)
        if findMethod=='queryString' and simpleNames and not (set(namesGlob)-set(simpleNames)):
            return self.findByNames(simpleNames, findMethod='queryString')

        # glob pattern found in some namesGlob
        restUrl = self.api['list'].url
        if restUrl.count('%') >= 2:
            restUrl = eval(restUrl)
        jsonDict = self.pageHandler(restUrl)
        objs = []
        for obj in jsonDict['results']:
            if isGlobMatched(namesGlob, obj[nameTag]):
                #print(obj['display_name'])
                objs.append(obj)
        return objs

    def delete(self, namesGlob, ids=[], mgr=None):                          # Network_object
        ''' extract kwargs to local namesapce '''
        #exec('\n'.join('%s=kwargs["%s"]' % (k, k) for k in kwargs.keys()))

        mgr = mgr or self.mgr
        namesGlob, ids = listify(namesGlob), listify(ids)

        objs = self.findByNamesGlob(namesGlob)
        #objs = self.list(mgr=mgr, display=False, nameGlob=namesGlob)

        for obj in objs:
            name, objId = obj['display_name'], obj['id']
            self.logger.info1('Deleting %s, id=%s' % (name,objId))
            restUrl = eval(self.api['delete'].url)
            #print(mgr.url_prefix)
            #print('restUr=%s'%restUrl)
            r = mgr.delete(restUrl)
            mgr.checkForError(r)

    def doRestApi(self, action, retryParams=None, **kwargs):
        ''' action: api key or "<restMethod> <restUrl>" '''
        ''' extract kwargs to local namesapce '''
        ''' kwargs: files, data, headers supressRestErrMsg '''
        exec('\n'.join('%s=kwargs["%s"]' % (k, k) for k in kwargs.keys()))

        restKw = {}
        if 'files' in kwargs: restKw['files'] = kwargs['files']
        if 'data' in kwargs: restKw['data'] = kwargs['data']
        if 'headers' in kwargs: restKw['headers'] = kwargs['headers']
        if 'suppressRestErrMsg' not in locals():
            suppressRestErrMsg = False

        if ' ' in action and action.split(' ')[1].startswith('/'):
            restMethod, restUrl = action.split(' ')
        elif action in self.api:
            restMethod = self.api[action].method
            restUrl = self.api[action].url
        else:
            self.logger.error('No API defined for action %s' % action)
            return None

        if restUrl.count('%') >= 2: restUrl = eval(restUrl)
        self.logger.info1('%s %s' % (restMethod, restUrl))
        if 'data' in kwargs:
            self.logger.debug('%s: REST BODY json=%s' % (type(self), kwargs['data']))

        #self.logger.info1('%s %s' % (getattr(self.mgr, restMethod).__name__, restUrl))
        r = getattr(self.mgr, restMethod)(restUrl, retryParams=retryParams, **restKw)
        if r.status_code >= 400 and not suppressRestErrMsg:
            self.mgr.responseError(r)
        return r

    @staticmethod
    def _mkObjId(prefix='PM_'):
        return prefix+uuid.uuid4().hex[:16]

    @staticmethod
    def _mkObjIdFromName(name):
        return re.sub('\W', '_', name)

    def _pmRestMethodMap(self, method):
        '''
        polstricyMgrVersion = self.mgr.version
        if policyMgrVersion.startswith('2.1'):
            if method=='patch':
                return 'post'
        '''
        return method

class Pools(Network_object):
    resType = 'IpPool'
    api = {
        'list':      Api('get',    '/api/v1/pools/ip-pools'),
        'update':    Api('put',   '"/api/v1/pools/ip-pools/%s"%objId'),
        'get':       Api('get',   '"/api/v1/pools/ip-pools/%s"%objId'),
    }
    listUrl = api['list'].url
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "name": .display_name,
                "id":   .id,
                "subnets": [.subnets[] | {
                    "ranges": (.allocation_ranges[] |.start + "-" + .end),
                    "cidr": .cidr,
                    "gw":   .gateway_ip,
                    "dns":  .dns_nameservers|join(",")
                }],
                "tags": (if .tags then [.tags[]|.scope+":"+.tag]|sort|join(", ") else "" end),
            }'''),
    }

    def __init__(self, mgr):
        super(self.__class__, self).__init__(mgr=mgr)
        self.listUrl='/api/v1/pools/ip-pools'

    def info(self):
        restUrl = '/api/v1/pools/ip-pools'
        r = self.rest_api(api=restUrl,method="GET", display=False)
        self.json_print(json.loads(r.text),indent=4)
        return json.loads(r.text)

    def config(self, data):
        restUrl = "/api/v1/pools/ip-pools"
        r = self.rest_api(api=restUrl,method="POST",
                          data=json.dumps(data), convert=False, display=False)
        self.mgr.logger.info("IPPool: posted pool \"%s\"" %data['display_name'])
        self.mgr.logger.info("   Result: %d" %r.status_code)


class HostSwitch(Network_object):
    def __init__(self,name,pnics=None,profiles=None, ippool= None):
        # name = this is the name, should the match the one define in TZ
        # pnics array of pnics
        # ipppol - UUID of the
        self.name = name
        self.pnics=pnics
        self.ippool = ippool
        self.profiles = profiles

    def getDict(self):
        data={}
        data['host_switch_name'] = self.name
        if self.pnics:
            data['pnics'] = self.pnics
        if self.profiles:
            data['host_switch_profile_ids'] = self.profiles
        if self.ippool:
            data['ip_assignment_spec'] = {}
            data['ip_assignment_spec']['ip_pool_id'] = self.ippool
            data['ip_assignment_spec']['resource_type'] = 'StaticIpPoolSpec'
        return data

class ManagerNode(Network_object):
    api = {
        'about':      Api('get',    '/api/v1/node'),
        'status':     Api('get',    '/api/v1/node/status'),
    }
    def __init__(self, host,
                 thumbprint=False,
                 rootpassword='CptWare12345!',
                 adminuser='admin',
                 adminpassword='CptWare12345!',
                 verify=False,
                 content_type="application/json",
                 accept='application/json',
                 loglevel="INFO",
                 nsxtAuth=True,
                 mgr=None,
                 pm=None,
                 certFile=None,
                 sessCookieFile=None,
                 safe=False,
                 timeout=None,
                 crSessCookieFile=None,
                 logfile=None,
                 logtag='',
                 ):

        #super(self.__class__, self).__init__(mgr=mgr)
        self.host = host
        self.rootpassword = rootpassword
        self.adminuser = adminuser
        self.adminpassword=adminpassword
        self.thumbprint=None
        self.ssh = None

        #self.logger=cp
        if thumbprint:
                self.thumbprint = self.getThumbprint()

        if mgr:
            self.mgr=mgr
        else:
            self.mgr = restlib.RestConnect('https://%s' % host,
                                      user=adminuser,
                                      password=adminpassword,
                                      verify=verify,
                                      content_type=content_type,
                                      accept=accept,
                                      logLevel=loglevel,
                                      logFile=logfile,
                                      logTag=logtag,
                                      nsxtAuth=nsxtAuth,
                                      certFiles=certFile,
                                      sessCookieFile=sessCookieFile)
            if timeout:
                self.mgr.timeout=float(timeout)
            self.mgr.useSearchAPI = False

            if safe:
                ''' disable PUT and POST rest request '''
                mgr.setVerbOp('post', None)
                mgr.setVerbOp('patch', None)
                mgr.setVerbOp('put', None)

            if crSessCookieFile:
                sCookie = SessionCookie(self.mgr, sessCookieFile=crSessCookieFile)
                sCookie.create()

        self.logger = self.mgr.logger
        self.getClusterInfo()
        self.clusterid = self.getClusterId()

    def connectSsh(self, password, username='root'):
        self.ssh = paramiko.SSHClient()
        self.ssh.load_system_host_keys()
        self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        logging.getLogger("paramiko").setLevel(logging.WARNING)
        try:
            self.ssh.connect(self.host, username=username, password=self.rootpassword)
        except Exception as e:
            print(e)
    sshConnect = connectSsh

    def sshExecute(self, cmd, output="raw"):
        ''' output: raw or lines '''
        _, out, err = self.ssh.exec_command(cmd)
        status = out.channel.recv_exit_status()
        if err.readlines():
            print(err.readlines())
        return out.read() if output=='raw' else [l.encode('utf-8').strip() for l in out.readlines()]

    def getMgr(self):
        return self.mgr
    def getIpAddress(self):
        return socket.gethostbyname(self.host)
    def getAdminUser(self):
        return self.adminuser
    def getAdminPassword(self):
        return self.adminpassword

    def getThumbprint(self, refresh=False):
        if self.thumbprint and not refresh:
            return self.thumbprint
        if not self.ssh:
            self.connectSsh(password=self.rootpassword)

        cmd = (" /opt/vmware/nsx-cli/bin/scripts/nsxcli -c "
            "get certificate api thumbprint")
        stdin,stdout,stderr = self.ssh.exec_command(cmd)
        line = stdout.read().strip()
        return line

    def getClusterId(self):
        return self.clusterid

    def getClusterInfo(self,display=False):
        restUrl='/api/v1/cluster/status'
        r=self.rest_api(api=restUrl,method='GET',display=False)
        data=json.loads(r.text)
        if 'cluster_id' in data.keys():
            self.clusterid=data['cluster_id']
        else:
            self.clusterid=None

        if display:
            self.json_print(data,convert=False)
        return data

    @staticmethod
    def ts2dt(ts, tz=''):
        return datetime.datetime.fromtimestamp(ts/1000).strftime('%D %T')+(
            ' %s'%(tz.split('/')[-1]) if tz else '')

    def about(self, display=True):
        restKey = 'about'
        restUrl = self.api[restKey].url
        restMethod = self.api[restKey].method
        #r = self.rest_api(api=restUrl, method="GET", mgr=self.mgr)
        #r = self.mgr.get(url=restUrl)
        r = self.mgr.getWithRetry(url=restUrl)
        m = r.json()
        #print(json.dumps(m))
        rDict = {}
        for k in ['hostname', 'node_version', 'kernel_version', 'cli_timeout']:
            if display:
                val = m[k]
                if k=='hostname': val += ' (%s)' % self.mgr.hostip
                print('\t%-16s%s' % (k, val))
            rDict.update({k:m[k]})
        if display:
            print('\t%-16s%s' % ('system_time',
                #datetime.datetime.fromtimestamp(m['system_time']/1000).strftime('%D %T'),
                self.ts2dt(m['system_time'], m['timezone'])))
        rDict.update({'system_time':m['system_time']})

        r = self.doRestApi('status')
        rJson = r.json()
        print()
        print('\t%-16s%s (%s)' % ('uptime', self.ts2dt(m['system_time']-rJson['uptime']),
            datetime.timedelta(seconds=rJson['uptime']/1000)))
        print('\t%-16s%s' % ('MEM c/u/t (GB)', '%0.3f / %0.3f / %0.3f' % (
            rJson['mem_cache']/1048576.0, rJson['mem_used']/1048576.0, rJson['mem_total']/1048576.0)))
        print('\t%-16s%s' % ('swap u/t (GB)', '%0.3f / %0.3f' % (
            rJson['swap_used']/1048576.0, rJson['swap_total']/1048576.0)))
        print('\t%-16s%s' % ('load 5s 1m 15m', '%s %s %s' % tuple(rJson['load_average'])))
        print('\t%-16s%s' % ('cpu_cores', '%s' % rJson['cpu_cores']))

        ptbl = PrettyTable(['fileSystem', 'mount', 'type', 'used (GB)', 'total (GB)'])
        ptbl.align = 'l'
        for row in sorted(rJson['file_systems']):
            ptbl.add_row([row['file_system'], row['mount'], row['type'],
                '%6.3f'%(row['used']/1048576.0), '%6.3f'%(row['total']/1048576.0)])
        print('\t'+str(ptbl).replace('\n', '\n\t'))

        return rDict


class ControllerNode(Network_object):
    def __init__(self,host,
            rootpassword='CptWare12345!',
            adminuser='admin',
            adminpassword='CptWare12345!',
            secret='Vmware123!',
            thumbprint=None):

        self.host = host
        self.rootpassword = rootpassword
        self.adminuser = adminuser
        self.adminpassword=adminpassword
        self.secret = secret
        self.thumbprint = thumbprint

        self.ssh = paramiko.SSHClient()
        self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.ssh.connect(host,username='root', password=self.rootpassword)

        #if not thumbprint:
        #    self.thumbprint=self.getThumbprint()

    def doexec(self,cmd):
            cmd = "/opt/vmware/nsx-cli/bin/scripts/nsxcli -c " + cmd
            print ("Running for %s: %s" %(self.host,cmd))
            stdin,stdout,stderr = self.ssh.exec_command(cmd)
            out = stdout.read()
            print (out)
            return out

    def getThumbprint(self):
        cmd = (" /opt/vmware/nsx-cli/bin/scripts/nsxcli -c "
            "get control-cluster certificate thumbprint")
        stdin,stdout,stderr = self.ssh.exec_command(cmd)
        line = stdout.read().strip()
        self.thumbprint = line
        return line



class Controller(Network_object):
    def __init__(self, hosts, manager = None,
            rootpassword='CptWare12345!',
            adminuser='admin',
            adminpassword='CptWare12345!',
            secret='CptWare12345!'):

        self.controllers = []
        for h in hosts:
            self.controllers.append(ControllerNode(host=h,
                    rootpassword=rootpassword,
                    adminuser=adminuser,
                    adminpassword=adminpassword,
                    secret=secret))

        if manager:
            self.manager=ManagerNode(host=manager,rootpassword=rootpassword, thumbprint=True)

    def joinMp(self):
        cmd = (" join management-plane %s thumbprint %s "
                "username %s password %s "
                %(self.manager.host, self.manager.thumbprint,
                    self.manager.adminuser,self.manager.adminpassword))

        for c in self.controllers:
            c.doexec(cmd)

    def getThumbprint(self):
        for c in self.controllers:
            c.getThumbprint()

    def setSecret(self):
        for c in self.controllers:
            cmd=" set control-cluster security-model shared-secret secret %s" \
                % (c.secret)
            c.doexec(cmd)
            c.getThumbprint()

    def initializeCluster(self, node):
        cmd = " initialize control-cluster"
        node.doexec(cmd)

    def joinCluster(self, frm, nodes):
        for c in nodes:
            c.getThumbprint()
            cmd=" join control-cluster %s thumbprint %s" %(c.host,c.thumbprint)
            frm.doexec(cmd)

    def activateCluster(self, nodes):
        for n in nodes:
            cmd = " activate control-cluster"
            n.doexec(cmd)


    def joinCp(self):
        self.setSecret()

        self.initializeCluster(self.controllers[0])

        if len(self.controllers) <= 1:
            return

        self.joinCluster(frm = self.controllers[0],
                nodes = self.controllers[1:])

        self.activateCluster(nodes=self.controllers[1:])

class FabricNode(Network_object):
    #resType = ['EdgeNode', 'HostNode']
    listUrl = '/api/v1/fabric/nodes'
    api = {
        'list':      Api('get',     '/api/v1/fabric/nodes'),
        'state':     Api('get',    "'/api/v1/fabric/nodes/%s/state'%nodeId"),
        'status':    Api('get',    "'/api/v1/fabric/nodes/%s/status'%nodeId"),
        'statuses':  Api('get',     '/api/v1/fabric/nodes/status'),
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "name":       .display_name,
                "id":         .id,
                "type":       .resource_type,
                "OS":          (.os_type+" "+.os_version),
                "deployType":  (.deployment_type // ""),
                "IPaddresses": .ip_addresses | join(", "),
            }'''),
        'status': PtblFmt(api['status'].url, '''
            .[]|{
                "name": .display_name,
                "mpa":  .mpa_connectivity_status,
                "lcp":  .lcp_connectivity_status,

                "controller":   [.lcp_connectivity_status_details[]| .control_node_ip] | join(","),
                "memUsed (GB)": (if .system_status then (.system_status|
                    ( (.mem_used/1024/1024|tostring|.[0:5]) +"/"+ (.mem_total/1024/1024|tostring|.[0:5]) )
                    ) else "" end),
                "uptime":     (if .system_status.uptime
                    then (.system_status.uptime/86400000|tostring|.[0:5]+"d") else "" end),

                "version":    .software_version,
                "deployment": .host_node_deployment_status,
            }'''),
        #        "sysTime": (.system_status.system_time/1000|todate),
        'state': PtblFmt(api['state'].url, '''
            .[]|{
                "name": .display_name,
                "state": .state,
            }'''),
    }

    #def __init__(self,mgr):
    #    super(self.__class__, self).__init__(mgr=mgr)
    #    self.listUrl='/api/v1/fabric/nodes'

    def findByIp(self,ip,display=True):
        fnodes = self.list(display=False)
        if fnodes['result_count'] <= 0:
            if display:
                print("FabricNodes: No fabric nodes in defined on MP.")
            return None

        for n in fnodes['results']:
            if ip in n['ip_addresses']:
                if display:
                    self.json_print(data=n,convert=False)
                return n
        if display:
            print("No fabric node found with IP %s" %ip)
        return None

    def delete(self,name,uninstall=False,display=False, singular=True):
        node = self.findByName(name=name,display=display)
        if not node:
            print("Fabric node delete failed, node not found: %s" %name)
            return False
        if uninstall == True:
            flag = 'True'
        else:
            flag = 'False'

        restUrl='/api/v1/fabric/nodes/%s?unprepare_host=%s' %(node['id'],flag)
        r = self.rest_api(api=restUrl,method="DELETE",display=display)
        print ("Deleting fabric node: %s ID: %s" %(name,node['id']))
        if r.status_code == 200:
            print ("Fabric node delete successfull. Name: %s ID: %s"
                   %(name,node['id']))
            return True
        else:
            print ("Fabric node delete not successfull. Name: %s ID: %s, code: %s"
                   %(name,node['id'], r.status_code))
            print (r.text)
            return False

    '''
    def getState(self,name=None,node=None,jq=False):
        if not name and not node:
            return
        if name and not node:
            node = self.findByName(name=name,display=False)
            node = node['id']
        restUrl = "/api/v1/fabric/nodes/%s/state" %node
        r = self.rest_api(restUrl,method="GET")
        self.json_print(data=r.text,convert=True)
    '''

    def getState(self,name=None,node=None,jq=False):
        if not name and not node:
            return
        if name and not node:
            nodes = [(n['display_name'],n['id']) for n in self.findByNamesGlob(name)]
        else:
            nodes = [('', node)]
        jResult = []
        for nodeName,nodeId in nodes:
            restUrl = "/api/v1/fabric/nodes/%s/state" %nodeId
            r = self.rest_api(restUrl,method="GET")
            if jq:
                jsonDict = json.loads(r.text)
                jsonDict['display_name'] = nodeName
                jResult.append(jsonDict)
            else:
                self.json_print(data=r.text,convert=True)
        if jq:
            self.jqTable(jsonStr=json.dumps(jResult), jqFilter=self.ptblFmts['state'].jqFilter)


    def getStatus(self,name=None,node=None,jq=False):
        if not name and not node:
            return
        if name and not node:
            nodes = [(n['display_name'],n['id']) for n in self.findByNamesGlob(name)]
        else:
            nodes = [('', node)]
        jResult = []
        for nodeName,nodeId in nodes:
            restUrl = "/api/v1/fabric/nodes/%s/status" %nodeId
            r = self.rest_api(restUrl,method="GET")
            if jq:
                jsonDict = json.loads(r.text)
                jsonDict['display_name'] = nodeName
                jResult.append(jsonDict)
                ### print('>>>', nodeName,nodeId )
            else:
                self.json_print(data=r.text,convert=True)
        if jq:
            self.jqTable(jsonStr=json.dumps(jResult), jqFilter=self.ptblFmts['status'].jqFilter)

        return json.loads(r.text)

        '''
        print('-=---------')
        data = '{"node_ids":["0631fb0b-74c9-42ea-a1ee-28cd704744ce","6fc7cdec-ba65-11e7-87f4-ecf4bbd94b24"]}'
        r = self.mgr.get(self.api['statuses'].url, data = data,
                headers={'Accept': 'application/json',
                    'Content-Type': 'application/json'})
        print(r.text)
        print('-=---------')
        '''

    def jqOp(self, feature, nameGlob='*'):
        if feature in ['state', 'status']:
            nodes = [(n['display_name'],n['id']) for n in self.findByNamesGlob(nameGlob)]
            jsonDicts = []
            for nodeName,nodeId in nodes:
                jsonDict = self.doRestApi(feature, nodeId=nodeId).json()
                jsonDict['display_name'] = nodeName
                jsonDicts.append(jsonDict)
            self.jqTable(jsonStr=jsonDicts, jqFilter=self.ptblFmts[feature].jqFilter)
        else:
            self.jqTable(nameGlob=nameGlob)

class DiscoveredNode(Network_object):

    api = {
        'list':      Api('get',     '/api/v1/fabric/discovered-nodes'),
    }

    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "name": .display_name,
                "id": .id,
                "type": .resource_type,
                "OS": (.os_type+" "+.os_version),
                "deployType": (.deployment_type // ""),
                "IPaddresses": .ip_addresses | join(", "),
            }'''),
    }


    def __init__(self, mgr):
        super(self.__class__, self).__init__(mgr=mgr)
        self.listUrl='/api/v1/fabric/discovered-nodes'

    def findByIp(self,ip,display=True):
        fnodes = self.list(display=False)
        if fnodes['result_count'] <= 0:
            if display:
                print("FabricNodes: No fabric nodes in defined on MP.")
            return None

        for n in fnodes['results']:
            if ip in n['ip_addresses']:
                if display:
                    self.json_print(data=n,convert=False)
                return n
        if display:
            print("No fabric node found with IP %s" %ip)
        return None

    def hostPrep(self,name=None,ip=None):
        if not name and not ip:
            print("Either host name or ID must be specified")
            return None

        node=None
        if ip:
            node = self.findByIp(ip=ip, display=False)

        if not node and name:
            node=self.findByName(name=name, display=False)

        if not node:
            print("Could not find discovered node to prep")
            return None

        restUrl='/api/v1/fabric/discovered-nodes/%s?action=hostprep' % node['external_id']

        r = self.rest_api(method='POST', api=restUrl)
        if r.status_code != 200:
            print("Error in host prep of node %s - %s"
                  %(node['display_name'], node['external_id']))
        else:
            print("Successfully sent prep command to node %s - %s" %
                  (node['display_name'], node['external_id']))

        if not node and name:
            node=self.findByName(name=name, display=False)

        if not node:
            print("Could not find discovered node to prep")
            return None

        restUrl='/api/v1/fabric/discovered-nodes/%s?action=hostprep' % node['external_id']

        r = self.rest_api(method='POST', api=restUrl)
        if r.status_code != 200:
            print("Error in host prep of node %s - %s"
                  %(node['display_name'], node['external_id']))
        else:
            print("Successfully sent prep command to node %s - %s" %
                  (node['display_name'], node['external_id']))


class EdgeNode(Network_object):
    resType = 'EdgeNode'
    listUrl = '/api/v1/fabric/nodes'

    def __init__(self, host, rootpassword='CptWare12345!',
            adminuser='admin', adminpassword='CptWare12345!'):
        self.host = host
        self.rootpassword = rootpassword
        self.adminuser = adminuser
        self.adminpassword=adminpassword
        self.ssh = paramiko.SSHClient()
        self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.ssh.connect(host,username='admin', password=self.adminpassword)

    def doexec(self,cmd):
        cmd = "/opt/vmware/nsx-cli/bin/scripts/nsxcli -c " + cmd
        print ("Running for %s: %s" %(self.host,cmd))
        stdin,stdout,stderr = self.ssh.exec_command(cmd)
        out = stdout.read()
        print (out)
        return out

    def joinmp(self,mgr,thumbprint,user='admin',password='CptWare12345!'):
        cmd = "join management-plane %s thumbprint %s username %s password %s" \
                %(mgr, thumbprint,user, password)
        self.doexec(cmd)

class Edge(Network_object):
    api = {
        'list':      Api('get',     '/api/v1/fabric/nodes?resource_type=EdgeNode'),
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "name":       .display_name,
                "id":         .id,
                "type":       .resource_type,
                "OS":          (.os_type+" "+.os_version),
                "deployType":  (.deployment_type // ""),
                "IPaddresses": .ip_addresses | join(", "),
            }'''),
    }

    def list(self, display=True):                                         # Edge
        restUrl = '/api/v1/fabric/nodes?resource_type=EdgeNode'
        r = self.rest_api(restUrl,method="GET")
        if display:
            self.json_print(data=r.text, convert=True)
        return r.json()



class TransportZoneProfile(Network_object):
    def __init__(self,mgr):
        super(self.__class__, self).__init__(mgr=mgr)
        self.listUrl = '/api/v1/transportzone-profiles'

class Transportzone(Network_object):
    resType = 'TransportZone'
    api = {
        'list':      Api('get',     '/api/v1/transport-zones'),
        'create':    Api('post',    '/api/v1/transport-zones'),
        'get':       Api('get',    '"/api/v1/transport-zones/%s"%objId'),
        'update':    Api('put',    '"/api/v1/transport-zones/%s"%objId'),
        'delete':    Api('delete', '"/api/v1/transport-zones/%s"%objId'),
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "name": .display_name,
                "id": .id,
                "type": .transport_type,
                "hostSwitch": .host_switch_name,
                "tags": (if .tags then [.tags[]|.scope+":"+.tag]|sort|join(", ") else "" end),
            }''')
    }

    def __init__(self, mgr):
        super(self.__class__, self).__init__(mgr=mgr)
        self.listUrl='/api/v1/transport-zones'

    '''
    def list(self,display=True):                            # Transportzone
        restUrl = '/api/v1/transport-zones'
        r = self.rest_api(restUrl,method="GET")
        data = json.loads(r.text)
        if display:
            self.json_print(data, convert=False)
        return  data['results']
    '''

    def config(self,data):
        restUrl = '/api/v1/transport-zones'
        r = self.rest_api(api=restUrl, method="POST", data=data)

    def find(self,name, display=True):
        return self.findByName(name=name,display=display)


    #def delete(self, namesGlob, ids):
    #    namesGlob, ids = listify(namesGlob), ids.split(',') if ids else []
    #    if namesGlob:
    #        tzs = self.findByNamesGlob(namesGlob)
    #    else:
    #        tzs = self.findByNamesGlob(ids, nameTag='id')
    #    for tz in tzs:
    #        name, objId = tz['display_name'], tz['id']
    #        self.logger.info1('Deleting TZ %s, id=%s' % (name,objId))
    #        r = self.mgr.delete(eval(self.api['delete'].url))
    #        self.mgr.checkForError(r)

    def createTZ(self, name, desc, swName, tzType):
        jsonDict = {
            'display_name': name,
            'description': desc,
            'host_switch_name': swName,
            'transport_type': tzType,
        }
        restUrl = self.api['create'].url
        if restUrl.count('%')>=2: restUrl=eval(restUrl)
        restMethod = self.api['create'].method
        r = self.rest_api(restUrl, method=restMethod, data=jsonDict)

class TransportNode(Network_object):
    resType = 'TransportNode'
    api = {
        'list':        Api('get',    '/api/v1/transport-nodes'),
        'create':      Api('post',   '/api/v1/transport-nodes'),
        'delete':      Api('delete', '"/api/v1/transport-nodes/%s"%_tnId'),
        'get':         Api('get',    '"/api/v1/transport-nodes/%s"%_tnId'),
        'resync':      Api('post',   '"/api/v1/transport-nodes/%s?action=resync_host_config"%_tnId'),
        'maintenance': Api('post',   '"/api/v1/transport-nodes/%s/?action=%s"%(_tnId,_action)'),
        'update':      Api('put',    '"/api/v1/transport-nodes/%s"%_tnId'),
        'state':       Api('get',    '"/api/v1/transport-nodes/%s/state"%_tnId'),
        'status':      Api('get',    '"/api/v1/transport-nodes/%s/status"%_tnId'),
    }

    #"name": ((.display_name|if test("%s") then . else empty end)+"\n"+.id),
    #"name/id": ((.display_name|if test("%s") then . else empty end)+"\n "+.id),
    #"name": (.display_name+"\n "+.id),
    #"name/id": (.display_name+"\n "+.id),
    #            "IPs|20":   (if .node_deployment_info.ip_addresses then (.node_deployment_info.ip_addresses|join(",")) else "" end),
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            def shortUuid:if . then .[:4]+".."+.[-4:] else "" end;
            .results[] | {
                "name/id":     (.display_name+"\n "+(.id)),
                "type/OS":  (.node_deployment_info.resource_type+"\n"+
                    (if .node_deployment_info.os_type then .node_deployment_info|(.os_type+"/"+.os_version)
                    else "" end)+"\n"
                ),
                "IPs|20":   (.node_deployment_info.ip_addresses//[]|join(",")),
                "tz":       [.transport_zone_endpoints[].transport_zone_id|shortUuid]|join(",\n"),
                "mgr(vc)":  (.node_deployment_info.managed_by_server|(if .!="" then
                    . else "standalone" end)//""),
                "hostSwitch": (if .host_switches then
                        ([.host_switches[] | {
                            "swName":               .host_switch_name,
                            "pnics":                [.pnics[] | {"devName": .device_name}],
                            "host_switch_profile":  [.host_switch_profile_ids[] |
                                { "key": (.key+":\n  "+(.value|shortUuid)) }
                            ],
                        }])
                    else "" end),
            }'''),
        'state': PtblFmt(api['state'].url, '''
            .[]|{
                "name":    .display_name,
                "id":      .transport_node_id,
                "state":   .state,
                "failMsg": (.failure_message // ""),
                "IPs":     (if .host_switch_states then [.host_switch_states[] | ([.endpoints[]|.ip]|join(",")) ]|join(";") else "" end),
            }'''),
        'status': PtblFmt(api['status'].url, '''
            .[]|{
                "name":       .node_display_name,
                "id":         .node_uuid,
                "mgmt/mpa":   (.mgmt_connection_status+"/"+.node_status.mpa_connectivity_status),
                "lcp-S/IPs": (
                    .node_status| (
                        .lcp_connectivity_status
                        +":\n"+
                        (
                            [
                                .lcp_connectivity_status_details[]|(.control_node_ip+"-"+.status)
                            ]|join(",\n")
                        )
                    )
                ),
                "ctlr-U/D/d": .control_connection_status|(
                    .status+"/"+(.up_count|tostring)+"/"+(.down_count|tostring)+"/"+(.degraded_count|tostring)),
                "pnic-U/D/d": .pnic_status|(
                    .status+"/"+(.up_count|tostring)+"/"+(.down_count|tostring)+"/"+(.degraded_count|tostring)),
                "tunn-U/D":   .tunnel_status|(
                    .status+"/"+(.up_count|tostring)+"/"+(.down_count|tostring)),

            }'''),
    }
    #            "IPs":      [.host_switch_states[] | ([.endpoints[]|.ip]|join(",")) ]|join(";"),

    def __init__(self, mgr, fill=True):
        super(self.__class__, self).__init__(mgr=mgr)
        self.nodes = None
        self.listUrl = '/api/v1/transport-nodes'
        if fill:
            self.list(display=False)

    '''
    def list(self, targets=None, display=True):             # TransportNode
        restUrl = '/api/v1/transport-nodes'
        r = self.rest_api(restUrl,method="GET")
        data=json.loads(r.text)
        self.nodes = data

        if not targets:
            if display:
                self.json_print(data=data, convert=False)
            return data['results']

        found = {}
        found['targets'] = targets
        found['results'] = []
        found['count'] = 0
        for node in data['results']:
            if not targets:
                continue
            for name in targets:
                if name == node['display_name']:
                    found['results'].append(name)
                    found['count'] +=1
        self.json_print(data=found, convert=False)
    '''

    def find(self,name=None,id=None,ip=None,display=True):
        if id:
            return self.findById(id=id,display=display)
        elif ip:
            return self.findByIp(ip=ip,display=display)
        else:
            return self.findByName(name=name,display=display)

    def findByNodeId(self,id,display=True):
        nodes = self.list(display=False)
        if nodes['result_count'] == 0:
            if display:
                print("No transport nodes defined in MP")
            return None
        for n in nodes['results']:
            if n['node_id'] == id:
                if display:
                    self.json_print(data=n,convert=False)
                return n
        if display:
            print("No transport node found with node id: %s" % id)
        return None

    def findByIp(self,ip,display=True):
        fnodes=FabricNode(mgr=self.mgr)
        node=fnodes.findByIp(ip=ip,display=False)
        if not node:
            if display:
                print("No Transport Node found with IP: %s" %ip)
            return None
        tn = self.findByNodeId(id=node['id'],display=display)
        return tn


    def delete(self,name,display=False):
        tn = self.find(name=name,display=False)
        if not tn:
            print("Transport node delete - node not found: %s" %name)
            return False

        restUrl = '/api/v1/transport-nodes/%s' %tn['id']
        print ("Deleting transport node: %s, id: %s" %(name,tn['id']))
        r=self.rest_api(api=restUrl,method="DELETE",display=False)
        if r.status_code == 200:
            print ("Successfully deleted TN %s with id %s" %(name,tn['id']))
            return True
        else:
            print ("Failed to delete TN %s with id %s, code: %s"
                   %(name,tn['id'],r.status_code))
            print (r.text)
            return False
    '''
    TBD

    def setLldp(self,name,profile,display=True):
        tn = self.find(name=name,display=False)
        if not tn:
            print("TransportNode %s not found" %name)
            return False

        profiles = UplinkProfile(mgr=self.mgr)
        lldp = profiles.findByName(name=profile)
        if not lldp:
            print("Uplink profile for LLDP with name %s not found" %profile)
            return False

    '''

    def migrateVmk(self,tnname,vmk,vss,display=True):
        tn = self.find(name=tnname,display=False)
        if not tn:
            print("Transport Node not found: %s" %tnname)
            return False

        restUrl = ('/api/v1/transport-nodes/%s?esx_mgmt_if_migration_dest=%s&if_id=%s'
                   %(tn['id'], vss,vmk))
        print('>>>', restUrl )
        r = self.rest_api(api=restUrl,method="PUT",data=tn, display=display)
        print('>>>', r )
        if r.status_code == 200:
            return True
        else:
            print("Migration failed with code %d, reason: "
                  %(r.status_code))
            print (r.text)

    def jqOp(self, feature, nameGlob='*'):
        if feature=='state':
            jResult = []
            for obj in self.findByNames(nameGlob):
                restUrl='/api/v1/transport-nodes/%s/state' % obj['id']
                r = self.rest_api(method='GET',api=restUrl,display=False)
                rDict = json.loads(r.text)
                rDict['display_name'] = obj['display_name']
                jResult.append(rDict)
            #self.jqTable(jsonStr=json.dumps(jResult), jqFilter=self.ptblFmts['state'].jqFilter)
            self.jqTable(apiKey='state', jsonStr=json.dumps(jResult), jqFilter=self.ptblFmts['state'].jqFilter)
        elif feature=='status':
            jResult = []
            for obj in self.findByNames(nameGlob):
                results={}
                if obj:
                    restUrl='/api/v1/transport-nodes/%s/status' % obj['id']
                    try:
                        self.logger.info1('Getting status of "%s"' % obj['display_name'])
                        r = self.rest_api(method='GET',api=restUrl,display=False)
                        rText = r.text
                        if r.status_code==200:
                            results={}
                            results['result_count'] = 1
                            results['results'] = [json.loads(r.text)]
                            jResult.append(json.loads(rText))
                    except:
                        print('#### node_display_name', obj['display_name'])
            self.jqTable(jsonStr=json.dumps(jResult), jqFilter=self.ptblFmts['status'].jqFilter)
        else:
            self.jqTable(nameGlob=nameGlob)

    def getState(self,name=None,ip=None,tnid=None, detail=False,display=True,jq=False):
        '''
        if provided, only one of name or tnid will be used, with tnid taking precedence.
        if not found with
        tnid, then name will be used
        '''
        if jq:
            jResult = []
            for obj in self.findByNames(name or '*'):
                restUrl='/api/v1/transport-nodes/%s/state' % obj['id']
                r = self.rest_api(method='GET',api=restUrl,display=False)
                rDict = json.loads(r.text)
                rDict['display_name'] = obj['display_name']
                jResult.append(rDict)
            #self.jqTable(jsonStr=json.dumps(jResult), jqFilter=self.ptblFmts['state'].jqFilter)
            self.jqTable(apiKey='state', jsonStr=json.dumps(jResult), jqFilter=self.ptblFmts['state'].jqFilter)
            return

        obj = None
        obj = self.find(name=name,ip=ip,id=tnid,display=False)
        results=None
        if obj:
            restUrl='/api/v1/transport-nodes/%s/state' % obj['id']
            r = self.rest_api(method='GET',api=restUrl,display=False)
            if r.status_code==200:
                results={}
                results['result_count'] = 1
                results['results'] = [json.loads(r.text)]
        else:
            restUrl='/api/v1/transport-nodes/state'
            r = self.rest_api(method='GET',api=restUrl,display=False)
            if r.status_code==200:
                results=json.loads(r.text)
        if display:
            print(detail, jq)
            if detail:
                self.json_print(data=results,convert=False)
            else:
                print("Number of results: %d" %results['result_count'])
                headers=OD([('display_name','name'),('transport_node_id',"id"),("state","state"),("failure_message","message")])
                self.print_table(headers=headers,data=results['results'])
        return results

    def getStatus(self,name=None,ip=None,tnid=None, detail=False,display=True,jq=False):
        '''
        if provided, only one of name or tnid will be used, with tnid taking precedence.
        if not found with
        tnid, then name will be used
        '''

        jResult = []
        for obj in self.findByNames(name):
            results={}
            if obj:
                restUrl='/api/v1/transport-nodes/%s/status' % obj['id']
                try:
                    self.logger.info1('Getting status of "%s"' % obj['display_name'])
                    r = self.rest_api(method='GET',api=restUrl,display=False)
                    rText = r.text
                    if r.status_code==200:
                        results={}
                        results['result_count'] = 1
                        results['results'] = [json.loads(r.text)]
                        jResult.append(json.loads(rText))
                except:
                    rDict = {
                        'node_display_name': obj['display_name'],
                        'node_uuid': '-',
                        'mgmt_connection_status': '',
                        'control_connection_status': {
                            'status': '-',
                            'up_count': 0,
                            'down_count': 0,
                            'degraded_count': 0},
                        'pnic_status': {
                            'status': '-',
                            'up_count': 0,
                            'down_count': 0,
                            'degraded_count': 0},
                        'tunnel_status': {
                            'status': '-',
                            'up_count': 0,
                            'down_count': 0,
                            },
                    }
                    rText = json.dumps(rDict)
                if display and detail:
                    self.json_print(data=results,convert=False)
            #else:
            #    restUrl='/api/v1/transport-nodes/status'
            #    r = self.rest_api(method='GET',api=restUrl,display=False)
            #    if r.status_code==200:
            #        results=json.loads(r.text)
            #if not jq:
            #    return results
        if jq or not detail:
            self.jqTable(jsonStr=json.dumps(jResult), jqFilter=self.ptblFmts['status'].jqFilter)

    def getBondStatus(self,name=None,ip=None,tnid=None,display=True):
        obj = self.find(name=name,id=tnid,ip=ip,display=False)
        if not obj:
            if display:
                print("TN not found for bond status")
            return None
        restUrl='/api/v1/transport-nodes/%s/pnic-bond-status' % obj['id']
        r = self.rest_api(method='GET',api=restUrl,display=False)
        if r.status_code==200:
            results=json.loads(r.text)
        if display:
            self.json_print(data=results,convert=False)
        return results



    def addTz(self,tnname,tzname,display=True):
        tzlist = Transportzone(mgr=self.mgr)
        tz = tzlist.find(name=tzname,display=False)
        if not tz:
            print ("TransportZone with name %s not found while configuring TN: %s"
                    %(tzname,tname))
            return

        tn = self.find(name=tnname,display=False)
        if not tn:
            print ("TransportNode not found: %s" %tnname)
            return

        tzids = tn['transport_zone_endpoints']
        for z in tzids:
            if z['transport_zone_id'] == tz['id']:
                print ("TransportNode %s already part of TZ (%s,%s)"
                        %(tnname,tzname,tz['id']))
                return
        tzep = {}
        tzep['transport_zone_id'] = tz['id']
        tzids.append(tzep)

        data = {}
        data['node_id'] = tn['node_id']
        data['transport_zone_endpoints'] = tzids
        data['display_name'] = tn['display_name']
        data['description'] = tn['description']
        data['host_switches'] = tn['host_switches']
        data['host_switch_spec'] = tn['host_switch_spec']
        data['_revision'] = tn['_revision']

        restUrl = '/api/v1/transport-nodes/%s' %tn['id']
        r = self.rest_api(api=restUrl,method='PUT',data=data,display=display)


    def update(self, nodename, nics=[], swname=None, uplink=None, lldp=None,
              ippool=None, vmklist=None, targets=None):
        ''' update TN hsw configuration
            hswName can be prefixed with '+', '~' for add/remove hsw operation
            hswName w/o any prefixed will be modified according to given parameters
            supported parameters: uplink, lldp, ippool
            not yet supported parameters: vlansw, vnics, tzname
        '''

        def _mapPnics(ulProf, nics):
            team = ulProf['teaming']
            uplinkList = team['active_list']
            if 'standby_list' in team:
                uplinkList += team['standby_list']

            pnics = []
            for upIndex,n in enumerate(nics):
                uplinkName = uplinkList[upIndex]['uplink_name'] if uplinkList[0]['uplink_type']=='PNIC' \
                    else ulProf['lags'][0]['uplinks'][upIndex]['uplink_name']
                pnics.append({
                    'device_name': n,
                    'uplink_name': uplinkName
                })
            return pnics

        op = '='
        if swname[0] in ['+', '-', '!', '~']:
            op = re.sub('[!~]', '-', swname[0])
            swname = swname[1:]

        tn = self.find(name=nodename, display=False)
        if not tn:
            self.logger.error("Transport node %s not found." % nodename)
            exit(1)
        uppd = Uplinkprofile(mgr=self.mgr)

        targetSwitches = filter(lambda sw:sw['host_switch_name']==swname, tn['host_switch_spec']['host_switches'])
        curSwNames = [sw['host_switch_name'] for sw in tn['host_switch_spec']['host_switches']]
        modifiedHsw=None
        if op=='=':
            self.logger.info('Updating switch %s' % swname)
            if swname not in curSwNames:
                self.logger.error('Switch %s not found' % swname)
                exit(102)

            hsw = targetSwitches[0]
            modifiedHsw=hsw
            if uplink or nics:
                hswProf = filter(lambda p:p['key']=='UplinkHostSwitchProfile', hsw['host_switch_profile_ids'])[0]
                ulProf = uppd.findByName(name=uplink, display=False) if uplink \
                    else uppd.findById(hswProf['value'], display=False)

                hswProf['value'] = ulProf['id']
                if nics:
                    hsw['pnics'] = _mapPnics(ulProf, nics)

            if lldp:
                hswProf = filter(lambda p:p['key']=='LldpHostSwitchProfile', hsw['host_switch_profile_ids'])[0]
                lldpProf = uppd.findByName(name=lldp, display=False)
                hswProf['value'] = lldpProf['id']

            if ippool:
                ipp = Pools(mgr=self.mgr).findByName(ippool, display=False)
                hsw['ip_assignment_spec']['ip_pool_id'] = ipp['id']
        elif op=='+':
            self.logger.info('Adding switch %s' % swname)
            if swname in curSwNames:
                self.logger.error('Switch %s arelady exist' % swname)
                exit(103)

            profiles, pnics, poolProfile = [], None, None
            if lldp:
                lldpProf = uppd.findByName(name=lldp, display=False)
                if lldpProf:
                    profiles.append({ 'key': lldpProf['resource_type'], 'value': lldpProf['id'] })
            if uplink:
                ulProf = uppd.findByName(name=uplink, display=False)
                if ulProf:
                    profiles.append({ 'key': ulProf['resource_type'], 'value': ulProf['id'] })
                    if nics:
                        pnics = _mapPnics(ulProf, nics)
            if ippool:
                ipp = Pools(mgr=self.mgr).findByName(ippool, display=False)
                if ipp:
                    poolProfile = ipp['id']

            hsw = HostSwitch(name=swname, pnics=pnics, profiles=profiles, ippool=poolProfile)
            hswDict = hsw.getDict()
            tn['host_switch_spec']['host_switches'].append(hswDict)
            modifiedHsw=tn['host_switch_spec']['host_switches'][-1]
        elif op in ['-', '~', '!']:
            self.logger.info('Removing switch %s' % swname)
            if swname not in curSwNames:
                self.logger.error('Switch %s not found' % swname)
                exit(102)

            tn['host_switch_spec']['host_switches'] = [sw for sw in
                tn['host_switch_spec']['host_switches'] if sw['host_switch_name']!=swname]

        _tnId = tn['id']
        restUrl = self.api['update'].url
        if restUrl.count('%') >= 2: restUrl = eval(restUrl)

        if vmklist:
            if not targets:
                print("vmklist must require targets")
                exit(103)
            if len(vmklist.split(',')) != len(targets.split(',')):
                print("Number of vmklist objects not equal targets")
                exit(103)
            if not modifiedHsw:
                print("Didn't set modified HSW for migration")
                exit(103)
            else:
                modifiedHsw['is_migrate_pnics'] = True
            #restUrl="%s?vnic=%s&vnic_migration_dest=%s" %(restUrl,vmklist,targets)
            restUrl="%s?if_id=%s&esx_mgmt_if_migration_dest=%s" %(restUrl,vmklist,targets)

        r = self.doRestApi('update', _tnId=_tnId, data=json.dumps(tn))
        if not self.mgr.checkForError(r):
            self.logger.info('TN updated')

    def config(self,nodename,nics,swname,uplink,lldp=None,ippool=None,
            vlansw=None,vnics=None,tzname=None):
        # Let's fine the node
        fnodes = FabricNode(mgr=self.mgr)
        node = fnodes.findByName(name=nodename,display=False)
        if not node:
            print ("Can't find fabric node with name: %s" %nodename)
            return

        if vlansw and not vnics:
            print ("Must supply vnics for vlan switch")
            return

        #Find the uplink profile
        upprofiles = Uplinkprofile(mgr=self.mgr)
        profile = upprofiles.findByName(name=uplink,display=False)
        if not profile:
            print( "Can't find uplink profile with name: %s" %uplink)
            return

        profiles = []
        profItem={}
        profItem['key'] = profile['resource_type']
        profItem['value'] = profile['id']
        profiles.append(profItem)

        #find LLDP profile
        lldpProfile=None
        if lldp:
            lldpProfile = upprofiles.findByName(name=lldp,display=False)
            if not lldpProfile:
                print ("Can't find the lldp profile with name: %s" %lldp)
                return


        if lldpProfile:
            profItem={}
            profItem['key'] = lldpProfile['resource_type']
            profItem['value'] = lldpProfile['id']
            profiles.append(profItem)

        #find the ippooln
        poolProfile=None
        if ippool:
            pools=Pools(mgr=self.mgr)
            poolProfile=pools.findByName(name=ippool)
            if not poolProfile:
                print ("Can't find the IP pool with name: %s" %ippool)
                return
        if poolProfile:
            poolProfile = poolProfile['id']


        data={}
        data['display_name'] = node['display_name']
        if 'os_type' in node.keys():
            data['description'] = node['display_name'] + ' ' + node['os_type']
        else:
            data['description'] = node['display_name'] + ' ' + node['resource_type']


        team = profile['teaming']
        if 'standby_list' in team:
            uplinkList = team['active_list'] + team['standby_list']
        else:
            uplinkList = team['active_list']

        pnics = []
        upIndex = 0
        vIndex = 0
        vlanNics=[]
        if uplinkList[0]['uplink_type'] == 'PNIC':
            if len(uplinkList) < len(nics):
                print ("You have more nics than defined in the profile")
                return
            for n in nics:
                pnic={}
                pnic['device_name'] = n
                pnic['uplink_name'] = uplinkList[upIndex]['uplink_name']
                pnics.append(pnic)
                upIndex +=1
            if vnics and len(uplinkList) < len(vnics):
                print ("You have more vnics than defined in the profile")
                return
            elif vnics:
                for n in vnics:
                    vnic={}
                    vnic['device_name'] = n
                    vnic['uplink_name'] = uplinkList[vIndex]['uplink_name']
                    vlanNics.append(vnic)
                    vIndex +=1
        else:
            if profile['lags'][0]['number_of_uplinks'] < len(nics):
                print ("You have more nics than defined in the LAG profile")
                return
            for n in nics:
                pnic={}
                pnic['device_name'] = n
                pnic['uplink_name'] = profile['lags'][0]['uplinks'][upIndex]['uplink_name']
                pnics.append(pnic)
                upIndex +=1
            if vnics:
                for n in vnics:
                    print ("working on %s" %n)
                    print ("current index %d" %vIndex)
                    vnic={}
                    vnic['device_name'] = n
                    #self.json_print( profile['lags'][0])
                    print ("using %s" %profile['lags'][0]['uplinks'][vIndex]['uplink_name'])
                    vnic['uplink_name'] = profile['lags'][0]['uplinks'][vIndex]['uplink_name']
                    vlanNics.append(vnic)
                    vIndex+=1

        switchSpec = {}
        switchSpec['resource_type'] = "StandardHostSwitchSpec"
        switchSpec['host_switches'] = []

        hsw = HostSwitch(name=swname, pnics=pnics, profiles = profiles,
                ippool=poolProfile)
        hswDict=hsw.getDict()

        switchSpec['host_switches'].append(hswDict)


        if vlansw:
            vsw = HostSwitch(name=vlansw,pnics=vlanNics,profiles=profiles)
            vswDict = vsw.getDict()
            switchSpec['host_switches'].append(vswDict)

        data['host_switch_spec'] = switchSpec

        if tzname:
            tz = Transportzone(mgr=self.mgr)
            tzid = tz.find(name=tzname)
            if tzid:
                tzep = {}
                tzep['transport_zone_id'] = tzid['id']
                data['transport_zone_endpoints'] = [tzep]

        data['node_id'] = node['id']

        restUrl = '/api/v1/transport-nodes'
        self.json_print(data=data,convert=False)
        r = self.rest_api(api=restUrl, method="POST",data=data,convert=True)
        if r.status_code != 201:
            print ("Didn't get 201 result from TN post")
            self.json_print(data=json.loads(r.text), convert=False)


def _mkTagQuery(tags, op='OR'):
    tagQuery = '(%s)' % (
        ' %s '%op).join(
            ['(tags.scope:%s AND tags.tag:%s)' %
                tuple([v or '*' for v in tag.split(':')]) \
            for tag in tags]
        ) if tags else ''
    tagQuery = re.sub(r'tags.scope:\* AND ', '', tagQuery)
    tagQuery = re.sub(r' AND tags.tag:\*', '', tagQuery)
    return tagQuery

def _mkSearchQuery(key, vals, op='OR'):
    conds = ['%s:%s'%(key,val) for val in listify(vals)]
    qStr = ' %s '.join(conds) if vals else ''
    return '(%s)'%qStr if len(conds)>1 else qStr

def _jqResOrCrit(resType, key, vals, reMagic=False):
    if not reMagic:
        vals = [v.replace('/', '\/') for v in vals]
    keyCond = _mkSearchQuery(key, vals, op='OR')
    resCond = _mkSearchQuery('resource_type', resType)
    combCond = [resCond, keyCond]
    combCond = [c for c in combCond if c]
    return ' AND '.join(combCond)

def _jqResOrCrit0(resType, key, vals):
    orCond = ' AND (%s)'%' OR '.join(['%s:%s'%(key,val) for val in vals]) if vals else ''
    return 'resource_type:%s%s' % (resType, orCond)

class SwitchPorts(Network_object):
    resType = 'LogicalPort'
    api = {
        'list':       Api('get',     '/api/v1/logical-ports'),
        'update':     Api('put',    '"/api/v1/logical-ports/%s"%objId'),
        'delete':     Api('delete', '"/api/v1/logical-ports/%s"%objId'),
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            def shortUuid:if . then .[:4]+".."+.[-4:] else "" end;
            .results[] | {
                "name/id":    (.display_name+"\n "+.id),
                "ls name/id": (.logical_switch_name+"\n "+(.logical_switch_id)),
                "admState":   .admin_state,
                "attachment": (if .attachment then
                    .attachment|(.attachment_type+" "+.display_name+"\n "+(.id|shortUuid)) else "" end),
                "profiles":   (if .profileNames then .profileNames|join("\n") else "" end),
                "addr":       (.address_bindings|join("\n")),
            }'''),
    }

    def __init__(self, mgr):
        super(self.__class__, self).__init__(mgr=mgr)
        self.ports = None
        self.count = 0

    def getPorts(self, switch=None, display=True):
        restUrl = '/api/v1/logical-ports'
        if switch:
            restUrl = restUrl + "?logical_switch_id="+switch
            print( restUrl)

        r = self.rest_api(restUrl,method="GET")
        data = json.loads(r.text)
        self.count = data['result_count']
        if self.count > 0:
            self.ports = data['results']

        if not display:
            return
        if self.count == 0:
            print ("  No ports found for switch %s" %switch)
            return
        for p in self.ports:
            print ("ID: %s" % p['id'] )
            print ("name: %s" %p['display_name'])
            if 'attachment' in p:
                a = p['attachment']
                print ("   attach_type: %s" %a['attachment_type'])
                print ("   id: %s" %a['id'])
            else:
                print ("   Not attached")


    def delZeroPorts(self, swid):
        restUrl = '/api/v1/logical-ports'
        if swid:
            restUrl = restUrl + "?logical_switch_id="+swid

        self.getPorts(switch=swid, display=False)

        for p in self.ports:
            if 'attachment' in p:
                a = p['attachment']
                if a['id'][:8] == '00000000':
                    print ("Deleting %s" %p['id'])
                    print ("   VIF: %s" %a['id'])
                    restUrl = '/api/v1/logical-ports/%s?detach=True' %p['id']
                    print ("   " +restUrl)
                    r = self.rest_api(api=restUrl, method="DELETE")
                    print (r.text)
                    if r.status_code != 200:
                        print ("Delete didn't work")
                        print (r.text)
                    else:
                        print ("   API return success code: 200")

    def delete(self,name,swid=None,iterate=False):
        restUrl='/api/v1/logical-ports'
        if swid:
            restUrl = restUrl+"?logical_switch_id="+swid

        self.getPorts(switch=swid,display=False)
        if not self.ports:
            return
        for p in self.ports:
            if p['display_name'] == name:
                print("Deleting %s" %p['display_name'])
                restUrl='/api/v1/logical-ports/%s?detach=True' %p['id']
                r=self.rest_api(api=restUrl,method="DELETE")
                if r.status_code != 200:
                    print(" ...failed")
                else:
                    print(" ...done")
                if not iterate:
                    break


    def delDownPorts(self,swid):
        restUrl = '/api/v1/logical-ports'
        if swid:
            restUrl = restUrl + "?logical_switch_id="+swid

        self.getPorts(switch=swid, display=False)

        for p in self.ports:
            if 'admin_state' in p:
                if p['admin_state'] == 'DOWN':
                    print("Deleting %s" %p['display_name'])
                    restUrl='/api/v1/logical-ports/%s?detach=True' %p['id']
                    r=self.rest_api(api=restUrl,method="DELETE")
                    if r.status_code != 200:
                        print(" ...failed")
                    else:
                        print(" ...done")

    def delOperDownPorts(self, swid):
        restUrl = '/api/v1/logical-ports'
        if swid:
            restUrl = restUrl + "?logical_switch_id="+swid

        self.getPorts(switch=swid, display=False)
        for p in self.ports:
            restUrl='/api/v1/logical-ports/%s/status' % p['id']
            r = self.rest_api(api=restUrl,method="GET", display=False)
            data=json.loads(r.text)
            if data['status'] == "DOWN":
                print("Deleting %s" %p['display_name'])
                restUrl='/api/v1/logical-ports/%s?detach=True' %p['id']
                r=self.rest_api(api=restUrl,method="DELETE")
                if r.status_code != 200:
                    print(" ...failed")
                else:
                    print(" ...done")

    def delNotAttachedPorts(self,swid):
        restUrl = 'api/v1/logical-ports'
        if swid:
            restUrl = restUrl+"?logical_switch_id="+swid
        self.getPorts(switch=swid,display=False)
        for p in self.ports:
            if 'attachment' not in p:
                print("Deleting %s" %p['display_name'])
                restUrl='/api/v1/logical-ports/%s?detach=True' %p['id']
                r=self.rest_api(api=restUrl,method="DELETE")
                if r.status_code != 200:
                    print(" ...failed")
                else:
                    print(" ...done")

    def admin(self,state,name=None, id=None):
        port = None
        if id:
            port = self.findByid(id=id, restUrl='/api/v1/logical-ports',
                                   display=False)
        elif not port and name:
            port = self.findByName(name=name, restUrl='/api/v1/logical-ports',
                                   display=False)
        if not port:
            print ("Port not found by id or name")
            return False

        restUrl = '/api/v1/logical-ports/%s' %port['id']
        if state == 0:
            port['admin_state'] = "DOWN"
        else:
            port['admin_state'] = "UP"
        r = self.rest_api(api=restUrl,method="PUT", data=port)
        if r.status_code == 200:
            return True
        else:
            return False

    @cptutil.memoize
    def uuid2name(self, uuid, searchd=None):
        if not searchd:
            searchd = Search(mgr=self.mgr)
        obj = searchd.query('id:%s'%uuid)
        results = obj['results']
        return results[0]['display_name'] if results else ''

    def lsPortJq(self, lsNamesGlob):
        search = Search(mgr=self.mgr, display=False)

        queryStr = _jqResOrCrit('LogicalSwitch', 'display_name', lsNamesGlob)
        lss = search.query(queryStr)['results']
        lsIds = [ls['id'] for ls in lss][:122]

        queryStr = _jqResOrCrit('LogicalPort', 'logical_switch_id', lsIds)
        jsonDict = search.query(queryStr)

        for lsp in jsonDict['results']:
            lsp['logical_switch_name'] = self.uuid2name(lsp['logical_switch_id'], search)
            if 'attachment' in lsp:
                lsp['attachment']['display_name'] = self.uuid2name(lsp['attachment']['id'], search)
            profNames = []
            for prof in lsp['switching_profile_ids']:
                profName = self.uuid2name(prof['value'], search)
                profNames.append(profName)
            lsp['profileNames'] = profNames

        self.jqTable(jsonStr=json.dumps(jsonDict))


class Switch(Network_object):
    resType = 'LogicalSwitch'
    api = {
        'list':      Api('get',    '/api/v1/logical-switches'),
        'update':    Api('put',   '"/api/v1/logical-switches/%s"%objId'),
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            def shortUuid:if . then .[:4]+".."+.[-4:] else "" end;
            .results[] | {
                "name": .display_name,
                "id":   .id,
                "tz":   .transport_zone_id|shortUuid,
                "vlan": (.vlan // ""),
                "vni":  (.vni // ""),
                "tags": (if .tags then [.tags[]|.scope+":"+.tag]|sort|join(", ") else "" end),
            }'''),
    }

    def __init__(self, mgr):
        super(self.__class__, self).__init__(mgr=mgr)
        self.id = None
        self.vnid = None
        self.ports = None
        self.switches = None
        self.listUrl='/api/v1/logical-switches'
        self.data=None

    def listInt(self, display = True, short=True):
        restUrl = '/api/v1/logical-switches'
        #r = self.rest_api(restUrl, method="GET")
        data=self.list(display=False)
        #data = json.loads(r.text)
        if data['result_count'] <= 0:
            if display:
                print ("No switches found")
                return None
            else:
                return None
        if display:
            if not short:
                self.json_print(data=r.text,convert=True)
                return
            for s in data['results']:
                print ("Name: " + s['display_name'])
                print ("   id: %s" %(s['id']))
                print ("   tz id: %s" %(s['transport_zone_id']))
                if 'vni' in s:
                    print ("   rep_mode: %s" %(s['replication_mode']))
                    print ("   vni: %d" %(s['vni']))
                if 'vlan' in s:
                    print ("   vlan: %d" %(s['vlan']))
                print ("   state: %s" %(s['admin_state']))

        self.switches =data['results']
        return data['results']

    def updateTeaming(self, name, teaming=None):
        sw = self.findByName(name=name, display=False)
        if not sw:
            print("Switch %s not found" %name)
            return None

        if not teaming:
            if 'uplink_teaming_policy_name' in sw:
                del sw['uplink_teaming_policy_name']
        else:
            sw['uplink_teaming_policy_name'] = teaming

        api='/api/v1/logical-switches/%s' %sw['id']
        if sw['_protection'] == 'REQUIRE_OVERRIDE':
            hdr={'X-Allow-Overwrite': 'true'}
        else:
            hdr=None
        r = self.rest_api(api, method='PUT', data=sw, hdr=hdr,convert=True)
        if r.status_code != 200:
            print("Update of teaming policy for %s failed with code %d"
                  %(name, r.status_code))
            return None
        else:
            return r

    def config(self,name,tzname,replication='MTEP', teaming=None,vlan=0, force=False):
        tz = Transportzone(mgr=self.mgr)
        tzid = tz.find(name=tzname,display=False)
        if not tzid:
            print ("Can't find transport zone: %s" %tzname)
            return None
        if self.findByName(name=name) and not force:
            print("Logical switch named %s already exist" %name)
            return

        ls = {}
        ls['display_name'] = name
        ls['description'] = name + ' ' + tzid['transport_type']
        ls['transport_zone_id'] = tzid['id']
        ls['admin_state'] = 'UP'
        if tzid['transport_type'] == 'VLAN':
            ls['vlan'] = vlan
        elif tzid['transport_type'] == 'OVERLAY':
            ls['replication_mode'] = replication
        else:
            print ("Unknown transport zone type: %s" %tzid['transport_type'])
            return None
        if teaming:
            ls['uplink_teaming_policy_name'] = teaming

        restUrl = '/api/v1/logical-switches'
        r = self.rest_api(restUrl,method="POST", data=ls,convert=True)
        if r.status_code != 201:
            print ("Logical switch create ERROR")
            print ("Return code: %d, expecting 201" %r.status_code)
            print ("post data")
            self.json_print(data=ls,convert=True)
            return None
        else:
            return r.status_code


    def getVni(self, swname, display = False):
        val = None
        switches = self.listInt(display=False)
        for sw in switches:
            if sw['display_name'] == swname:
                self.switch = sw['display_name']
                if 'vni' in sw:
                    val = sw['vni']
                else:
                    val = sw['vlan']
                self.data=sw
                if display:
                    print (val)
                break

        self.vnid = val
        return val

    def findTag(self,sw, tag):
        if not "tags" in sw:
            return False
        mytags = sw['tags']

        for t in mytags:
            if t['tag'] == tag:
                return True

        return False


    def tag(self, tags, name=None,id=None, scope=None, display=False):
        switches = self.listInt(display=False)
        modsw = None
        for sw in switches:
            if id and sw['id'] == id:
                modsw = sw
                break
            elif name and sw['display_name'] == name:
                modsw = sw
                break
        if not modsw:
            print ("Logical switch couldn't be found")
            return


        if 'tags' in modsw:
            mytags = modsw['tags']
        else:
            mytags = []

        for t in tags:
            if self.findTag(sw=modsw,tag=t):
                print ("Tag '%s' already exist for switch %s, skipping." %(t,modsw['display_name']))
                continue
            else:
                newtag={}
                newtag['tag'] = t
                if scope:
                    newtag['scope'] = scope
                mytags.append(newtag)
        modsw['tags'] = mytags
        restUrl = '/api/v1/logical-switches/%s' %modsw['id']
        r = self.rest_api(api=restUrl,method='PUT',
                          data=modsw,display=display)
        if r.status_code != 200:
            raise ValueError("Failed to update switch with new tags: %d" %r.status_code)





    def getId(self, swname, display = False):
        switches = self.listInt(display=False)
        for sw in switches:
            if sw['display_name'] == swname:
                self.switch = sw['display_name']
                if display:
                    print (sw['id'])
                self.id = sw['id']
                self.data=sw
                return sw['id']

        return None

    def getPorts(self, swname=None, swId=None):
        if not swname and not swId:
            print ("Either switch name or port ID must be provided")
            return None

        if swname:
            useId = None
            swid = self.getId(swname=swname)
            if not swid:
                print ("Can't find switch id for switch: " + swname)
                return None
            if swId and swid != swId:
                print ("The provided switch ID does not match the retrieved id")
                print ("  Switch name: " + swname)
                print ("  Retrieved Id: " + swid)
                print ("   Provided Id: " + swId)
                return None
            else:
                useId = swid
        elif swId:
            swid = swId

        swport = SwitchPorts(mgr=self.mgr)
        swport.getPorts(switch=swid)
        self.ports = swport
        return swport

    def delZeroPorts(self, switchname= None, swid=None):
        if not swid and switchname:
            swid = self.getId(swname=switchname)

        if not swid:
            print ("Can't find switch to create port on")
            return None

        swport = SwitchPorts(mgr=self.mgr)
        swport.delZeroPorts(swid=swid)

    def deletePort(self,name,switchname=None,swid=None):
        if not swid and switchname:
            swid= self.getId(swname=switchname)
        swport=SwitchPorts(mgr=self.mgr)
        swport.delete(name=name,swid=swid)

    def delDownPorts(self,swid=None):
        swport=SwitchPorts(mgr=self.mgr)
        swport.delDownPorts(swid=swid)
    def delNotAttachedPorts(self,swid=None):
        swport=SwitchPorts(mgr=self.mgr)
        swport.delNotAttachedPorts(swid=swid)
    def delOperDownPorts(self,swid=None):
        swport=SwitchPorts(mgr=self.mgr)
        swport.delOperDownPorts(swid=swid)
    def createPort(self, switchname = None, swid=None, vif=None,
                   br=None, tn=None,display=True,name=None,unblocked=None):
        restUrl='/api/v1/logical-ports'

        if not swid and switchname:
            swid = self.getId(swname=switchname)

        if not swid:
           print ("Can't find switch to create port on id:name %s:%s"
                  %(swid,switchname))
           return None

        if (vif and br):
            print ("LS.createPort: cannot specify both VIF and BR")
            return None

        data = {}
        data['logical_switch_id'] = swid
        data['admin_state'] = 'UP'
        if name:
            data['display_name'] = name
        if tn:
            tnobjs=TransportNode(mgr=self.mgr)
            tno = tnobjs.findByName(name=tn, display=False)
            if not tno:
                print("TN %s not found." % tn)
                return None
            attach = {}
            attach['attachment_type'] = "VIF"
            if not vif:
                attach['id'] = str(uuid.uuid4())
            ctx={}
            ctx['transport_node_uuid'] = tno['id']
            ctx['resource_type'] = 'VifAttachmentContext'
            ctx['vif_type'] = 'INDEPENDENT'
            attach['context'] = ctx
            data['attachment'] = attach
        elif vif:
            attach = {}
            attach['attachment_type'] = "VIF"
            attach['id'] = vif
            data['attachment'] = attach
            if unblocked:
                data['init_state'] = 'UNBLOCKED_VLAN'
        elif br:
            attach = {}
            attach['attachment_type'] = "BRIDGEENDPOINT"
            attach['id'] = br['id']
            data['attachment'] = attach


        r = self.rest_api(api=restUrl, method="POST", data=data, convert=True)
        if r.status_code != 201:
            if display:
                print ("Did not get return code 201 on port create")
                print (r.text)
            return None

        result = json.loads(r.text)
        if display:
            print("Logical port: name, id: %s " %(result['display_name'], result['id']))
        return result['id']

class IPSubnet(Network_object):
    def __init__(self,mgr,cidr):
        super(self.__class__, self).__init__(mgr=mgr)
        self.address = cidr.split('/')
        if len(self.address) != 2:
            raise ValueError("IPSubnet: Invalid CIDR address: %s" %cidr)

        self.ip = self.address[0]
        self.mask = self.address[1]

    def getIp(self):
        return self.ip
    def getMask(self):
        return self.mask

    def getDict(self):
        data={}
        data['ip_addresses'] = [self.ip]
        data['prefix_length'] = self.mask
        return data

class RouteMap(Network_object):
    def __init__(self,mgr,rid):
        super(RouteMap,self).__init__(mgr=mgr)
        self.rid = rid
        self.listUrl = '/api/v1/logical-routers/%s/routing/route-maps' % rid


    def delete(self, name, display=False):
        rm = self.findByName(name=name,display=False)
        if not rm:
            print('Routemap %s not found' %name)
            return False

        restUrl = self.listUrl + ('/%s' % rm['id'])
        r = self.rest_api(api=restUrl,method='DELETE',display=display)
        if r.status_code != 200:
            print("Error in deleting routemap %s code: %d" %(name,r.status_code))
            print(r.text)
            return False
        return True

    def create(self, specList, name, description=None, tags=None):
        '''
        spec: <comma seperated prefixlistname>:as_pre:medis:weight:comm:action

        0 - prefixlist: names of prefix list
        1 - as_pre: as_path_prepend, comma seperated
        2 - medis: multi_exit_discriminator
        3 - weight: weight
        4 - comm: communit
        5 - action: PERMIT,DENY

        '''
        data={}
        data['display_name'] = name
        if description:
            data['description'] = description

        if tags:
            t = Tags(mgr=self.mgr)
            data['tags'] = t.createFromSpec(spec=tags)

        data['sequences'] = []

        for spec in specList:
            specs = spec.split(':')
            # prefixes
            specs[0] = specs[0].split(',')
            # as_path_prepend
            specs[1] = specs[1].split(',')

            sequence = {}

            prefixes=[]
            pxf = PrefixList(mgr=self.mgr,rid=self.rid)
            for p in specs[0]:
                if p =='':
                    continue
                prefix = pxf.findByName(name=p,display=False)
                if prefix:
                    prefixes.append(prefix['id'])
                else:
                    print("Error in routemap create, prefix %s not found." %p)
                    return False

            sequence['match_criteria'] = {}
            sequence['match_criteria']['ip_prefix_lists'] = prefixes

            aspre = None
            for a in specs[1]:
                if a=='':
                    continue
                if not aspre:
                    aspre = a
                else:
                    aspre+=(' %s'%a)
            if specs[2] != '':
                discrim = None
            else:
                discrim = specs[2]

            if specs[3] != '':
                weight = specs[3]
            else:
                weight = None


            if specs[4] != '':
                comm = specs[4]
            else:
                comm = None
            if aspre or discrim or weight or comm:
                sequence['set_criteria'] = {}
                if aspre:
                    sequence['set_criteria']['as_path_prepend'] = aspre
                if discrim:
                    sequence['set_criteria']['multi_exit_discriminator'] = discrim
                if weight:
                    sequence['set_criteria']['weight'] = weight
                if comm:
                    sequence['set_criteria']['add_community'] = comm

            sequence['action'] = specs[5]
            data['sequences'].append(sequence)
        r = self.rest_api(method='POST', api=self.listUrl,
                          data=data,display=False)
        if r.status_code != 200:
            print('Error in creating route-map: %s' % name)
            return False
        else:
            return True



class PrefixList(Network_object):
    def __init__(self,mgr,rid):
        super(PrefixList,self).__init__(mgr=mgr)
        self.listUrl = '/api/v1/logical-routers/%s/routing/ip-prefix-lists' %rid

    def __getLen(self, val):
        try:
            l = int(val)
        except:
            return 0

        if 1 <= l <= 32:
            return l
        else:
            return 0

    def __createPrefix(self, spec):
        '''
        spec: cidr:ge_val:leval:action
        example: 10.1.0.0/16:24:32:PERMIT
        the ge_val and le_val can be empty
        '''
        vals = spec.split(':')
        if len(vals) != 4:
            raise ValueError("IP prefixlist spec %s not valid" %spec)

        data={}
        data['action'] = vals[3]
        ge = self.__getLen(vals[2])
        le = self.__getLen(vals[1])
        if ge != 0:
            data['ge'] = ge
        if le != 0:
            data['le'] = le
        if vals[0].strip() != '':
            data['network'] = vals[0]

        return data

    def __createPrefixList(self,specList):
        data=[]
        for spec in specList:
            prefix = self.__createPrefix(spec=spec)
            data.append(prefix)
        return data

    def delete(self, name, display=False):
        pxf = self.findByName(name=name,display=False)
        if not pxf:
            print('Prefix %s not found' %name)
            return False

        restUrl = self.listUrl + ('/%s' % pxf['id'])
        r = self.rest_api(api=restUrl,method='DELETE',display=display)
        if r.status_code != 200:
            print("Error in deleting prefixlist %s code: %d" %(name,r.status_code))
            print(r.text)
            return False
        return True


    def create(self, name, prefixes,tags = None,
               description = None, display=False):
        data={}
        data['display_name'] = name
        if description:
            data['description'] = description
        if tags:
            t = Tags(mgr=self.mgr)
            data['tags'] = t.createFromSpec(spec=tags)
        if prefixes:
            data['prefixes'] = self.__createPrefixList(specList=prefixes)

        r = self.rest_api(method='POST',api=self.listUrl,
                          data=data,display=display)
        if r.status_code != 200:
            print("Error in creating prefix list: %s" %name)

    def update(self,name,prefixes=None,tags=None,
               description=None,display=False):
        pfl = self.findByName(name=name,display=False)
        if not pfl and display:
            print("Prefix list % s not found." %name)
            return False

        restUrl = self.listUrl + ('/%s' % pfl['id'])
        if tags:
            t=Tags(mgr=self.mgr)
            pfl['tags'] = t.createFromSpec(spec=tags)
        if prefixes:
            pfl['prefixes'] = self.__createPrefixList(specList=prefixes)

        if description:
            pfl['description'] = description

        r = self.rest_api(method='PUT',api=restUrl,
                          data=pfl,display=display)
        if r.status_code != 200:
            print("Error in updating PrefixList %s" %name)
            return False
        return True

    def convertToSpec(self, name, display=False):
        prefixList = self.findByName(name=name,display=False)
        if not prefixList and display:
            print("Prefix list %s not found." %name)
            return None
        specList = []
        for n in prefixList['prefixes']:
            spec=[]
            if 'network' in n:
                spec.append(n['network'])
            else:
                spec.append('')
            if 'ge' in n:
                spec.append(n['ge'])
            else:
                spec.append('')
            if 'le' in n:
                spec.append(n['le'])
            else:
                spec.append('')
            if 'action' in n:
                spec.append(n['action'])
            else:
                spec[3].append('')

            spec = ('%s:%s:%s:%s' %(spec[0],spec[1],spec[2],spec[3]))
            specList.append(spec)
        if display:
            for i in range(0,len(specList)):
                print(specList[i], end=' ')
            print('')
        return specList

    def prefixList(self, name, prefixes,tags = None,
               description = None, display=False):

        prefixList = self.findByName(name=name)
        if not prefixList and display:
            print("Prefix list %s not found." %name)
            return None


class DhcpRelayServices(Network_object):

    def __init__(self, mgr):
        super(self.__class__, self).__init__(mgr=mgr)
        self.listUrl='/api/v1/dhcp/relays'
    '''
    def list(self, display=True):                           # Services
        restUrl='/api/v1/services'

        r = self.rest_api(restUrl,method='GET')
        data=json.loads(r.text)
        if display:
            self.json_print(data=data,convert=False)

        return data['results']
    '''

    def find(self,name,display=True):
        return self.findByName(name=name,display=display)

    def configDhcpRelayService(self,name,profile,display=True):
        prof = self.findDhcpProfile(name=profile,display=False)
        if not prof:
            print ("DHCP Serice Profile not found: " + profile)
            return

        restUrl='/api/v1/dhcp/relays'

        data={}
        data['display_name'] = name
        data['dhcp_relay_profile_id'] = prof['id']
        data['resource_type'] = 'DhcpRelayService'

        r = self.rest_api(restUrl,data=data,method='POST',display=display)
        if r.status_code != 201:
            print ("Failed to create DHCP relay service: " +name)
            return


    def delete(self,name,display=True):
        svc = self.find(name=name,display=False)

        if not svc:
            print ("Service '%s' not found" %name)
            return

        restUrl = '/api/v1/dhcp/relays/' +  svc['id']
        r = self.rest_api(restUrl,method='DELETE',display=display)

        if r.status_code != 200:
            raise ValueError("Unsuccessful in deleting service: %d" %r.status_code)
        else:
            print ("Service %s deleted" %name)

    def createDhcpProfile(self,name,servers,display=True):
        restUrl = '/api/v1/dhcp/relay-profiles'
        if len(servers) == 0:
            print ("DHCP Servers list empty")
            return None

        data={}
        data['display_name'] = name
        data['server_addresses'] = servers
        data['resource_type'] = 'DhcpRelayProfile'

        r = self.rest_api(restUrl,data=data,method='POST',display=display)
        if r.status_code != 201:
            raise ValueError("Failed to create DHCP Relay Profile: %s" %name)

    def listDhcpProfile(self,display=True):
        return self.list(restUrl='/api/v1/dhcp/relay-profiles', display=display)


    def findDhcpProfile(self,name,display=True):
        dhcp = self.listDhcpProfile(display=False)

        for d in dhcp['results']:
            if d['display_name'] == name:
                if display:
                    self.json_print(data=d,convert=False)
                return d
        return None

    def deleteDhcpProfile(self,name,display=False):
        dhcp = self.findDhcpProfile(name=name,display=False)

        if not dhcp:
            print ("DHCP profile not found: " + name)
            return

        restUrl = '/api/v1/dhcp/relay-profiles/' + dhcp['id']
        r = self.rest_api(restUrl,method='DELETE',display=display)
        if r.status_code != 200:
            raise ValueError("Failed to delete DHCP profile: %s" %name)

class LogicalRouterPort(Network_object):
    def deletePort(self,name,display=True):
        lrp = self.findPort(target=name,display=False)
        if not lrp:
            if display:
                print ("Logical Router port not found for delete: %s" %name)
                return
        restUrl='/api/v1/logical-router-ports/'+lrp['id']
        r = self.rest_api(restUrl,method='DELETE',display=display)
        if r.status_code != 200:
            print ("Delete of logical router port %s with id %s not successful: %d"
                   %(name,lrp['id'],r.status_code))
        elif display:
            print ("Delete of LogicalRouter Port successful.  Name: %s, id:%s"
                   %(name,lrp['id']))

    def createRouterLink(self, tier0, tier1,
            tier0_cidr = None, tier1_cidr=None):

        restUrl='/api/v1/logical-router-ports'
        #
        # Self housekeeping to ensure we don't create links
        # with the same name, not an NSX limitation, but
        # good for our own sanity
        if self.findPort(target=tier0['display_name']+'_'+tier1['display_name'],
                         display=False):
            raise ValueError("createRouterLink: a pre-existing '%s' is found."
                             %(tier0['display_name']+'_'+tier1['display_name']))
        if self.findPort(target=tier1['display_name']+'_'+tier0['display_name'],
                         display=False):
            raise ValueError("createRouterLink: a pre-existing '%s' is found."
                             %(tier1['display_name']+'_'+tier0['display_name']))


        # tier0
        data={}
        data['display_name'] = tier0['display_name']+'_'+tier1['display_name']
        data['description'] = data['display_name'] + " Tier0Tier1 Router Link"
        data['logical_router_id'] = tier0['id']
        data['resource_type'] = 'LogicalRouterLinkPortOnTIER0'


        print ("Creating Tier0 LR port...")
        r = self.rest_api(restUrl,method='POST',data=data,display=True)
        if r.status_code != 201:
            raise ValueError("LogicalRouterPort: failed to create Tier0 LR port")

        tr0 = json.loads(r.text)

        #tier1
        data={}
        data['display_name'] = tier1['display_name']+'_'+tier0['display_name']
        data['description'] = data['display_name'] + " Tier1Tier0 Router Link"
        data['logical_router_id'] = tier1['id']
        data['resource_type'] = 'LogicalRouterLinkPortOnTIER1'
        data['edge_cluster_member_index'] = []
        if 'edge_cluster_id' in tier1:
            ecObj = EdgeCluster(mgr=self.mgr)
            ec = ecObj.findById(id=tier1['edge_cluster_id'],
                                restUrl='/api/v1/edge-clusters',display=False)
            if not ec:
                raise ValueError("Can't find edgecluster by ID: %s" %ecid)

            ecount=0
            for m in ec['members']:
                data['edge_cluster_member_index'].append(m['member_index'])
                ecount+=1
                if ecount == 2:
                    break


            del ecObj

        tr0id = {}
        tr0id['target_type'] = 'LogicalRouterLinkPortOnTIER0'
        tr0id['target_id'] = tr0['id']
        tr0id['target_display_name'] = tr0['display_name']
        data['linked_logical_router_port_id'] = tr0id

        print ("Creating Tier1 LR port...")
        r = self.rest_api(restUrl,method='POST',data=data,display=True)
        if r.status_code != 201:
            raise ValueError("LogicalRouterPort: failed to create Tier0 LR port")
        tr1 = json.loads(r.text)


        tr0['linked_logical_router_port_id'] = tr1['id']
        if tier0_cidr:
            ips = IPSubnet(mgr=self.mgr,cidr=tier0_cidr)
            ipsdict = ips.getDict()
            tr0['subnets'] = [ipsdict]
        else:
            if 'subnets' in tr0:
                del tr0['subnets']
        '''
        tr0id = {}
        tr0id['target_type'] = 'LogicalRouterLinkPortOnTIER0'
        tr0id['target_id'] = tr0['id']
        tr0id['target_display_name'] = tr0['display_name']

        tr1['linked_logical_router_port_id']=tr0id
        if tier1_cidr:
            ips = IPSubnet(mgr=self.mgr,cidr=tier0_cidr)
            ipsdict = ips.getDict()
            tr1['subnets'] = [ipsdict]
        else:
            if 'subnets' in tr1:
                del tr1['subnets']

        print ("PUT of Tier0 link to tie the Tier1")
        restUrl = '/api/v1/logical-router-ports/'+tr0['id']
        r = self.rest_api(api=restUrl, method='PUT',data=tr0,display=True)
        if r.status_code != 200:
            raiseValueError("LogicalRouterPort: failed to update Tier0 LR port")

        self.listPorts(display=True)

        print ("PUT of Tier1 link to tie the Tier1")
        restUrl = '/api/v1/logical-router-ports/'+tr1['id']
        r = self.rest_api(api=restUrl, method='PUT',data=tr1,display=True)
        if r.status_code != 200:
            raiseValueError("LogicalRouterPort: failed to update Tier0 LR port")
        self.listPorts(display=True)
        '''
    def createUplinkPort(self, name, edgecluster, edge, router,switch,cidr):
        '''
        Creates an uplink port...this covers only Tier0 for now
        '''

        ec = EdgeCluster(mgr=self.mgr)
        cluster = ec.find(name=edgecluster,display=False)
        if not cluster:
            raise ValueError("LogicalRouterPort.createUplinkPort: \
                    Edgecluster not found: %s" % edgecluster)

        edgeIndex = ec.getIndex(name=edgecluster, member_name=edge)
        if edgeIndex is None:
            raise ValueError("LogicalRouterPort.createUplinkPort: \
                    Edge %s not found in cluster: %s" %(edge,edgecluster))

        routers = LogicalRouter(mgr=self.mgr)
        lr = routers.find(name=router,display=False)
        if not lr:
            raise ValueError("LogicalRouterPort.createUplinkPort: \
                    Router %s not found" %router)



        sw = Switch(mgr=self.mgr)
        swport = sw.createPort(switchname=switch,name=name,display=False)
        if not swport:
            raise ValueError("LogicalRouterPort.createUplinkPort: \
                    Edge %s not found in cluster: %s" %(edge,edgecluster))

        ipsubnet = IPSubnet(mgr=self.mgr,cidr=cidr)
        subnet=ipsubnet.getDict()

        data = {}
        data['resource_type'] = 'LogicalRouterUpLinkPort'
        data['logical_router_id'] = lr['id']
        data['display_name'] = name
        data['description'] = router +" "+name
        data['edge_cluster_member_index'] = [edgeIndex]
        data['linked_logical_switch_port_id'] = {'target_id':swport}
        data['subnets'] = [subnet]

        restUrl = '/api/v1/logical-router-ports'
        r = self.rest_api(restUrl,method="POST",data=data)
        if r.status_code != 201:
            print ("ERROR: Failed to successfully post data, return code: \
                    %d" %r.status_code)
            print ("API: %s" %restUrl)
            print ("DATA:")
            self.json_print(data,convert=False)

    def createDownLinkPort(self,router,switch,cidr,services=None,display=True):
        lr = LogicalRouter(mgr=self.mgr)
        lrid = lr.find(name=router,display=False)
        if not lrid:
            print ("createDownLinkPort: Router not found: " + router)
            return None
        sw = Switch(mgr=self.mgr)
        swport = sw.createPort(switchname=switch,name=router+"_"+switch,
                               display=False)
        if not swport:
            print ("createDownLinkPort: Switch port create failed: %s_%s"
                   %(router,switch))
            return None

        swref = {}
        swref['target_id'] = swport

        svc = []
        if services:
            svcobj = DhcpRelayServices(mgr=self.mgr)
            for i in services:
                s = svcobj.find(name=i,display=False)
                if s:
                    sref = {}
                    sref['target_id'] = s['id']
                    sdata={}
                    sdata['service_id'] = sref
                    svc.append(sdata)
                else:
                    raise ValueError("CreateDownLinkPort: Service not found: %s"
                                     %i)
        subnet = IPSubnet(mgr=self.mgr, cidr=cidr)
        subdict = subnet.getDict()

        data={}
        data['display_name'] = router+'_'+switch
        data['description'] = cidr
        data['linked_logical_switch_port_id'] = swref
        data['logical_router_id'] = lrid['id']
        data['resource_type'] = 'LogicalRouterDownLinkPort'
        if len(svc) > 0:
            data['service_bindings'] = svc
        data['subnets'] = [subdict]

        restUrl = '/api/v1/logical-router-ports'

        r = self.rest_api(api=restUrl,method="POST", data=data,
                          convert=True,display=display)
        if r.status_code != 201:
            raise ValueError("CreateDownLinkPort: downlink port create failed: "
                             + router + '_' + switch)



    def listPorts(self,display=True):
        '''
        List all LR ports
        '''
        restUrl = '/api/v1/logical-router-ports'
        return self.list(restUrl=restUrl, display=display)

    def findPort(self,target,rid=None, display=True):
        '''
        Find a specific LR uplink port by name
        '''
        ports = self.listPorts(display=False)
        for p in ports['results']:
            if p['display_name'] == target:
                if rid:
                    if p['logical_router_id'] != rid:
                        continue
                if display:
                    self.json_print(data=p,convert=False)
                return p
        return None
    '''
    def deletePort(self,target,display=False):

        #Delete a port by name


        port = self.findPort(target=target,display=False)
        if not port:
            print("Port not found: %s" %target)
        else:
            restUrl='/api/v1/logical-router-ports/%s' %port['id']
            r = self.rest_api(restUrl,method="DELETE")

    '''


class LogicalRouter(Network_object):
    resType = 'LogicalRouter'
    api = {
        'list':      Api('get',    '/api/v1/logical-routers'),
        'update':    Api('put',   '"/api/v1/logical-routers/%s"%objId'),
    }
    #"extTransitNet": .advanced_config.external_transit_networks,
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "name": .display_name,
                "id":   .id,
                "type": .router_type,
                "intTransitNet": .advanced_config.internal_transit_network,
                "extTransitNet": (if .advanced_config.external_transit_networks
                    then (.advanced_config.external_transit_networks | join(",")) else "" end),
                "tags":  (if .tags then [.tags[]|.scope+":"+.tag]|sort|join(", ") else "" end),
            }'''),
    }
    #            "fwSections": ([.firewall_sections[] | .target_id] | join("\n")),

    def __init__(self,mgr):
        super(LogicalRouter,self).__init__(mgr=mgr)
        self.listUrl = '/api/v1/logical-routers'

    def routerList(self,display=True,table=False):
        restUrl = '/api/v1/logical-routers'
        #r = self.rest_api(restUrl,method="GET")
        data = self.list(display=False)
        #data = json.loads(r.text)
        if display:
            if table:
                ptbl = PrettyTable(['Name', 'ID', 'rType', 'Type', 'intTransNet', 'extTransNet'])
                for r in data['results']:
                    extTransNets = \
                        ','.join(r['advanced_config']['external_transit_networks']) \
                            if 'external_transit_networks' in r['advanced_config'] else ''
                    ptbl.add_row([r['display_name'], r['id'], r['resource_type'],
                        r['router_type'], r['advanced_config']['internal_transit_network'],
                        extTransNets])
                print(ptbl)
                del ptbl
            else:
                self.json_print(data=data, convert=False)
        return data

    def find(self,name,display=True):
        return self.findByName(name=name,display=display)

        #clean up the rest later
        data = self.routerList(display=False)
        for i in data['results']:
            if i['display_name'] == name:
                if display:
                    self.json_print(data=i,convert=False)
                return i
        return None

    def listRouteMap(self,router,display=True, name=None, brief=False):
        t0 = self.findByName(name=router,display=False)
        if not t0:
            print("Router %s not found" % router)
            return
        rms=[]
        rm = RouteMap(mgr=self.mgr, rid=t0['id'])
        if not brief:
            rms = rm.list(display=display)
        else:
            rms=rm.list(display=False)
            for i in rms['results']:
                print("Name: %s  ID: %s" %(i['display_name'],i['id']))

        return rms
    '''
    def findRouteMap(self,router,name, display=True):
        t0 = self.find(name=router,display=False)
        if not t0:
            print("Router %s not found" %router)
            return None
        rm = RouteMap(mgr=self.mgr,rid=t0['id'])
        rms = rm.list(display=False)
        for i in rms['results']:
            if i['display_name'] == name:
                if display:
                    self.json_print(data=i,convert=False)
                return i
        return None
    '''

    def deleteRouteMap(self,router,name,display=False):
        t0 = self.find(name=router,display=False)
        if not t0:
            print("Router %s not found" % router)
            return False
        rm = RouteMap(mgr=self.mgr, rid=t0['id'])
        return rm.delete(name=name,display=display)


    def createRouteMap(self,router,name,specList,
                       description=None,tags=None):
        '''
        specList: colon seperated fields
        0 - comma seperated prefixlist
        1 - comma seperated list of as_prepend
        2 - multi exit discriminator
        3 - weight
        4 - community
        5 - action
        '''
        t0 = self.find(name=router,display=False)
        if not t0:
            print("Router %s not found" % router)
            return
        rm = RouteMap(mgr=self.mgr, rid=t0['id'])
        rm.create(specList=specList, name=name,
                  description=description, tags=tags)

    def listPrefixList(self,router,display=True, name=None, brief=False):
        t0 = self.find(name=router,display=False)
        pxf = PrefixList(mgr=self.mgr, rid=t0['id'])
        #print(pxf.listUrl)
        if not brief:
            pxf.list(display=True)
        else:
            if name:
                pxf.converToSpec(name=name,display=True)
            else:
                data = pxf.list(display=False)
                for p in data['results']:
                    if 'display_name' in p:
                        pxf.convertToSpec(name=p['display_name']
                                          ,display=True)

    def deletePrefixList(self,router,name,display=False):

        t0 = self.find(name=router,display=False)
        if not t0:
            print("Router %s not found" % router)
            return False
        pxf = PrefixList(mgr=self.mgr, rid=t0['id'])
        return pxf.delete(name=name,display=display)

    def createPrefixList(self,router,name,
                         spec,
                         description=None,
                         tags=None,
                         display=False):

        t0 = self.find(name=router,display=False)
        if not t0 or t0['router_type'] != "TIER0":
            print("Router %s not found, or not Tier0" %router)
            return

        prefixlist = PrefixList(mgr=self.mgr, rid=t0['id'])
        prefixlist.create(name=name,prefixes=spec,tags=tags,
                          description=description, display=display)

    def updatePrefixList(self,router,name,
                         spec,
                         description=None,
                         tags=None,
                         display=False):

        t0 = self.find(name=router,display=False)
        if not t0 or t0['router_type'] != "TIER0":
            print("Router %s not found, or not Tier0" %router)
            return

        prefixlist = PrefixList(mgr=self.mgr, rid=t0['id'])
        prefixlist.update(name=name,prefixes=spec,tags=tags,
                          description=description, display=display)


    def config(self,name,tier,edgecluster=None,
            tier0=None,ha="ACTIVE_ACTIVE",display=False):

        if self.find(name=name,display=False):
            print ("Logical router with name already exist: %s" %name)
            return

        data={}
        data['display_name'] = name
        data['description'] = name + " " + str(tier)
        if tier == 0 and edgecluster == None:
            print ("Tier 0 LR requires an Edge Cluster")
            return

        if edgecluster:
            ecl = EdgeCluster(mgr=self.mgr)
            ec = ecl.find(name=edgecluster,display=False)
            if not ec:
                print ("Edge Cluster not found: %s" %edgecluster)
                return
            data['edge_cluster_id'] = ec['id']

        lr = None
        if tier == 0:
            data['router_type'] = 'TIER0'
        elif tier==1:
            data['router_type'] = 'TIER1'
        else:
            raise ValueError("Unknown LR tier type: %d" %tier)

        if tier == 0:
            data['high_availability_mode'] = ha

        # Create the LR
        restUrl='/api/v1/logical-routers'
        r = self.rest_api(restUrl,method='POST',data=data,display=display)
        if r.status_code != 201:
            raise ValueError("Failed to create LR %s: %d" %(name,r.status_code))

        # Connect the Tier1 and Tier0 if specified
        # Note that we are not allowing the specification of routelink IPs here
        #  ....same as default behavior in UI
        if tier==1:
            if not tier0:
                print ("Tier0 router not specified for new Tier1, not proceeding \
                with routerlink")
                return
            t0 = self.find(name=tier0,display=False)
            if not t0:
                print ("Tier0 %s not found, not proceeding with routerlink" %tier0)
                return
            lr1 = json.loads(r.text)

            self.createRouterLink(t0,lr1)

    def deleteRouter(self,name,display=False):
        lr = self.find(name=name, display=False)
        if not lr:
            print("deleteRouter: Logical router not found: %s" %name)
            return False
        restUrl = '/api/v1/logical-routers/%s?force=True' % lr['id']

        r = self.rest_api(api=restUrl,method="DELETE",display=False)
        if r.status_code == 200:
            print ("Delete Logical router succeeded. name: %s id: %s"
                   %(name, lr['id']))
            return True
        else:
            print ("Delete Logical router failed, result code: %s" %r.status_code)
            print (r.text)
            return False


    def createRouterLink(self, tier0, tier1,
            tier0_cidr = None, tier1_cidr=None):
        lrp = LogicalRouterPort(mgr=self.mgr)
        lrp.createRouterLink(tier0 = tier0, tier1=tier1,
                             tier0_cidr=tier0_cidr, tier1_cidr=tier1_cidr)

    def getBgp(self,router,display=True):
        lr = self.find(name=router,display=False)
        if not lr:
            print ("Router not found: %s" %router)
            return None

        restUrl = '/api/v1/logical-routers/%s/routing/bgp' %lr['id']
        r = self.rest_api(restUrl,method='GET')
        if display:
            self.json_print(r.text,convert=True)
        return json.loads(r.text)

    def updateBgp(self,router,localas=None, status=None, ecmp=None,gr=None,
            display=False):
        '''
        Updates the global BGP configuration of a router
        '''

        lr=self.find(name=router,display=False)
        if not lr:
            print ("Router not found: %s" %router)
            return None


        cfg = self.getBgp(router=router,display=False)
        if not cfg:
            print ("BGP configuration not found for router: %s" %router)
            return None

        if localas is not None:
            cfg['as_number'] = localas
        if status is not None:
            cfg['enabled'] = str(status)
        if ecmp is not None:
            cfg['ecmp']=ecmp
        if gr is not None:
            cfg['graceful_restart'] = gr
        restUrl = '/api/v1/logical-routers/%s/routing/bgp' %lr['id']
        r = self.rest_api(restUrl,method='PUT',data=cfg,display=display)
        if r.status_code != 200:
            raise ValueError("Updating BGP config on LR %s failed: %d"
                    %(router,r.status_code))
        if display:
            self.json_print(r.text,convert=True)

    def getBfd(self,router,display=True):
        lr = self.find(name=router,display=False)
        if not lr:
            print ("configureBfd: Can't find logical router: %s" %router)
            return False
        restUrl='/api/v1/logical-routers/%s/routing/bfd-config' % lr['id']
        r = self.rest_api(api=restUrl,method="GET",display=True)
        if display:
            self.json_print(data=r.text,convert=True)
        return json.loads(r.text)

    def configureBfd(self,router, rx=1000, tx=1000, multi=3, enable=True):
        lr = self.find(name=router,display=False)
        if not lr:
            print ("configureBfd: Can't find logical router: %s" %router)
            return False
        data=self.getBfd(router=router,display=False)
        data['declare_dead_multiple'] = multi
        data['receive_interval'] = rx
        data['transmit_interval'] = tx
        if enable:
            data['enabled'] = 'True'
        else:
            data['enabled'] = 'False'
        restUrl='/api/v1/logical-routers/%s/routing/bfd-config' % lr['id']
        r = self.rest_api(api=restUrl,data=data,method="PUT", display=False)
        if r.status_code == 200:
            print("BGP configured successfuly on router %s" % router)
            return True
        else:
            print("BGP not configured successfully on router %s, code: %s"
                  %(router,r.status_code))
            return False


    def createBgpNeighbor(self,router,localip,peer,remoteas,secret=None,
            keepalive=60,holdtimer=180,display=False):
        '''
        '/api/v1/logical-routers/<logical-router-id>/routing/bgp/neighbors'
        '''

        lr = self.find(name=router,display=False)
        if not lr:
            raise ValueError('Router not found: %s' %router)

        data={}
        data['display_name'] = peer
        data['neighbor_address'] = peer
        data['remote_as'] = remoteas
        data['keep_alive_timer'] = keepalive
        data['hold_down_timer'] = holdtimer
        if localip:

            data['source_addresses'] = localip
        if secret:
            data['password'] = secret

        restUrl = '/api/v1/logical-routers/'+lr['id']+'/routing/bgp/neighbors'
        r = self.rest_api(restUrl,method="POST",data=data,display=display)
        if r.status_code != 200:
            print ("ERROR: createBgpNeigbhor, return code not 200: %d" \
                %r.status_code)
            print ("REST API: %s" %restUrl)
            print ("POST DATA")
            self.json_print(data=data,convert=False)

    def configureBgpRouteMap(self,router,neighbor,inbound=None,outbound=None,
                             ip='IPV4_UNICAST'):
        lr = self.find(name=router,display=False)
        if not lr:
            print("Router not found: %s" %router)
            return False

        restUrl='/api/v1/logical-routers/%s/routing/bgp/neighbors' % lr['id']
        nb = self.findByName(name=neighbor, restUrl=restUrl, display=False)

        if not nb:
            print("Neighbor %s not found on router %s" %(neighbor,router))
            return False

        if inbound:
            inmap=self.findRouteMap(router=router,name=inbound, display=False)
            if not inmap:
                print("inbound map not found: %s" %inbound)
                return
        else:
            inmap=None
        if outbound:
            outmap=self.findRouteMap(router=router,name=outbound, display=False)
            if not outmap:
                print("outbound map not found: %s" %outbound)
                return
        else:
            outmap=None

        for n in nb['address_families']:
            if n['type'] == ip:
                if inmap:
                    n['in_filter_routemap_id'] = inmap['id']
                if outmap:
                    n['out_filter_routemap_id'] = outmap['id']

        restUrl='/api/v1/logical-routers/%s/routing/bgp/neighbors/%s' % \
            (lr['id'],nb['id'])
        r = self.rest_api(api=restUrl,data=nb, method="PUT",display = False)
        if r.status_code == 200:
            print("BGP neighbor %s on router %s updated with routemap" %(neighbor,router))
            return True
        else:
            print("BGP neighbor %s on router %s not updated for routemap, code: %s"
                  %(neighbor,router,r.status_code))
            return False


    def configureBgpBfd(self,router,neighbor, enable,
                        rx=1000, tx=1000, multi=3):
        lr = self.find(name=router,display=False)
        if not lr:
            print("Router not found: %s" %router)
            return False

        restUrl='/api/v1/logical-routers/%s/routing/bgp/neighbors' % lr['id']
        nb = self.findByName(name=neighbor, restUrl=restUrl, display=False)


        if not nb:
            print("Neighbor %s not found on router %s" %(neighbor,router))
            return False

        bfd={}
        bfd['receive_interval'] = rx
        bfd['transmit_interval'] = tx
        bfd['declare_dead_multiple'] = multi
        nb['bfd_config'] = bfd
        if enable:
            nb['enable_bfd'] = 'True'
        else:
            nb['enable_bfd'] = 'False'

        restUrl='/api/v1/logical-routers/%s/routing/bgp/neighbors/%s' % \
            (lr['id'],nb['id'])
        r = self.rest_api(api=restUrl,data=nb, method="PUT",display = False)
        if r.status_code == 200:
            print("BGP neighbor %s on router %s updated" %(neighbor,router))
            return True
        else:
            print("BGP neighbor %s on router %s not updated, code: %s"
                  %(neighbor,router,r.status_code))
            return False


    def listBgpNeighbor(self, router, display=True, table=False):
        '''
        List all BGP Neighbors
        '''

        lr = self.findByName(name=router,display=False)
        if not lr:
            raise ValueError('Router not found: %s' %router)

        if lr['router_type'] != 'TIER0':
            print("Router %s is not Tier0, skipping" %router)
            return

        restUrl = '/api/v1/logical-routers/%s/routing/bgp/neighbors' % lr['id']
        try:
            r = self.rest_api(restUrl,method="GET")
        except Exception as e:
            print(e)
            return None
        data = json.loads(r.text)
        if display:
            if table:
                ptbl = PrettyTable(['Name', 'source', 'neighbor', 'hold_down', 'remote_as', 'id'])
                for r in data['results']:
                    ptbl.add_row([r['display_name'], ', '.join(r['source_addresses']),
                        r['neighbor_address'], r['hold_down_timer'],
                        r['remote_as'], r['id']])
                print('BGP neighbors for logical router %s(%s):' % (router, lr['id']))
                print(ptbl)
                print('%d entries' % data['result_count'])
                del ptbl
            else:
                self.json_print(data=data, convert=False)
        return data

    def getRedistributionRules(self,name,display=True):
        lr = self.find(name=name,display=False)
        if not lr:
            print("ERROR: getRedistributionRules: router not found - %s" %name)
            return
        restUrl='/api/v1/logical-routers/%s/routing/redistribution/rules' \
            %lr['id']
        r = self.rest_api(restUrl,method='GET')
        data=json.loads(r.text)
        if display:
            self.json_print(data=data,convert=False)
        return data


    '''
    def listRouteMap(self,router,display=True):
        lr=self.find(name=router,display=False)
        restUrl='/api/v1/logical-routers/%s/routing/route-maps' %lr['id']

        r = self.rest_api(restUrl,method='GET')
        data=json.loads(r.text)
        if display:
            self.json_print(data=data,convert=False)
            return data['results']
    '''

    def findRouteMap(self,router,name,display=True):
        rm = self.listRouteMap(router=router,display=False)
        if not 'results' in rm:
            return None
        for i in rm['results']:
            if i['display_name'] == name:
                if display:
                    self.json_print(data=i,convert=False)
                return i
        return None


    def updateRedistributionRules(self,router,
                                  enable,
                                  sources,
                                  name=None,
                                  desc=None,
                                  dest='BGP',
                                  add=False,
                                  routemap=None,
                                  display=True):
        # if add is true, then create new rule and appended
        # if add is false, this is the only rule


        if enable:
            self.updateRedistribution(name=router,enable=enable,display=display)
        if not sources:
            return

        lr = self.find(name=router,display=False)
        if not lr:
            print("ERROR: UpdateRedistribution: router not found - %s" %name)
            return

        redist = self.getRedistributionRules(name=router,display=False)
        if not redist:
            raise ValueError("ERROR: UpdateRedistributionRules: - %s" %name)
            return

        rules = redist['rules']

        newRule={}
        if name:
            newRule['display_name'] = name
        if desc:
            newRule['description'] = desc
        newRule['destination'] = dest
        if routemap:
            rm = self.findRouteMap(router=router,name=routemap,display=False)
            if not rm:
                print ("ERROR: updateRedistributionRules-routemap not found: "+
                       routemap)
                return
            newRule['route_map_id'] = routemap['id']

        newRule['sources'] = []
        for i in sources:
            if i == 'static':
                newRule['sources'].append('STATIC')
            elif i == 'nsxcon':
                newRule['sources'].append('NSX_CONNECTED')
            elif i == 'nsxstatic':
                newRule['sources'].append('NSX_STATIC')
            elif i == 'nat0':
                newRule['sources'].append('TIER0_NAT')
            elif i == 'nat1':
                newRule['sources'].append('TIER1_NAT')
            elif i == 'lbvip1':
                newRule['sources'].append('TIER1_LB_VIP')
            elif i == 'lbnat1':
                newRule['sources'].append('TIER1_LB_SNAT')

        if add:
            rules.append(newRule)
        else:
            redist['rules'] = [newRule]

        restUrl='/api/v1/logical-routers/%s/routing/redistribution/rules' %lr['id']
        r = self.rest_api(restUrl,method='PUT', data=redist, display=display)
        if r.status_code != 200:
            raise ValueError("ERROR: updateRedistributionRules: %s" %name)

    def getRedistribution(self,name,rules=True,display=True):
        lr = self.find(name=name,display=False)
        if not lr:
            print("ERROR: getRedistribution: router not found - %s" %name)
            return
        restUrl='/api/v1/logical-routers/%s/routing/redistribution' %lr['id']
        r = self.rest_api(restUrl,method='GET')
        data=json.loads(r.text)
        if display:
            print ("Status:")
            self.json_print(data=data,convert=False)
        if display and rules:
            print ("Rules:")
            self.getRedistributionRules(name=name,display=display)
        return data

    def updateRedistribution(self,name,enable,display):
        redist = self.getRedistribution(name=name,rules=False,display=False)
        if not redist:
            print("ERROR: updateRedistribution: router not found - %s" %name)
            return
        lr = self.find(name=name,display=False)
        restUrl='/api/v1/logical-routers/%s/routing/redistribution' %lr['id']


        if enable=='yes':
            redist['bgp_enabled'] = 'True'
        else:
            redist['bgp_enabled'] = 'False'

        r = self.rest_api(restUrl,method='PUT',data=redist,display=display)
        if r.status_code != 200:
            print ("ERROR: updateRedistribution failed: %d" %r.status_code)


    def getAdvertisement(self,name, display=True):
        lr = self.find(name=name,display=False)
        if not lr:
            print("ERROR: getAdvertisement: router not found - %s" %name)
            return

        restUrl='/api/v1/logical-routers/%s/routing/advertisement' %lr['id']
        r = self.rest_api(restUrl,method="GET")
        data = json.loads(r.text)
        if display:
            self.json_print(data=data,convert=False)
        return data

    def updateAdvertisement(self, name, enable=None, nsx=None,
                            static=None, nat=None, lbsnat=None, lbvip=None,
                            display=False):

        adv = self.getAdvertisement(name=name,display=False)
        if not adv:
            print("ERROR: updateAdvertisement: router not found - %s" %name)
            return

        if enable:
            if enable=='yes':
                adv['enabled'] = 'True'
            else:
                adv['enabled'] = 'False'
        if nsx:
            if nsx=='yes':
                adv['advertise_nsx_connected_routes'] = 'True'
            else:
                adv['advertise_nsx_connected_routes'] = 'False'
        if static:
            if static=='yes':
                adv['advertise_static_routes'] = 'True'
            else:
                adv['advertise_static_routes'] = 'False'

        if nat:
            if nat=='yes':
                adv['advertise_nat_routes'] = 'True'
            else:
                adv['advertise_nat_routes'] = 'False'
        if lbvip:
            if lbvip=='yes':
                adv['advertise_lb_vip'] = 'True'
            else:
                adv['advertise_lb_vip'] = 'False'
        if lbsnat:
            if lbsnat=='yes':
                adv['advertise_lb_snat_ip'] = 'True'
            else:
                adv['advertise_lb_snat_ip'] = 'False'

        lr = self.find(name=name)
        restUrl = '/api/v1/logical-routers/%s/routing/advertisement' %lr['id']
        r = self.rest_api(restUrl,method='PUT',data=adv,display=display)
        if r.status_code != 200:
            print ("ERROR: updateAdvertisement failed: %d" %r.status_code)

    def addHaVip(self, name, cidr, uplink1, uplink2, enabled='True', display=True):
        lr = self.find(name=name, display=False)
        if not lr:
            raise ValueError("addHaVip: can't find router %s" %name)

        ipsubnet = IPSubnet(mgr=self.mgr, cidr=cidr)
        vipsubnet = {}
        vipsubnet['active_vip_addresses'] = [ipsubnet.getIp()]
        vipsubnet['prefix_length'] = ipsubnet.getMask()
        vipconfig = {}
        vipconfig['enabled'] = enabled
        vipconfig['ha_vip_subnets'] = [vipsubnet]

        lrp = LogicalRouterPort(mgr=self.mgr)
        link1 = lrp.findPort(target=uplink1,rid=lr['id'], display=False)
        link2 = lrp.findPort(target=uplink2,rid=lr['id'], display=False)
        if not link1 or not link2:
            raise ValueError("addHaVip: uplink not found")

        vipconfig['redundant_uplink_port_ids'] = [link1['id'], link2['id']]

        advcfg = lr['advanced_config']
        advcfg['ha_vip_configs'] = [vipconfig]

        data=lr
        data['advanced_config'] = advcfg

        restUrl='/api/v1/logical-routers/%s' %lr['id']
        r=self.rest_api(api=restUrl,method='PUT',data=data, convert=True,
                        display=display)

    def addStaticRoute(self, router, cidr, nexthop, display=True):
        lr = self.find(name=router, display=False)
        if not lr:
            raise ValueError("addHaVip: can't find router %s" %router)

        sr = {}
        sr['description'] = cidr
        sr['display_name'] = cidr
        sr['logical_router_id'] = lr['id']
        sr['network'] = cidr
        hop = {}
        if nexthop == 'NULL':
            hop['blackhole_action'] = 'DISCARD'
        else:
            hop['ip_address'] = nexthop
        sr['next_hops'] = [hop]

        restUrl = '/api/v1/logical-routers/%s/routing/static-routes' %lr['id']
        r = self.rest_api(restUrl,method="POST", data=sr,
                          convert=True, display=display)

    def getStaticRoutes(self,router,display=True):
        lr = self.find(name=router, display=False)
        if not lr:
            raise ValueError("getStaticRoutes: can't find router %s" %router)


        restUrl = '/api/v1/logical-routers/%s/routing/static-routes' %lr['id']
        r = self.rest_api(restUrl,method="GET", display=False)
        data= json.loads(r.text)
        print ("Router: %s\nid: %s" %(lr['display_name'], lr['id']))
        print ("Total Static routes: %d" %data['result_count'])
        routefmt = '{:>19} {:<11}'
        print ('{:>19} {:<11}'.format('Route', 'NextHop'))
        print ('------------------- -----------')
        for i in data['results']:
            first = True
            for h in i['next_hops']:
                if 'blackhole_action' in h:
                    val = 'NULL'
                else:
                    val = h['ip_address']
                if first:
                    print (routefmt.format(i['network'],
                                           val))
                else:
                    print (routefmt.format(' ', val))
                first = False

    def delStaticRoute(self,router, cidr, nexthop, display=True):
        lr = self.find(name=router, display=False)
        if not lr:
            raise ValueError("delStaticRoute: can't find router %s" %router)


        restUrl = '/api/v1/logical-routers/%s/routing/static-routes' %lr['id']
        r = self.rest_api(restUrl,method="GET", display=False)
        data= json.loads(r.text)

        routeId=None
        for i in data['results']:
            if i['network'] == cidr:
                for h in i['next_hops']:
                    if nexthop == 'NULL':
                        if 'blackhole_action' in h:
                            if h['blackhole_action'] == 'DISCARD':
                                break

                    elif h['ip_address'] == nexthop:
                        routeId = i['id']
                        break

                if routeId:
                    break

        if not routeId:
            print ("Route %s with next hop of %s not found on LR %s"
                   %(cidr, nexthop, router))
            return

        restUrl = ('/api/v1/logical-routers/%s/routing/static-routes/%s'
                   %(lr['id'], routeId))
        r = self.rest_api(restUrl,method='DELETE')


    def addNatRule(self, router, action, name=None,tags=None,
               match=None, source=None, dest=None,
               passfw=True,priority=1024, translated_network=None,
               translated_port=None, enable=True, log=False, desc=None):


        lr = self.find(name=router,display=False)
        if not lr:
            raise ValueError("addNat: can't find router ''%s'" %router)
        restUrl='/api/v1/logical-routers/%s/nat/rules' %lr['id']
        data={}
        if name:
            data['display_name'] = name
        if desc:
            data['description'] == desc
        data['action'] = action
        data['resource_type'] = 'NatRule'
        data['enabled'] = enable
        data['logging'] = log
        data['nat_pass'] = passfw
        data['rule_priority'] = priority
        if tags:
            t=Tags(mgr=self.mgr)
            data['tags'] = t.createFromSpec(spec=tags)

        if match:
            mdata={}
            spec=match.split(':')
            service = spec[0].strip().lower()
            ### not supporteD!
            # 'alg':alg_proto:source_port,source_port2:dest_port
            #  0       1       2        3
            # dest_port must be one element array
            #if spec[0].lower() == 'alg':
            #    if spec[1].strip().upper() in ['ORACLE_TNS', 'FTP',
            #                           'SUN_RPC_TCP', 'SUN RPC_UDP',
            #                           'MS_RPC_TCP', 'MS_RPC_UDP',
            #                           'NBNS_BROADCAST',
            #                           'NBDG_BROADCAST', 'TFTP']:
            #        mdata['alg'] = spec[1].strip().upper()
            #        mdata['resource_type'] = 'ALGTypeNSService'
            #        if spec[3].strip() != '':
            #            mdata['destination_ports'] = [spec[2]]
            #        if spec[2].strip() != '':
            #            mdata['source_ports'] = spec[2].split(',')
            #
            #    else:
            #        print("Alg type %s not supported" %spec[1])
            #        return False

            if service == 'ip':
                # 'ip':protonum
                mdata['resource_type'] = 'IPProtocolNSService'
                mdata['protocol_number'] = spec[1].strip()

            elif service == 'icmp':
                # 'icmp':ICMPv4|ICMPv6":icmp code:icmp type
                #   0       1             2            3
                mdata['resource_type'] = "ICMPTypeNSService"
                if spec[1].strip().lower() == 'icmpv4':
                    mdata['protocol'] = 'ICMPv4'
                elif spec[1].strip().lower() == 'icmpv6':
                    mdata['protocol'] == 'ICMPv6'
                else:
                    print("ICMP protocol of '%s' not supported" %spec[1])
                    return False
                if spec[2].strip() != '':
                    mdata['icmp_code'] = spec[2].strip()
                if spec[3].strip() != '':
                    mdata['icmp_type'] == spec[3].strip()

            elif service == 'l4':
                # 'l4':tcp|udp:source ports:dest ports
                #   0    1          2            3
                mdata['resource_type'] = 'L4PortSetNSService'
                if spec[1].strip().lower() == 'tcp':
                    mdata['4_protocol'] = 'TCP'
                elif spec[1].strip().lower() == 'udp':
                    mdata['4_protocol'] = 'UDP'
                if spec[2].strip() != '':
                    mdata['source_ports'] = spec[2].split(':')
                if spec[3].strip() != '':
                    mdata['destination_ports'] = spec[3].split(':')
            else:
                print("Match type of %s is not supported" %spec[0])
                return False

            data['match_service'] = mdata


        if action == 'SNAT':
            if not translated_network:
                print("SNAT must have translated_network specified")
                return False
            data['translated_network'] = translated_network
            if source:
                data['match_source_network'] = source
            if dest:
                data['match_destination_network'] = dest

        elif action == 'DNAT':
            if not translated_network:
                print("DNAT must have translation destination ip/ip range/cidr")
                return False
            else:
                data['translated_network'] = translated_network
            if not dest:
                print("DNAT must have match destination ip/ip range/cidr")
                return False
            else:
                data['match_destination_nework'] = dest
            if source:
                data['match_source_network'] = source
            if traslated_port:
                data[translated_ports] = translated_port

        elif action == 'NO_SNAT':
            if not source:
                print("NO_SNAT must specific a matching source ip/range/cidr")
                return False
            else:
                data['match_source_network']=source
            if dest:
                data['match_destination_network']=dest

        elif action == 'NO_DNAT':
            if not dest:
                print("NO_DNAT must have match destination ip/ip range/cidr")
                return False
            else:
                data['match_destination_nework'] = dest
            if source:
                data['match_source_network'] = source
        elif action == 'REFLEXIVE':
            print("Reflexive NAT not implemented yet")
            return False


        r = self.rest_api(api=restUrl,method="POST", data=data, display=True)
        if r.status_code != 201:
            print("NAT rule create failed with code %d to router %s"
                  %(r.status_code, router))
            return False
        else:
            return True




class EdgeCluster(Network_object):
    resType = "EdgeCluster"
    api = {
        'list':     Api('get',     '/api/v1/edge-clusters'),
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "name": .display_name,
                "id":   .id,
                "members": ([.members[]|.transport_node_id]|join(",\n"))
            }'''),
    }

    def selflist(self,display=True):
        restUrl = '/api/v1/edge-clusters'
        return self.list(restUrl=restUrl,display=display)
        r = self.rest_api(restUrl,method="GET")
        data = json.loads(r.text)
        if display:
            self.json_print(data=data, convert=False)
        return data

    def config(self,name,members=None):
        data={}
        data['display_name'] = name
        data['description'] = name + ' edgecluster'
        if members:
            if type(members) != list:
                print ("Members must be a list")
                return

            cmembers=[]
            tnlist = TransportNode(mgr=self.mgr,fill=False)
            for i in members:
                tn = tnlist.find(name=i, display=False)
                if not tn:
                    raise ValueError("Edge TN not found: %s" %i)
                edge={}
                edge['transport_node_id'] = tn['id']
                cmembers.append(edge)
            if len(cmembers) > 0:
                data['members'] = cmembers

        restUrl='/api/v1/edge-clusters'
        r = self.rest_api(restUrl,method="POST",data=data)
        if r.status_code != 201:
            raise ValueError("Failed to create edge cluster: %s, code: %d"
                    %(name,r.status_code))

    def delete(self,name,display=False):
        ec = self.find(name=name,display=False)
        if not ec:
            print("EdgeCluster delete can't find cluster: %s" %name)
            return False
        restUrl = '/api/v1/edge-clusters/%s' %ec['id']
        r = self.rest_api(api=restUrl,method="DELETE")
        if r.status_code == 200:
            print ("Delete edge cluster successful.  name: %s id: %s" %
                   (name,ec['id']))
            return True
        else:
            print ("Delete edge cluster failed: name: %s id: %s, code:%s" %
                   (name, ec['id'],r.status_code))
            print (r.text)
            return False


    def find(self,name,display=True):
        return self.findByName(name=name,restUrl='/api/v1/edge-clusters',
                               display=display)

    def getIndex(self,name,member_name=None,member_id=None):
        '''
        Member name takes precedence over member_id
        '''
        cluster = self.find(name=name,display=False)
        if not cluster:
            print ("Edge cluster not found: %s" %name)
            return None

        if member_name and not member_id:
            tnlist = TransportNode(mgr=self.mgr,fill=False)
            tn  = tnlist.find(name=member_name,display=False)
            if not tn:
                print ("Edge not not found: %s" %member_name)
                return None
            member_id = tn['id']

        if not member_id:
            print ("Edge name or ID must be provied")
            return None

        for i in cluster['members']:
            if i['transport_node_id'] == member_id:
                return i['member_index']
        print ("No member found in edge cluster")
        return None


class EsxiHost(Network_object):
    api = {
        'list':      Api('get',     '/api/v1/fabric/nodes?resource_type=HostNode'),
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "name":       .display_name,
                "id":         .id,
                "type":       .resource_type,
                "OS":          (.os_type+" "+.os_version),
                "deployType":  (.deployment_type // ""),
                "IPaddresses": .ip_addresses | join(", "),
            }'''),
    }

    # Currently everything here supports both ESXi and KVM host
    def __init__(self, mgr, host=None, user='root', password='Vmware123!'):
        super(EsxiHost,self).__init__(mgr=mgr)
        self.user=user
        self.password = password
        if host:
            self.__getHostInfo(host=host)
            self.ssh = paramiko.SSHClient()
            self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            self.ssh.connect(host,username=self.user, password=self.password)
        self.listUrl='/api/v1/fabric/nodes'

    def __getHostInfo(self,host):
        try:
            nameinfo = socket.gethostbyaddr(host)
        except:
            try:
                socket.inet_aton(host)
            except:
                raise ValueError("Given hostname or IP is not valid: %s" %host)
            else:
                self.hostname=host
                self.ip=host
        else:
            self.hostname=nameinfo[0]
            self.ip=nameinfo[2][0]

    def getPlatform(self):
        cmd = '/bin/uname'

        #print ("Running for %s: %s" %(self.hostname,cmd))
        stdin,stdout,stderr = self.ssh.exec_command(cmd)
        out = stdout.read().strip()
        print ('platform is ' + out)
        if out == 'VMkernel':
            return 'esx'
        elif out == 'Linux':
            return 'kvm'
        else:
            raise ValueError("Unknown platform: %s" % out)

    def doexec(self,cmd):
        cmd = "/opt/vmware/nsx-cli/bin/scripts/nsxcli -c " + cmd
        print ("Running for %s: %s" %(self.hostname,cmd))
        stdin,stdout,stderr = self.ssh.exec_command(cmd)
        out = stdout.read()
        print(out)
        return out

    def getThumbprint(self,platform=None,display=True):
        if not platform:
            platform=self.getPlatform()
        if platform=="kvm":
            return self.__getKvmThumbprint(display=display)
        if platform=='esx':
            return self.__getEsxiThumbprint(display=display)

    def __getEsxiThumbprint(self,display=True):
        cmd='/bin/openssl x509 -in /etc/vmware/ssl/rui.crt -fingerprint \
                -sha256 -noout'
        if display:
            print ("Running for %s: %s" %(self.hostname,cmd))
        stdin,stdout,stderr = self.ssh.exec_command(cmd)
        out = stdout.read().split('=')[1]
        if display:
            print(out)
        return out


    def __getKvmThumbprint(self,display=True):
        cmd='/usr/bin/ssh-keygen -l -f /etc/ssh/ssh_host_rsa_key'
        if display:
            print ("Running for %s: %s" %(self.hostname,cmd))
        stdin,stdout,stderr = self.ssh.exec_command(cmd)
        out = stdout.read().split(' ')[1].strip().split(':')[1]
        if display:
            print(out)
        return out

    def __getLinuxDist(self,display=True):
        cmd='/usr/bin/lsb_release -si'
        if display:
            print ("Running for %s: %s" %(self.hostname,cmd))
        stdin,stdout,stderr = self.ssh.exec_command(cmd)
        out = stdout.read().strip()
        if display:
            print ("thumbprint " + out)
        return out


    def apiJoinmp(self,mgr,user='admin',password='Vmware123!'):
        data={}
        platform = self.getPlatform()
        thumbprint = self.getThumbprint(display=True)
        thumbprint = thumbprint.replace("\n","")
        thumbprint = thumbprint.replace(":","")
        data['display_name'] = self.hostname
        data['description'] = self.hostname + ' ' + platform
        data['ip_addresses'] = [self.ip]
        cred = {}
        cred['username'] = self.user
        cred['password'] = self.password
        cred['thumbprint'] = thumbprint
        data['host_credential']= cred
        if platform == 'esx':
            data['os_type'] = 'ESXI'
        elif platform == 'kvm':
            dist = self.__getLinuxDist(display=False)
            if dist == 'Ubuntu':
                data['os_type'] = 'UBUNTUKVM'
            elif dist == 'RedHatEnterpriseServer':
                data['os_type'] = 'RHELKVM'
            else:
                raise ValueError('Host.apiJoinmp: unknown KVM distribution: %s'
                        % dist)

        data['resource_type'] = 'HostNode'

        restUrl = '/api/v1/fabric/nodes'
        print(data)
        r = self.rest_api(restUrl,method='POST',data=data,display=False)
        if r.status_code != 201:
            raise ValueError("Host.apiJoinmp: Can't join host %s to MP"
                    %self.hostname)

    def findByIp(self,ip, display=False):
        nodes = self.list(display=False)
        for n in nodes['results']:
            if ip in n['ip_addresses']:
                if display:
                    self.json_print(n, convert=False)
                return n
        if display:
            print("No node found with ip %s" %ip)
        return None

    def deleteHost(self,host,ip=None,unprep=False, display=False):
        node=self.findByName(name=host, display=False)
        print (node)
        if not node and ip:
            node=self.findByIp(ip=ip, display=False)
        if not node:
            if display:
                print("Host not found")
            return None
        restUrl='api/v1/fabric/nodes/%s?unprepare_host=%s' % (node['id'],unprep)
        r = self.rest_api(api=restUrl,method='DELETE')
        if r.status_code != 200:
            print("Deletion of node failed with code: %d" %r.status_code)

    def detachmp(self,mgr,thumbprint,user='admin',password='Vmware123!'):
        cmd = "detach management-plane %s thumbprint %s username %s password %s" \
              %(mgr,thumbprint,user,password);
        self.doexec(cmd=cmd)
    def clearmp(self):
        cmd = "clear management-plane"
        self.doexec(cmd=cmd)

    def joinmp(self,mgr,thumbprint,user='admin',password='Vmware123!'):
        cmd = "join management-plane %s thumbprint %s username %s password %s" \
                %(mgr, thumbprint,user, password)
        self.doexec(cmd=cmd)


class Uplinkprofile(Network_object):
    resType = 'UplinkHostSwitchProfile'
    api = {
        'list':      Api('get',    '/api/v1/host-switch-profiles?include_system_owned=true'),
        'get':       Api('get',   '"/api/v1/host-switch-profiles/%s"%_hspId'),
        'delete':    Api('delete','"/api/v1/host-switch-profiles/%s"%_hspId'),
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "name":           .display_name,
                "id":             .id,
                "transport_vlan": .transport_vlan,
                "teaming":        .teaming.policy,
                "type":           .resource_type,
            }'''),
    }

    def __init__(self, mgr):
        super(self.__class__, self).__init__(mgr=mgr)

    '''
    def list(self,display=True):                                                        # Uplinkprofile
        restUrl = '/api/v1/host-switch-profiles?include_system_owned=True'
        r = self.rest_api(restUrl,method="GET")
        data = json.loads(r.text)
        if display:
            self.json_print(data=data, convert=False)
        return data
    '''

    def config(self,data):
        restUrl = '/api/v1/host-switch-profiles'
        self.json_print(data=data,convert=False)
        r = self.rest_api(api=restUrl, method="POST", data=data)


    '''
    def findByName(self,name,display=True):                                             # Uplinkprofile
        data = self.list(display=False)
        profile = None
        for p in data['results']:
            if p['display_name'] == name:
                profile = p
                break
        if profile and display:
            self.json_print(data=profile,convert=False)
        return profile
    '''

    def findById(self,id,display=True):
        data = self.list(display=False)
        profile = None
        for p in data['results']:
            if p['id'] == id:
                profile = p
                break
        if profile and display:
            self.json_print(data=profile,convert=False)
        return profile


    def activeUplinks(self,name,obj=None,display=True):
        if not obj:
            data=self.findByName(name=name,display=False)
            if not data:
                raise ValueError("Uplinkprofile %s not found" %name)
        else:
            data = obj
        links = []
        for i in data['teaming']['active_list']:
            if i['uplink_type'] == 'LAG':
                for u in data['lags']:
                    if i['uplink_name'] == u['name']:
                        for x in u['uplinks']:
                            links.append(x['uplink_name'])
                        return links
                return None
            else:
                links.append(i['uplink_name'])
        return links

    def standbyUplinks(self,name,obj=None,display=True):
        if not obj:
            data=self.findByName(name=name,display=False)
            if not data:
                raise ValueError("Uplinkprofile %s not found" %name)
        else:
            data=obj
        if not 'standby_list' in data['teaming']:
            return []

        links = []
        for i in data['teaming']['standby_list']:
            links.append(i['uplink_name'])
        return links

    def uplinkList(self,name, obj=None, display=True):
        active=self.activeUplinks(name=name,obj=obj,display=False)
        standby = self.standbyUplinks(name=name, obj=obj,display=False)
        links=active+standby
        return links



class ManagerCluster(Network_object):
    resType = ''
    api = {
        'status':      Api('get',    '/api/v1/cluster-manager/status'),
    }
    ptblFmts = {
        'status': PtblFmt(api['status'].url, '''
            .groups[] | {
                "group_type":   .group_type,
                #"group_id":     .group_id,
                "group_status": .group_status,
                "leaders":      [
                   .leaders[] | {
                        "service_name":     .service_name,
                        #"lease_version",    .lease_version",
                    }
                ],
                "members":      [
                    .members[] | {
                        "ip":   .member_ip,
                        "fqdn":   .member_fqdn,
                        "status":   .member_status
                    }
                ]
            }'''),
    }



class Cluster(Network_object):
    api = {
        'cluster':       Api('get',    '/api/v1/cluster'),
        'clusterNodes':  Api('get',    '/api/v1/cluster/nodes'),
        'clusterNode':   Api('get',   '"/api/v1/cluster/nodes/%s"%nodeId'),
        'clusterStatus': Api('get',    '/api/v1/cluster/status'),
        'vip':           Api('get',    '/api/v1/cluster/api-virtual-ip'),
        'getCert':       Api('get',    '/api/v1/cluster/api-certificate'),
    }
    ptblFmts = {
        'cluster': PtblFmt(api['cluster'].url, '''
            .nodes[] | {
                "name": .display_name,
                "fqdn": .fqdn,
                "status": .status,
                "client": ([
                    .msg_clients[] | {
                        "msgClient": .entity_type,
                        "cType": ([.clients[] | .client_type]|join(","))
                    }
                ]),
                "entity": ([
                    .entities[] | {
                        "entType": .entity_type,
                        "ip:port": (.ip_address+":"+(.port|tostring)),
                    }
                ])
            }'''),
        'clusterNodes': PtblFmt(api['clusterNodes'].url, '''
            def fmtPort: if . then ":"+(.|tostring) else "" end;
            .results[] | {
                "name": .display_name,
                "id": .id,
                "mgmtIp": (.appliance_mgmt_listen_addr // ""),
                "ctrAddr": (.controller_role.control_cluster_listen_addr| .ip_address+(.port|fmtPort)),
                "mgrAddr": (.manager_role.api_listen_addr| .ip_address+(.port|fmtPort))
            }'''),
        'clusterStatus': PtblFmt(api['clusterStatus'].url, '''{
                "id": .cluster_id,
                "status": .control_cluster_status.status,
                "node": ([.mgmt_cluster_status.online_nodes[] | {
                    "uuid": .uuid,
                    "mgmtIp": .mgmt_cluster_listen_ip_address
                }])
            }'''),
        'vip': PtblFmt(api['vip'].url, '''{
                "vip": .ip_address
            }'''),
    }
    def __init__(self, mp):
        super(self.__class__, self).__init__(mp=mp)
        self.listUrl = '/api/v1/cluster/nodes'
        self.clusterid = self.info(display=False)['cluster_id']
        self.mgr=mp.getMgr()


    def info(self, display=True):
        restUrl = '/api/v1/cluster'
        r = self.mgr.get(restUrl,
                headers={'Accept': 'application/json'})
        if r.status_code >= 400:
            print (r.text)
            self.mgr.responseError(r)
            return None

        if display:
            self.json_print(json.loads(r.text),indent=4)
        return json.loads(r.text)


    def createCluster(self,primary,secondaries):
        primary.getThumbprint(refresh=True)
        primary.getClusterInfo()
        for s in secondaries:
            s.getClusterInfo()
            data={}
            data['certficate_sha256_thumbprint'] = primary.getThumbprint()
            data['cluster_id']=primary.getClusterId()
            data['ip_address'] = primary.getIpAddress()
            #data['port'] = 443
            data['username'] = primary.getAdminUser()
            data['password'] = primary.getAdminPassword()

            restUrl='/api/v1/cluster?action=join_cluster'
            r = s.rest_api(api=restUrl,method='POST', data=data, display=True)
            if r.status_code != 200:
                print("Error in joining cluster.  primary: %s, secondary: %s"
                      % (primary.getIpAddress(), s.getIpAddress()))
                raise ValueError("Failure to join cluster: %d'" %r.status_code)

    def nodes(self):
        restUrl = '/api/v1/cluster/nodes'
        r=self.mgr.get(restUrl,
                headers={'Accept': 'application/json'})
        if r.status_code >= 400:
            print (r.text)
            self.mgr.responseError(r)
            return None

        cluster = json.loads(r.text)

        for i in cluster['results']:
            self.walk_and_replace_dict_keyval(d=i,
                    name='certificate', val='_snipped_')
            self.json_print(i,indent=4)

    def status(self):
        restUrl = '/api/v1/cluster/status'
        r = self.rest_api(api=restUrl)
        self.json_print(json.loads(r.text), indent=4)

    def jq(self, jqType=None, display=True):
        if not jqType or jqType=='details':
            if display: print('Cluster:')
            return self.jqTable(apiKey='cluster', jqFilter=self.ptblFmts['cluster'].jqFilter, display=display)
        if not jqType or jqType=='nodes':
            if display: print('Cluster nodes:')
            return self.jqTable(apiKey='clusterNodes', jqFilter=self.ptblFmts['clusterNodes'].jqFilter, display=display)
        if not jqType or jqType=='status':
            if display: print('Cluster status:')
            return self.jqTable(apiKey='clusterStatus', jqFilter=self.ptblFmts['clusterStatus'].jqFilter, display=display)
        if not jqType or jqType=='vip':
            return self.jqTable(apiKey='vip', jqFilter=self.ptblFmts['vip'].jqFilter, display=display)

class IPSet(Network_object):
    #listUrl = '/api/v1/ip-sets'
    resType = 'IPset'
    api = {
        'list':     Api('get',   '/api/v1/ip-sets'),
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "name": .display_name,
                "id": .id,
                "ipAddresses": .ip_addresses | join(", "),
            }'''),
    }

    def __init__(self, mgr):
        super(self.__class__, self).__init__(mgr=mgr)
        self.listUrl='/api/v1/ip-sets'

    def config(self,name,ips,display=True, update=False):
        qstr = "resource_type:IPSet AND display_name:%s" %name

        ip=self.search(qstr=qstr,resource="IPSet", name=name)

        if ip and not update:
            print ("IPSet.config: ipset with name already exist: %s, --update not specified" %name)
            return

        if ip:
            data=ip
        else:
            data={}
        data['display_name'] = name
        if ips:
            data['ip_addresses'] = ips

        method=None
        if ip:
            restUrl = '/api/v1/ip-sets/%s'%ip['id']
            method='PUT'
        else:
            restUrl = '/api/v1/ip-sets'
            method='POST'

        r = self.rest_api(api=restUrl,method=method,data=data,display=display)
        if r.status_code != 201 and r.status_code != 200:
            print ("ERROR: IPSet.config: %d" %r.status_code)


    def delete(self,name,display=True):
        ipset=self.findByName(name=name,display=False)
        if not ipset:
            return

        restUrl = '/api/v1/ip-sets/%s' %ipset['id']

        r = self.rest_api(restUrl,method='DELETE',display=display)

        if r.status_code != 200:
            print ("ERROR: IPSet.delete: %d" %r.status_code)


class NSGroups(Network_object):
    resType = 'NSGroup'
    api = {
        'list':     Api('get',   '/api/v1/ns-groups'),
        'update':   Api('put',  '"/api/v1/ns-groups/%s"%objId'),
        'create':   Api('post',  '/api/v1/ns-groups'),
        'mbrIP':    Api('get',  '"/api/v1/ns-groups/%s/effective-ip-address-members"%nsgId'),
        'mbrLP':    Api('get',  '"/api/v1/ns-groups/%s/effective-logical-port-members"%nsgId'),
        'mbrLS':    Api('get',  '"/api/v1/ns-groups/%s/effective-logical-switch-members"%nsgId'),
        'mbrVM':    Api('get',  '"/api/v1/ns-groups/%s/effective-virtual-machine-members"%nsgId'),
        'mbrTYPE':  Api('get',  '"/api/v1/ns-groups/%s/member-types"%nsgId'),
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            def tagExpr:.target_type+"."+"tag "+.scope+":"+.tag;
            def simExpr:.target_type+"."+.target_property+" "+.op+" "+.value;
            def trage:if .resource_type=="NSGroupTagExpression" then tagExpr
                elif .resource_type=="NSGroupSimpleExpression" then simExpr
                else "" end;
            .results[] | {
                "name": .display_name,
                "id": .id,
                "members":  (if .members then [.members[]|trage]|join("\n") else "" end),
                "criteria": (if .membership_criteria then
                    [.membership_criteria | to_entries | .[] | {
                        "r#":        .key,
                        "expression": .value | (
                            if .resource_type=="NSGroupComplexExpression" then
                                .expressions[] | trage
                            else
                                trage
                            end)
                        }]
                    else "" end),
                "tags":     (if .tags then [.tags[]|.scope+":"+.tag]|sort|join(", ") else "" end),
            }'''),
        'mbrVM': PtblFmt(api['mbrVM'].url, '''
            .results[] | {
                "name": .display_name,
                "external_id": .external_id,
                "power": .power_state,
            }'''),
        'mbrIP': PtblFmt(api['mbrIP'].url, '''
            .results | { "IPs": join(",\n") }'''),
        'mbrLS': PtblFmt(api['mbrLS'].url, '''
            .results[] | {
                "name": .target_display_name,
                "id": .target_id,
            }'''),
        'mbrLP': PtblFmt(api['mbrLP'].url, '''
            .results[] | {
                "name": .target_display_name,
                "id": .target_id,
            }'''),
        'mbrTYPE': PtblFmt(api['mbrTYPE'].url, '''
            .results | { "MemberTypes": join(", ") }'''),

    }

    def __init__(self, mgr):
        super(self.__class__, self).__init__(mgr=mgr)
        self.listUrl='/api/v1/ns-groups'

    def create(self, nsgSpec):              # NSGroups
        nsSpec='''
            testNSGroup0000;
                IPSet.id=id(IPSet2);
                vm.name<simon & vm.tag=cqe:cpt,
                lp.tag=cqe:,
                ls.tag=:cpt,
                vm.name^cpt-sc2
        '''
        jsonDict1 = {
          "display_name": "testNSGroup",
          'resource_type': 'NSGroup',
          'members': [{'op': 'EQUALS',
                      'resource_type': 'NSGroupSimpleExpression',
                      'target_property': 'id',
                      'target_type': 'IPSet',
                      'value': 'f4d4769b-2e50-4e82-9241-adbdc8ca9025'}],
          'membership_criteria': [{'expressions': [{'op': 'CONTAINS',
                                                      'resource_type': 'NSGroupSimpleExpression',
                                                      'target_property': 'name',
                                                      'target_type': 'VirtualMachine',
                                                      'value': 'simon'},
                                                     {'resource_type': 'NSGroupTagExpression',
                                                      'scope': 'cqe',
                                                      'scope_op': 'EQUALS',
                                                      'tag': 'cpt',
                                                      'tag_op': 'EQUALS',
                                                      'target_type': 'VirtualMachine'}],
                                    'resource_type': 'NSGroupComplexExpression'},
                                   {'resource_type': 'NSGroupTagExpression',
                                    'scope': 'cqe',
                                    'scope_op': 'EQUALS',
                                    'tag_op': 'EQUALS',
                                    'target_type': 'LogicalPort'},
                                   {'resource_type': 'NSGroupTagExpression',
                                    'scope_op': 'EQUALS',
                                    'tag': 'cpt',
                                    'tag_op': 'EQUALS',
                                    'target_type': 'LogicalSwitch'},
                                   {'op': 'STARTSWITH',
                                    'resource_type': 'NSGroupSimpleExpression',
                                    'target_property': 'name',
                                    'target_type': 'VirtualMachine',
                                    'value': 'cpt-sc2'}],
        }
        jsonDict = jsonDict1
        r = self.rest_api(self.api['create'].url, method='POST', data=jsonDict, display=False)


    '''
    def list(self,restUrl=None,brief=False,display=True):   # NSGroups
        if not restUrl:
            restUrl = '/api/v1/ns-groups'

        #r = self.rest_api(restUrl,method='GET')
        #data = json.loads(r.text)
        data = self.pageHandler(restUrl)
        if display:
            if brief:
                print("Number of results: %d" %data['result_count'])
                ind = 0
                for i in data['results']:
                    print("%d. Name: %s" %(ind,i['display_name']))
                    print("   ID: %s" %(i['id']))
                    if 'members' in i:
                        mcount= len(i['members'])
                    else:
                        mcount=0
                    if 'membership_criteria' in i:
                        scount=len(i['membership_criteria'])
                    else:
                        scount = 0
                    print("   Members: %d Memberships: %d"
                          %(mcount,scount))
                    ind+=1
            else:
                self.json_print(data=data,convert=False)
        return data

    '''

    def find(self,name,display=True):
        return self.findByName(name=name,display=display)

    def delete(self,name,display=True):
        self.deleteByName(name=name,display=display)

    def config(self,name,ips=None,ls=None, nsgroup=None, lp=None,
               vmcontain=None,vmequal=None,vmstart=None,
               lstag=None,lptag=None,vmtag=None,desc=None,
               display=True, update=False):
        '''
        All the parameters are for direct membership specifications
        except for the tags (lstag,lptag,vmtag)
        '''
        qstr = "resource_type:NSGroup AND display_name:%s" %name

        grp=self.search(qstr=qstr,resource="NSGroup", name=name)

        if grp and not update:
            print ("NSGroups.config: group by name exists: %s and update not specified" %name)
            return

        if grp:
            self.json_print(grp)
            data=grp
            if 'effective_member_count' in data.keys():
                del data['effective_member_count']
        else:
            data = {}
        data['display_name'] = name
        if desc:
            data['description'] = desc

        members=[]

        if ips:
            ipsets = IPSet(mgr=self.mgr)
            for i in cptutil.iflatten(ips):
                ipset = ipsets.findByName(name=i,display=False)
                #qstr = "resource_type:IPSet AND display_name:%s" %i
                #ipset=self.search(qstr=qstr,resource="IPSet", name=i)
                if not ipset:
                    print("NSGroups.config: IPSet name %s not found" %i)
                    return
                grpexpr = {}
                grpexpr['op'] = 'EQUALS'
                grpexpr['resource_type'] = 'NSGroupSimpleExpression'
                grpexpr['target_property'] = 'id'
                grpexpr['target_type'] = 'IPSet'
                grpexpr['value'] = ipset['id']
                members.append(grpexpr)

        if ls:
            for i in ls:
                qstr = "resource_type:LogicalSwitch AND display_name:%s" %i
                sw=self.search(qstr=qstr,resource="LogicalSwitch", name=i)
                if not sw:
                    print ("NSGroups.config: Switch name %s not found:" %i)
                    return
                grpexpr = {}
                grpexpr['op'] = 'EQUALS'
                grpexpr['resource_type'] = 'NSGroupSimpleExpression'
                grpexpr['target_property'] = 'id'
                grpexpr['target_type'] = 'LogicalSwitch'
                grpexpr['value'] = sw['id']
                members.append(grpexpr)

        if nsgroup:
            nsgroups = NSGroups(mgr=self.mgr)
            for i in cptutil.iflatten(nsgroup):
                #qstr = "resource_type:NSGroup AND display_name:%s" %i
                #ns=self.search(qstr=qstr,resource="NSGroup", name=i)
                ns=nsgroups.findByName(name=i, display=False)
                if not ns:
                    print ("NSGroups.config: NSGroup name %s not found:" %i)
                    return
                grpexpr = {}
                grpexpr['op'] = 'EQUALS'
                grpexpr['resource_type'] = 'NSGroupSimpleExpression'
                grpexpr['target_property'] = 'id'
                grpexpr['target_type'] = 'NSGroup'
                grpexpr['value'] = ns['id']
                members.append(grpexpr)

        if lp:
            for i in cptutil.iflatten(lp):
                qstr = "resource_type:LogicalPort AND display_name:%s" %i
                port=self.search(qstr=qstr,resource="LogicalPort", name=i)
                if not port:
                    print ("NSGroups.config: LogicalPort name %s not found:" %i)
                    return
                grpexpr = {}
                grpexpr['op'] = 'EQUALS'
                grpexpr['resource_type'] = 'NSGroupSimpleExpression'
                grpexpr['target_property'] = 'id'
                grpexpr['target_type'] = 'LogicalPort'
                grpexpr['value'] = port['id']
                members.append(grpexpr)

        membership=[]
        if vmcontain:
            for i in cptutil.iflatten(vmcontain):
                grpexpr = {}
                grpexpr['target_property'] = 'name'
                grpexpr['target_type'] = 'VirtualMachine'
                grpexpr['resource_type'] = 'NSGroupSimpleExpression'
                grpexpr['op'] = 'CONTAINS'
                grpexpr['value'] = i
                membership.append(grpexpr)
        if vmequal:
            for i in cptutil.iflatten(vmequal):
                grpexpr = {}
                grpexpr['target_property'] = 'name'
                grpexpr['target_type'] = 'VirtualMachine'
                grpexpr['resource_type'] = 'NSGroupSimpleExpression'
                grpexpr['op'] = 'EQUALS'
                grpexpr['value'] = i
                membership.append(grpexpr)
        if vmstart:
            for i in cptutil.iflatten(vmstart):
                grpexpr = {}
                grpexpr['target_property'] = 'name'
                grpexpr['target_type'] = 'VirtualMachine'
                grpexpr['resource_type'] = 'NSGroupSimpleExpression'
                grpexpr['op'] = 'STARTSWITH'
                grpexpr['value'] = i
                membership.append(grpexpr)

        if lstag:
            for tag in cptutil.iflatten(lstag):
                grpexpr = {}
                grpexpr['target_type'] = 'LogicalSwitch'
                grpexpr['resource_type'] = 'NSGroupTagExpression'
                grpexpr['tag_op'] = 'EQUALS'
                grpexpr['tag'] = tag
                if ':' in tag:
                    grpexpr['scope'], grpexpr['tag'] = tag.split(':')
                membership.append(grpexpr)
        if lptag:
            for tag in cptutil.iflatten(lptag):
                grpexpr = {}
                grpexpr['target_type'] = 'LogicalPort'
                grpexpr['resource_type'] = 'NSGroupTagExpression'
                grpexpr['tag_op'] = 'EQUALS'
                grpexpr['tag'] = tag
                if ':' in tag:
                    grpexpr['scope'], grpexpr['tag'] = tag.split(':')
                membership.append(grpexpr)
        if vmtag:
            for tag in cptutil.iflatten(vmtag):
                grpexpr = {}
                grpexpr['target_type'] = 'VirtualMachine'
                grpexpr['resource_type'] = 'NSGroupTagExpression'
                grpexpr['tag_op'] = 'EQUALS'
                grpexpr['tag'] = tag
                if ':' in tag:
                    scope, tag = tag.split(':')
                    if scope: grpexpr['scope'] = scope
                    if tag: grpexpr['tag'] = tag
                membership.append(grpexpr)

        if len(members) > 0:
            data['members'] = members
        if len(membership) > 0:
            data['membership_criteria'] = membership

        if grp:
            restUrl='/api/v1/ns-groups/%s' %grp['id']
            method='PUT'
        else:
            restUrl = '/api/v1/ns-groups'
            method='POST'
        r = self.rest_api(restUrl,method=method,data=data,display=display)
        if r.status_code != 201 and r.status_code!=200:
            print("ERROR: NSGroups.config: %d" %r.status_code)
            return

    def member(self, mType, namesGlob='*', fmt='jq'):
        if mType == 'mbrIP-VM':
            dict = {}
            print('test')
            self.logger.info("Getting effective IP addresses of all security groups")
            for nsg in self.findByNamesGlob(namesGlob):
                self.logger.info2("Getting effective IP addresses of %s" % nsg)
                restKey = 'mbrIP'
                nsgId = nsg['id']
                restUrl = eval(self.api[restKey].url)
                restMethod = self.api[restKey].method
                r = self.rest_api(restUrl, method=restMethod, display=False)
                if r.status_code != 201 and r.status_code != 200:
                    print("ERROR: NSGroups.config: %d" % r.status_code)
                    return
                else:
                    data = json.loads(r.text)
                    self.logger.info2("Json of IP addresses of security group %s\n%s" % (nsg,data))
                    ips = data['results']
                    search = Search(mgr=self.mgr)
                    dict1 = {}
                    for ip in ips:
                        if len(ip.split('/')) == 2 or len(ip.split('::')) >=2:
                            dict1[ip] = None
                            self.logger.info2("%s doesnt have VM associated because it is with subnet or ipv6 address" % (ip))
                            continue
                        ip_data = search.search(ip)
                        if ip_data['results'][0]['resource_type'] == 'IPSet':
                            dict1[ip] = None
                            self.logger.info2("%s doesn't have VM associated because it is IPSet" % (ip))                        
                            continue
                        owner_vm_id = ip_data['results'][0]['owner_vm_id']
                        vm_data = search.search(owner_vm_id)
                        for vm in vm_data['results']:
                            if vm['resource_type'] == 'VirtualMachine':
                                dict1[ip] = vm['display_name']
				self.logger.info2("%s associated vm is %s" % (ip, vm['display_name']))
                    dict[nsg['display_name']] = dict1
            return dict
        else:
	    for nsg in self.findByNamesGlob(namesGlob):
                self.jqTable(apiKey=mType, nsgId=nsg['id'])

class Syslog(Network_object):
    def getProperties(self,display=True):
        restUrl = '/api/v1/node/services/syslog'

        r = self.rest_api(restUrl,method='GET')
        data=json.loads(r.text)
        if display:
            self.json_print(data=data,convert=False)
        return data

    def list(self,display=True):                            # Syslog
        restUrl = '/api/v1/node/services/syslog/exporters'

        r = self.rest_api(restUrl,method='GET')
        data = json.loads(r.text)
        if display:
            self.json_print(data=data,convert=False)
        return data['results']


    def find(self,name,display=True):
        ngs = self.list(display=False)

        for i in ngs:
            if i['exporter_name'] == name:
                if display:
                    self.json_print(data=i,convert=False)
                return i
        return None

    def delete(self,name,display=True):
        exporter=self.find(name=name,display=False)
        if not exporter:
            return

        restUrl = '/api/v1/node/services/syslog/exporters/%s' \
                  %exporter['exporter_name']

        r = self.rest_api(restUrl,method='DELETE',display=display)

        if r.status_code != 200:
            print ("ERROR: Syslog.delete: %d" %r.status_code)


    def status(self,display=True):
        restUrl='/api/v1/node/services/syslog/status'
        r = self.rest_api(restUrl,method='GET')
        data=json.loads(r.text)
        if display:
            self.json_print(data=data,convert=False)
        return data

    def config(self,name,server,port=514,protocol='UDP',level='NOTICE',
               facility=['LOCAL7'], cert=None):

        data={}
        data['exporter_name'] = 'name'
        data['server'] = server
        data['level'] = level
        if facility:
            data['facilities'] = facility
        data['port'] = port
        data['protocol'] = protocol
        if protocol == 'TLS' and not cert:
            print ("ERROR: Syslog.config, cert not specified for TLS exporter")
            return
        elif protocol=='TLS':
            data['tls_ca_pem'] = cert


        restUrl = '/api/v1/node/services/syslog/exporters'
        r = self.rest_api(restUrl,method='POST',data=data,display=True)

        if r.status_code != 201:
            print("ERROR: Syslog.config failed to create: %d" %r.status_code)
            return

class Bridge(Network_object):
    def createBridgeCluster(self,name, nodes,display=True):
        tnlist = []
        tns = TransportNode(mgr=self.mgr)
        for n in nodes:
            tn = tns.find(name=n, display=False)
            if not tn:
                raise ValueError("createBridgeCluster: TN with name %s not found"
                                 %n)
            clusterNode = {}
            clusterNode['transport_node_id'] = tn['id']
            tnlist.append(clusterNode)

        if len(tnlist) == 0:
            raise ValueError("createBridgeCluster: must have atleast one TN")

        brCluster = {}
        brCluster['bridge_nodes'] = tnlist
        brCluster['display_name'] = name
        restUrl  = '/api/v1/bridge-clusters'
        r = self.rest_api(api=restUrl,method='POST',
                          data=brCluster,
                          display=display)
        return json.loads(r.text)

    def deleteBridgeCluster(self,name,display=False):
        brc = self.findByName(name=name,restUrl='/api/v1/bridge-clusters',
                              display=False)
        if not brc:
            print ("deleteBridgeCluster: cluster %s not found" %name)
            return False

        restUrl='/api/v1/bridge-clusters/%s' % brc['id']
        print ("Deleting bridge cluster %s with id %s" %(name,brc['id']))
        r = self.rest_api(api=restUrl,method='DELETE')
        if r.status_code == 200:
            return True
        else:
            print ("...Delete bridgeCluster failed, code: %s" %r.status_code)
            print (r.text)
            return False


    def findBridgeEndPoint(self, id, beps = None):
        if not beps:
            beps = self.list(restUrl = '/api/v1/bridge-endpoints',display=False)

        for b in beps['results']:
            if b['id'] == id:
                return b
        return None

    def listBridges(self,switch=''):
        sw = None
        if switch:
            sw = self.findByName(name=switch,
                                 restUrl='/api/v1/logical-switches',
                                 display=None)
            if not sw:
                print ("Can't find switch by name: %s" %switch)
        ports = self.list(restUrl='/api/v1/logical-ports', display=None)
        beps = self.list(restUrl='/api/v1/bridge-endpoints',display=False)
        for p in ports['results']:
            if sw and p['logical_switch_id'] != sw['id']:
                continue
            if not 'attachment' in p:
                continue
            if p['attachment']['attachment_type'] == "BRIDGEENDPOINT":
                print ("{:>10}: {}".format("port_name", p['display_name']))
                print ("{:>10}: {}".format("port_id", p['id']))
                print ("{:>10}: {}".format("switch_id", p['logical_switch_id']))
                print ("{:>10}: {}".format("br_id", p['attachment']['id']))
                br = self.findBridgeEndPoint(id=str(p['attachment']['id']),
                                             beps=beps)
                if br:
                    print ("{:>10}: {}".format("vlan", br['vlan']))


    def deleteBridgePoint(self,name='',id='',display=True):
        bep = None
        if not id and name:
            bep = self.findByName(restUrl='/api/v1/bridge-endpoints', name=name)
        elif id:
            bep = self.findById(restUrl='/api/v1/bridge-endpoints', id=id)
        if not bep:
            print ("Bridge endpoint not found")
            return

        restUrl = "/api/v1/bridge-endpoints/%s" %bep['id']
        print ("Deleting bridge endpoint with name %s, id %s"
               %(bep['display_name'], bep['id']))
        r = self.rest_api(api=restUrl,method="DELETE")



    def createBridgePoint(self,brcluster,vlan,ha=True, name='', tz=None, display=True):
        '''
        brcluster = self.findByName(restUrl='/api/v1/bridge-clusters',
                                    name=brcluster,
                                    display=False)

        if not brcluster:
            raise ValueError("Bridge cluster %s not found" %brcluster)
        '''
        data={}
        if brcluster['resource_type'] != 'EdgeCluster':
            data['bridge_cluster_id'] = brcluster['id']
            data['ha_enable'] = ha
        else:
            if not tz:
                print("Must provide transportzone when using edge cluster")
                return None
            tzo=Transportzone(mgr=self.mgr)
            tz = tzo.find(name=tz,display=None)
            if not tz:
                print("TZ %s not found" %tz)
                return None
            data['vlan_transport_zone_id'] = tz['id']

        data['vlan'] = vlan
        if name:
            data['display_name'] = name

        restUrl = '/api/v1/bridge-endpoints'
        r = self.rest_api(api=restUrl, method='POST',
                          data=data, display=display)
        return json.loads(r.text)

    def listBridgeEndPoints(self,display=True):
        self.list(restUrl='/api/v1/bridge-endpoints', display=display)


    def create(self,switch,vlan,brcluster,brpoint=None,display=True):
        sw = self.findByName(name=switch,
                                 restUrl='/api/v1/logical-switches',
                                 display=False)
        if not sw:
            raise ValueError("Can't find switch by name: %s" %switch)

        br = self.findByName(name=brcluster,
                             restUrl='/api/v1/bridge-clusters',
                             display=False)
        if not br:
            ec=EdgeCluster(mgr=self.mgr)
            br=ec.find(name=brcluster, display=False)
        if not br:
            raise ValueError("Can't find bridge cluster by name: %s"
                                 %brcluster)
        if not brpoint:
            brpoint = self.createBridgePoint(brcluster=br, vlan=vlan,
                                             ha=True, display=False)

        name = ("%s_%s_bridge" %(switch,vlan))
        ls = Switch(mgr=self.mgr)
        port = ls.createPort(swid=sw['id'], br = brpoint,
                             name=name, display = True)

    def delete(self,name = None,id=None,deleteBrpoint=True,display=True):
        lrp = None
        if not id and name:
            lrp = self.findByName(name=name,
                                  restUrl='/api/v1/logical-ports',
                                  display=False)
        if id:
            lrp = self.findById(id=id, restUrl='/api/v1/logical-ports',
                                display=False)
        if not lrp:
            print ("Can't find the switch port by name or id")
            return False

        attach = lrp['attachment']
        if attach['attachment_type'] != 'BRIDGEENDPOINT':
            print ("Attachment type for switch port is %s, expecting \
            BRIDGEENDPOINT." %attach['attachment_type'])
            return False

        print ("Deleting switchport...")
        restUrl = '/api/v1/logical-ports/%s?detach=True' %lrp['id']
        r = self.rest_api(api=restUrl, method="DELETE")
        deletedLrp = False
        if r.status_code == 200:
            print ("    Switchport delete successful")
            deletedLrp = True
        else:
            print ("    Delete switchport unsuccessful, code: %d" %r.status_code)
            return False

        if deleteBrpoint:
            print ("Deleting bridge endpoint...")
            brp = self.findById(id=lrp['attachment']['id'], restUrl='/api/v1/bridge-endpoints',
                                display=False)
            if not brp:
                print ("   Can't find valid bridge endpoint to delete: %s" %id)
                return False
            restUrl = '/api/v1/bridge-endpoints/%s' %brp['id']
            r = self.rest_api(api = restUrl, method="DELETE",
                              display=False)
            if r.status_code == 200:
                print ("   Delete bridge endpoint successful: %s" %brp['id'])
                return True
            else:
                print ("   Delete bridge endpoint unsuccessful: %s" %brp['id'])
                return False
'''
Class Syslog(Network_object):
    def addExporter(self, level,server,protocol,port,msgids=None, facility=None):
        data={}
        data['exporter_name'] = server
        if facility:
            data['facilities'] = facility
        data['level']= level
        data['port'] = port
        data['protocol'] = protocol
        restUrl = '/api/v1/node/services/syslog/exporters'
        r = self.rest_api(api=restUrl,method="POST",data=data,display=False)
        if r.status_code == 201:
            print("Syslog exporter configured: %s:%s:%s" %(server,protocol,port))
            return True
        else:
            print("Syslog exporter configuration failed, code: %s" %r.status_code)
            return False


'''




class Principal(Network_object):
    resType = 'PrincipalIdentity'
    api = {
        'create':   Api('post',    '/api/v1/trust-management/principal-identities'),
        'list':     Api('get',     '/api/v1/trust-management/principal-identities'),
        'delete':   Api('delete', '"/api/v1/trust-management/principal-identities/%s"%pId'),
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "name":   .display_name,
                "id":     .id,
                "certId": .certificate_id,
                "role":   .role,
                "perm":   .permission_group
            }'''),
    }

    def deletePrincipal(self, namesGlob, ids):
        mgr = self.mgr
        namesGlob, ids = listify(namesGlob), listify(ids)
        principals = self.findByNamesGlob(namesGlob)
        for principal in principals:
            pName, pId = principal['display_name'], principal['id']
            self.logger.info1('Deleting principal "%s"' % pName)
            r = mgr.delete(eval(self.api['delete'].url))
            if not mgr.checkForError(r):
                self.logger.info1('Deleted  principal "%s"' % pName)

    def createPrincipal(self, fqName, certId, desc='', perm='read_write_api_users', role='enterprise_admin'):
        mgr = self.mgr
        name, node = fqName.split('@')
        self.logger.info1('Creating principle "%s" w/Cert "%s"' % (name, certId))
        jsonDict = {
            "name" : name,
            "node_id" : node,
            "permission_group" : perm,
            "role" : role,
            "certificate_id" : certId
        }
        r = mgr.post(self.api['create'].url, data=json.dumps(jsonDict))
        if not mgr.checkForError(r):
            self.logger.info1('Created  principle "%s" w/Cert "%s"' % (name, certId))


class Global(Network_object):
    api = {
        'list':                     Api('get',     '/api/v1/global-configs'),
        'getSwitchingConfig':       Api('get',     '/api/v1/global-configs/SwitchingGlobalConfig'),
        'getRoutingConfig':         Api('get',     '/api/v1/global-configs/RoutingGlobalConfig'),
        'getEsxOpaqueConfig':       Api('get',     '/api/v1/global-configs/EsxGlobalOpaqueConfig'),
        'getFipsConfig':            Api('get',     '/api/v1/global-configs/FipsGlobalConfig'),
        'getOperationCollectorConfig':     Api('get',     '/api/v1/global-configs/OperationCollectorGlobalConfig'),
        'getSecurityConfig':        Api('get',     '/api/v1/global-configs/SecurityGlobalConfig'),
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "name": .display_name,
                "resource_type":   .resource_type,
                "physical_uplink_mtu": (.physical_uplink_mtu // ""),
                "global_replication_mode_enabled": (if .global_replication_mode_enabled==null then "" else .global_replication_mode_enabled end),
                "l3_forwarding_mode": (.l3_forwarding_mode // ""),
                "logical_uplink_mtu": (.logical_uplink_mtu // "")
            }'''),
        }



class Certificate(Network_object):
    listUrl='/api/v1/trust-management/certificates'
    #resType = ['certificate_ca', 'certificate_signed', 'certificate_self_signed']
    api = {
        'list':     Api('get',     '/api/v1/trust-management/certificates'),
        'get':      Api('get',    '"/api/v1/trust-management/certificates/%s"%certId'),
        'delete':   Api('delete', '"/api/v1/trust-management/certificates/%s"%certId'),
        'import':   Api('post',    '/api/v1/trust-management/certificates?action=import'),
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "name": .display_name,
                "id":   .id,
                "type/desc": ((.resource_type+"\n "+.description)|rtrimstr("\n ")),
                "usedBy": (if .used_by
                    then ([
                        .used_by[] | ((.service_types|join(","))+": "+
                            (.node_id | (if (contains("policy")) then "policy_node"  else . end))
                        ) ]|join(",\n"))
                    else "" end)
            }'''),
    }

    def find(self, name, types=None, display=False):
        if not types:
            return self.findByName(name=name,display=display)

        certs = self.list(display=False)
        for c in certs['results']:
            if c['display_name'] != name:
                continue
            if c['resource_type'] in types:
                return c
        return None


    def readCert(self,filename):
        fp = open(filename,'r')
        return fp.read()

    def applyHttpCert(self,name):
        #cert = self.findByName(restUrl='/api/v1/trust-management/certificates',
        #                       name=name,
        #                       display=False)
        cert = self.find(name=name, types=['certificate_signed', 'certificate_self_signed'],
                         display=False)
        if not cert:
            print("Certificate %s not found" %name)
        else:
            restUrl='/api/v1/node/services/http?action=apply_certificate&certificate_id=%s'\
                %cert['id']
            #print(cert['display_name'])
            #print(cert['id'])
            r = self.rest_api(api=restUrl,method="POST",display=True)
            print(r.status_code)



    def importCertificate(self, name, cert, key=None, passphrase=None, description=None):
        restUrl = '/api/v1/trust-management/certificates?action=import'

        data={}
        data['display_name'] = name
        if description:
            data['description'] = description
        if passphrase:
            data['passphrase'] = passphrase
        if key:
            data['private_key'] = self.readCert(filename=key)
        data['pem_encoded'] = self.readCert(filename=cert)
        #print ("Calling certificate add")
        r = self.rest_api(api=restUrl,method='POST',display=True,
                          data=data)
        #print (r.status_code)

    def delete(self,name,id=None):
        restUrl = None
        if id:
            restUrl = '/api/v1/trust-management/certificates/%s'%id
        else:
            cert=self.findByName(restUrl='/api/v1/trust-management/certificates',
                                 name=name, display=False)
            if cert:
                restUrl='/api/v1/trust-management/certificates/%s'%cert['id']
        if not restUrl:
            print("No certificate found")
            return
        r = self.rest_api(api=restUrl,method="DELETE",display=False)
        if r.status_code == 200:
            print("Successfully deleted")
        else:
            print("Delete failed with code: %d" %r.status_code)


class Firewall(Network_object):
    resType = 'Firewall'
    api = {
        'listSection':   Api('get', '"/api/v1/firewall/sections?exclude_applied_to_type=LogicalRouter&type=%s"%fwtype'),
        'listL3Section': Api('get', '/api/v1/firewall/sections?exclude_applied_to_type=LogicalRouter&type=LAYER3'),
    }

    ptblFmts = {
        'listL3Section': PtblFmt(api['listL3Section'].url, '''
            def shortUuid:if . then .[:4]+".."+.[-4:] else "" end;
            .results[] | {
                "name":     .display_name,
                "id":       .id,
                "default":  .is_default,
                "type":     .resource_type,
                "ruleCnt":  .rule_count,
                "sectType": .section_type,
                "stateful": .stateful,
            }
        '''),
    }

    def listSections(self,fwtype="LAYER3", display=True, brief=False):
        '''
        Only deals with DFW
        '''
        restUrl='/api/v1/firewall/sections?exclude_applied_to_type=LogicalRouter&type=%s' % fwtype

        if display and not brief:
            res = self.list(restUrl=restUrl,display=True)
        else:
            res = self.list(restUrl=restUrl,display=False)
            print("Total sections: %d" %res['result_count'])
            ind = 0
            for i in res['results']:
                print("%d. Name: %s" %(ind,i['display_name']))
                print("   ID: %s" %i['id'])
                print("   Tyle: %s  Stateful: %s" %(i['section_type'],i['stateful']))
                print("   Rule Count: %d" %i['rule_count'])
                ind+=1
                print ("   Applied Tos:")
                if not 'applied_tos' in i:
                    print("")
                    continue
                for a in i['applied_tos']:
                    print("      Target: %s" %a['target_display_name'])
                    print("      TargetID: %s" %a['target_id'])
                    print("      Type: %s" %a['target_type'])
                    print("")
        return res

    def listSectionRules(self,name=None,id=None,
                         fwtype="LAYER3",display=True,brief=False):
        '''
        List the rules in section by name.  If section ID is provided, always use that.
        Otherwise, provide name for section search.
        Minimal name or ID must be provided
        '''
        if name and not id:
            section = self.findSection(name=name,fwtype=fwtype,display=False)
            if not section:
                print ("Firewall section %s of type %s not found"
                       %(name, fwtype))
                return None
            else:
                id=section['id']

        restUrl='/api/v1/firewall/sections/%s/rules' %id
        return self.list(restUrl=restUrl,display=display,brief=brief)



    def findSection(self,name,fwtype="LAYER3",display=True):
        restUrl='/api/v1/firewall/sections?type=%s&page_size=1000' %fwtype
        section = self.findByName(restUrl=restUrl,name=name,display=display)
        return section


    def deleteSection(self,name,fwtype="LAYER3", display=True):
       qstr = "resource_type:FirewallSection AND display_name:%s" %name
       section=self.search(qstr=qstr,resource="FirewallSection", name=name)

       if section:
           restUrl='/api/v1/firewall/sections/%s?cascade=True' %section['id']
           r=self.rest_api(api=restUrl,method='DELETE', display=display)
           if r.status_code != 200:
               print("Firewall section %s delete failed with code: %d"
                     %(name,r.status_code))
       else:
           if display:
               print("Section to delete not found: %s" %(name))

    def addSection(self,name,op,opsection,desc,fwtype,state,tags, update=False):
        '''
        This does not support apply-to on create.
        Use method to add new apply-to after create.
        '''
        qstr = "resource_type:FirewallSection AND display_name:%s" %name

        section=self.search(qstr=qstr,resource="FirewallSection", name=name)

        if not update and section:
            print("DFW Section %s already exist" %name)
            return
        sect=None
        if op == 'insert_before' or op=='insert_after':
            if not opsection:
                print ("Section must be specified with insert before/after")
                return False
            sect = self.findSection(name=opsection,fwtype=fwtype,display=False)
            if not sect:
                print ("Firewall section '%s' not found" %opsection)
                return False

        if section:
            restUrl='/api/v1/firewall/sections/%s' %section['id']
        elif sect:
            restUrl='/api/v1/firewall/sections?operation=%s&id=%s' %(op,sect['id'])
        elif op=='insert_bottom' or op=='insert_top':
            restUrl='/api/v1/firewall/sections?operation=%s' %op
        else:
            restUrl='/api/v1/firewall/sections'


        if section:
            data=section
        else:
            data={}
        data['display_name'] = name
        if desc:
            data['description'] = desc
        data['section_type'] = fwtype
        data['stateful'] = state

        if tags:
            tag=Tags(mgr=self.mgr)
            data['tags'] = tag.createFromList(tagnames=tags)
        if section:
            r=self.rest_api(api=restUrl,method='PUT', data=data,display=True)
            ret = 200
        else:
            r=self.rest_api(api=restUrl,method='POST',data=data,display=True)
            ret = 201
        if r.status_code != ret:
            print ("Firewall section creation/update failed: %d" %r.status_code)

    def delSectionApplyTo(self,name,target,targettype,fwtype="LAYER3",
                          deleteall=False,display=False):
        sect = self.findSection(name=name,fwtype=fwtype,display=False)
        if not sect:
            print("Section with name %s not found" %name)
            return False

        if not deleteall:
            res = ResourceReference(mgr=self.mgr)
            field = res.create(target=target,targettype=targettype,display=False)

            if not field:
                print ("Can't find the target object")
                return False

        if 'applied_tos' in sect:

            if not deleteall:
                found=res.inList(sources=sect['applied_tos'],id=field['target_id'])
                if found:
                    sect['applied_tos'].remove(found)

                else:
                    print("Resource %s of type not found in section %s's apply-to list"
                          %(target, name))
                    return False
            else:
                del sect['applied_tos']

            restUrl = '/api/v1/firewall/sections/%s' %sect['id']
            r = self.rest_api(api=restUrl,method="PUT",data=sect,display=True)
            if r.status_code != 200:
                print("Return code was not 200: %d" %r.status_code)
                return False
            else:
                print("Deleted")
                return True

        return False


    def addSectionApplyTo(self,name,target,targettype,fwtype="LAYER3"):
        sect = self.findSection(name=name,fwtype=fwtype,display=False)
        if not sect:
            print("Section with name %s not found" %name)
            return False

        res = ResourceReference(mgr=self.mgr)
        field = res.create(target=target,targettype=targettype,display=False)

        if not field:
            return False
        if 'applied_tos' in sect:
            if res.inList(sources=sect['applied_tos'],id=field['target_id']):
                print("Object already in applied to list")
                return False


            sect['applied_tos'].append(field)
        else:
            sect['applied_tos'] = [field]
        restUrl = '/api/v1/firewall/sections/%s' %sect['id']
        r = self.rest_api(api=restUrl,method="PUT",data=sect,display=True)
        if r.status_code != 200:
            print("Return code was not 200: %d" %r.status_code)
            return False
        else:
            return True

    def findRuleByName(self,sectionId,name):
        restUrl='/api/v1/firewall/sections/%s/rules' %sectionId
        return self.findByName(restUrl=restUrl,name=name,display=False)

    def findRuleById(self,sectionId,id):
        restUrl='/api/v1/firewall/sections%s/rules' %sectionId
        return self.findById(restUrl=restUrl,id=id,display=False)

    def delRuleFromSection(self,
                           sectionName,
                           name,
                           id,
                           fwtype="LAYER3"):
        if not name and not id:
            print("Either name or ID must be provided")
            return False

        section = self.findSection(name=sectionName,
                                   fwtype=fwtype,
                                   display=False)
        if not section:
            print("Firewall section of type %s name %s not found"
                  %(fwtype,sectionName))
            return False

        if not id:
            rule=self.findRuleByName(sectionId=section['id'],name=name)
            if not rule:
                print("Can't find rule by name %s in section %s of type %s"
                      %(name,sectionName,fwtype))
                return False
            id = rule['id']

        restUrl=('/api/v1/firewall/sections/%s/rules/%s'
                 %(section['id'],id))

        r = self.rest_api(method='DELETE',api=restUrl)
        if r.status_code != 200:
            print("Delete firewall rule with section %s and id failed %s, name: %s"
                  %(sectionName,id,name))
            return False
        return True

    def addSrcDstToRule(self,
                         sectionName,
                         ruleId,
                         sources,
                         destinations,
                         fwType='LAYER3'):


        section=self.findSection(name=sectionName,
                                 fwtype=fwtype,
                                 display=False)
        if not section:
            print("Section %s not found." %sectioinName)
            return None

        data = self.findRuleById(sectionId=section['id'], id=ruleId)
        if not data:
            print("Rule id %s not found in section %s" %(ruleId,sectionName))
            return None

        rule = FireWallRule(mgr=self.mgr,current=data)
        if sources:
            for s in sources:
                reftype,ref,exclude=self.parseSrcDst(value=s)
                r = rule.addSrcDest(sdtype=reftype,
                                values=ref,
                                field=FirewallSpec.SRCDST_SRC,
                                negation=exclude)
                if not r:
                    print("Invalid source spec...quiting")
                    return None
        if destinations:
            for d in destinations:
                reftype,ref,exclude=self.parseSrcDst(value=d)
                r = rule.addSrcDest(sdtype=reftype,
                                    values=ref,
                                    field=FirewallSpec.SRCDST_DST,
                                    negation=exclude)
                if not r:
                    print("Invalid destination spec...quiting")
                    return None

        restUrl = ('/api/v1/firewall/sections/%s/rules/%d'
                   %(section['id'], rule['id']))
        r = self.rest_api(method='PUT', data=rule.rule,
                          api=restUrl,display=True)
        if r.status_code != 200:
            print ("Modify rule src/dst failed with code %d" % r.status_code)
            return None
        else:
            return rule.rule

    def addServiceToRule(self,
                         sectionName,
                         ruleId,
                         services,
                         fwType='LAYER3'):
        section=self.findSection(name=sectionName,
                                 fwtype=fwtype,
                                 display=False)
        if not section:
            print("Section %s not found." %sectioinName)
            return None

        data = self.findRuleById(sectionId=section['id'], id=ruleId)
        if not data:
            print("Rule id %s not found in section %s" %(ruleId,sectionName))
            return None

        rule = FireWallRule(mgr=self.mgr,current=data)

        if services:
            for s in services:
                r = rule.addService(name=s)
                if not r:
                    print("Invalid service spec...quiting")
        restUrl = ('/api/v1/firewall/sections/%s/rules/%d'
                   %(section['id'], rule['id']))
        r = self.rest_api(method='PUT', data=rule.rule,
                          api=restUrl,display=True)
        if r.status_code != 200:
            print ("Modify rule src/dst failed with code %d" % r.status_code)
            return None
        else:
            return rule.rule



    def addRuleToSection(self,
                         sectionName,
                         name,
                         description,
                         direction,
                         protocol,
                         sources,
                         destinations,
                         services,
                         log,
                         insertType,
                         referenceId,
                         action,
                         update=False,
                         dupcheck=False,
                         fwtype="LAYER3"):


        '''
        sources and destination in the format of type:value:exclude
        where type is resource reference, value is of the type - the
        only literal accepted would be for IPv4Address.
        exclude could be true or false - false by default if not
        specified. So minimum format is type:value

        The value can be a comma seperated list of values of the same
        reference type using the same exclude flag.
        '''
        #qstr = "resource_type:FirewallSection AND display_name:%s" %sectionName
        #section=self.search(qstr=qstr,resource="FirewallSection", name=sectionName)
        section=self.findSection(name=sectionName,fwtype=fwtype,display=False)
        if not section:
            print("Section %s not found." %sectionName)
            return None

        if insertType in [FirewallSpec.INSERT_BEFORE,
                          FirewallSpec.INSERT_AFTER] and not referenceId:
            print("Firewall insert type of %s requires non-empty reference rule ID"
                  %insertType)
            return None

        doUpdate=False
        if not dupcheck and not update:
            rule = FirewallRule(mgr=self.mgr)
        else:
            r=self.findRuleByName(sectionId=section['id'], name=name)
            if r:
                if not update and dupcheck:
                    print("Existing rule with name %s already exist in section %s, update not specified"
                          %(name,section['display_name']))
                    return
                else:
                    doUpdate=True
                    rule=FirewallRule(mgr=self.mgr,current=r)

            else:
                rule=FirewallRule(mgr=self.mgr)
        if doUpdate:
            restUrl='/api/v1/firewall/sections/%s/rules/%s'%(section['id'], rule.getVal('id'))
        elif insertType in ["insert_before", "insert_after"]:
            restUrl='/api/v1/firewall/sections/%s/rules?operation=%s&id=%s' \
                %(section['id'],insertType,referenceId)
        else:
            restUrl='/api/v1/firewall/sections/%s/rules?operation=%s' \
                %(section['id'],insertType)

        if name:
            rule.setName(name=name)
        if description:
            rule.setDescription(description=description)

        rule.setDirection(direction=direction)

        rule.setIpProtocol(proto=protocol)

        if sources:
            for s in sources:
                reftype,ref,exclude=self.parseSrcDst(value=s)
                r = rule.addSrcDest(sdtype=reftype,
                                values=ref,
                                field=FirewallSpec.SRCDST_SRC,
                                negation=exclude)
                if not r:
                    print("Invalid source spec...quiting")
                    return
        if destinations:
            for d in destinations:
                reftype,ref,exclude=self.parseSrcDst(value=d)
                r = rule.addSrcDest(sdtype=reftype,
                                    values=ref,
                                    field=FirewallSpec.SRCDST_DST,
                                    negation=exclude)
                if not r:
                    print("Invalid destination spec...quiting")
                    return

        if services:
            for s in services:
                r = rule.addService(name=s)
                if not r:
                    print("Invalid service spec...quiting")


        rule.setLogging(log=log)
        rule.setAction(action=action)
        print (restUrl)
        print (rule.rule)
        print (self.json_print(rule.rule, convert=False))
        if doUpdate:
            method="PUT"
        else:
            method="POST"

        r = self.rest_api(method=method, data=rule.rule,
                          api=restUrl)
        if r.status_code != 200:
            print ("Firewall creation failed with, code: %d" %r.status_code)


    def parseSrcDst(self,value):
        '''
        Takes colon seperated string in format of "reftype:value:negation".
        The third field is optional and defaults to false.
        The 2nd field is a comma seperated list
        '''
        values = value.split(':')
        if len(values) not in [2,3]:
            raise ValueError("Format of resource type, value, negation invalid")

        ref = values[0].lower()
        if ref == "ipv4address":
            reftype = FirewallSpec.RSC_IP
        elif ref == "logicalswitch":
            reftype = FirewallSpec.RSC_LS
        elif ref == "logicalport":
            reftype = FirewallSpec.RSC_LP
        elif ref == "ipset":
            reftype = FirewallSpec.RSC_IPSET
        elif ref == "nsgroup":
            reftype = FirewallSpec.RSC_NSG
        else:
            raise ValueError("Unsupported reference type of %s" % ref)

        names = values[1].split(',')
        names = [n.strip() for n in names if n.strip()]

        exclude = False
        if len(values) == 3:
            negation = values[2].lower()
            if negation not in ['true','false']:
                raise ValueError("Negation paramter %s is not of true/false" %negation)
            if negation == 'true':
                exclude = True


        return ref, names, exclude














class FirewallSpec(Enum):
    SRCDST_SRC = 1
    SRCDST_DST = 2
    SRCDST_BOTH = 3

    DIR_IN="IN"
    DIR_OUT="OUT"
    DIR_BOTH="IN_OUT"

    IP_IPV4="IPV4"
    IP_IPV6="IPV6"
    IP_BOTH="IPV4_IPV6"

    ACTION_ALLOW="ALLOW"
    ACTION_DROP="DROP"
    ACTION_REJECT="REJECT"

    TRUE="True"
    FALSE="False"

    RSC_IP="IPv4Address"
    RSC_IPSET="IPSet"
    RSC_LP="LogicalPort"
    RSC_LS="LogicalSwitch"
    RSC_NSG="NSGroup"

    FW_L2="LAYER2"
    FW_L3="LAYER3"

    INSERT_TOP="insert_top"
    INSERT_BOTTOM="insert_bottom"
    INSERT_BEFORE="insert_before"
    INSERT_AFTER="insert_after"


class FirewallRule(Network_object):
    resType = 'FirewallRule'
    def __init__(self,mgr,current=None):
        '''
        In T context, let's always deal with FW from perspective of its section
        '''
        super(FirewallRule,self).__init__(mgr=mgr)
        if current:
            self.rule=current
        else:
            self.rule={}


    def getVal(self,key):
        if key in self.rule.keys():
            return self.rule[key]
        else:
            return None

    def setName(self,name):
        self.rule['display_name'] = name
        return True

    def setDirection(self,direction):
        dirs = ["IN","OUT","IN_OUT"]


        if direction not in dirs:
            print("Direction %s not one of possibilities" %direction)
            return False
        self.rule['direction'] = direction
        return True

    def setDescription(self,description):
        self.rule['description'] = description

    def setIpProtocol(self,proto):
        protos = ["IPV4","IPV6","IPV4_IPV6"]

        if proto not in protos:
            print("IP Protocol %s not one of accepted options" %proto)
            return False
        self.rule['ip_protocol'] = proto

    def setLogging(self,log):
        if log:
            self.rule['logged'] = 'True'
        else:
            self.rule['logged'] = 'False'
        return True

    def setTag(self,tag):
        self.rule['rule_tag'] = tag
        return True


    def setAction(self,action):
        actions = ["ALLOW","DROP","REJECT"]

        if action not in actions:
            print("Action %s not one of accepted options" %action)
            return False
        self.rule['action'] = action

    def addSrcDest(self,sdtype,values,field, negation=False):
        '''
        sdtype = resource type.  Supports only one sdtype for entire list of values
        values = list of values of this resource type
        field = apply to source,dst,or both
        negation = if True, set to exclude the value
        '''
        rsco = ResourceReference(mgr=self.mgr)
        for i in values:
            rsc = rsco.create(target=i,targettype=sdtype,display=False)
            if not rsc:
                '''
                Do we need to show an error here and break, or show error and continue
                or silent continue?
                '''
                print("Source/Destination resource type of %s named %s not valid"
                      %(sdtype,i))
                return False

            if field == FirewallSpec.SRCDST_BOTH or field == FirewallSpec.SRCDST_SRC:
                if not 'sources' in self.rule:
                    self.rule['sources'] = []
                self.rule['sources'].append(rsc)
                if negation:
                    self.rule['sources_excluded'] = 'True'

            if field == FirewallSpec.SRCDST_BOTH or field == FirewallSpec.SRCDST_DST:
                if not 'destinations' in self.rule:
                    self.rule['destinations'] = []
                self.rule['destinations'].append(rsc)
                if negation:
                    self.rule['destination_excluded'] = 'True'

        return self.rule

    def addService(self,name=None,id=None):
        service = NSServices(mgr=self.mgr)
        svg = NSServiceGroups(mgr=self.mgr)
        obj = None
        if id:
            obj = service.findById(id=id,display=False)
            if not obj:
                obj = svg.findById(id=id,display=False)
        elif name:
            obj = service.findByName(name=name, display=False)
            if not obj:
                obj = svg.findByName(name=name,display=False)
        else:
            print("Must provide either valid id or name")
            return False
        if not obj:
            print ("Service or servicegroup %s not found" %name)
            return False
        data={}
        data['target_id'] = obj['id']
        data['target_type']=obj['resource_type']

        if not 'services' in self.rule:
            self.rule['services'] = [data]
        else:
            self.rule['services'].append(data)
        return True



class ResourceReference(Network_object):
    def inList(self,sources,id):
        if not sources:
            return None
        for s in sources:
            if s['target_id'] == id:
                return s
        return None

    def create(self,target,targettype,display=False):
        data = None
        obj=None
        print ("TargetType: %s, %s" %(targettype,target))
        targettype=targettype.lower()
        if targettype=='ipv4address':
            data={}
            data['target_id'] = target
            data['target_type'] = targettype
            return data

        elif targettype=="logicalswitch":
            obj=self.findByName(restUrl='/api/v1/logical-switches',
                                name=target,
                                display=False)
        elif targettype=='logicalport':
            obj=self.findByName(restUrl='/api/v1/logical-ports',
                                name=target,
                                display=False)
        elif targettype=='nsgroup':
            obj=self.findByName(restUrl='/api/v1/ns-groups',
                                name=target,
                                display=False)
        elif targettype=='ipset':
            obj=self.findByName(restUrl='/api/v1/ip-sets',
                                name=target,
                                display=False)
            #print('>>>', target, obj)

        if not obj:
            print("%s with name %s not found" %(targettype,target))
        else:
            data={}
            data['target_id'] = obj['id']
            data['target_type'] = obj['resource_type']

        #print('RETURNING >>>', data)
        return data

class Tags(Network_object):
    ptblFmts = {
        'list': PtblFmt('', '''
            .[] | {
                "name": .display_name,
                "type": .resource_type,
                "tags": (if .tags then [.tags[]|.scope+":"+.tag]|sort|join(", ") else "" end),
            }'''),
    }

    def createFromSpec(self,spec):
        '''
        spec: [<scope>:<tag name>]
        if <scope>: not given, value is consider tagname with no scope
        '''
        tagsList = []
        for i in spec:
            vals=i.split(':')
            if len(vals) == 1:
                tagsList+=self.createFromList(tagnames=[vals[0]])
            elif len(vals) == 2:
                tagsList+=self.createFromList(tagnames=[vals[1]],
                                                    scope=vals[0])
            else:
                raise ValueError('Incorrect tag spec format: %s' %i)
        return tagsList

    def convertToSpec(self,tags,display=False):
        specList = []
        for t in tags:
            spec=''
            if 'scope' in t:
                spec='%s:' %t['scope']
            else:
                spec=':'
            if 'tag' in t:
                spec+='%s' %['tag']
            else:
                spec+=''
            specList.append(spec)
        if display:
            for s in specList:
                print(s, end=' ')
            print ('')
        return specList


    def createFromList(self,tagnames,scope=None):
        tags = []
        for n in tagnames:
            tag={}
            if scope:
                tag['scope']=scope
            tag['tag'] = n
            tags.append(tag)

        if len(tags) > 0:
            return tags
        else:
            return None

    ptblFmts = {
        'list': PtblFmt('', '''
            .[] | {
                "name": .display_name,
                "type": .resource_type,
                "tags": (if .tags then
                    [.tags[]|.scope+":"+.tag]|sort|join(", ")
                    else "" end),
            }'''),
    }

    def tagOp(self, op, tags=None, resType=None, resNamesGlob=None,
              parentId=None, parentName=None):
        ''' op: add, set, delete, clear, list, jq'''
        resTypeMap = {
            'edge':     ResTypeMap('EdgeNode', EdgeNode),
            'host':     ResTypeMap('HostNode', FabricNode),
            'ippool':   ResTypeMap('IpPool', Pools),
            #'lp':       ResTypeMap('LogicalPort', SwitchPorts),
            'lr':       ResTypeMap('LogicalRouter', LogicalRouter),
            'ls':       ResTypeMap('LogicalSwitch', Switch),
            'lsp':      ResTypeMap('LogicalPort', SwitchPorts),
            'nsgroup':  ResTypeMap('NSGroup', NSGroups),
            'vm':       ResTypeMap('VirtualMachine', VM),
            'tz':       ResTypeMap('TransportZone', Transportzone),
        }

        nTags = tags.split(',') if tags else []

        self.logger.info1('%s tag "%s" to "%s": "%s"' % (op, tags, resType, resNamesGlob))
        #print('class = %s' % resTypeMap[resType].nsxvClass)
        objInst = resTypeMap[resType].nsxvClass(mgr=self.mgr)

        search = Search(mgr=self.mgr, display=False)
        #queryStr = _jqResOrCrit0(resTypeMap[resType].apiResType, 'display_name', resNamesGlob)
        #print(queryStr)
        queryStr = _jqResOrCrit(resTypeMap[resType].apiResType, 'display_name', resNamesGlob)
        #print(queryStr)

        if op in ['list', 'jq']:
            tagQuery = _mkTagQuery(nTags)
            #print('tagQuery = %s' % tagQuery)

            if tagQuery:
                queryStr += ' AND '+tagQuery
            #print(queryStr)
            objs = search.query(queryStr)['results']
            if op == 'list':
                pprint(objs)
            elif op == 'jq':
                self.jqTable(objs)
            return objs

        if resType == 'vm':
            vm =VM(self.mgr)
            vm.tagOp(op, tags, vmNamesGlob=resNamesGlob)
            return

        objs = search.query(queryStr)['results']
        parent=None
        if resType == 'lsp':
            # Require to specify the switch name or ID.  Don't want to mis-tag ports
            # because a VM with multiple NICs will have same name on multiple switches
            if not parentId and not parentName:
                print("Must specify the switch name or ID when tagging switchports")
                return
            parent=self.findById(restUrl='/api/v1/logical-switches',
                                 id=parentId,display=False)
            if parentId:
                parent=Sw.findById(id=parentId)
            if not parent and parentName:
                parent=self.findByName(restUrl='/api/v1/logical-switches',
                                       name=parentName, display=False)
            if not parent:
                print("Parent logical switch not found, nothing done")
                return

        for obj in objs:
            if resType == 'lsp' and obj['logical_switch_id'] != parent['id']:
                continue

            if resType in ['ls', 'lr', 'lsp']:
                del obj['status']

            rTags = obj.get('tags', [])
            #print('rTags = %s' % rTags)
            if op=='add':
                for nTag in nTags:
                    tScope,tTag = nTag.split(':')
                    rTags.append({'scope':tScope,'tag':tTag})
            elif op=='set':
                rTags = []
                for nTag in nTags:
                    if not nTag: continue
                    tScope,tTag = nTag.split(':')
                    rTags.append({'scope':tScope,'tag':tTag})
            elif op=='clear':
                rTags = []
            elif op=='delete':
                dTags = []
                for nTag in nTags:
                    tScope,tTag = nTag.split(':')
                    dTags.append({'scope':tScope,'tag':tTag})
                rTagSet = set([tuple(d.items()) for d in rTags])
                dTagSet = set([tuple(d.items()) for d in dTags])
                rTags = [dict(t) for t in rTagSet-dTagSet]
            obj['tags'] = rTags
            objId = obj['id']
            restUrl = eval(objInst.api['update'].url)
            restMethod = objInst.api['update'].method
            #print('nTags = %s' % nTags)
            #print('rTags = %s' % rTags)
            #print('url = %s' % restUrl)
            r = self.rest_api(restUrl, method=restMethod, data=obj)
            self.mgr.checkForError(r)
            #self.mgr.dumpResquestsResponse(r)



class NSServices(Network_object):
    resType = 'NSService'
    listUrl = '/api/v1/ns-services'
    api = {
        'list':      Api('get',    '/api/v1/ns-services'),
        'create':    Api('post',   '/api/v1/ns-services'),
        'delete':    Api('post',  '"/api/v1/ns-services/%s"%objId'),
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "name": .display_name,
                "id":   .id,
                "element": (.nsservice_element | (
                    if .l4_protocol then
                        (.l4_protocol +"/"+
                        (if .source_ports then .source_ports|join(",") else "" end) +"/"+
                        (if .destination_ports then .destination_ports|join(",") else "" end))
                    elif .alg then "alg"+"/"+.alg+"/"+(.destination_ports|join(","))
                    elif .protocol=="ICMPv4" or .protocol=="ICMPv6" then
                        .protocol+"/"+(.icmp_type|tostring)+"/"+((.icmp_code//"")|tostring)
                    elif .resource_type=="IGMPTypeNSService" then .resource_type
                    else .resource_type
                    end)),
                "system":   .default_service,
            }'''),
    }

    def createNSService(self, nsserviceSpec, update=False):
        '''
            name : desc : proto : srcPorts : dstPorts
            name : desc : "ICMPv{4,6}" : icmpType : icmpCode
            name : desc : IGMP
            name : desc : ETHER : ether_type
            name : desc : ALG : alg_type : alg_sourceport : alg_dstport
            name : desc : IP : ip_proto_num

            Sample nsserviceSpec :
                mySvc1 : mySvcDesc : TCP : 1234,5678 : ;
                mySvc2 : mySvcDesc2 : UDP :  : 1234,5678;
                mySvc3 : mySvcDesc3 : ICMPv4 : 0 : 0;
                mySvc4 : mySvcDesc4 : ICMPv6 : 1;
                mySvc5 : mySvcDesc5 : ICMPv6 : 2 : 0;
        '''
        #nsserviceSpec = 'mySvc1:mySvcDesc:TCP:1234,5678:'
        for nssSpec in [s.strip() for s in nsserviceSpec.split(';')]:
            if not nssSpec: continue
            comps = [c.strip() for c in nssSpec.split(':')]
            self.logger.info3(comps)
            jsonDict = {}
            jsonDict['display_name'] = nsName = comps.pop(0)

            # elastic search doesn't work properly when there is / in string
            #qstr = "resource_type:NSService AND display_name:%s" %nsName
            #nss=self.search(qstr=qstr,resource="NSService", name=nsName)
            nss = self.findByName(name=nsName,display=False)

            if nss and not update:
                print("NSService with name %s already exist" % nsName)
                return
            if nss:
                jsonDict=nss

            jsonDict['description'] = nsDesc = comps.pop(0)
            nsElement = jsonDict['nsservice_element'] = {}
            nsProto = comps.pop(0).upper()
            if nsProto in ['TCP', 'UDP']:
                nsElement['resource_type'] = 'L4PortSetNSService'
                nsElement['l4_protocol'] = nsProto
                nsSrcPorts = [p for p in comps.pop(0).split(',') if p]
                nsDstPorts = [p for p in comps.pop(0).split(',') if p]
                if nsSrcPorts: nsElement['source_ports'] = nsSrcPorts
                if nsDstPorts: nsElement['destination_ports'] = nsDstPorts
            elif nsProto in ['ICMPV4', 'ICMPV6']:
                nsIcmpType = int(comps.pop(0))
                nsElement['resource_type'] = 'ICMPTypeNSService'
                nsElement['protocol'] = 'ICMPv4' if nsProto=='ICMPV4' else 'ICMPv6'
                nsElement['icmp_type'] = nsIcmpType
                if comps and comps[0].strip()!='':
                    nsIcmpCode = int(comps.pop(0).strip())
                    nsElement['icmp_code'] = nsIcmpCode
            elif nsProto in ['ALG']:
                alg = comps.pop(0).strip().upper()
                if alg not in ['ORACLE_TNS', 'SUN_RPC_TCP', 'SUN_RPC_UDP',
                               'MS_RPC_TCP', 'MS_RPC_UDP', 'FTP',
                               'NBNS_BROADCAST', 'NBDG_BROADCAST', 'TFTP']:
                    self.logger.error("ALG %s not supported" %alg)
                    return
                nsElement['resource_type'] = 'ALGTypeNSService'
                nsElement['alg'] = alg
                sport = comps.pop(0).strip()
                if sport != '':
                    nsElement['source_ports']=listify(int(sport))
                dport = comps.pop(0).strip()
                if dport=='':
                    self.logger.error("ALG destination port cannot be empty")
                    return
                nsElement['destination_ports']=listify(int(dport))
            elif nsProto in ['IGMP']:
                nsElement['resource_type'] = 'IGMPTypeNSService'
            elif nsProto in ['IP']:
                nsElement['resource_type'] = 'IPProtocolNSService'
                proto = comps.pop(0).strip()
                if proto == '':
                    self.logger.error("IP Protocol number cannot be blank")
                    return
                nsElement['protocol_number'] = int(proto)
            elif nsProto in ['ETHER']:
                nsElement['resource_type'] = 'EtherTypeNSService'
                proto = comps.pop(0).strip()
                if proto == '':
                    self.logger.error("Ethernet type number cannot be blank")
                    return
                nsElement['eth_type'] = int(proto)
            else:
                self.logger.error('Protocol %s supported by this script' % nsProto)

            if nsElement == {}:
                del jsonDict['nsservice_element']

            self.logger.info4(jsonDict)
            #pprint_od(jsonDict)

            if nss:
                restUrl='/api/v1/ns-services/%s' % nss['id']
                method='PUT'
            else:
                restUrl='/api/v1/ns-services'
                method='POST'

            r = self.rest_api(api=restUrl, method=method, data=jsonDict, display=False)
            self.mgr.checkForError(r)


class NSServiceGroups(Network_object):
    resType = 'NSServiceGroup'
    listUrl='/api/v1/ns-service-groups'
    api = {
        'list':      Api('get',     '/api/v1/ns-service-groups'),
        'create':    Api('post',    '/api/v1/ns-service-groups'),
        'delete':    Api('delete', '"/api/v1/ns-service-groups/%s"%objId'),
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "name":   .display_name,
                "id":     .id,
                "member": ([.members[] | .target_id+" "+.target_display_name] | join(",\n")),
            }'''),
    }

    def createNSServiceGroup(self, nsservicegroupSpec, update=False):
        '''
            name : desc : svcNames : svcIds : svcGrpNames : svcGrpIds;
        '''
        #nsservicegroupSpec= '''
        #    mySvcGrp1 : mySvcGrpDesc :  :  : Heartbeat,View 5.x : 6525a2c3-32a8-4560-84fd-0fe3482b845b;
        #    mySvcGrp2 : mySvcGrpDesc2 : AD Server,FTP :  : Heartbeat,View 5.x : ;
        #    mySvcGrp3 : mySvcGrpDesc3 :  : ed5d47fc-3d90-461d-bc78-9be38cf2d1b9,2a71e150-9539-4636-a666-4ccd918441ef :  : d671c7cb-3746-446c-99ca-40fba5b85893,9e39aff9-c308-433d-9774-fbcaf3f25b5c;
        #'''
        #nsservicegroupSpec= ''' mySvcGrp2 : mySvcGrpDesc2 :  :  : Heartbeat : ; '''
        #nsservicegroupSpec= ''' mySvcGrp2 : mySvcGrpDesc2 : AD Server,FTP : 886e7916-54a8-43fd-b30d-105b339a2681 :  : ; '''
        for nssgSpec in [s.strip() for s in nsservicegroupSpec.split(';')]:
            #print('nssgSpec = %s' % nssgSpec )
            if not nssgSpec: continue
            self.logger.info3(nssgSpec.split(':'))
            nssgName, nssgDesc, nssgNsMbrNames, nssgNsMbrIds, nssgNsMbrGrpNames, nssgNsMbrGrpIds = [
                c.strip() for c in nssgSpec.split(':')]
            jsonDict = {}
            jsonDict['display_name'] = nssgName
            #qstr = "resource_type:NSServiceGroup AND display_name:'%s''" %nssgName
            #nssGroup=self.search(qstr=qstr,resource="NSServiceGroup", name=nssgName)
            nssGroup = self.findByName(name=nssgName, display=False)
            if nssGroup and not update:
                print("NSGroup with name %s already exist" % nssgName)
                return
            if nssGroup:
                jsonDict = nssGroup
            jsonDict['description'] = nssgDesc
            jsonDict['members'] = []
            nssgNsMbrNames =    [n.strip() for n in nssgNsMbrNames.split(',') if n.strip()]
            nssgNsMbrIds =      [n.strip() for n in nssgNsMbrIds.split(',') if n.strip()]
            nssgNsMbrGrpNames = [n.strip() for n in nssgNsMbrGrpNames.split(',') if n.strip()]
            nssgNsMbrGrpIds =   [n.strip() for n in nssgNsMbrGrpIds.split(',') if n.strip()]


            nssd = NSServices(mgr=self.mgr)
            #print('nssgNsMbrNames = %s' % nssgNsMbrNames)
            #for nssg in nssd.findByNamesGlob(nssgNsMbrNames):
            for nssg in nssd.findByNamesGlob(nssgNsMbrNames)+nssd.findByNamesGlob(nssgNsMbrIds, nameTag='id'):
                #print('display_name>>>', nssg['display_name'])
                jsonDict['members'].append({
                    'target_display_name': nssg['display_name'],
                    'target_id': nssg['id'],
                    'target_type': 'NSService'
                })
            for nssg in self.findByNamesGlob(nssgNsMbrGrpNames)+self.findByNamesGlob(nssgNsMbrGrpIds, nameTag='id'):
                jsonDict['members'].append({
                    'target_display_name': nssg['display_name'],
                    'target_id': nssg['id'],
                    'target_type': 'NSServiceGroup'
                })

            #self.logger.info4(jsonDict)
            #pprint(jsonDict)
            if nssGroup:
                restUrl='/api/v1/ns-service-groups/%s' %nssGroup['id']
                method='PUT'
            else:
                restUrl='/api/v1/ns-service-groups'
                method='POST'

            r = self.rest_api(api=restUrl, method=method, data=jsonDict, display=False)
            self.mgr.checkForError(r)


#class Tag(Network_object):
#    ptblFmts = {
#        'list': PtblFmt('', '''
#            .[] | {
#                "name": .display_name,
#                "type": .resource_type,
#                "tags": (if .tags then
#                    [.tags[]|.scope+":"+.tag]|sort|join(", ")
#                    else "" end),
#            }'''),
#    }
#
#    def tagOp(self, op, tags=None, resType=None, resNamesGlob=None):
#        ''' op: add, set, delete, clear, list, jq'''
#        resTypeMap = {
#            'edge':     ResTypeMap('EdgeNode', EdgeNode),
#            'host':     ResTypeMap('HostNode', FabricNode),
#            'ippool':   ResTypeMap('IpPool', Pools),
#            #'lp':       ResTypeMap('LogicalPort', SwitchPorts),
#            'lr':       ResTypeMap('LogicalRouter', LogicalRouter),
#            'ls':       ResTypeMap('LogicalSwitch', Switch),
#            'lsp':      ResTypeMap('LogicalPort', SwitchPorts),
#            'nsgroup':  ResTypeMap('NSGroup', NSGroups),
#            'vm':       ResTypeMap('VirtualMachine', VM),
#            'tz':       ResTypeMap('TransportZone', Transportzone),
#        }
#
#        nTags = tags.split(',') if tags else []
#
#        self.logger.info1('%s tag "%s" to "%s": "%s"' % (op, tags, resType, resNamesGlob))
#        #print('class = %s' % resTypeMap[resType].nsxvClass)
#        objInst = resTypeMap[resType].nsxvClass(mgr=self.mgr)
#
#        search = Search(mgr=self.mgr, display=False)
#        #queryStr = _jqResOrCrit0(resTypeMap[resType].apiResType, 'display_name', resNamesGlob)
#        #print(queryStr)
#        queryStr = _jqResOrCrit(resTypeMap[resType].apiResType, 'display_name', resNamesGlob)
#        #print(queryStr)
#
#        if op in ['list', 'jq']:
#            tagQuery = _mkTagQuery(nTags)
#            #print('tagQuery = %s' % tagQuery)
#
#            if tagQuery:
#                queryStr += ' AND '+tagQuery
#            #print(queryStr)
#            objs = search.query(queryStr)['results']
#            if op == 'list':
#                pprint(objs)
#            elif op == 'jq':
#                self.jqTable(objs)
#            return objs
#
#        if resType == 'vm':
#            vm =VM(self.mgr)
#            vm.tagOp(op, tags, vmNamesGlob=resNamesGlob)
#            return
#            return
#
#        objs = search.query(queryStr)['results']
#        for obj in objs:
#            if resType in ['ls', 'lr', 'lsp']:
#                del obj['status']
#            rTags = obj.get('tags', [])
#            #print('rTags = %s' % rTags)
#            if op=='add':
#                for nTag in nTags:
#                    tScope,tTag = nTag.split(':')
#                    rTags.append({'scope':tScope,'tag':tTag})
#            elif op=='set':
#                rTags = []
#                for nTag in nTags:
#                    if not nTag: continue
#                    tScope,tTag = nTag.split(':')
#                    rTags.append({'scope':tScope,'tag':tTag})
#            elif op=='clear':
#                rTags = []
#            elif op=='delete':
#                dTags = []
#                for nTag in nTags:
#                    tScope,tTag = nTag.split(':')
#                    dTags.append({'scope':tScope,'tag':tTag})
#                rTagSet = set([tuple(d.items()) for d in rTags])
#                dTagSet = set([tuple(d.items()) for d in dTags])
#                rTags = [dict(t) for t in rTagSet-dTagSet]
#            obj['tags'] = rTags
#            objId = obj['id']
#            restUrl = eval(objInst.api['update'].url)
#            restMethod = objInst.api['update'].method
#            #print('nTags = %s' % nTags)
#            #print('rTags = %s' % rTags)
#            #print('url = %s' % restUrl)
#            r = self.rest_api(restUrl, method=restMethod, data=obj)
#            self.mgr.checkForError(r)
#            #self.mgr.dumpResquestsResponse(r)


class VirtualNetworkInterface(Network_object):
    resType = 'VirtualNetworkInterface'
    api = {
        'list':       Api('get',  '/api/v1/fabric/vifs'),
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "devName":   .device_name,
                "devKey":  .device_key,
                "mac":  .mac_address,
                "IPs":    [.ip_address_info[] | (.source+": "+(.ip_addresses|sort|join(","))) ] | join("\n")
            }'''),
    }
    listUrl = api['list'].url

class VM(Network_object):
    '''
    Note I named it this to not confuse with the VirtualMachine.py stuff
    Intend of this class is to manage tags for security markings
    '''
    resType = 'VirtualMachine'
    api = {
        'list':       Api('get',   '/api/v1/fabric/virtual-machines'),
        'updateTags': Api('post',  '/api/v1/fabric/virtual-machines?action=update_tags')
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "name":   .display_name,
                "extId":  .external_id,
                "power":  .power_state,
                "tags":   (if .tags then [.tags[]|.scope+":"+.tag]|sort|join(", ") else "" end),
            }'''),
    }
    def __init__(self, mgr):
        super(VM,self).__init__(mgr=mgr,
                                listUrl='/api/v1/fabric/virtual-machines')

    def tagOp(self, op, tags, vmNamesGlob, vmExtIds=''):
        ''' op: add, set, delete, list '''
        nTags = tags.split(',')

        vms = self.findByNamesGlob(vmNamesGlob, findMethod='queryString')
        for vm in vms:
            rTags = vm.get('tags', [])
            if op=='add':
                for nTag in nTags:
                    tScope,tTag = nTag.split(':')
                    rTags.append({'scope':tScope,'tag':tTag})
            elif op=='set':
                rTags = []
                for nTag in nTags:
                    if not nTag: continue
                    tScope,tTag = nTag.split(':')
                    rTags.append({'scope':tScope,'tag':tTag})
            elif op=='clear':
                rTags = []
            elif op=='delete':
                dTags = []
                for nTag in nTags:
                    tScope,tTag = nTag.split(':')
                    dTags.append({'scope':tScope,'tag':tTag})
                rTagSet = set([tuple(d.items()) for d in rTags])
                dTagSet = set([tuple(d.items()) for d in dTags])
                rTags = [dict(t) for t in rTagSet-dTagSet]
            jdata = {
                'external_id': vm['external_id'],
                'tags': rTags
            }
            self.rest_api(
                self.api['updateTags'].url,
                method=self.api['updateTags'].method.upper(),
                data=jdata)

    def vmIpList(self, vmNameGlob):
        #vmNameGlob = 'ubuntu_t2_ls9-0160'
        #vmNameGlob = 'ubuntu_t1_ls1-010*'
        #vmNameGlob = 'ubuntu_t*-01*'
        search = Search(self.mgr, display=False)
        jqFilterVm = '''.results[] | {
            "name":     .display_name,
            "id":       .external_id,
            "hostId":   .host_id,
        }'''
        vms = search.query('resource_type:VirtualMachine AND display_name:%s'%vmNameGlob, '.')
        #print('========= vms:')
        #pprint(vms)
        vms = [dict(d) for d in pyjq.all(jqFilterVm, vms)]
        #print('--------- vms:')
        #pprint(vms)
        rows = []
        for vm in vms:
            #print('#### >>>> vm:')
            #pprint(vm)

            vmHosts = search.query('resource_type:TransportNode AND id:%s'%vm['hostId'], '.', display=False)
            vmHostName = vmHosts['results'][0]['display_name'] if vmHosts else ''
            #print('vmHostName = %s' % vmHostName)

            vmName = vm['name']
            # IPs exist for ESXi VM
            #    "IPs":   .ip_address_info[].ip_addresses|sort|join(",\n"),
            jqFilterVif = '''.results[] | {
                "lpAttId":   .lport_attachment_id,
                "IPs": (if .ip_address_info and (.ip_address_info|length)>0 then
                    .ip_address_info[]|.ip_addresses|sort|join(",\n")
                    else "" end),
            }'''
            #print('>>>>> id=>>%s'%vm['id'])
            vifs = search.query('resource_type:VirtualNetworkInterface AND owner_vm_id:%s'%vm['id'], '.')
            #print('========= vifs:')
            #pprint(vifs)
            vifs = [dict(d) for d in pyjq.all(jqFilterVif, vifs)]
            #print('--------- vifs:')
            #pprint(vifs)
            for vif in vifs:
                jqFilterLsp = '''.results[] | {
                    "id":   .id,
                    "lsId": .logical_switch_id,
                }'''
                #print('>>>>> attId=>>%s'%vif['lpAttId'])
                lsps = search.query('resource_type:LogicalPort AND attachment.id:%s'%vif['lpAttId'], '.')
                #print('========= lsps:')
                #pprint(lsps)
                lsps = [dict(d) for d in pyjq.all(jqFilterLsp, lsps)]
                #print('--------- lsps:')
                #pprint(lsps)
                for lsp in lsps:

                    lss = search.query('resource_type:LogicalSwitch AND id:%s'%lsp['lsId'], '.', display=False)
                    lsName = lss['results'][0]['display_name'] if lss else ''
                    #print('lsName = %s' % lsName)

                    #jqFilter = '''.results[] | {
                    #    "id":   .id,
                    #}'''
                    url = '/api/v1/logical-ports/%s/state' % lsp['id']
                    #print(url)
                    r = self.mgr.get(url)
                    self.mgr.checkForError(r)
                    statusDict = r.json()
                    #print('========= state:')
                    #print(r.text)
                    jqFilter = '''.discovered_bindings[] | {
                        "ip_address":   .binding.ip_address,
                    }'''
                    ips = [dict(d) for d in pyjq.all(jqFilter, statusDict)]

                    jqFilter = '''[.discovered_bindings[]|.binding.ip_address]|sort|unique|join(",\n")'''
                    ips = pyjq.all(jqFilter, statusDict)
                    #print('%-20s %s' % (vmName, ips[0]))
                    #    'vifIPs': vif['IPs'],
                    row = {
                        'vmName': vmName,
                        'vifIPs': vif['IPs'],
                        'lsportIPs': ips[0],
                        'host': vmHostName,
                        'ls': lsName,
                    }
                    rows.append(row)
                    #print(row)
        #pprint(rows)
        #    "vifIPs":   .vifIPs,
        jqFilter = '''.results[] | {
            "vmName":   .vmName,
            "vifIPs":   .vifIPs,
            "lsportIPs":   .lsportIPs,
            "host":   .host,
            "ls":   .ls,
        }'''
        ptbl = cptutil.fmtDictsAsPrettytable(rows, colSortKeys=re.findall(r'"([^"]*)"\s*:', jqFilter))
        print(ptbl)
        if ptbl:
            print('Count: %s' % ptbl.rowcount)


class SessionCookie(Network_object):
    #def __init__(self, mgr, sessCookieFile):
    #    super(SessionCookie,self).__init__(mgr=mgr)
    #    self.sessCookieFile = sessCookieFile

    def _create(self, r):
        if 200<=r.status_code<300:
            #pprint(type(r.headers))
            #for k,v in r.headers.items():
            #    print('  %-20s%s' % (k, v))
            with open(self.sessCookieFile, 'w') as f:
                f.write(json.dumps({k:v for k,v in r.headers.items() if k.lower()
                    in ['set-cookie', 'x-xsrf-token', 'date']}))
                self.logger.info4(json.dumps(dict(r.headers)))
                self.logger.info1('cookie: %s' % r.headers['set-cookie'].split()[0])
                self.logger.info1('x-xsrf-token: %s' % r.headers['x-xsrf-token'])
        else:
            self.logger.error('Failed to create session cookie - %d' % r.status_code)
            self.mgr.dumpResquestsResponse(r)

    def create(self):
        if '@' in self.mgr.username:
            url = '/api/v1/eula/acceptance'
            r = self.mgr.get(url)
        else:
            r = self.mgr.post('/api/session/create',
                data='j_username=%s&j_password=%s' % (self.mgr.username,self.mgr.password),
                headers={'Content-Type':'application/x-www-form-urlencoded', 'Accept':'*/*'})
        self._create(r)

    def logout(self):
        r = self.mgr.post('/logout',
            headers={
                'Cookie': self.mgr.sess['cookie'],
                'X-XSRF-TOKEN': self.mgr.sess['xsrfToken'],
            })
        del self.mgr.sess

    #def useSessFile(self):
    #    with open(self.sessCookieFile) as f:
    #        headers = CaseInsensitiveDict(json.loads(f.read()))
    #        if hasattr(self.mgr, 'auth'):
    #            del self.mgr.auth
    #        self.mgr.sess = {
    #            'cookie': headers['set-cookie'].split()[0].strip(';'),
    #            'xsrfToken': headers['x-xsrf-token']
    #        }
    #        self.logger.info2('cookie: %s' % self.mgr.sess['cookie'])
    #        self.logger.info2('x-xsrf-token=%s' % self.mgr.sess['xsrfToken'])
    #        self.mgr._checkNsxtAuth()

class Eula(Network_object):
    def eulaOp(self, op):
        if op=='accept':
            r = self.mgr.post('/api/v1/eula/accept')
            self.mgr.checkForError(r)
        elif op in ['acceptance', 'content']:
            r = self.mgr.get('/api/v1/eula/%s' % op)
            self.mgr.checkForError(r)
            print(r.json()[op])

class Search(Network_object):
    api = {
        'search':    Api('get', '"/api/v1/search?query=%s&cursor=%d"%(queryStr, cursor)'),
        'search_pm': Api('get', '"/policy/api/v1/search?query=%s&cursor=%d"%(queryStr, cursor)'),
    }
    #@memoized
    #@cptutil.memoize
    @memoize
    def query(self, queryStr, jqFilter='', nameGlob='', display=None):
        ''' query: elasticSearch query string, eg:
            tags.scope=Tier&tags.tag=Web
            tags.scope:scope2
            tags.tag:tag2
            tags.scope:scope2 OR tags.tag:tag1
            display_name:VM-*
            display_name:VM-1-11-000?
            resource_type:VirtualMachine
            resource_type:LogicalSwitch
            resource_type:LogicalPort
            resource_type:TransportZone
            resource_type:VirtualMachine
            power_state:VM_RUNNING
            router_type:TIER0
        '''
        self.logger.info2(queryStr)
        uuidSearch = False
        reo = re.match(r'^[0-9a-f]{4,8}..[0-9a-f]{4,12}$', queryStr, re.I)
        if reo:
            queryStr = queryStr.replace('..', '*')
            uuidSearch = True

        if display==None:
            display = self.display if hasattr(self, 'display') else True
        jqFilter = jqFilter or '''.results[] | {
            "name":     .display_name,
            "id/extId": (.id // .external_id),
            "type":     .resource_type,
            "tags":     (if .tags then [.tags[]|.scope+":"+.tag]|sort|join(", ") else "" end),
        }'''
        firstLoop = True
        cursor = count = 0
        while firstLoop or cursor<count:
            url = '/api/v1/search?query=%s&cursor=%d' % (queryStr, cursor)
            self.logger.info2('url=%s' % url)
            #r = self.rest_api(url, method='GET')
            r = self.mgr.get(url)
            self.mgr.checkForError(r)
            #print(r.text)
            rDict = r.json()
            if firstLoop:
                firstLoop = False
                resultDict = rDict
            else:
                resultDict['results'].extend(rDict['results'])
            self.logger.info3(pformat(rDict))
            #pprint(rDict, indent=4); exit()
            count = int(rDict['result_count'])
            if count>0:
                orgCursor = cursor
                cursor = int(rDict['cursor'])
                if nameGlob and jkFilter!='.':
                    jqFilter = re.sub(r'\.display_name',
                        '(.display_name|if test("%s") then . else empty end)' %
                        cptutil.globToRe(nameGlob), jqFilter)

                if jqFilter=='.':
                    if display:
                        pprint(rDict)
                else:
                    if not display:
                       continue
                    #print(type(rDict)); exit()
                    rows = pyjq.all(jqFilter, rDict)
                    if uuidSearch:
                        rePat = queryStr.replace('*', '.*')
                        #print(queryStr, rePat)
                        #pprint_od(rows)
                        #rows = pyjq.all('.[] | (if test("%s") then . else empty end)'%rePat, rows)
                        #print(type(rows))
                        #rows = pyjq.all('.', rows)
                        #pprint_od(rows)

                    ptbl = cptutil.fmtDictsAsPrettytable(rows,
                        colSortKeys=re.findall(r'"([^"]*)"\s*:', jqFilter))
                    if display:
                        print(ptbl)
                        print("Count: %s (%s-%s/%s)" % (
                            (ptbl.rowcount,(orgCursor+1),cursor,count) if ptbl
                            else (0,0,0,0)))
        return resultDict



class ComputeManager(Network_object):
    resType = 'ComputeManager'
    api = {
        'list':       Api('get',     '/api/v1/fabric/compute-managers'),
        'register':   Api('post',    '/api/v1/fabric/compute-managers'),
        'unregister': Api('delete', '"/api/v1/fabric/compute-managers/%s"%cmId'),
        'get':        Api('get',    '"/api/v1/fabric/compute-managers/%s"%cmId'),
        'update':     Api('put',    '"/api/v1/fabric/compute-managers/%s"%cmId'),
        'state':      Api('get',    '"/api/v1/fabric/compute-managers/%s/state"%cmId'),
        'status':     Api('get',    '"/api/v1/fabric/compute-managers/%s/status"%cmId'),
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "name": .display_name,
                "id":   .id,
                "fullName": (.origin_properties[]|select(.key=="fullName")|.value)
            }'''),
        'state': PtblFmt(api['list'].url, '''
            .results[] | {
                "name": .display_name,
                "state": .state,
            }'''),
        'status': PtblFmt(api['list'].url, '''
            .results[] | {
                "name": .display_name,
                "connection": .connection_status,
                "registration": .registration_status,
            }'''),
    }

    def cmOp(self, op, namesGlob):
        if op in ['state', 'status']:
            jdata = []
            for cm in self.findByNamesGlob(namesGlob):
                cmName, cmId = cm['display_name'], cm['id']
                restUrl = eval(self.api[op].url)
                r = self.mgr.get(restUrl)
                self.mgr.checkForError(r)
                jd = r.json()
                jd['display_name'] = cmName
                jdata.append(jd)
            jString = json.dumps({'results':jdata})
            self.jqTable(jString, jqFilter=self.ptblFmts[op].jqFilter)
        elif op == 'unregister':
            cms = self.findByNamesGlob([server], nameTag='server')
            #print(cms)
            cmTuples = [(cm['display_name'], cm['id'], cm['server']) for cm in cms]
            #print(cmTuples)
            for cmName,cmId,cmServer in cmTuples:
                self.logger.info2('Un-Registering ComputeManager "%s"' % server)
                r = self.mgr.delete(eval(self.api['unregister'].url))
                self.mgr.checkForError(r)
                #self.mgr.dumpResquestsResponse(r)

    def register(self, op, server, svrType='vCenter', username='', password='', svrName='', svrThumbprint=''):
        ''' op: register, unregister, update '''
        if op == 'register':
            data = {
                "display_name": svrName or server,
                "server": server,
                "origin_type": svrType,
                "credential" : {
                    "credential_type": "UsernamePasswordLoginCredential",
                    "username": username,
                    "password": password,
                    "thumbprint": svrThumbprint,
                }
            }
            self.logger.info2('Registering ComputeManager "%s" with NSX' % server)
            r = self.mgr.post(self.api['register'].url, data=json.dumps(data))
            #self.mgr.dumpResquestsResponse(r)
            if r.status_code>=400:
                errMsg = json.loads(r._content)['error_message']
                if 'thumbprint' in errMsg:
                    reo = re.search('.*thumbprint is ([0-9A-F:]+)', errMsg)
                    data['credential']['thumbprint'] = reo.group(1)
                    #pprint(data)
                    self.logger.info2('ComputeManager "%s" thumbprint: %s' %
                        (server, data['credential']['thumbprint']))
                    r = self.mgr.post(self.api['register'].url, data=json.dumps(data))
                    self.mgr.checkForError(r)
                else:
                    self.logger.error(errMsg)
        elif op == 'update':
            cms = self.findByNamesGlob([server], nameTag='server')
            cmTuples = [(cm['display_name'], cm['id'], cm['server']) for cm in cms]
            for cmName,cmId,cmServer in cmTuples:
                r = self.mgr.get(eval(self.api['get'].url))
                curData = r.json()
                pprint(curData)
                print('===============')
                self.logger.info2('Update ComputeManager "%s"' % server)

                data = {
                    'display_name': svrName or server,
                    'server': server,
                    'origin_type': svrType,
                    'credential': {
                        'credential_type': 'UsernamePasswordLoginCredential',
                    #    #'username': username,
                    #    #'password': password,
                        'thumbprint': svrThumbprint or curData['credential']['thumbprint'],
                    },
                    '_revision': curData['_revision']
                }

                print('=============<<')
                pprint(data)
                data = cptutil.traverseRmNullEntry(data)
                print('=============')
                pprint(data)
                print('>>=============')
                self.logger.info2('Updating ComputeManager "%s" with NSX' % server)
                r = self.mgr.put(eval(self.api['unregister'].url), data=json.dumps(data))
                self.mgr.checkForError(r)
                #self.mgr.dumpResquestsResponse(r)


class Vidm(Network_object):
    resType = ''
    api = {
        'list':  Api('get',     '/api/v1/node/aaa/providers/vidm'),
        'get':   Api('get',     '/api/v1/node/aaa/providers/vidm'),
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            {
                "vidm":         .host_name,
                "client_id":    .client_id,
                "node_host_name": .node_host_name,
                "enable":       .vidm_enable,
                "lb":           .lb_enable,
            }'''),
    }

class PM_Role(Network_object):
    resType = ''
    api = {
        'list':       Api('get',     '/policy/api/v1/aaa/roles'),
        'getBinding': Api('get',     '/policy/api/v1/aaa/role-bindings'),
    }
    listUrl = api['list'].url
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "role": .role,
            }'''),
        'getBinding': PtblFmt(api['getBinding'].url, '''
            .results[] | {
                "name": .name,
                "type": .type,
                "roles": ([.roles[]|.role]|join(", ")),
            }'''),
    }

    """
    def __init__(self,mp):
        super(self.__class__, self).__init__(mp=mp)
        self.listUrl='/policy/api/v1/aaa/roles'

    def findByName(self, name, display=False):
        r = self.list(display=False)
        for i in r['results']:
            if i['role'] == name:
                return True

        return False

    def bind(self, name, roles, utype='remote_user', display=False):
        data={}
        data['name'] = name
        data['display_name'] = name
        data['type'] = utype
        data['resource_type'] = 'RoleBinding'
        data['roles'] = []
        for i in roles:
            role={}
            role['role'] = i
            data['roles'].append(role)

        self.post(api='/policy/api/v1/aaa/role-bindings', data=data,
                  codes=[200], display=True)
    """


class PM_DeploymentZone(Network_object):
    resType = 'DomainDeploymentZone'
    api = {
        'list':       Api('get',     '/policy/api/v1/infra/deployment-zones'),
        'get':        Api('get',    '"/policy/api/v1/infra/deployment-zones/%s"%objId'),
    }
    listUrl = api['list'].url
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "name": .display_name,
                "id":   .id,
                "path":   .path,
            }'''),
    }

    def jqDeploymentZone(self, nameGlob=''):
        url = self.ptblFmts['list'].url
        r = self.rest_api(url, method='GET')
        self.jqTable(jsonStr=r.text, nameGlob=nameGlob,
            jqFilter=self.ptblFmts['list'].jqFilter, apiKey='list')

class PM_Site(PM_DeploymentZone):
    resType = 'Site'
    api = {
        'list':       Api('get',     '/policy/api/v1/infra/sites'),
        'get':        Api('get',    '"/policy/api/v1/infra/sites/%s"%objId'),
    }
    listUrl = api['list'].url
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "name": .display_name,
                "id":   .id,
                "path":   .path,
            }'''),
    }


class PM_DeploymentMap(Network_object):
    resType = 'DomainDeploymentMap'
    api = {
        'list':       Api('get',    '"/policy/api/v1/infra/domains/%s/domain-deployment-maps"%objId'),
        'get':        Api('get',    '"/policy/api/v1/infra/domains/%s/domain-deployment-maps/%s"%(domId,dmId)'),
        'create':     Api('patch',  '"/policy/api/v1/infra/domains/%s/domain-deployment-maps/%s"%(domId,dmId)'),
        'delete':     Api('delete', '"/policy/api/v1/infra/domains/%s/domain-deployment-maps/%s"%(domId,dmId)'),
    }
    listUrl = api['list'].url
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "name": .display_name,
                "id":   .id,
                "enfPoint":   (.enforcement_point_path|split("/"))[-1],
            }'''),
    }

    def jqListDeploymentMap(self, nameGlob='', op='list', domain=None, display=True): # PM_DeploymentMap
        mgr = self.mgr
        domObj = PM_Domain(mgr)
        doms = domObj.list(display=False)
        jqFilterDz = '.results[] | {"name":.display_name, "id":.id}'
        doms = [dict(d) for d in pyjq.all(jqFilterDz, doms)]
        #pprint(doms)

        data = {}
        for dom in doms:
            #print('>>', domain)
            if domain and not isGlobMatched(domain, dom['name']): continue
            #print('<<', domain)
            objId = domId = dom['id']
            restUrl = eval(self.api['list'].url)
            r = self.rest_api(restUrl, method='GET')
            if display:
                print('Domain: %s' % dom['name'])
            if op=='jq':
                jqTableDict = self.jqTable(jsonStr=r.text, nameGlob=nameGlob, display=display,
                    jqFilter=self.ptblFmts['list'].jqFilter, apiKey='list')
                data = jqTableDict['restRespJson']
            elif op=='list':
                data = r.json()
                #pprint(data)
                #print('nameGlob=',nameGlob)
                if nameGlob:
                    data['results'] = [e for e in data['results'] if
                        isGlobMatched(nameGlob, e['display_name'])]
                    data['result_count'] = len(data['results'])
                if display:
                    print(json.dumps(data, indent=4))
        return data  ##### WARNING: ONLY RETURNING LAST SET OF DATA

    def _pmEnfPointToPath(self, name):
        return PM_EnforcementPoint(self.mgr).jqListEnforcementPoint(name, op='list', display=False)['results'][0]['path'] or ''

    def create(self, domainName, enfPointName):    # PM_DeploymentMap
        mgr = self.mgr
        domObj = PM_Domain(mgr)
        doms = domObj.list(display=False, nameGlob=domainName)
        if doms['result_count']<1:
            self.logger.error('domain %s not found' % domainName)
            return
        domId = doms['results'][0]['id']
        dmName = dmId = self._mkObjId('DM_%s-%s-'%(domainName,enfPointName))
        enfPointPath = self._pmEnfPointToPath(enfPointName)

        jDict = {
            "display_name": dmName,
            "enforcement_point_path": enfPointPath
        }
        restKey='create'
        restUrl = eval(self.api[restKey].url)
        #restMethod = self.api[restKey].method
        restMethod = self._pmRestMethodMap(self.api[restKey].method)
        self.logger.info1('creating deploymentMap "%s" for domain "%s"' % (dmName, domainName))
        self.logger.info4(jDict)
        r = getattr(mgr, restMethod)(restUrl, data=json.dumps(jDict))
        if not mgr.checkForError(r):
            self.logger.info1('created  deploymentMap "%s" for domain "%s"' % (dmName, domainName))

    def delete(self, domainName, enfPointName):    # PM_DeploymentMap
        ############### NOT YET WORKING ###############
        mgr = self.mgr
        domObj = PM_Domain(mgr)

        enfPointPath = self._pmEnfPointToPath(enfPointName)
        doms = domObj.list(display=False, nameGlob=domainName).get('results',[])
        dms = self.jqListDeploymentMap(nameGlob='*', op='list', domain=domainName, display=False).get('results',[])
        dms = [dm for dm in dms if dm['enforcement_point_path']==enfPointPath]
        if not doms:
            self.logger.error('domain %s not found' % domainName)
            return

        for dom,dm in itertools.product(doms,dms):
            domName, domId = dom['display_name'], dom['id']
            dmName,  dmId =  dm['display_name'],  dm['id']
            self.logger.info1('deleting deploymentMap "%s" for domain "%s"' % (dmName, domName))
            restKey='delete'
            restUrl = eval(self.api[restKey].url)
            restMethod = self._pmRestMethodMap(self.api[restKey].method)
            r = getattr(mgr, restMethod)(restUrl)
            if not mgr.checkForError(r):
                self.logger.info1('deleted  deploymentMap "%s" for domain "%s"' % (dmName, domName))
        return


        #domId  = doms[0]['id']
        #dmsListResult = self.jqListDeploymentMap(nameGlob='*', op='list', domain=domainName)
        #dms = dmsListResult.get('results',[])
        #dms = [dm for dm in dms if dm['enforcement_point_path']==enfPointPath]
        #for dm in dms:
        #    dmName, dmId = dm['display_name'], dm['id']
        #    restKey='delete'
        #    restUrl = eval(self.api[restKey].url)
        #    restMethod = self._pmRestMethodMap(self.api[restKey].method)
        #    r = getattr(mgr, restMethod)(restUrl)
        #    mgr.checkForError(r)


class PM_EnforcementPoint(Network_object):
    resType = 'EnforcementPoint'
    api = {
        'get':      Api('get',    '"/policy/api/v1/infra/deployment-zones/%s/enforcement-points"%objId'),
        'create':   Api('patch',  '"/policy/api/v1/infra/deployment-zones/%s/enforcement-points/%s"%(dzId,epId)'),
        'delete':   Api('delete', '"/policy/api/v1/infra/deployment-zones/%s/enforcement-points/%s"%(dzId,epId)'),
        'update':   Api('put',    '"/policy/api/v1/infra/deployment-zones/%s/enforcement-points/%s"%(dzId,epId)'),
    }
    ptblFmts = {
        'get': PtblFmt(api['get'].url, '''
            .results[] | {
                "name": .display_name,

                "type": (.connection_info.resource_type|.[0:4]),
                "addr": .connection_info.enforcement_point_address,
            }'''),
    }

    def jqListEnforcementPoint(self, nameGlob='', op='list', display=True):
        mgr = self.mgr
        deplZone = PM_DeploymentZone(mgr)
        dzs = deplZone.list(display=False)
        jqFilterDz = '''.results[] | {"name":.display_name, "id":.id}'''
        dzs = [dict(d) for d in pyjq.all(jqFilterDz, dzs)]
        for dz in dzs:
            objId = dz['id']
            url = eval(self.ptblFmts['get'].url)
            r = self.rest_api(url, method='GET')
            if op=='jq':
                jqTableDict = self.jqTable(jsonStr=r.text, nameGlob=nameGlob,
                    jqFilter=self.ptblFmts['get'].jqFilter, apiKey='get', display=display)
                data = jqTableDict['restRespJson']
            elif op=='list':
                data = r.json()
                if display:
                    print(json.dumps(data, indent=4))
        ##### NOTE THIS ONLY RETUN THE LAST SET OF DATA ####
        return data


class PM_Service(Network_object):
    resType = 'Service'
    api = {
        'list':       Api('get',     '/policy/api/v1/infra/services'),
        'get':        Api('get',    '"/policy/api/v1/infra/services/%s"%objId'),
        'create':     Api('patch',  '"/policy/api/v1/infra/services/%s"%objId'),
        'delete':     Api('delete', '"/policy/api/v1/infra/services/%s"%objId'),
        'deleteSE':   Api('delete', '"/policy/api/v1/infra/services/%s/service-entries/%s"%(svcId,svceId)'),

    }
    listUrl = api['list'].url
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "name": .display_name,
                "id":   .id,
                "services":   (
                    if .service_entries then
                        [.service_entries[]|
                            if .l4_protocol then
                                .l4_protocol+"/"+(.destination_ports|join(","))
                            elif .protocol=="ICMPv4" or .protocol=="ICMPv6" then
                                .protocol+":"+(.icmp_type|tostring)+"/"+((.icmp_code//"")|tostring)
                            elif .alg then
                                "alg:"+.alg+"/"+(.destination_ports|join(","))
                            elif .ether_type then
                                "ether:"+":"+(.ether_type|tostring)
                            elif .protocol_number then
                                "IP:"+(.protocol_number|tostring)
                            elif .resource_type=="IGMPTypeServiceEntry" then
                                "IGMP:"+.id
                            else "_UNKNOWN_" end
                        ] | join("\n")
                    else "" end
                )
            }'''),
    }

    def createPMService(self, serviceName, servicesSpec):
        '''
            syntax:
              One or more of the follwing:
                <ruleName> ":" "IP"     ":" <ipProtocol>                  [";"]
                <ruleName> ":" "TCP"    ":" <ports>                       [";"]
                <ruleName> ":" "UDP"    ":" <ports>                       [";"]
                <ruleName> ":" "ICMPv4" ":" <ICMPType> [ ":" <ICMPCode> ] [";"]
                <ruleName> ":" "ICMPv6" ":" <ICMPType> [ ":" <ICMPCode> ] [";"]
                <ruleName> ":" "alg"    ":" <algType>    ":" <ports>      [";"]
                <ruleName> ":" "IGMP    ":" <igmpType>   ":" <ports>      [";"]

                algType    ::= "ORACLE_TNS" | "FTP" | "SUN_RPC_TCP" | "SUN_RPC_UDP" | "MS_RPC_TCP" | "MS_RPC_UDP" |
                             "NBNS_BROADCAST" | "NBDG_BROADCAST"
                igmpType   ::= "Leave_Group" | "Membership_Query" | "V2_Membership_Report" | "V3_Membership_Report"
                ports      ::= <port> [",", port]...

                port       ::= <int>
                ipProtocol ::= <int>
                ICMPType   ::= <int>
                ICMPCode   ::= <int>

            Examples:
                "sc-9-1 : TCP    : 1234,5678"
                "sc-9-2 : UDP    : 4321"
                "se1    : TCP    : 1234,5678   ;
                 se2    : UDP    : 4321        ;
                 se3    : ICMPv4 : 2    : 1    ;
                 se4    : ICMPv6 : 2           ;
                 se5    : alg    : FTP  : 21   ;
                 se6    : IGMP   : Leave_Group ;
                 se7    : ether  :  800        ;
                 GRE    : IP     : 47             "

        '''
        mgr = self.mgr
        #servicesSpec = 'mySvc1:mySvcDesc:TCP:1234,5678:'
        services = servicesSpec.split(';')
        svcEntries = []
        for svcSpec in [s.strip() for s in services]:
            if not svcSpec: continue
            comps = [c.strip() for c in svcSpec.split(':')]
            self.logger.info3(comps)
            svcEntName = comps.pop(0)
            proto = comps.pop(0).upper()

            #print('>>>>proto = %s' % proto)
            #print('>>>>comps = %s' % comps)
            if proto in ['TCP', 'UDP']:
                #print('>>>>==========')
                dstPorts = comps.pop(0)
                service = {
                    'display_name': self._mkObjIdFromName(svcEntName),
                    'resource_type': 'L4PortSetServiceEntry',
                    'l4_protocol': proto,
                    'destination_ports': dstPorts.split(','),
                }
                svcEntries.append(service)
                #print('>>> service  '); pprint(service)
                #print('>>> svcEntries '); pprint(svcEntries)
            elif proto == 'ALG':
                # ORACLE_TNS, FTP, SUN_RPC_TCP, SUN_RPC_UDP, MS_RPC_TCP, MS_RPC_UDP, NBNS_BROADCAST, NBDG_BROADCAST
                alg = comps.pop(0)
                dstPorts = comps.pop(0)
                service = {
                    'display_name': svcEntName,
                    'resource_type': 'ALGTypeServiceEntry',
                    'alg': alg,
                    'destination_ports': dstPorts.split(','),
                }
                svcEntries.append(service)
            elif proto == 'IGMP':
                # Leave_Group, Membership_Query, V2_Membership_Report, V3_Membership_Report
                igmpType = comps.pop(0).upper()

                service = {
                    'resource_type': 'IGMPTypeServiceEntry',
                    'display_name': {
                        'LEAVE_GROUP':          'IGMP_Leave_Group',
                        'MEMBERSHIP_QUERY':     'IGMP_Membership_Query',
                        'V2_MEMBERSHIP_REPORT': 'IGMP_V2_Membership_Report',
                        'V3_MEMBERSHIP_REPORT': 'IGMP_V3_Membership_Report'
                    }[igmpType]
                }
                svcEntries.append(service)
                pprint(svcEntries)
            elif proto in ['ICMPV4', 'ICMPV6']:
                service = {
                    'display_name': svcEntName,
                    'resource_type': 'ICMPTypeServiceEntry',
                    'protocol': 'ICMPv4' if proto=='ICMPV4' else 'ICMPv6',
                    'icmp_type': int(comps.pop(0))
                }
                if comps and comps[0].strip()!='':
                    icmpCode = int(comps.pop(0).strip())
                    service['icmp_code'] = icmpCode
                svcEntries.append(service)
            elif proto in ['IP']:
                service = {
                    'display_name': svcEntName,
                    'resource_type': 'IPProtocolServiceEntry',
                    'protocol_number': int(comps.pop(0))
                }
                svcEntries.append(service)
            elif proto in ['ETHER']:
                service = {
                    'display_name': svcEntName,
                    'resource_type': 'EtherTypeServiceEntry',
                    'ether_type': int(comps.pop(0),16)
                }
                svcEntries.append(service)
            else:
                self.logger.error('Protocol %s supported by this script' % proto)

        restKey = 'create'
        jDict = {
            'display_name': serviceName,
            'service_entries':  svcEntries,
            'resource_type': 'Service',
        }
        #objId = svcId = self._mkObjId('SV')
        objId = svcId = self._mkObjIdFromName(serviceName)
        restUrl = eval(self.api[restKey].url)
        #restMethod = self.api[restKey].method
        restMethod = self._pmRestMethodMap(self.api[restKey].method)
        #print(restMethod, restUrl)
        #print('>>> mgr: ', mgr.url_prefix)
        #print('>>> restUrl: ', restUrl)
        #pprint(jDict)
        self.logger.info4(jDict)
        r = getattr(mgr, restMethod)(restUrl, data=json.dumps(jDict))
        mgr.checkForError(r)

    def deletePMService(self, namesGlob, ids=[]):     # PM_Service
        mgr = self.mgr
        namesGlob, ids = listify(namesGlob), listify(ids)

        #svcs = self.findByNamesGlob(namesGlob)
        svcs = self.list(mgr=mgr, display=False, nameGlob=namesGlob)['results']

        for svc in svcs:
            #print('svc.display_name = %s' % svc['display_name'])
            for path in [s['path'] for s in svc['service_entries']]:
                svcId, svceId = re.search(r'([^/]+)/service-entries/([^/]+)', path).groups()
                self.logger.info1('Deleting Service element id=%s' % svceId)
                restKey = 'deleteSE'
                restUrl = eval(self.api[restKey].url)
                restMethod = self.api[restKey].method
                r = getattr(mgr, restMethod)(restUrl)
                mgr.checkForError(r)
            objId = svc['id']
            restUrl = eval(self.api['delete'].url)
            #print('restUr=%s'%restUrl)
            name, objId = svc['display_name'], svc['id']
            self.logger.info1('Deleting %s, id=%s' % (name,objId))
            r = mgr.delete(restUrl)
            mgr.checkForError(r)


class PM_CommunicationProfile(Network_object):
    resType = 'CommunicationProfile'
    api = {
        'list':       Api('get',     '/policy/api/v1/infra/communication-profiles'),
        'get':        Api('get',    '"/policy/api/v1/infra/communication-profiles/%s"%objId'),
        'create':     Api('patch',  '"/policy/api/v1/infra/communication-profiles/%s"%objId'),
        'delete':     Api('delete', '"/policy/api/v1/infra/communication-profiles/%s"%objId'),
        'deletePE':   Api('delete', '"/policy/api/v1/infra/communication-profiles/%s/communication-profile-entries/%s"%(cpId,cpeId)'),
    }
    '''
    GET    /policy/api/v1/infra/communication-profiles
    DELETE /policy/api/v1/infra/communication-profiles/<communication-profile-id>
    GET    /policy/api/v1/infra/communication-profiles/<communication-profile-id>
    POST   /policy/api/v1/infra/communication-profiles/<communication-profile-id>
    GET    /policy/api/v1/infra/communication-profiles/<communication-profile-id>/communication-profile-entries
    DELETE /policy/api/v1/infra/communication-profiles/<communication-profile-id>/communication-profile-entries/<communication-profile-entry-id>
    GET    /policy/api/v1/infra/communication-profiles/<communication-profile-id>/communication-profile-entries/<communication-profile-entry-id>
    POST   /policy/api/v1/infra/communication-profiles/<communication-profile-id>/communication-profile-entries/<communication-profile-entry-id>
    '''
    listUrl = api['list'].url
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "name": .display_name,
                "id":   .id,
                "commProfEntry": [
                    .communication_profile_entries[] | {
                        "name":   .display_name,
                        "seq":    .sequence_number,
                        "action": .action,
                        "service": (.services|join(",")),
                    }
                ]
            }'''),
    }

    def create(self, profName, profEntsSpec):   # PM_CommunicationProfile
        '''
            syntax:
              One or more of the follwing:
                <name> ":" <action> ":" <services> [";"]

                action   ::= "ALLOW" | "DROP" | "REJECT"
                services ::= <serviceName> [",", <serviceName>]...
            Examples:
                "pfEnty-1-1 : ALLOW : AD_Server,CIM-HTTP ;
                 pfEnty-1-2 : DROP  : FTP"


            profEntsSpec (communication profile entries spec)::
            <cpeName> : <action> : <svc>[[,<svc>...];]...
            suicp1 : ALLOW : AD_Server,CIM-HTTP ;
            suicp2 : ALLOW : FTP
        '''
        mgr = self.mgr
        profEnts = profEntsSpec.split(';')
        cpes = []
        seq = 0
        for profEnt in [p.strip() for p in profEntsSpec.split(';')]:
            if not profEnt: continue
            cpeName, cpeAction, cpeServices = [c.strip() for c in profEnt.split(':')]
            self.logger.info3('%s %s %s' % (cpeName, cpeAction, cpeServices))
            svcs = cpeServices.split(',')
            cpes.append({
                'display_name':    cpeName,
                'sequence_number': seq,
                'action':          cpeAction.upper(),
                'services':        svcs,
            })
            seq += 1

        objId = self._mkObjIdFromName(profName)
        jDict = {
            'display_name': profName,
            'communication_profile_entries':  cpes,
            'id': profName,
        }
        #pprint(jDict)
        restKey = 'create'
        restUrl = eval(self.api[restKey].url)
        restMethod = self._pmRestMethodMap(self.api[restKey].method)
        self.logger.info4(jDict)
        r = getattr(mgr, restMethod)(restUrl, data=json.dumps(jDict))
        mgr.checkForError(r)

    def delete(self, nameGlob, mgr=None):                 # PM_CommunicationProfile
        mgr = self.mgr

        commProfs = self.list(mgr=mgr, display=False, nameGlob=nameGlob)['results']

        for cp in commProfs:
            cpName = cp['display_name']
            for path in [s['path'] for s in cp['communication_profile_entries']]:
                cpId, cpeId = re.search(r'([^/]+)/communication-profile-entries/([^/]+)', path).groups()
                self.logger.info1('Deleting %s Element %s' % (self.resType, cpeId))
                restKey = 'deletePE'
                restUrl = eval(self.api[restKey].url)
                restMethod = self.api[restKey].method
                r = getattr(mgr, restMethod)(restUrl)
                mgr.checkForError(r)
            cpId = objId = cp['id']
            cpName = cp['display_name']

            restKey = 'delete'
            restUrl = eval(self.api[restKey].url)
            self.logger.info1('Deleting %s %s (%s)' % (self.resType, cpName, cpId))
            r = mgr.delete(restUrl)
            mgr.checkForError(r)


class PM_Domain(Network_object):
    resType = 'Domain'
    api = {
        'list':       Api('get',     '/policy/api/v1/infra/domains'),
        'get':        Api('get',    '"/policy/api/v1/infra/domains/%s"%objId'),
        'create':     Api('patch',  '"/policy/api/v1/infra/domains/%s"%objId'),
        'delete':     Api('delete', '"/policy/api/v1/infra/domains/%s"%objId'),
    }
    listUrl = api['list'].url
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "name": .display_name,
                "id":   .id,
            }'''),
    }

    def jqDomain(self, nameGlob=''):
        url = self.ptblFmts['list'].url
        r = self.rest_api(url, method='GET')
        self.jqTable(jsonStr=r.text, nameGlob=nameGlob, jqFilter=self.ptblFmts['list'].jqFilter, apiKey='list')


    def create(self, name):
        mgr = self.mgr
        domObj = PM_Domain(mgr)
        doms = domObj.list(display=False)
        jqFilterDz = '.results[] | {"name":.display_name, "id":.id}'
        doms = [dict(d) for d in pyjq.all(jqFilterDz, doms)]
        doms = [d for d in doms if d['name']==name]
        if doms:
            mgr.logger.warning('Domain "%s" already exist' % name)
            return

        mgr.logger.info1('Creating Domain "%s"' % name)
        restKey='create'
        objId = domId = self._mkObjIdFromName(name)
        objId = domId = self._mkObjId('%s_'%name)

        jDict = {
            'display_name': name,
        }
        data = json.dumps(jDict)
        restUrl = eval(self.api[restKey].url)
        #restMethod = self.api[restKey].method
        restMethod = self._pmRestMethodMap(self.api[restKey].method)
        #print(restUrl, restMethod, data)
        self.logger.info("Creating %s domain" %name)
        r = getattr(mgr, restMethod)(restUrl, data=data)
        if not mgr.checkForError(r):
            self.logger.info("Created %s domain" % name)

    def delete(self, nameGlob):                     # PM_domain
        mgr = self.mgr
        domObj = PM_Domain(mgr)
        doms = domObj.list(display=False)
        jqFilterDz = '.results[] | {"name":.display_name, "id":.id}'
        doms = [dict(d) for d in pyjq.all(jqFilterDz, doms)]

        domFound = False
        for dom in doms:
            if not isGlobMatched(nameGlob, dom['name']): continue
            domFound = True
            domName = dom['name']
            mgr.logger.info1('Deleting Domain "%s"' % domName)
            objId = domId = dom['id']
            restKey='delete'
            restUrl = eval(self.api[restKey].url)
            restMethod = self.api[restKey].method
            #print(restUrl, restMethod)
            r = getattr(mgr, restMethod)(restUrl)
            self.logger.info('Deleting %s' % dom['name'])
            if not mgr.checkForError(r):
                mgr.logger.info('Deleted  Domain "%s"' % domName)
        if not domFound:
            mgr.logger.warning('Domain "%s" not found' % nameGlob)

class PM_Group(Network_object):
    resType = 'Group'
    api = {
        'list':       Api('get',    '"/policy/api/v1/infra/domains/%s/groups"%objId'),
        'get':        Api('get',    '"/policy/api/v1/infra/domains/%s/groups/%s"%(domId,grpId)'),
        'create':     Api('patch',  '"/policy/api/v1/infra/domains/%s/groups/%s"%(domId,grpId)'),
        'delete':     Api('delete', '"/policy/api/v1/infra/domains/%s/groups/%s"%(domId,grpId)'),
    }
    ptblFmts = {
        'list': PtblFmt(api['get'].url, '''
            def triage:
                    if .resource_type=="Condition" then
                         .member_type + ":" + .key + " " + .operator + " " + .value
                    elif .resource_type=="ConjunctionOperator" then
                        "  "+.conjunction_operator
                    elif .resource_type=="IPAddressExpression" then
                        "IP:"+(.ip_addresses|join(","))
                    elif .resource_type=="NestedExpression" then
                        "    "+([.expressions[] |triage] |join("\n    "))
                    else "_UNHANDLED_EXPR_" end;
            .results[] | {
                "name": .display_name,
                "id":   .id,
                "expr|100": {"ident":"0:","val":.} | [.val.expression[]| triage] |join("\n")
            }'''),
    }

    @memoize
    def jqListGroup(self, nameGlob='', op='list', domain=None, display=True, useCache=False): # PM_Group
        mgr = self.mgr
        domObj = PM_Domain(mgr)
        doms = domObj.list(display=False)
        jqFilterDz = '.results[] | {"display_name":.display_name, "id":.id}'
        doms = [dict(d) for d in pyjq.all(jqFilterDz, doms)]

        for dom in doms:
            domName = dom['display_name']
            if (domain and not isGlobMatched(domain, domName)): continue
            objId = domId = dom['id']
            url = eval(self.api['list'].url)
            rDict = self.list(url, display=False, useCache=useCache)
            jsonStr = json.dumps(rDict)

            if op=='jq':
                if display:
                    print('DOMAIN: %s' % domName)
                    self.jqTable(jsonStr=jsonStr, nameGlob=nameGlob, display=True,
                        jqFilter=self.ptblFmts['list'].jqFilter, apiKey='list')
            elif op=='list':
                if nameGlob:
                    rDict['results'] = [e for e in rDict['results'] if
                        isGlobMatched(nameGlob, e['display_name'])]
                    rDict['result_count'] = len(rDict['results'])
                if display:
                    print(json.dumps(rDict, indent=4))
        return rDict

    def findGroupByName(self, name, domain):
        group = self.jqListGroup(name, op='list', domain=domain, display=False)

    @staticmethod
    def _parseGroupSpec(gName, gSpec):
        exps = []
        #crits = re.split('([|&])', gSpec) if re.search('[|&]',gSpec) else [gSpec]
        crits = cptutil.parseNestedParenExpr(gSpec) if isinstance(gSpec, basestring) else gSpec
        for crit in crits:
            #print('#### crit: %s' % crit)
            if isinstance(crit, list):
                rExpr = PM_Group._parseGroupSpec(gName, crit)
                condDict = {
                    'resource_type': 'NestedExpression',
                    'expressions': rExpr['expression']
                }
            else:
                comps = [c.strip() for c in crit.split(':')]
                if len(comps)==1 and comps[0] in ['|', '&']:
                    logicalOp = {'|':'OR','&':'AND'}[comps[0]]
                    condDict = {
                        'conjunction_operator': logicalOp,
                        'resource_type': 'ConjunctionOperator'
                    }
                elif comps[0] in ['VirtualMachine']:
                    mType, mKey, mOp, mVal = comps
                    condDict = {
                        'resource_type': 'Condition',
                        'key': mKey,
                        'member_type': mType,
                        'operator': mOp,
                        'value': urllib2.unquote(mVal),
                    }
                elif comps[0] in ['IP']:
                    mType, mVal = comps
                    mVal = [v.strip() for v in mVal.split(',')]
                    condDict = {
                        'resource_type': 'IPAddressExpression',
                        'ip_addresses': mVal,
                    }
                elif comps[0] in ['LogicalSwitch']:
                    mType, mKey, mOp, mVal = comps
                    condDict = {
                        'resource_type': 'Condition',
                        'key': mKey,
                        'member_type': mType,
                        'operator': mOp,
                        'value': urllib2.unquote(mVal),
                    }
                elif comps[0] in ['LogicalPort']:
                    mType, mKey, mOp, mVal = comps
                    condDict = {
                        'resource_type': 'Condition',
                        'key': mKey,
                        'member_type': mType,
                        'operator': mOp,
                        'value': urllib2.unquote(mVal),
                    }
            exps.append(condDict)
        jDict = {
            'display_name': gName,
            'expression': exps
        }
        #pprint(jDict)
        return jDict

    def create(self, groupName, groupSpecs, domain):       # PM_Group
        '''
            syntax:
              One or more of the follwing (each group can contain a single type (eg: VM or IP, not both):
                "VirtualMachine"  ":" "Tag"  ":"  "EQUALS"     ":"  <tagValue>     ["|" | "&"]
                "VirtualMachine"  ":" "Name" ":"  "STARTSWITH" ":"  <vmNameString> ["|" | "&"]
                "VirtualMachine"  ":" "Name" ":"  "CONTAINS"   ":"  <vmNameString> ["|" | "&"]
                "IP" ":" <ipSpec> ["|" | "&"]

                ipRange::= <ip> "-" <ip>
                ipCidr ::= <ip> "/" <int>
            Examples:
                "VirtualMachine  : Tag  : EQUALS     : vScope-vTag |
                 VirtualMachine  : Tag  : EQUALS     : vTag        |
                 VirtualMachine  : Name : STARTSWITH : vName       |
                 VirtualMachine  : Name : CONTAINS   : vName "
                "VirtualMachine  : Tag  : EQUALS     : webvm "
                "VirtualMachine  : Name : STARTSWITH : vmware-     &
                 VirtualMachine  : Name : CONTAINS   : -prod-"
                "IP : 1.1.1.1-1.1.1.2 |
                 IP : 2.2.2.0/24      |
                 IP : 3.3.3.3 "
            Example2:
                "(VirtualMachine : Tag  : EQUALS      : vScope-vTag &
                  VirtualMachine : Name : STARTSWITH  : vName)      |
                  LogicalSwitch  : Tag  : EQUALS      : ls-tag      |
                 (LogicalPort    : Tag  : EQUALS      : lp-tag1     &
                  LogicalPort    : Tag  : EQUALS      : lp-tag2)"
            '''
        mgr = self.mgr
        domObj = PM_Domain(mgr)
        doms = domObj.list(display=False, nameGlob=domain)
        if doms['result_count']<1:
            self.logger.error('domain %s not found' % domain)
            return
        domId = doms['results'][0]['id']
        #jqFilterDz = '.results[] | {"name":.display_name, "id":.id}'
        #doms = [dict(d) for d in pyjq.all(jqFilterDz, doms)]

        for groupSpec in listify(groupSpecs):
            #jDict = self._parseGroupSpec0(groupName, groupSpec)
            jDict = self._parseGroupSpec(groupName, groupSpec)
            self.logger.info3(cptutil.pformat_json(jDict))

            restKey='create'
            #grpId = self._mkObjId('GP')
            grpId = self._mkObjIdFromName(groupName)
            data = json.dumps(jDict)
            restUrl = eval(self.api[restKey].url)
            #restMethod = self.api[restKey].method
            self.logger.info("Creating %s group in %s domain" % (groupName, domain))
            restMethod = self._pmRestMethodMap(self.api[restKey].method)
            #print(restUrl, restMethod, data)
            #pprint(jDict)
            r = getattr(mgr, restMethod)(restUrl, data=data)
            if not mgr.checkForError(r):
                self.logger.info("Created %s group in %s domain" % (groupName, domain))

    def delete(self, nameGlob, domain):         # PM_Group
        mgr = self.mgr
        domObj = PM_Domain(mgr)
        doms = domObj.list(display=False, nameGlob=domain)
        if doms['result_count']<1:
            self.logger.error('domain %s not found' % domain)
            return
        domId = doms['results'][0]['id']

        objId = domId
        restKey='list'
        restUrl = eval(self.api[restKey].url)
        restMethod = self.api[restKey].method
        r = getattr(mgr, restMethod)(restUrl)
        mgr.checkForError(r)
        for group in [e for e in r.json()['results']
                if isGlobMatched(nameGlob, e['display_name'])]:
            #print(group['display_name'], group['id'])

            restKey='delete'
            grpName, grpId = group['display_name'], group['id']
            restUrl = eval(self.api[restKey].url)
            restMethod = self.api[restKey].method
            #print(restUrl, restMethod)
            self.logger.info('Deleting %s "%s"' % (self.resType,grpName))
            r = getattr(mgr, restMethod)(restUrl)
            if not mgr.checkForError(r):
                self.logger.info('Deleted  %s "%s"' % (self.resType,grpName))

#------


class PM_Firewall(Network_object):
    resType = "SecurityPolicy"

    api = {
        'seclist': Api('get', '"/policy/api/v1/infra/domains/%s/security-policies"%domId'),
        'secget': Api('get', '"/policy/api/v1/infra/domains/%s/security-policies/%s"%(domId,secId)'),
        'seccreate': Api('patch', '"/policy/api/v1/infra/domains/%s/security-policies/%s"%(domId,secId)'),
        'secdelete': Api('delete', '"/policy/api/v1/infra/domains/%s/security-policies/%s"%(domId,secId)'),
        'rulecreate': Api('patch', '"/policy/api/v1/infra/domains/%s/security-policies/%s/rules/%s"%(domId,secId,ruleId)'),
        'ruleget': Api('get', '"/policy/api/v1/infra/domains/%s/security-policies/%s/rules/%s"%(domId,secId,ruleId)'),
        'rulelist': Api('get', '"/policy/api/v1/infra/domains/%s/security-policies/%s/rules/"%(domId,secId)'),
        'rulemodify': Api('put', '"/policy/api/v1/infra/domains/%s/security-policies/%s/rules/%s"%(domId,secId,ruleId)'),
        'ruledelete': Api('delete', '"/policy/api/v1/infra/domains/%s/security-policies/%s/rules/%s"%(domId,secId,ruleId)')
    }

    ptblFmts = {
        'list': PtblFmt(api['rulelist'].url, '''
                .results[] | {
                    "name":     .display_name,
                    "id":       .id,
                    "srcGroup": .source_groups[],
                    "dstGroup": .destination_groups[],
                    "scope":    .scope[],
                    "action":   .action,
                    "service":  .services[],
                }'''),
        'seclist': PtblFmt(api['seclist'].url, '''
                .results[] | {
                    "name":       .display_name,
                    "id":         .id,
                    "seq":        .sequence_number,
                    "category": .category,
                }'''),
        'rulelist': PtblFmt(api['rulelist'].url, '''
                def lastComp:([.[]|split("/")|.[-1]]|join(",\n"));
                .results[] | {
                    "name":     .display_name,
                    "id":       .id,
                    "seq":      .sequence_number,
                    "srcGroup": .source_groups|lastComp,
                    "dstGroup": .destination_groups|lastComp,
                    "scope":    .scope|join("\n"),
                    "action":   .action,
                    "service":  .services|lastComp,
                }'''),
    }

    def getDomainIdByName(self, domain):
        mgr = self.mgr
        domObj = PM_Domain(mgr)
        doms = domObj.list(display=False, nameGlob=domain)
        if doms['result_count'] < 1:
            self.logger.error('domain %s not found' % domain)
            print('domain %s not found' % domain)
            sys.exit()
        domId = doms['results'][0]['id']
        return domId

    def getPolicyIdByName(self, domain, policyName):
        secs = self.listpolicy(domain, display=False)

        for sec in secs['results']:
            if sec['display_name'] == policyName:
                return sec['id']
        self.logger.warning("Policy %s not found in domain %s" % (policyName, domain))
        return

    def getRuleIdByName(self, domain, policy, ruleName):
        rules = self.listrules(domain, policy, display=False)

        for rule in rules['results']:
            if rule['display_name'] == ruleName:
                return rule['id']
        self.logger.warning("Rule %s not found in policy %s" % (ruleName, policy))
        return

    def findPolicyByName(self, policy, domain, display=True):
        mgr = self.mgr
        domId = self.getDomainIdByName(domain)
        secId = self.getPolicyIdByName(domain, policy)
        if secId is None:
            return
        restKey = 'secget'
        restUrl = eval(self.api[restKey].url)
        restMethod = self.api[restKey].method
        r = getattr(mgr, restMethod)(restUrl)
        mgr.checkForError(r)
        if display:
            print(json.dumps(r.json(), indent=4))
        return r

    def createpolicy(self, name, category, domain, desc):              # PM_Firewall
        resp = self.findPolicyByName(name, domain, display=False)
        mgr = self.mgr
        data = {}

        if resp is None:
            domId = self.getDomainIdByName(domain)
            secId = self._mkObjIdFromName(name)
            data['category'] = category.capitalize()
            data['display_name'] = name
            if desc:
                data['description'] = desc
            restKey = 'seccreate'
            restUrl = eval(self.api[restKey].url)
            restMethod = self.api[restKey].method
            data = json.dumps(data)
            self.logger.info("Creating %s policy in %s domain" % (name, domain))
            r = getattr(mgr, restMethod)(restUrl, data=data)
            if not mgr.checkForError(r):
                self.logger.info("Created %s policy in %s domain" % (name, domain))
        elif resp.status_code == 200:
            self.logger.info1("%s policy is already there" % name)
            return
        else:
            print(json.dumps(resp.json()))

    def listpolicy(self, domain, display=True):           # PM_Firewall
        mgr = self.mgr
        domId = self.getDomainIdByName(domain)
        restKey = 'seclist'
        restUrl = eval(self.api[restKey].url)
        restMethod = self.api[restKey].method
        r = getattr(mgr, restMethod)(restUrl)
        mgr.checkForError(r)
        if display:
            print(json.dumps(r.json(), indent=4))
        return r.json()

    def deletepolicy(self, domain, nameGlob):
        mgr = self.mgr
        domId = self.getDomainIdByName(domain)
        policy_list = self.listpolicy(domain, display=False)
        secdic = {}
        for res in policy_list['results']:
            if isGlobMatched(nameGlob, res['display_name']):
                secdic[res['id']] = res['display_name']
        domId = self.getDomainIdByName(domain)
        restKey = 'secdelete'
        if len(secdic) is 0:
            self.logger.error("No policy matched in the given domain")
            return
        for secId, secName in secdic.iteritems():
            restUrl = eval(self.api[restKey].url)
            restMethod = self.api[restKey].method
            self.logger.info("Deleting policy %s from domain %s" % (secName, domain))
            r = getattr(mgr, restMethod)(restUrl)
            if not mgr.checkForError(r):
                self.logger.info("Deleted policy %s from domain %s" % (secName, domain))

    def deleterule(self, domain, policy, nameGlob):
        mgr = self.mgr
        domId = self.getDomainIdByName(domain)
        secId = self.getPolicyIdByName(domain, policy)
        rule_list = self.listrules(domain, policy, display=False)
        ruledic = {}
        for rule in rule_list['results']:
            if isGlobMatched(nameGlob, rule['display_name']):
                ruledic[rule['id']] = rule['display_name']
        restKey = 'ruledelete'
        if len(ruledic) is 0:
            self.logger.error("No rule matched in the %s policy" % policy)
            return
        for ruleId, ruleName in ruledic.iteritems():
            restUrl = eval(self.api[restKey].url)
            restMethod = self.api[restKey].method
            self.logger.info("Deleting rule %s from domain %s" % (ruleName, domain))
            r = getattr(mgr, restMethod)(restUrl)
            if not mgr.checkForError(r):
                self.logger.info("Deleted rule %s from domain %s" % (ruleName, domain))

    def getNameFromPath(self, path_list):
        if len(path_list) == 1 and path_list[0] == "ANY":
            return path_list
        else:
            name_list = [path.split('/')[-1] for path in path_list]
            return name_list

    def listrules(self, domain, policy, op='list', display=True):
        mgr = self.mgr
        domId = self.getDomainIdByName(domain)
        secId = self.getPolicyIdByName(domain, policy)
        restKey = 'rulelist'
        restUrl = eval(self.api[restKey].url)
        restMethod = self.api[restKey].method
        r = getattr(mgr, restMethod)(restUrl)
        mgr.checkForError(r)
        if op == 'jq':
            data = r.json()
            for result in data['results']:
                result['source_groups'] = self.getNameFromPath(result['source_groups'])
                result['destination_groups'] = self.getNameFromPath(result['destination_groups'])
                result['scope'] = self.getNameFromPath(result['scope'])
                result['services'] = self.getNameFromPath(result['services'])
            self.jqTable(jsonStr=json.dumps(data), display=display,
                     jqFilter=self.ptblFmts['list'].jqFilter, apiKey='rulelist')
        else:
            if display:
                print(json.dumps(r.json(), indent=4))
        return r.json()

    def getGroupPathList(self, dict, groups):
        group_list = []
        if len(groups) == 1 and groups[0] == "ANY":
            return ["ANY"]
        for group in groups:
            try:
                path = "/infra/domains/%s/groups/%s" % (dict[group][1], dict[group][0])
                group_list.append(path)
            except KeyError:
                self.logger.warning("Group %s is not found, Skipping that group" % group)
        return group_list

    def getServicePathList(self, services):
        path = "/infra/services/"
        service_list = [path + s for s in services]
        return service_list

    def getGroupDomainDictionary(self):
        mgr = self.mgr
        dict = {}
        domain_list = PM_Domain(mgr).list(display=False)
        for dom in domain_list['results']:
            group_list = PM_Group(mgr).jqListGroup(domain=dom['display_name'], display=False)
            for grp in group_list['results']:
                val_list = [grp['id'], dom['id']]
                dict[grp['display_name']] = val_list
        return dict

    def findRuleByName(self, ruleName, policy, domain, display=True):
        mgr = self.mgr
        domId = self.getDomainIdByName(domain)
        secId = self.getPolicyIdByName(domain, policy)
        if secId is None:
            return
        ruleId = self.getRuleIdByName(domain, policy, ruleName)
        if ruleId is None:
            return
        restKey = 'ruleget'
        restUrl = eval(self.api[restKey].url)
        restMethod = self.api[restKey].method
        r = getattr(mgr, restMethod)(restUrl)
        mgr.checkForError(r)
        if display:
            print(json.dumps(r.json(), indent=4))
        return r

    def addruletopolicy(self, policyName, domain, name, description, direction, protocol, sources, destinations,
                         scopes, services, log, action, disable_state, tag):
        resp = self.findPolicyByName(policyName, domain, display=False)
        if resp is None:
            self.logger.error("Policy %s is not found in %s domain" % (policyName, domain))
            return
        dict = {}
        data = {}
        mgr = self.mgr
        domain_list = PM_Domain(mgr).list(display=False)
        '''
        for dom in domain_list['results']:
            group_list = PM_Group(mgr).jqListGroup(domain=dom['display_name'], display=False)
            for grp in group_list['results']:
                val_list = [grp['id'], dom['id']]
                dict[grp['display_name']] = val_list
        '''
        dict = self.getGroupDomainDictionary()
        data['disabled'] = disable_state
        data['description'] = description
        data['display_name'] = name
        data['direction'] = direction
        data['logged'] = log
        data['ip_protocol'] = protocol
        data['action'] = action
        data['tag'] = tag
        if services is None:
            data['services'] = ["ANY"]
        else:
            data['services'] = self.getServicePathList(services)

        if sources is None:
            data['source_groups'] = ["ANY"]
        else:
            data['source_groups'] = self.getGroupPathList(dict, sources)

        if destinations is None:
            data['destination_groups'] = ["ANY"]
        else:
            data['destination_groups'] = self.getGroupPathList(dict, destinations)

        if scopes is None:
            data['scope'] = ["ANY"]
        else:
            data['scope'] = self.getGroupPathList(dict, scopes)
        data = json.dumps(data)
        domId = self.getDomainIdByName(domain)
        secId = self.getPolicyIdByName(domain, policyName)
        ruleId = self._mkObjIdFromName(name)
        restKey = 'rulecreate'
        restUrl = eval(self.api[restKey].url)
        restMethod = self.api[restKey].method
        self.logger.info("Adding rule %s in policy %s" % (name, policyName))
        r = getattr(mgr, restMethod)(restUrl, data=data)
        if not mgr.checkForError(r):
            self.logger.info("Added rule %s in policy %s" % (name, policyName))

    def deleteGroupFromList(self, original_list, group_list):
        for group in group_list:
            if group in original_list:
                original_list.remove(group)
            else:
                self.logger.warning("Group %s is not found in existing rule, Skipping deleting that group" % group)
        if len(original_list) == 0:
            self.logger.info("Group or service list got empty after deleting %s. So setting it to ANY" % group_list)
            return ["ANY"]
        else:
            original_list

    def modifyrule(self, type, ruleName, policy, domain, description=None, direction=None, protocol=None, sources=[],
                   destinations = [], scopes = [], services = [], log = None, action = None, disable_state = None,
                   tag = None):
        mgr = self.mgr
        domId = self.getDomainIdByName(domain)
        secId = self.getPolicyIdByName(domain, policy)
        ruleId = self.getRuleIdByName(domain, policy, ruleName)
        if domId is None or secId is None or ruleId is None:
            return
        restKey = 'ruleget'
        restUrl = eval(self.api[restKey].url)
        restMethod = self.api[restKey].method
        self.logger.info("Fetching rule %s from policy %s" % (ruleName, policy))
        r = getattr(mgr, restMethod)(restUrl)
        data = r.json()
        self.logger.debug(json.dumps(data, indent=4))
        dict = self.getGroupDomainDictionary()
        group_sources_local = self.getGroupPathList(dict, sources)
        group_destination_local = self.getGroupPathList(dict, destinations)
        group_scope_local = self.getGroupPathList(dict, scopes)
        group_services_local = self.getServicePathList(services)

        if type == 'add':
            if (data['source_groups'][0] == 'ANY' and len(sources) != 0) \
                    or (data['destination_groups'][0] == 'ANY' and len(destinations) != 0)\
                    or (data['scope'][0] == 'ANY' and len(scopes) !=0)\
                    or (data['services'][0] == 'ANY' and len(services) != 0):
                self.logger.error("You can't do add operation with having ANY value in existing. Use update instead")
                return
            [data['source_groups'].append(source) for source in group_sources_local if
             not(source in data['source_groups'])]
            [data['destination_groups'].append(destination) for destination in group_destination_local if
             not (destination in data['destination_groups'])]
            [data['scope'].append(scope) for scope in group_scope_local if
             not (scope in data['scope'])]
            [data['services'].append(service) for service in group_services_local if
             not (service in data['services'])]

        elif type == 'update':
            if 'description' in data:
                data['description'] = description if description is not None  else data['description']
            data['disabled'] = disable_state if disable_state is not None else data['disabled']
            data['direction'] = direction if direction is not None else data['direction']
            data['ip_protocol'] = protocol if protocol is not None else data['ip_protocol']
            data['logged'] = log if log is not None else data['logged']
            data['action'] = action if action is not None else data['action']
            data['tag'] = tag if tag is not None else data['tag']

            data['source_groups'] = group_sources_local if len(sources) is not 0 else data['source_groups']
            data['destination_groups'] = group_destination_local if len(destinations) is not 0 else data['destination_groups']
            data['scope'] = group_scope_local if len(scopes) is not 0 else data['scope']
            data['services'] = group_services_local if len(services) is not 0 else data['services']

        elif type == 'delete':
            data['source_groups'] = self.deleteGroupFromList(data['source_groups'], group_sources_local)
            data['destination_groups'] = self.deleteGroupFromList(data['destination_groups'], group_destination_local)
            data['scope'] = self.deleteGroupFromList(data['scope'], group_scope_local)
            data['services'] = self.deleteGroupFromList(data['services'], group_services_local)

        data = json.dumps(data)
        restKey = 'rulemodify'
        restUrl = eval(self.api[restKey].url)
        restMethod = self.api[restKey].method
        self.logger.info("Modifying rule %s from policy %s" % (ruleName, policy))
        r = getattr(mgr, restMethod)(restUrl, data=data)
        if not mgr.checkForError(r):
            self.logger.info("Rule %s modified" % ruleName)

    def jqListSecurityPolicy(self, nameGlob='*', op='jq', domain='*', display=True, listrules=False): # PM_Firewall
        mgr = self.mgr

        domObj = PM_Domain(mgr)
        doms = domObj.list(display=False)
        jqFilterDz = '.results[] | {"display_name":.display_name, "id":.id}'
        doms = [dict(d) for d in pyjq.all(jqFilterDz, doms)]

        for dom in doms:
            if not isGlobMatched(domain, dom['display_name']): continue
            domName, domId = dom['display_name'], dom['id']
            url = eval(self.api['seclist'].url)
            r = self.rest_api(url, method='GET')
            if display:
                print('## Domain: %s (%s)' % (dom['display_name'], dom['id']))
                print('#### Security-policies:')
            if op=='jq':
                restKey = 'seclist'
                jqTableDict = self.jqTable(jsonStr=r.text, nameGlob=nameGlob,
                    jqFilter=self.ptblFmts[restKey].jqFilter, apiKey=restKey)
                sps,spPtbl = jqTableDict['rows'], jqTableDict['ptbl']
                sps = [dict(d) for d in pyjq.all(self.ptblFmts[restKey].jqFilter, json.loads(r.text))]
                data = sps
                if listrules:
                    for sp in sps:
                        spName, secId = sp['name'], sp['id']
                        if nameGlob and not isGlobMatched(nameGlob, spName): continue
                        if display: print('###### Security Policy rule: %s (%s/%s)' % (spName, domId, secId))
                        jqTableDict = self.jqTable(apiKey='rulelist', domId=domId, secId=secId)
                        spes,spePtbl = jqTableDict['rows'], jqTableDict['ptbl']
                        #self.listrules(domain, spName, op='jq', display=True)
            elif op=='list':
                data = r.json()
                if display: pprint_json(data)
                jqFilter='.results[] | {"name":.display_name, "id":.id}'
                sps = [dict(d) for d in pyjq.all(jqFilterDz, data)]
                for sp in sps:
                    spName, secId = sp['name'], sp['id']
                    if not isGlobMatched(nameGlob, spName): continue
                    restUrl = eval(self.api['get'].url)
                    r = self.rest_api(restUrl, method='GET')
                    print(r.text)

        return data

#------

class PM_CommunicationMap(Network_object):
    resType = 'CommunicationMap'
    api = {
        'list':      Api('get',    '"/policy/api/v1/infra/domains/%s/communication-maps"%objId'),
        'get':       Api('get',    '"/policy/api/v1/infra/domains/%s/communication-maps/%s"%(domId,cmId)'),
        'create':    Api('patch',  '"/policy/api/v1/infra/domains/%s/communication-maps/%s"%(domId,cmId)'),
        'create-21': Api('post',   '"/policy/api/v1/infra/domains/%s/communication-map"%domId'),
        'delete':    Api('delete', '"/policy/api/v1/infra/domains/%s/communication-maps/%s"%(domId,cmId)'),
        'deleteCme': Api('delete', '"/policy/api/v1/infra/domains/%s/communication-maps/%s/communication-entries/%s"%(domId,cmId,cmeId)'),
    }
    ptblFmts = {
        'list': PtblFmt(api['get'].url, '''
            .results[] | {
                "name":       .display_name,
                "id":         .id,
                "category":   .category,
                "precedence": .precedence,
            }'''),
        'get': PtblFmt(api['get'].url, '''
            .communication_entries[] | {
                "name":     .display_name,
                "id":       .id,
                "seq":      .sequence_number,
                "srcGroup": .source_groups|join("\n"),
                "dstGroup": .destination_groups|join("\n"),
                "scope":    .scope|join("\n"),
                "action":   .action,
                "service":  .services|join("\n"),
            }'''),
    }
    api21 = {
        'list':      Api('get',    '"/policy/api/v1/infra/domains/%s/communication-map"%objId'),
        'get':       Api('get',    '"/policy/api/v1/infra/domains/%s/communication-map/%s"%(domId,cmId)'),
        'create':    Api('post',   '"/policy/api/v1/infra/domains/%s/communication-map"%domId'),
        'deleteCme': Api('delete', '"/policy/api/v1/infra/domains/%s/communication-map/communication-entries/%s"%(domId,cmeId)'),
    }
    ptblFmts21 = {
    #                    "srcGroup": .source_groups|join("\n"),
        'list': PtblFmt(api['get'].url, '''
            {
                "name":       .display_name,
                "id":         .id,
                "precedence": .precedence,
                "commEntry":
                    [.communication_entries[] | {
                        "name":     .display_name,
                        "id":       .id,
                        "seq":      .sequence_number,
                        "srcGroup": ([.source_groups[]|split("/")[-1]]|join("\n")),
                        "dstGroup": ([.destination_groups[]|split("/")[-1]]|join("\n")),
                        "commProfile": (.communication_profile_path|split("/")[-1]),
                    }]
             }'''),
        'get': PtblFmt(api['get'].url, '''
            .communication_entries[] | {
                "name":     .display_name,
                "id":       .id,
                "seq":      .sequence_number,
                "srcGroup": .source_groups|join("\n"),
                "dstGroup": .destination_groups|join("\n"),
                "scope":    .scope|join("\n"),
                "action":   .action,
                "service":  .services|join("\n"),
            }'''),
    }

    def jqListCommunicationmap(self, nameGlob='*', op='list', domain=None, display=True): # PM_Communicationmap
        mgr = self.mgr
        #mgrVerIs21 = mgr.version.startswith('2.1')
        #if mgrVerIs21:
        #    self.api = self.api21
        #    self.ptblFmts = self.ptblFmts21

        domObj = PM_Domain(mgr)
        doms = domObj.list(display=False)
        jqFilterDz = '.results[] | {"name":.display_name, "id":.id}'
        doms = [dict(d) for d in pyjq.all(jqFilterDz, doms)]

        for dom in doms:
            if domain and not isGlobMatched(domain, dom['name']): continue
            objId = domId = dom['id']
            url = eval(self.api['list'].url)
            r = self.rest_api(url, method='GET')
            if display: print('## Domain: %s (%s)' % (dom['name'], dom['id']))
            if display: print('#### Communication-Maps:')
            if op=='jq':
                restKey = 'list'
                #print(restKey, nameGlob, self.ptblFmts[restKey].jqFilter)
                jqTableDict = self.jqTable(jsonStr=r.text, nameGlob=nameGlob,
                    jqFilter=self.ptblFmts[restKey].jqFilter, apiKey=restKey)
                cms,cmPtbl = jqTableDict['rows'], jqTableDict['ptbl']
                cms = [dict(d) for d in pyjq.all(self.ptblFmts[restKey].jqFilter, json.loads(r.text))]
                #print(cms)
                data = cms
                for cm in cms:
                    cmName, cmId = cm['name'], cm['id']
                    if not isGlobMatched(nameGlob, cmName): continue
                    if display: print('###### Communication-entry: %s (%s/%s)' % (cmName, domId, cmId))
                    restUrl = eval(self.api['get'].url)
                    #print(self.ptblFmts['get'].jqFilter)
                    self.logger.info4('restUrl=%s' % restUrl)
                    r = self.rest_api(restUrl, method='GET')
                    #print('<><><>', r.text)
                    jqTableDict = self.jqTable(jsonStr=r.text, nameGlob='',
                        jqFilter=self.ptblFmts['get'].jqFilter, apiKey='get')
                    cmes,cmePtbl = jqTableDict['rows'], jqTableDict['ptbl']
            elif op=='list':
                data = r.json()
                if display: pprint_json(data)
                jqFilter='.results[] | {"name":.display_name, "id":.id}'
                cms = [dict(d) for d in pyjq.all(jqFilterDz, data)]
                #print(cms)
                for cm in cms:
                    cmName, cmId = cm['name'], cm['id']
                    if not isGlobMatched(nameGlob, cmName): continue
                    restUrl = eval(self.api['get'].url)
                    r = self.rest_api(restUrl, method='GET')
                    print(r.text)


            return data

    @memoize
    def _pmGroupToPath(self, name, domain):
        self.logger.info2('domain/name = %s/%s'%(domain,name))
        results = PM_Group(self.mgr).jqListGroup(name, op='list', domain=domain, display=False, useCache=True)['results']
        if not results:
            self.logger.warning('"%s" Group "%s" not defined' % (domain, name))
        path = results[0]['path'] if results else '_NOTDEFINED_'
        self.logger.info1('%s\t%s' % (name, path))
        return path
        #return PM_Group(self.mgr).jqListGroup(name, op='list', domain=domain, display=False)['results'][0]['path'] or ''

    @memoize
    def _pmServiceToPath(self, name):
        #print(self.findByNamesGlob(name)['results'][0]['path'])
        #print('policy service: %s' % name)
        name = urllib2.quote(name)
        #print('policy service- %s' % name)
        results = PM_Service(self.mgr).list(nameGlob=name, display=False, useCache=True)['results']
        if not results:
            self.logger.warning('Service "%s" not defined' % name)
        path = results[0]['path'] if results else '_NOTDEFINED_'
        self.logger.info1('%s\t%s' % (name, path))
        return path

    def _pmCommProfToPath(self, name):
        #print(self.findByNamesGlob(name)['results'][0]['path'])
        results = PM_CommunicationProfile(self.mgr).list(display=False, nameGlob=name)['results']
        if not results:
            self.logger.warning('Communication Profile "%s" not defined' % name)
        path = results[0]['path'] if results else '_NOTDEFINED_'
        self.logger.info1('%s\t%s' % (name, path))
        return path

    def _parseRulesSpec(self, rulesSpec, domain, domId):
        ''' rName, rSrcs, rDsts, rScope, rAction, rServices = [c.strip() for c in comps] '''
        rSeq = 10
        cms = []

        for ruleSpec in rulesSpec.split(';'):
            ruleSpec = ruleSpec.strip()
            if not ruleSpec: continue
            comps = ruleSpec.split(':')
            rName, rSrcs, rDsts, rScope, rAction, rServices = [c.strip() for c in comps]
            #print(rName, rSrcs, rDsts, rScope, rAction, rServices)
            rAction = rAction.upper()
            rSrcs = [('ANY' if gName.upper() in ['', 'ANY']
                else self._pmGroupToPath(gName,domain)) for gName in rSrcs.split(',')]
            rDsts = [('ANY' if gName.upper() in ['', 'ANY']
                else self._pmGroupToPath(gName,domain)) for gName in rDsts.split(',')]
            rServices = [('ANY' if sName.upper() in ['', 'ANY']
                else self._pmServiceToPath(urllib2.unquote(sName))) for sName in rServices.split(',')]
            rScope = [('ANY' if sName.upper() in ['', 'ANY']
                else sName) for sName in rScope.split(',')]
            self.logger.info1('Mapping to path done')
            cms.append( {
                'display_name': re.sub('[ /]','_',rName),
                'sequence_number': rSeq,
                'source_groups': rSrcs,
                'destination_groups': rDsts,
                'scope': rScope,
                'action': rAction,
                'services': rServices,
            } )
            rSeq += 10
        return cms

    def create(self, domain, name,       # PM_CommunicationMap
            precedence,
            category='',
            entriesSpec='',
            applicationSpec='',
            emergencySpec='',
            environmentalSpec='',
            infrastructureSpec=''):
        ''' rName, rSrcs, rDsts, rScope, rAction, rServices = [c.strip() for c in comps] '''

        rulesSpec = entriesSpec or applicationSpec or emergencySpec or environmentalSpec or infrastructureSpec
    #category = 'Emergency'

        mgr = self.mgr
        domObj = PM_Domain(mgr)
        doms = domObj.list(display=False, nameGlob=domain)
        if doms['result_count']<1:
            self.logger.error('domain %s not found' % domain)
            return
        domId = doms['results'][0]['id']
        #jqFilterDz = '.results[] | {"name":.display_name, "id":.id}'
        #doms = [dict(d) for d in pyjq.all(jqFilterDz, doms)]

        jDict = {
            'category': category.capitalize(),
            'display_name': name,
            'precedence': precedence,
            'communication_entries': self._parseRulesSpec(rulesSpec, domain, domId),
        }
        #pprint(jDict)

        restKey='create'
        #cmId = self._mkObjId('CM')
        cmId = self._mkObjIdFromName(name)
        data = json.dumps(jDict)
        restUrl = eval(self.api[restKey].url)
        #restMethod = self.api[restKey].method
        restMethod = self._pmRestMethodMap(self.api[restKey].method)
        #print(restUrl, restMethod, data)
        if '_NOTDEFINED_' in data:
            self.logger.error('CommunicationMap "%s" not created due to missing object definition' % name)
        else:
            r = getattr(mgr, restMethod)(restUrl, data=data)
            return not mgr.checkForError(r)

    def delete(self, domain, category, nameGlob):               # PM_CommunicationMap
        ''' CODING IN PROGRESS '''
        force = False
        force = True

        mgr = self.mgr
        domObj = PM_Domain(mgr)
        doms = domObj.list(display=False, nameGlob=domain)
        if doms['result_count']<1:
            self.logger.error('domain %s not found' % domain)
            return
        domId = doms['results'][0]['id']

        objId = domId
        restKey='list'
        restUrl = eval(self.api[restKey].url)
        restMethod = self.api[restKey].method
        r = getattr(mgr, restMethod)(restUrl)
        mgr.checkForError(r)

        cms = [e for e in r.json()['results']
            if isGlobMatched(nameGlob, e['display_name']) and e['category']==category.capitalize()]

        #cms = [e for e in r.json()['results'] if isGlobMatched(nameGlob, e['display_name'])]
        #print('\n'.join(sorted([e['display_name'] for e in cms])))
        #print(len([e['display_name'] for e in cms]))
        #pprint_json(cms)
        #exit()

        for cm in cms:
            cmName, cmId = cm['display_name'], cm['id']
            #print(cmName, cmId)
            #'get':    Api('get',    '"/policy/api/v1/infra/domains/%s/communication-maps/%s"%(domId,cmId)'),
            url = eval(self.api['get'].url)
            #print(self.ptblFmts['get'].jqFilter)
            r = self.rest_api(url, method='GET')
            #print(r.text)
            jqTableDict = self.jqTable(jsonStr=r.text, nameGlob='',
                jqFilter=self.ptblFmts['get'].jqFilter, apiKey='get', display=False)
            cmes,cmePtbl = jqTableDict['rows'], jqTableDict['ptbl']
            if cmes and force:
                for cme in cmes:
                    cmeName, cmeId = cme['name'], cme['id']
                    restKey='deleteCme'
                    restUrl = eval(self.api[restKey].url)
                    restMethod = self.api[restKey].method
                    self.logger.info1('Deleting DOM/CM/CME "%s/%s/%s"' % (domain,cmName,cmeName))
                    self.logger.info4('REST %s %s' % (restMethod,restUrl))
                    r = getattr(mgr, restMethod)(restUrl)
                    mgr.checkForError(r)

            restKey='delete'
            cmName, cmId = cm['display_name'], cm['id']
            restUrl = eval(self.api[restKey].url)
            restMethod = self.api[restKey].method
            #print(restUrl, restMethod)
            self.logger.info1('Deleting DOM/CM "%s/%s"' % (domain,cmName))
            r = getattr(mgr, restMethod)(restUrl)
            mgr.checkForError(r)
        #for cm in cms:
        #    cmName, cmId = cm['name'], cm['id']
        #    print('###### Communication-entry: %s (%s)' % (cmName, cmId))
        #    url = eval(self.api['get'].url)
        #    #print(self.ptblFmts['get'].jqFilter)
        #    r = self.rest_api(url, method='GET', mgr=self.mgr)
        #    #print(r.text)
        #    cmes,cmePtbl = self.jqTable(jsonStr=r.text, nameGlob='',
        #        jqFilter=self.ptblFmts['get'].jqFilter, apiKey='get')

    """
    def delete21(self, domain):               # PM_CommunicationMap
        mgrVerIs21 = self.mgr.version.startswith('2.1')
        if mgrVerIs21:
            self.api = self.api21
            self.ptblFmts = self.ptblFmts21

        ''' CODING IN PROGRESS '''
        force = False
        force = True


        mgr = self.mgr
        domObj = PM_Domain(mgr)
        doms = domObj.list(mgr=mgr, display=False, nameGlob=domain)
        if doms['result_count']<1:
            self.logger.error('domain %s not found' % domain)
            return
        objId = domId = doms['results'][0]['id']
        domName = doms['results'][0]['display_name']
        #pprint(doms)
        #print('====== DOMAIN: %s %s' % (domName, domId))

        cmObj =  self.jqListCommunicationmap(nameGlob='', op='list', domain=domName, display=False)
        #pprint(cmObj)
        #print(domain, cmObj['display_name'])
        restKey='deleteCme'
        for ce in cmObj['communication_entries']:
            cmeId = ce['id']
            self.logger.info1('Removing %s Element %s' % (self.resType, cmeId))
            restUrl = eval(self.api[restKey].url)
            #print('url=',restUrl)
            restMethod = self.api[restKey].method
            r = getattr(mgr, restMethod)(restUrl)
            mgr.checkForError(r)
            #pprint(r.json())
    """

class PM_Realization(Network_object):
    resType = "RealizedEnforcementPoint"
    api = {
        'list':    Api('get', '/policy/api/v1/infra/realized-state/enforcement-points'),
        'listVif': Api('get', '/policy/api/v1/infra/realized-state/enforcement-points/default/vifs'),
        'listVm':  Api('get', '/policy/api/v1/infra/realized-state/enforcement-points/default/virtual-machines'),
        'getVm':   Api('get', '"/policy/api/v1/infra/realized-state/enforcement-points/default/virtual-machines/%s/details"%vmId'),
        'create':  Api('post', 'api/v1/loadbalancer/services')
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "state":  .state,
                "type": ([.intent_reference[] | split("/")[-2]] | join(",\n")),
                "name/id/path/realizId/intentRef": ([.display_name, .id, .path,
                    .realization_specific_identifier, (.intent_reference|join("\n"))
                    ] | join(",\n  "))
            }
        '''),
        'listVm': PtblFmt(api['listVm'].url, '''
            .results[] | {
                "name":   .display_name,
                "eId":   .external_id,
                "power_state":  .power_state,
                "os":  .guest_info.os_name,
                "source":  (.source|([.target_type,.target_display_name]|join("/")))
            }
        '''),
        'listVif': PtblFmt(api['listVif'].url, '''
            .results[] | {
                "id":          .external_id,
                "hostId":      .host_id,
                "mac_address": .mac_address,
                "ipInfo":  (.ip_address_info[] |
                    ( [(.ip_addresses|join(",")),.source]|join("/") ))
            }
        '''),
        'getVm': PtblFmt(api['listVif'].url, '''
            {
                "active_sessions":   .active_sessions,
                "archived_sessions": .archived_sessions
            }
        '''),
    }
    '''
                "ipInfo":  (.ip_address_info |
                    ( [.source,(.ip_addresses|join(","))]|join("/") ))
    '''

class PM_Segment(Network_object):
    resType = 'Segment'
    api = {
        'list':       Api('get',    '/policy/api/v1/infra/segments'),
        'delete':     Api('delete','"/policy/api/v1/infra/segments/%s"%_segId'),
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "name": .display_name,
                "id":   .id,
                "vlans": (if .vlan_ids then (.vlan_ids|join(",")) else "" end),
                "tz":   .transport_zone
            }'''),
    }

    def jq_PM_Segment(self, segNameGlob):
        segResp = self.jqTable(nameGlob=segNameGlob, display=False)
        #tzDict = {}
        #s_memoize.enabled=True; # This is a compiler time flag, not runtime flag!!!!

        #import inspect
        #print(inspect.getsource(self.getPolicyObjectByPath))

        for seg in segResp['restRespJson']['results']:
            tzPath = seg['transport_zone_path']

            tzObj = self.getPolicyObjectByPath(tzPath)
            tzName = tzObj.json()['display_name']

            '''
            if tzPath in tzDict:
                tzName = tzDict[tzPath]
            else:
                tzObj = self.getPolicyObjectByPath(tzPath)
                tzName = tzObj.json()['display_name']
                tzDict[tzPath] = tzName
            '''

            seg['transport_zone'] = re.sub(tzPath, tzName, seg['transport_zone_path'])
        self.jqTable(jsonStr=segResp['restRespJson'], nameGlob=segNameGlob)

    def delete_PM_Segment(self, segNameGlob):
        segIdDict = self.getIdsByNamesGlob(segNameGlob)
        for segId in segIdDict.keys():
            r = self.doRestApi('delete', _segId=segId)


class LbService(Network_object):
    resType = "LbService"
    api = {
        'list':   Api('get', '/api/v1/loadbalancer/services'),
        'create': Api('post', 'api/v1/loadbalancer/services')
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            def shortUuid:if . then .[:4]+".."+.[-4:] else "" end;
            .results[] | {
                "name": .display_name,
                "id": .id,
                "size": .size,
                "status": .enabled,
                "attachment":  (if .attachment then (.attachment | .target_display_name + "\n" + .id + "\n" + .type) else "" end)
            }
        '''),
    }

    def __init__(self,mgr):
        super(self.__class__,self).__init__(mgr=mgr)
        self.listUrl='/api/v1/loadbalancer/services'

    def createLbService(self, name, size, desc=None, logLevel="INFO"):
        data={}
        data['display_name']=name
        data['error_log_level']=logLevel
        data['size']=size
        if desc:
            data['description']=desc
        restUrl='/api/v1/loadbalancer/services'
        r = self.rest_api(api=restUrl, method='POST',
                          data=data, display=False)
        if r.status_code != 201:
            print("LB Service creation failed: %d" %r.status_code)

    def attachment(self,action, lbname, lrname):

        lb=self.findByName(name=lbname, display=False)
        if not lb:
            print("Load Balancer service %s not found" %lbname)
            return None


        if action=='del':
            if 'attachment' in lb:
                del lb['attachment']
            else:
                print('LB service %s does not have attachment to delete' %lbname)
                return None
        else:
            lro = LogicalRouter(mgr=self.mgr)
            lr = lro.findByName(name=lrname)



            if not lr:
                print("Logical router %s not found" %lrname)
                return None

            target={}
            target['target_id'] = lr['id']
            target['target_type'] = lr['resource_type']
            lb['attachment'] = target
        restUrl='/api/v1/loadbalancer/services/%s' % lb['id']
        r = self.rest_api(api=restUrl, data=lb, method='PUT', display=True)
        if r.status_code != 200:
            print("Update attachment failed with error code %d for LB %s"
                  %(r.status_code, lbname))
            return None
        else:
            return json.loads(r.text)


    def attachVip(self, lbname, action, vips):
        lb=self.findByName(name=lbname, display=False)
        if not lb:
            print("Load balancer service %s not found" %lbname)
            return None

        lbvip=LbVip(mgr=self.mgr)
        for v in vips:
            vip = lbvip.findByName(name=v, display=False)
            if not vip:
                print("LB VIP %s not found...continuing" %v)
                continue
            if action=="del":
                if not 'virtual_server_ids' in lb:
                    print("No VIPs attached to LB %s, quiting" %lbname)
                    continue
                if vip['id'] in vip['virtual_server_ids']:
                    vip['virtual_server_ids'].remove(vip['id'])
                else:
                    print("VIP %s not attached to LB %s" %(v,lbname))
                    continue
            else:
                if 'virtual_server_ids' in lb:
                    if vip['id'] in lb['virtual_server_ids']:
                        print("VIP %s already attached to LB %s" %(v, lbname))
                        continue
                    else:
                        lb['virtual_server_ids'].append(vip['id'])
                else:
                    lb['virtual_server_ids'] = [vip['id']]
        restUrl='/api/v1/loadbalancer/services/%s' %lb['id']
        r = self.rest_api(api=restUrl, data=lb, method='PUT', display=True)
        if r.status_code != 200:
            print("Update VIP failed with error code %d for LB %s"
                  %(r.status_code, lbname))
            return None
        else:
            return json.loads(r.text)





class LbPool(Network_object):
    api = {
        'list':   Api('get', '/api/v1/loadbalancer/pools'),
        'create': Api('post', 'api/v1/loadbalancer/pools')
    }

    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            def shortUuid:if . then .[:4]+".."+.[-4:] else "" end;
            .results[] | {
                "name": .display_name,
                "id": .id,
                "SNAT":  (if .snat_translation then .snat_translation.type else "" end),
                "SnatOvl": (if .snat_translation then .snat_translation.port_overload
                    else "" end),
                "sNAT Addr": (if .snat_translation and .snat_translation.type=="LbSnatIpPool"
                              then [.snat_translation.ip_addresses[]|.ip_address] | join(",")
                             else "" end),
                "Members": (if .members then [.members[]|.ip_address] | join(",\n")
                            elif .member_group then .member_group.grouping_object.target_display_name
                            else "" end),
                "ActiveMon": (if .active_monitor_ids then [.active_monitor_ids[]| shortUuid] | join(",\n")
                    else "" end),
                "PassMon": (if .passive_monitor_id then .passive_monitor_id |shortUuid else "" end)
            }
        '''),
    }


    def __init__(self,mgr):
        super(self.__class__,self).__init__(mgr=mgr)
        self.listUrl='/api/v1/loadbalancer/pools'


    def createLbPool(self,name,desc,algorithm, nat, overload, addr=None,minMem=1,
                     multiplex=False,multiCount=6):

        if self.findByName(name=name, display=False):
            print("LB Pool with name %s already exist" %name)
            return None
        data={}
        data['display_name'] = name
        if desc:
            data['description'] = desc
        data['algorithm'] = algorithm
        data['min_active_members'] = minMem
        data['tcp_multiplexing_enabled'] = multiplex
        data['tcp_multiplexing_number'] = multiCount
        natdata = {}
        print("Nat is %s" %nat)
        if nat == 'LbSnatAutoMap':
            print("In autonat")
            natdata['type'] = 'LbSnatAutoMap'
            natdata['port_overload'] = overload
            data['snat_translation'] = natdata
        elif nat== 'LbSnatIpPool':
            natdata['type'] = 'LbSnatIpPool'
            natdata['port_overload'] = overload
            natdata['ip_addresses'] = []
            if not addr:
                print("Atleast one IP address must be provided")
                return None
            for a in addr:
                IpElement={}
                if '/' in a:
                    IpElement['ip_address'],IpElement['prefix_length'] = a.split('/')
                else:
                    IpElement['ip_address'] = a
                natdata['ip_addresses'].append(IpElement)
            data['snat_translation'] = natdata
        else:
            pass
            # PassThrough - nothing needs to be done


        restUrl='/api/v1/loadbalancer/pools'
        r=self.rest_api(api=restUrl,method='POST', data=data,display=True)
        if r.status_code!=201:
            print('LB Pool creation create with name %s failed: %d' %(name,r.status_code))
            return None
        else:
            return json.loads(r.text)

    def updateMembers(self,pool,action,ip,name=None,state=True, backup=False,
                      maxCon=None,port=None,weight=1):
        def findMember():
            if not 'members' in ipPool:
                return None
            for m in ipPool['members']:
                for i in ip:
                    if m['ip_address'] == i:
                        return m
            return None

        ipPool=self.findByName(name=pool,display=False)

        if not ipPool:
            print("IP Pool %s not found" %pool)
            return False


        if action=='del':
            if not 'members' in ipPool:
                return True
            for i in ip:
                for m in ipPool['members']:
                    if m['ip_address'] == i:
                        ipPool['members'].remove(m)
        else:
            m = findMember()
            if m:
                print("IP address %s already in members list" %m['ip_address'])
                return False

            if name and len(name) != len(ip):
                print("Number of names do not match the number if IPs")
                return False
            for i in ip:
                data={}
                data['ip_address'] = i
                index=ip.index(i)
                if name:
                    data['display_name'] = name[index]
                else:
                    data['display_name'] = ip
                if backup:
                    data['backup_member'] = 'True'
                else:
                    data['backup_member'] = 'False'
                if maxCon:
                    if maxCon < 1 or maxCon > 2147483647:
                        print("Max concurrent connection must be 1 to 2147483647")
                        return False
                data['max_concurrent_connections'] = maxCon
                if port:
                    data['port'] = port
                if weight < 1 or weight > 255:
                    print("Weight must be 1 to 255")
                    return False
                else:
                    data['weight'] = weight

                if not 'members' in ipPool:
                    ipPool['members'] = []
                ipPool['members'].append(data)

        restUrl="/api/v1/loadbalancer/pools/%s" %ipPool['id']
        r = self.rest_api(api=restUrl, method='PUT', data=ipPool,display=False)
        if r.status_code != 200:
            print("Update IP Pool member failed with code: %d" %r.status_code)
            return False
        else:
            return json.loads(r.text)

    def updateMonitor(self,pool,action,active=None,passive=None):
        ipPool=self.findByName(name=pool,display=False)


        if not ipPool:
            print("IP Pool %s not found" %pool)
            return False

        if action=='del':
            if active:
                del ipPool['active_monitor_ids']
            if passive:
                del ipPool['passive_monitor_id']
        else:
            monitors = LbMonitor(mgr=self.mgr)
            if active:
                activeIds=[]
                for a in active:
                    m = monitors.findByName(name=a,display=False)
                    if not m:
                        print("Active monitor %s not found" %a)
                        return False
                    else:
                        activeIds.append(m['id'])
                ipPool['active_monitor_ids'] = activeIds

            if passive:
                m = monitors.findByName(name=passive,display=False)
                if not m:
                    print("Passive monitor %s not found" %a)
                    return False
                ipPool['passive_monitor_id'] = m['id']
        restUrl="/api/v1/loadbalancer/pools/%s" % ipPool['id']
        r = self.rest_api(api=restUrl,method="PUT", data=ipPool)
        if r.status_code != 200:
            print("Error in updating health monitor for LB pool %s, code: %d"
                  %(pool, r.status_code))
            self.json_print(r.text, convert=True)
        else:
            return json.loads(r.text)







    def updateDynamicMember(self, pool, action, nsgroup, ipfilter="IPV4",
                            maxip=0, port=None):
        ipPool=self.findByName(name=pool,display=False)

        if not ipPool:
            print("IP Pool %s not found" %pool)
            return False

        if action=='del':
            if "member_group" in ipPool:
                del ipPool['member_group']
            else:
                print("No member group configured, nothing deleted")
                return False

        else:
            nsg = NSGroups(mgr=self.mgr)
            group = nsg.findByName(name=nsgroup,display=False)
            if not group:
                print("NS Group of name %s not found" % nsgroup)
                return False

            target={}
            target['target_id'] = group['id']
            target['target_type'] = group['resource_type']

            data={}
            data['grouping_object'] = target
            data['ip_revision_filter'] = ipfilter
            if maxip:
                data['max_ip_list_size'] = maxip
            if port:
                data['port'] = port
            ipPool['member_group'] = data

        self.json_print(ipPool)

        restUrl='/api/v1/loadbalancer/pools/%s' %ipPool['id']
        r = self.rest_api(api=restUrl,method='PUT', data=ipPool,display=False)
        if r.status_code != 200:
            print("Update IP Pool grouping failed with code: %d" %r.status_code)
            return False
        else:
            return json.loads(r.text)

class LbMonitor(Network_object):
    api = {
        'list':   Api('get', '/api/v1/loadbalancer/monitors'),
        'create': Api('post', 'api/v1/loadbalancer/monitors')
    }

    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            def shortUuid:if . then .[:4]+".."+.[-4:] else "" end;
            .results[] | {
                "name": .display_name,
                "id": .id,
                "type": .resource_type
            }
        '''),
    }


    def __init__(self,mgr):
        super(self.__class__,self).__init__(mgr=mgr)
        self.listUrl='/api/v1/loadbalancer/monitors'


    def constructHttpHeaders(self, headerNames, headerValues):
        if len(headerNames) != len(headerValues):
            raise ValueError("LbMonitor - HTTP headers: number of headers != values")

    def constructHttpHeaders(self, headerNames, headerValues):
        if len(headerNames) != len(headerValues):
            raise ValueError("LbMonitor - HTTP headers: number of headers != values")

        headers = []
        for i in range(len(headerNames)):
            hdr = {}
            hdr['header_name'] = headerNames.index(i)
            hdr['header_value'] = headerValues.index(i)
            headers.append(hdr)

        return headers


    def configHttp(self, name, port=None,
                   fall=3, rise=3, interval=5, body=None,
                   headerName=None, headerValue=None,
                   reqMethod='GET', url=None,
                   version='HTTP_VERSION_1_1',
                   responseBody=None,
                   responseCode = None,
                   timeout = 15, desc=None):

        data={}
        data['display_name'] = name
        if desc:
            data['description'] = desc
        data['fall_count'] = fall
        data['rise_count'] = rise
        data['interval'] = interval
        if port:
            data['monitor_port'] = port
        if body:
            data['request_body'] = body
        if url:
            data['request_url'] = url

        if headerName:
            data['request_headers'] = self.constructHttpHeaders(headerNames=headerName,
                                                                headerValues=headerValue)

        data['request_method'] = reqMethod
        data['resource_type'] = 'LbHttpMonitor'
        if responseBody:
            data['resource_body'] = responseBody
        if responseCode:
            data['response_status_codes'] = responseCode
        data['timeout'] = timeout

        restUrl = '/api/v1/loadbalancer/monitors'
        r = self.rest_api(api=restUrl,method='POST',data=data,display=False)
        if r.status_code != 200:
            print("LbMonitor - configHttp: response code %d not expected" %r.status_code)
            print("   error: %s" %r.text)


    def configHttps(self, name, port=None,
                    fall=3, rise=3, interval=5, body=None,
                    headerName=None, headerValue=None,
                    reqMethod='GET', url=None,
                    certDepth=3, ciphers=None,
                    clientCert=None, protocols=None,
                    serverAuth = "IGNORE",
                    ca=None,
                    crl=None,
                    version='HTTP_VERSION_1_1',
                    responseBody=None,
                    responseCode = None,
                    timeout = 15, desc=None):

        data={}
        data['display_name'] = name
        if desc:
            data['description'] = desc
        data['fall_count'] = fall
        data['rise_count'] = rise
        data['interval'] = interval
        if port:
            data['monitor_port'] = port
        if body:
            data['request_body'] = body
        if url:
            data['request_url'] = url

        if headerName:
            data['request_headers'] = self.constructHttpHeaders(headerNames=headerName,
                                                                headerValues=headerValue)

        data['request_method'] = reqMethod
        data['resource_type'] = 'LbHttpsMonitor'
        if responseBody:
            data['resource_body'] = responseBody
        if responseCode:
            data['response_status_codes'] = responseCode
        data['timeout'] = timeout

        data['certificate_chain_depth'] = certDepth
        if ciphers:
            data['ciphers'] = ciphers
        if clientCert:
            data['client_certificate_id'] = clientCert
        if protocols:
            data['protocols'] = protocols
        data['server_auth'] = serverAuth
        if ca:
            data['server_auth_ca_ids'] = []
            # Assume that if CA is given, then auth is required
            for c in ca:
                data['server_auth_ca_ids'].append(c)
        if crl:
            data['server_auth_crl_ids'] = []
            for c in crl:
                data['server_auth_crl_ids'].append(c)


        restUrl = '/api/v1/loadbalancer/monitors'
        r = self.rest_api(api=restUrl,method='POST',data=data,display=False)
        if r.status_code != 201:
            print("LbMonitor - configHttp: response code %d not expected" %r.status_code)
            print("   error: %s"%r.text)


    def configPassive(self, name, fails=5, timeout=5, desc=None):
        data={}
        data['display_name'] = name
        if desc:
            data['description'] = desc
        data['max_fails'] = fails
        data['resource_type'] = 'LbPassiveMonitor'
        data['timeout'] = timeout

        restUrl = '/api/v1/loadbalancer/monitors'
        r = self.rest_api(api=restUrl,method='POST',data=data,display=False)
        if r.status_code != 200:
            print("LbMonitor - configHttp: response code %d not expected" %r.status_code)
            print("   error: %s"%r.text)

    def configIcmp(self, name, fall=3, rise=3, interval=5,
                   timeout=15, size=56, desc=None):
        data={}
        data['display_name'] = name
        if desc:
            data['description'] = desc
        data['fall_count'] = fall
        data['rise_count'] = rise
        data['interval'] = interval
        data['data_length'] = size
        data['resource_type'] = 'LbIcmpMonitor'
        data['timeout'] = timeout

        restUrl = '/api/v1/loadbalancer/monitors'
        r = self.rest_api(api=restUrl,method='POST',data=data,display=False)
        if r.status_code != 200:
            print("LbMonitor - configHttp: response code %d not expected" %r.status_code)
            print("   error: %s"%r.text)

    def configTcp(self, name, fall=3, rise=3, port=None,interval=3,
                  receive=None, send=None,timeout=15):

        data={}
        data['display_name'] = name
        if desc:
            data['description'] = desc
        data['fall_count'] = fall
        data['rise_count'] = rise
        data['interval'] = interval
        if port:
            data['monitor_port'] = port

        if send:
            data['send'] = send
        if receive:
            data['receive'] = receive
        data['resource_type'] = 'LbTcpMonitor'

        restUrl = '/api/v1/loadbalancer/monitors'
        r = self.rest_api(api=restUrl,method='POST',data=data,display=False)
        if r.status_code != 200:
            print("LbMonitor - configHttp: response code %d not expected" %r.status_code)
            print("   error: %s"%r.text)


class LbAppProfile(Network_object):
    api={
        'list': Api('get', '/api/v1/loadbalancer/application-profiles')
    }

    def __init__(self,mgr):
        super(self.__class__,self).__init__(mgr=mgr)
        self.listUrl='/api/v1/loadbalancer/application-profiles'


class LbVip(Network_object):
    api = {
        'list':   Api('get', '/api/v1/loadbalancer/virtual-servers'),
        'create': Api('post', 'api/v1/loadbalancer/virtual-servers')
    }

    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            def shortUuid:if . then .[:4]+".."+.[-4:] else "" end;
            .results[] | {
                "name": .display_name,
                "id": .id,
                "enabled": .enabled,
                "ip_address": .ip_address,
                "ip_protocol": .ip_protocol,
                "pool": (if .pool_id then .pool_id | shortUuid else "" end),

                "ports": (if .ports then
                            [.ports[]] | join(",")
                          else "" end),

                "def_mports": (if .default_pool_member_ports then
                            [.default_pool_member_ports[]] | join(",")
                          else "" end),
                "appprofile": .application_profile_id | shortUuid,
                "rules": (if .rule_ids then
                            [.rule_ids[]] | join(",")
                          else "" end),
            }
        '''),
    }


    def __init__(self,mgr):
        super(self.__class__,self).__init__(mgr=mgr)
        self.listUrl='/api/v1/loadbalancer/virtual-servers'


    def config(self, name, vip, appProfile, clientSslCert=None, clientSslProfile=None,
               maxConcurrent=None, maxNewConnRate=None, persistenceProfile=None,
               pool=None, ports=None, desc=None, tags=None):

        #appProfile determines L4 or L7
        app = self.findByName(name=appProfile,
                            restUrl='/api/v1/loadbalancer/application-profiles',
                            display=False)
        if not app:
            print("Application profile %s not found" %appProfile)
            return False

        data={}
        data['application_profile_id'] = app['id']
        data['display_name'] = name
        if desc:
            data['description'] = desc
        data['ip_address'] = vip
        if ports:
            data['ports'] = ports
        if tags:
            t=Tags(mgr=self.mgr)
            data['tags'] = t.createFromSpec(spec=tags)

        if maxConcurrent:
            data['max_concurrent_connections'] = maxConcurrent
        if maxNewConnRate:
            data['max_new_connection_rate'] = maxNewConnRate

        if persistenceProfile:
            pp = self.findByName(name=persistenceProfile,
                                 restUrl='/api/v1/loadbalancer/persistence-profiles',
                                 display=False)
            if not pp:
                print("Persistence profile '%s' not found" %persistenceProfile)
                return False
            else:
                data['persistence_profile_id'] = pp['id']

        if pool:
            lbp = LbPool(mgr=self.mgr)
            p = lbp.findByName(name=pool, display=False)
            if not p:
                print("LB Pool '%s' not found" %pool)
                return False
            else:
                data['pool_id'] = p['id']

        if app['resource_type'] == 'LbHttpProfile':
            #L7
            data['ip_protocol'] = "TCP"
            # clientSide SSL termination
            if clientSslCert:
                c = Certificate(mgr=self.mgr)
                cid = c.findByName(name=clientSslCert, display=False)
                certData={}
                if not cid:
                    print("SSL Certificate %s not found" %clientSslCert)
                    return False
                else:
                    certData['default_certificate_id'] = cid['id']
            if clientSslProfile:
                p = self.findByName(name=clientSslProfile,
                                    restUrl='/api/v1/loadbalancer/client-ssl-profiles',
                                    display=False)
                if not p:
                    print("Client SSL Profile %s not found" %clientSslProfile)
                    return False
                else:
                    certData['ssl_profile_id'] = p['id']
            data['client_ssl_profile_binding'] = certData
        elif app['resource_type'] == 'LbFastTcpProfile':
            # L4 tcp
            data['ip_protocol'] = "TCP"
        elif app['resource_type'] == 'lbFastUdpProfile':
            # L4 UDP
            data['ip_protocol'] = "UDP"
        else:
            print("App profile of type %s not handled by this script"
                  %app['resource_type'])




        restUrl = '/api/v1/loadbalancer/virtual-servers'
        r = self.rest_api(api=restUrl, method='POST', data=data, display=True)
        if r.status_code != 201:
            print("Error in creating VIP with code: %d" %r.status_code)
            return False
        else:
            return True






class ExcludeList(Network_object):
    api = {
        'list':   Api('get',   '/api/v1/firewall/excludelist'),
        'check':  Api('post', '"/api/v1/firewall/excludelist?action=check_if_exists&object_id=%s"%objectId'),
        'remove': Api('post', '"/api/v1/firewall/excludelist?action=remove_member&object_id=%s"%objectId'),
        'add':    Api('post',  '/api/v1/firewall/excludelist?action=add_member'),
    }

    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            def listify:if type=="array" then .[] else select(.) end;
            def shortUuid:if . then .[:4]+".."+.[-4:] else "" end;
            .members |listify |{
                "name": .target_display_name,
                "type": .target_type,
                "id":   .target_id,
            }'''),
    }

    def excludeListOp(self, op, nameGlob, targetType=None, fmt='brief'):
        # choices=['raw','xml','yaml','json','brief','pipe'],
        if op=='list':
            if fmt=='brief':
                jqTableDict = self.jqTable(apiKey='get', nameGlob=nameGlob)
                rows, ptbl = jqTableDict['rows'], jqTableDict['ptbl']
            else:
                self.list(fmt=fmt, nameGlob=nameGlob)
        else:
            # LogicalSwitch LogicalPort NSGroup
            if targetType == 'NSGroup':
                targetInst = NSGroups(self.mgr)
                targetObjs = targetInst.findByNamesGlob(nameGlob, nameTag='display_name')
            elif targetType == 'LogicalSwitch':
                targetInst = Switch(self.mgr)
                targetObjs = targetInst.findByNamesGlob(nameGlob, nameTag='display_name')
            elif targetType == 'LogicalPort':
                targetInst = SwitchPorts(self.mgr)
                targetObjs = targetInst.findByNamesGlob(nameGlob, nameTag='display_name')
            else:
                self.logger.error('Cannot add unsupported resource type "%s" to exclude list' % objName)
                return False

            for targetObj in targetObjs:
                objName,objId,objType = targetObj['display_name'],targetObj['id'],targetObj['resource_type']
                #print(op, nameGlob)
                if op=='add':
                    jsonDict = {
                        'target_id': objId,
                        'target_type': objType,
                    }
                    self.logger.info1('Adding %s "%s" to exclude list' % (objType, objName))
                    r = self.doRestApi('add', data=json.dumps(jsonDict))
                elif op=='check':
                    self.logger.info1('Check %s "%s" from exclude list' % (objType, objName))
                    r = self.doRestApi('check', objectId=objId)
                    if r.status_code==200:
                        print('%s "%s" is member of Exclude list' % (objType, objName))
                elif op=='remove':
                    self.logger.info1('Removing %s "%s" from exclude list' % (objType, objName))
                    r = self.doRestApi('remove', objectId=objId)
                    if r.status_code==200:
                        self.logger.info1('%s "%s" has been removed from Exclude list' % (objType, objName))


class SwitchProfile(Network_object):
    api = {
        'list': Api('get', '/api/v1/switch-profiles'),
    }


    def __init__(self,mgr):
        super(self.__class__, self).__init__(mgr=mgr)
        self.listUrl='/api/v1/switching-profiles'

    def configSpoofGuard(self, name, bindings, desc=None,tags=None):
        if self.findByName(name=name, display=False):
            print("Switch profile with name '%s' already exist'" %name)
            return False

        data={}
        data['display_name']=name
        if desc:
            data['description'] = desc
        data['resource_type'] = 'SpoofGuardSwitchingProfile'
        if tags:
            t=Tags(mgr=self.mgr)
            data['tags'] = t.createFromSpec(spec=tags)

        if bindings:
            data['white_list_providers'] = bindings
        else:
            data['white_list_providers'] = []


        return self.submitPost(data=data)

    def submitPost(self,data):
        r = self.rest_api(api=self.listUrl, method='POST', data=data, display=True)
        if r.status_code != 201:
            print("Switch profile creation failed with error %d" %r.status_code)
            return False
        else:
            return True


    def configSwitchSecurity(self, name, bpdu=True, bpduMacs=None,
                             blockdhcpserver=True, blockdhcpclient=False,
                             blockNonIp=False,
                             ratelimit=False,
                             rxbroadcast=0,
                             rxmulticast=0,
                             txbroadcast=0,
                             txmulticast=0, desc=None, tags=None):
        if self.findByName(name=name, display=False):
            print("Switch profile with name '%s' already exist'" %name)
            return False


        data={}
        data['display_name']=name
        if desc:
            data['description'] = desc
        data['resource_type'] = 'SwitchSecuritySwitchingProfile'
        if tags:
            t=Tags(mgr=self.mgr)
            data['tags'] = t.createFromSpec(spec=tags)


        data['block_non_ip_traffic'] = blockNonIp
        bpduFilter={}
        bpduFilter['enabled'] = bpdu
        if bpduMacs:
            bpduFilter['white_list'] = bpduMacs
        data['bpdu_filter'] = bpduFilter

        dhcpFilter={}
        dhcpFilter['client_block_enabled'] = blockdhcpclient
        dhcpFilter['server_block_enabled'] = blockdhcpserver
        data['dhcp_filter']=dhcpFilter

        rateLimit={}
        rateLimit['enabled'] = ratelimit
        rateLimit['rx_broadcast'] = rxbroadcast
        rateLimit['rx_multicast'] = rxmulticast
        rateLimit['tx_broadcast'] = txbroadcast
        rateLimit['tx_multicast'] = txmulticast
        data['rate_limits'] = rateLimit


        return self.submitPost(data=data)

    def configIpDiscovery(self, name, arpsnoop=True, arplimit=1,
                          dhcpsnoop=True, vmtools=False, desc=None, tags=None):
        if self.findByName(name=name, display=False):
            print("Switch profile with name '%s' already exist'" %name)
            return False


        data={}
        data['display_name']=name
        if desc:
            data['description'] = desc
        data['resource_type'] = 'IpDiscoverySwitchingProfile'
        if tags:
            t=Tags(mgr=self.mgr)
            data['tags'] = t.createFromSpec(spec=tags)

        data['arp_snooping_enabled'] = arpsnoop
        data['arp_bindings_limit'] = arplimit
        data['dhcp_snooping_enabled'] = dhcpsnoop
        data['vm_tools_enabled'] = vmtools

        return self.submitPost(data=data)


    def configMacManagement(self, name, macChange = True,
                            macAge=300, macLearn=False,
                            macLimit=4096, macLimitPolicy="ALLOW",
                            uflood=True, desc=None, tags=None):
        if self.findByName(name=name, display=False):
            print("Switch profile with name '%s' already exist'" %name)
            return False


        data={}
        data['display_name']=name
        if desc:
            data['description'] = desc
        data['resource_type'] = 'MacManagementSwitchingProfile'
        if tags:
            t=Tags(mgr=self.mgr)
            data['tags'] = t.createFromSpec(spec=tags)


        data['mac_change_allowed'] = macChange
        mLearn = {}
        mLearn['enabled'] = macLearn
        mLearn['aging_time']= macAge
        mLearn['limit'] = macLimit
        mLearn['limit_policy'] = macLimitPolicy
        mLearn['unicast_flooding_allowed'] = uflood
        data['mac_learning'] = mLearn

        return self.submitPost(data=data)

    def configPortMirror(self, name, dest, direction="BIDIRECTIONAL",
                         snap=None, key=None, desc=None, tags=None):

        if self.findByName(name=name, display=False):
            print("Switch profile with name '%s' already exist'" %name)
            return False


        data={}
        data['display_name']=name
        if desc:
            data['description'] = desc
        data['resource_type'] = 'PortMirroringSwitchingProfile'
        if tags:
            t=Tags(mgr=self.mgr)
            data['tags'] = t.createFromSpec(spec=tags)

        data['destinations'] = dest
        data['direction'] = direction
        if snap:
            data['snap_length'] = snap
        if key:
            data['key'] = key

        return self.submitPost(data=data)

    def configQos(self,name,cos=0, dscpMode="TRUSTED", dscp=0,
                  shapers=None, desc=None, tags=None):
        if self.findByName(name=name, display=False):
            print("Switch profile with name '%s' already exist'" %name)
            return False


        data={}
        data['display_name']=name
        if desc:
            data['description'] = desc
        data['resource_type'] = 'QosSwitchingProfile'
        if tags:
            t=Tags(mgr=self.mgr)
            data['tags'] = t.createFromSpec(spec=tags)

        data['class_of_service'] = cos
        dscpConfig={}
        dscpConfig['mode'] = dscpMode
        dscpConfig['priority'] = dscp
        data['dscp'] = dscpConfig
        shaperConfig=None
        if shapers:
            for s in shapers:
                if s==None:
                    continue
                shape={}
                shape['enabled'] = True
                shape['resource_type']=s
                if not shaperConfig:
                    shaperConfig=[shape]
                else:
                    shaperConfig.append(shape)
        if shaperConfig:
            data['shaper_configuration'] = shaperConfig

        return self.submitPost(data=data)



class Ipam(Network_object):
    resType = 'IpBlock'
    api = {
        'list': Api('get', '/api/v1/pools/ip-blocks'),
    }


    def __init__(self,mgr):
        super(self.__class__, self).__init__(mgr=mgr)
        self.listUrl='/api/v1/pools/ip-blocks'


    def config(self, name, cidr, desc=None, tags=None):
        if self.findByName(name=name, display=False):
            print("IPAM with name %s already exist" %name)
            return False
        data={}
        if tags:
            t = Tags(mgr=self.mgr)
            data['tags']=t.createFromSpec(spec=tags)

        data['cidr'] = cidr
        data['display_name'] = name
        if desc:
            data['description'] = desc

        r = self.rest_api(api=self.listUrl, method='POST', data=data)
        if r.status_code != 201:
            print("IPAM creation failed with error %d" %r.status_code)
            return False
        else:
            return True


class PM_EdgeCluster(Network_object):
    resType = 'PolicyEdgeCluster'
    api = {
        'list': Api('get', '/policy/api/v1/infra/sites/%s/enforcement-points/%s/edge-clusters' %('default', 'default')),
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            .results[] | {
                "name": .display_name,
                "id":   .id,
                "path": .path,
            }'''),
    }



class PM_DhcpRelay(Network_object):
    resType = 'DhcpRelayConfig'
    api = {
        'list': Api('get', '/policy/api/v1/infra/dhcp-relay-configs'),
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            def shortUuid:if . then .[:4]+".."+.[-4:] else "" end;
            .results[] | {
                "name": .display_name,
                "id":   .id,
                "servers": (.server_addresses|join(",\n")),
            }'''),
    }

class PM_Tier0(Network_object):
    resType = 'Tier0'
    api = {
        'list': Api('get', '/policy/api/v1/infra/tier-0s'),
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            def shortUuid:if . then .[:4]+".."+.[-4:] else "" end;
            .results[] | {
                "name": .display_name,
                "id":   .id,
                "transit": (.transit_subnets|join(",\n")),
                "internal": (.internal_transit_subnets|join(",\n")),
                "ha": .ha_mode,
                "dhcpRelay": [(.dhcp_config_paths[] | split("/"))[-1]] | join(",\n")
            }'''),
    }

class PM_Tier1(Network_object):
    resType = 'Tier0'
    api = {
        'list': Api('get', '/policy/api/v1/infra/tier-1s'),
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            def shortUuid:if . then .[:4]+".."+.[-4:] else "" end;
            .results[] | {
                "name": .display_name,
                "id":   .id,
                "advertisement": (.route_advertisement_types|join(",\n")),
                "dhcpRelay": [(.dhcp_config_paths[] | split("/"))[-1]] | join(",\n")
            }'''),
    }

class PM_PrefixList(Network_object):
    resType = 'PrefixList'
    api = {
        'list': Api('get', '"/policy/api/v1%s/prefix-lists"%t0Path'),
        'list': Api('get', '"/policy/api/v1/infra/tier-0s/%s/prefix-lists"%t0Name'),
    }
    ptblFmts = {
        'list': PtblFmt(api['list'].url, '''
            def shortUuid:if . then .[:4]+".."+.[-4:] else "" end;
            .results[] | {
                "tier0": (.parent_path|split("/")[-1]),
                "name": .display_name,
                "id":   .id,
                "prefixes":
                    (
                        [.prefixes[] | .action+"  "+ .network +
                            (
                                if has("ge") then " >= "+(.ge|tostring) else
                                    if has("le") then " <= "+(.le|tostring) else "" end
                                end
                            )
                        ]
                    ) | join("\n"),
            }'''),
    }
