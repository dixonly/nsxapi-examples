#!/usr/bin/env python
import pinit
import os, sys
import pdb, traceback, inspect
import ast
import re
import urllib2
import json, yaml, pyjq
import textwrap
import requests, restlib
import time, datetime
import logging
import collections, itertools
from   collections import OrderedDict as OD
from   collections import namedtuple
import xmltodict
from yamlxml import yaml_to_xml
import abc
import copy
import cptutil
from pprint import pformat, pprint
from cptutil import pformat_od, pprint_od
from cptutil import pformat_xml, pprint_xml
from cptutil import pprint_yaml, pformat_yaml
from cptutil import pprint_json, pformat_json, pprint_jsons
from cptutil import pformat_xmlInYaml, pprint_xmlInYaml
from cptutil import listify, tuplify, toUtf8Dict, byteify, flatten, iflatten
from cptutil import isGlobMatched
from cptutil import memoize, xw
from pyVim import connect
from pyVim.connect import SmartConnect
from pyVmomi import vim
from pyVmomi import vmodl
from hashlib import sha256
import vs
import nsxv
import vslib
#from nsxv import connect_to_vcenter
#from nsxv import connect_to_vcenter_kwargs
#from nsxv import find_portgroup_or_logical_switch_by_name
#from nsxv import enable_ls_learning_discovery
from random import shuffle
import random, math
import operator
from toasterlib import Toaster
from prettytable import PrettyTable
from sglib import fmtSgXml, mapNsxvObjNameToId
import OpenSSL
from nsxvFuncLib import get_inner_list, format_find_result, getYamlObjName, checkIsUniversal
from nsxvFuncLib import getDictValueByKeyPath, setDictValueByKeyPath, swapXmlTag, readYmlFile
from nsxvFuncLib import config_securitygroup, sbux_insert_securitygroup, unpackCSSpec, clusterNameToMo
from nsxvFuncLib import unpackCSSpec2
from nsxvFuncLib import hostNameToMoid, clusterNameToMoid, clusterNameGlobToMoids, hostNameGlobToMoids

import requests, urllib3
requests.packages.urllib3.disable_warnings()                        # for older requests package
if hasattr(urllib3, 'disable_warnings'):
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning) # for new requests package

Api         = namedtuple('Api',         ('method', 'url', 'headers'))
VcenterInfo = namedtuple('VcenterInfo', ('vcenter', 'vuser', 'vpasswd'))
JqTableSpec = namedtuple('JqTableSpec', ('jqFilter', 'headings'))
JqTblSpec   = namedtuple('JqTblSpec',   ('jqFilter', 'headings'))

PtblFmt     = namedtuple('PtblFmt',     ('url', 'jqFilter'))        # def from nsxtlib

###############################################################################
class Singleton(type):
    _instances = {}
    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        return cls._instances[cls]

class NsxVc(object):
    #__metaclass__ = Singleton

    def __init__(self, mgr, vpasswd, logger=None):
        self._vc = None
        # get vCenter info from NSX manager
        mgr.logger.info('Getting vCenter info from NSX manager')
        r = mgr.get('/api/2.0/services/vcconfig')
        if r.status_code >= 400:
            mgr.responseError(r)
        vcInfo = xmltodict.parse(r.text)['vcInfo']
        self.vcIp = vcInfo['ipAddress']
        self.vcUser = vcInfo['userName']
        self.vcPass = vpasswd

        if not self.vcIp or not self.vcUser or self.vcIp=='0.0.0.0':
            mgr.logger.error('Cannot get vCenter information from NSX manager')
            mgr.logger.error('Did you register your manager to  vCenter?')
        else:
            try:
                mgr.logger.info2('Connecting to vCenter: %s w/user: %s' % (self.vcIp, self.vcUser))
                self.vcInfo = VcenterInfo(self.vcIp, self.vcUser, self.vcPass)
                #print((self.vcIp, self.vcUser, self.vcPass))
                vslibVc = vslib.Vcenter(self.vcIp, self.vcUser, self.vcPass, logger=logger)
                self.vslibVc = vslibVc
                self.vcon = {'si': vslibVc.si, 'inv': vslibVc.inv}
                self.si = self.vcon['si']
                self.inv = self.vcon['inv']
            except Exception as e:
                mgr.logger.error(e)
                mgr.logger.error('Cannot get vCenter information from NSX manager')
                mgr.logger.error('Did you register your manager to  vCenter?')


class Network_object(object):
    #__metaclass__  = abc.ABCMeta

    def __init__(self, mgr, *args, **kwargs):
        self.mgr = mgr
        self.cachedObjs = None
        self.className = self.__class__.__name__

        self.logger = kwargs['logger'] if 'logger' in kwargs else self.mgr.logger

    def _checkGetResObjSize(self, rOd, outerTag, restMethod, restUrl):
        ''' support function for paged GET operation
        '''
        if rOd[outerTag] and 'pagingInfo' in rOd[outerTag]:
            pInfo = rOd[outerTag]['pagingInfo']
            pageSize, startIndex, totalCount = [int(pInfo[k]) for k in ['pageSize', 'startIndex', 'totalCount']]
            while totalCount > startIndex+pageSize:
                nItem = int(pInfo['pageSize'])
                newStartIndex = nItem+int(pInfo['startIndex'])
                self.mgr.logger.info('> pageSize, indext:newIndex, nItem, cumu/total: %4d, %4d:%-4d, %4d, %4d/%-4d' % (
                    pageSize, startIndex, newStartIndex, nItem, nItem+startIndex, totalCount))

                joinChar = '&' if '?' in restUrl else '?'
                restUrl = re.sub(r'(startIndex)=(\d*)', r'\1=%s'%newStartIndex, restUrl) \
                    if 'startIndex' in restUrl else '%s%cstartIndex=%d' % (restUrl, joinChar, newStartIndex)

                r = self.doRestApi('%s %s' % (restMethod, restUrl))
                newObjs = xmltodict.parse(r.text)

                op1, op2 = rOd, newObjs
                for k in self.rKeys: op1, op2 = op1[k], op2[k]
                op2 = listify(op2)
                op1.extend(op2)
                newNItem = len(op2)

                rOd[outerTag]['pagingInfo'] = newObjs[outerTag]['pagingInfo']
                pInfo = rOd[outerTag]['pagingInfo']
                pageSize, startIndex, totalCount = [int(pInfo[k]) for k in ['pageSize', 'startIndex', 'totalCount']]
                self.mgr.logger.info2('< pageSize,      startIndex, nItem, cumu/total: %4d, %9d, %4d, %4d/%-4d' % (
                    pageSize, startIndex, newNItem, newNItem+startIndex, totalCount ))
        return rOd

    def find(self, refresh=False, PCache='w', **kwargs):
        '''
        Find all network element of this class
        '''
        #self.logger.info('%s: refresh=%s, chachedObjs=%s' % (self, refresh, 'cachedObjs' if self.cachedObjs else 'NONE'))
        #if refresh: traceback.print_stack()

        # return mCache objects
        if self.cachedObjs and not refresh:
            self.logger.info1('returning mCached %s' % self.__class__.__name__)
            return self.cachedObjs

        if not refresh and 'r' in PCache:
            with cptutil.Cache(self.mgr.mgrIp) as cache:
                self.logger.info1('Getting %s from persistent cache' %
                        self.className)
                result = cache[self.className]
                if result:
                    self.logger.info1('%d persistently-cached %s' % (
                        len(result), self.className))
                    if self.mgr.logLevel<logging.INFO:
                        traceback.print_stack()
                    self.logger.info1('Memory caching result')
                    self.cachedObjs = result
                    self.logger.info1('returning pCached %s' % self.__class__.__name__)
                    return result
                else:
                    self.logger.info1('pCache miss')

        ''' extract kwargs to local namesapce '''
        exec('\n'.join('%s=kwargs["%s"]' % (k, k) for k in kwargs.keys()))

        '''
        cannot use doRestApi becase kwargs is not being passed down
        r = self.doRestApi('get')
        '''
        restUrl = self.rest_api['get'].url
        if restUrl.count('%') >= 2: restUrl = eval(restUrl)
        restMethod = self.rest_api['get'].method

        apiSendTime = datetime.datetime.now()
        r = getattr(self.mgr, restMethod)(restUrl)
        if r.status_code >= 400:
            self.mgr.responseError(r)
        apiRecvTime = datetime.datetime.now()
        self.logger.info3('GET API for %s of %s took %ss' % (
            cptutil.normDiskSize(len(r.text)), self.className, cptutil.fmtDeltaDatetime(apiSendTime, '%0.3f')))
        self.logger.debug('%s: r.text=%s...' % (self.__class__, r.text[:1000]))

        xmlConvStart = datetime.datetime.now()
        rOd = xmltodict.parse(r.text)
        rOd = self._checkGetResObjSize(rOd, self.rKeys[0], self.rest_api['get'].method, restUrl)
        objs = get_inner_list(rOd, self.rKeys)
        xmlConvEnd = datetime.datetime.now()
        nObj = len(objs)
        self.logger.info3('Processed %d non-cached %s took %ss' % (
            nObj, self.className, cptutil.fmtDeltaDatetime(xmlConvStart, '%0.3f')))
        self.logger.debug('\n'.join([e.split('\n')[0] for e in traceback.format_stack()]))

        shelveStart = datetime.datetime.now()
        if 'w' in PCache or 'r' in PCache:
            # if 'r' and execution got here, call has been made to mgr, need to update pCache
            with cptutil.Cache(self.mgr.mgrIp) as cache:
                cache[self.className] = objs
        shelveDuration = datetime.datetime.now()-shelveStart
        self.logger.info3('shelved %d %s took %ss' % (nObj, self.className,
            cptutil.fmtDeltaDatetime(shelveStart, '%0.3f')))

        self.cachedObjs = objs

        self.rawFindRespText = r.text
        #self.logger.debug('parsing r.text from XML into dict')
        #self.fullOd = byteify(xmltodict.parse(r.text))
        #self.logger.debug('parsed  r.text from XML into dict')

        cDictByOid = cDictByOname = {}
        for obj in objs:
            if 'objectId' in obj and 'name' in obj:
                cDictByOid.update({obj['objectId']:obj['name']})
                cDictByOname.update({obj['name']:obj['objectId']})
        self.cDictByOid = cDictByOid
        self.cDictByOname = cDictByOname

        return byteify(objs)

    def getByObjectId(self, objectId, result='od'):
        if 'getone' not in self.rest_api:
            self.logger.error('%s does not support getone API' % self.__class__.__name__)
            return None
        r = self.doRestApi('getone', objectId=objectId)
        if result=='od':
            return xmltodict.parse(r.text)
        else:
            return r.text

    '''
    def getByNamesGlob(self, namesGlob, results='objectId', idBy='name',
            refresh=False, matchMethod=None, logError=False, PCache='w'):
    def namesGlobToNames(self, namesGlob):
        for nameGlob in namesGlob:
            self.find_by_name(nameGlob, results=None, matchMethod='glob')
    '''

    def find_by_name(self, name, results='objectId', idBy='name',
            refresh=False, matchMethod=None, logError=False, PCache='w'):

        '''
        Find an an network element by name
        type/value retured by the method depends on value of results
        results:
            str => single object attribute
            list => list of object attributes
            None => all attributes
        matchMethod:
            None => exact match
            'glob' => glob style match
            're' => regular expression match (NOT implemented yet)
        '''
        name = urllib2.unquote(name)
        self.logger.debug('name:%s results:%s refresh:%s matchMethod:%s' % (
            name, results, refresh, matchMethod))
        self.logger.debug('calling find(%s)' % name)
        objs = self.find(refresh=refresh, PCache=PCache)
        #self.logger.warning('find(%s) returns %s' % (name,objs))

        if not objs:
            self.logger.debug('RETURN for %s (None)' % name)
            return None

        if matchMethod == 'glob':
            names = [obj['name'] for obj in objs]
            targetNames  = cptutil.filterListByGlob(names, name)
        elif matchMethod == 're':
            names = [obj['name'] for obj in objs]
            targetNames  = cptutil.filterListByRE(names, name)
        else:
            targetNames  = [ name ]
        #print('name=',name, 'names=',names, 'targetNames=',targetNames)

        resultList = []
        self.logger.debug('objs contains %d items' % len(objs))
        for obj in objs:
            #print('==>', targetNames, obj[idBy])
            if obj[idBy] in targetNames:
                if results=='raw':
                    objectId = obj['objectId']
                    action = 'getone' if 'getone' in self.rest_api else 'get'
                    r = self.doRestApi(action, objectId=objectId)
                    self.logger.debug('RETURN for (raw) %s' % name)
                    return r.text
                else:
                    #print('obj=%s' % obj)
                    #print('result=%s' % result)
                    self.logger.debug('formatting full result for %s' % name)
                    r = format_find_result(obj, results)
                    self.logger.debug('formatted  full result for %s' % name)
                if matchMethod == None:
                    self.logger.debug('RETURN for (full) %s' % name)
                    return r
                else:
                    resultList.append(r)
        if logError:
            self.logger.warning('%s %s not found' % (self.__class__.__name__, name))
        self.logger.debug('RETURN for (default) %s' % name)
        return resultList

    def doRestApi(self, _action, retryParams=None, **kwargs):
        ''' _action: rest_api key or "<restMethod> <restUrl>" '''
        ''' extract kwargs to local namesapce '''
        ''' kwargs: files, data, headers supressRestErrMsg '''
        exec('\n'.join('%s=kwargs["%s"]' % (k, k) for k in kwargs.keys()))

        restKw = {}
        if 'files' in kwargs: restKw['files'] = kwargs['files']
        if 'data' in kwargs: restKw['data'] = kwargs['data']
        if 'headers' in kwargs: restKw['headers'] = kwargs['headers']
        if 'suppressRestErrMsg' not in locals():
            suppressRestErrMsg = False

        if ' ' in _action and _action.split(' ')[1].startswith('/'):
            restMethod, restUrl = _action.split(' ')
        elif _action in self.rest_api:
            restMethod = self.rest_api[_action].method
            restUrl = self.rest_api[_action].url
        else:
            self.logger.error('No API defined for _action %s' % _action)
            return None

        if restUrl.count('%') >= 2: restUrl = eval(restUrl)
        self.logger.debug('%s: REST CALL %s %s' % (type(self), restMethod, restUrl))
        if 'data' in kwargs:
            self.logger.debug('%s: REST BODY xml=%s' % (type(self), pformat_xml(kwargs['data'])))

        self.logger.info1('%s %s' % (getattr(self.mgr, restMethod).__name__, restUrl))
        r = getattr(self.mgr, restMethod)(restUrl, retryParams=retryParams, **restKw)
        if r.status_code >= 400 and not suppressRestErrMsg:
            self.mgr.responseError(r)
        return r

    def _procGrpObjsMod(self, grpTag, grpObjsOrg, grpObjsModSpec, shim=None, refresh=True):
        ''' comma seperated +grp | -grp | grp '''
        self.logger.info4('(grpTag, grpObjsOrg, grpObjsModSpec) = %s, %s, %s' % (grpTag, grpObjsOrg, grpObjsModSpec))
        #print('1110>', grpObjsOrg, grpObjsModSpec, shim)
        if not grpObjsModSpec: return grpObjsOrg

        grpObjsOrgCopy = copy.deepcopy(grpObjsOrg)
        for grpObjModSpec in grpObjsModSpec.split(','):
            candidateOp, candidateName = grpObjModSpec[0], grpObjModSpec[1:]
            if candidateOp == '+':
                self.logger.info1('ADDING GROUPING OBJ %s %s' % (grpTag, grpObjModSpec))
                if shim:
                    grpObjsOrgCopy[shim] = grpObjsOrgCopy.get(shim, {})
                    grpObjsOrgCopy[shim] = listify(grpObjsOrgCopy[shim])
                    curOids = [x['objectId'] for x in grpObjsOrgCopy[shim] if x]
                    candidateOid = self._procGrpObjs0Val('%s|%s'%(grpTag,candidateName), refresh=refresh)
                    #print('IN:', curOids)
                    if candidateOid not in curOids:
                        grpObjsOrgCopy[shim].append(
                            {'objectId': self._procGrpObjs0Val('%s|%s'%(grpTag,candidateName), refresh=refresh)})
                    #print('OUT:', [x['objectId'] for x in grpObjsOrgCopy[shim]])
                else:
                    grpObjsOrgCopy = listify(grpObjsOrgCopy)
                    #print('1111>', grpObjsOrgCopy )
                    curOids = [x['objectId'] for x in grpObjsOrgCopy if x]
                    #print('IN:', curOids)
                    grpObjsOrgCopy.append(
                        {'objectId': self._procGrpObjs0Val('%s|%s'%(grpTag,candidateName), refresh=refresh)})
                    #print('OUT:', [x['objectId'] for x in grpObjsOrgCopy])
            elif candidateOp in ['-', '~']:
                self.logger.info1('REMOVING GROUPING OBJ %s %s' % (grpTag, grpObjModSpec))
                if shim:
                    grpObjsOrgCopy[shim] = listify(grpObjsOrgCopy[shim])
                    #print('IN:', [x['objectId'] for x in grpObjsOrgCopy[shim]])
                    grpObjsOrgCopy[shim] = \
                        filter(lambda x: 'name' not in x or x['name']!=candidateName,
                        grpObjsOrgCopy[shim])
                    #print('OUT:', [x['objectId'] for x in grpObjsOrgCopy[shim]])
                else:
                    grpObjsOrgCopy = listify(grpObjsOrgCopy)
                    #print('IN:', [x['objectId'] for x in grpObjsOrgCopy])
                    grpObjsOrgCopy = \
                        filter(lambda x: 'name' not in x or x['name']!=candidateName,
                        grpObjsOrgCopy)
                    #print('OUT:', [x['objectId'] for x in grpObjsOrgCopy])
            else:
                self.logger.error('#### INVALID grpObjsModSpec: %s' % grpObjsModSpec)

        #pprint_od(grpObjsOrgCopy)
        return grpObjsOrgCopy

    #@memoize
    #@cptutil.traceFuncParams
    def _procGrpObjs0Val(self, grpObjsSpec, refresh=True, PCache=''):
        gObjDicts = self._procGrpObjs(grpObjsSpec, refresh=refresh, PCache=PCache)
        if gObjDicts:
            return gObjDicts[0]['value'] 
        else:
            self.logger.error('Cannot resolve %s' % grpObjsSpec)
            print(traceback.print_stack())
            return []

    def _procGrpObjsOids(self, grpObjsSpec, refresh=True, PCache=''):
        gObjDicts = self._procGrpObjs(grpObjsSpec, refresh=refresh, PCache=PCache)
        if gObjDicts:
            return [gObjDict['value']  for gObjDict in gObjDicts]
        else:
            self.logger.error('Cannot resolve %s' % grpObjsSpec)
            print(traceback.print_stack())
            return []

    #@memoize
    def _procGrpObjs(self, grpObjsSpec, refresh=True, PCache=''):
        #self.logger.warning('>> %s' % grpObjsSpec)
        '''
        grpObjMap = {
        #   <key> | <apiType>                    <nsxvlibType>            GroupingObj       DFW      SG-member
        #                                                                                           static  dyn
            'A':  ('VirtualApp',                 vim.ResourcePool),     # vApp              S/D     M/E      E
            'AP': ('application',                Application),          # Application
            'AG': ('applicationgroup',           Application_group),    # ApplicationGroup
            'C':  ('ClusterComputeResource',     vim.ClusterComputeResource),   # Cluster   S/D/A   M/E      E
            'D':  ('Datacenter',                 vim.Datacenter),       # Datacenter        S/D/A   M/E      E
            'DG': ('DirectoryGroup',             DirectoryGroup),       # DirectoryGroup
            'E':  ('',                           None),                 # Edge                  A
            'G':  ('SecurityGroup',              Security_group),       # SecurityGroup     S/D/A   M/E      E
            'H':  ('',                           None),                 # Host                  A
            'I':  ('IPSet',                      Ipset),                # IPset             S/D     M/E      E
            'L':  ('VirtualWire',                Logical_switch),       # LogicalSwitch     S/D/A   M/E      E
            'M':  ('MACSet',                     Macset),               # MacSet                             E
            'N':  ('Network',                    vim.Network),          # Nework (PG)       S/D/A   M/E      E
            'NO': ('VM.GUEST_OS_FULL_NAME',      None),                 # OS Name                           D
            'NV': ('VM.NAME',                    None),                 # VM Name                           D
            'NC': ('VM.GUEST_HOST_NAME',         None),                 # Computer Name                     D
            'NT': ('VM.SECURITY_TAG',            Security_tag),         # SecurityTag                       D
            'P':  ('DistributedVirtualPortgroup',vim.dvs.DistributedVirtualPortgroup),# dPG S/D/A   M/E      E
            'SIP':('SIProfile',                  SIProfile),            # SIProfile
            'T':  ('',                           Security_tag),         # SecurityTag                        E
            'V':  ('VirtualMachine',             vim.VirtualMachine),   # VirtualMachine    S/D/A   M/E      E
            'VN': ('Vnic',                       vim.VirtualMachine),   # VNic              S/D/A   M/E      E
            'R':  ('',                           None),                 # ResourcePool      S/D     M/E      E
            'EN': ('',                           None),                 # entity                            D
            'i4': ('',                           None),                 # Ipv4Address       S/D     M/E      E
            'i6': ('',                           None),                 # Ipv6Address       S/D     M/E      E
        }
        '''
        grpObjMap = globals()['grpObjMap']

        if grpObjsSpec.lower() in ['', 'any']: return []

        rList = []
        grpObjsSpec = [urllib2.unquote(e).strip() for e in grpObjsSpec.split(',')] if grpObjsSpec else []
        #print('grpObjsSpec:', grpObjsSpec)
        self.logger.info2('Mapping %s' % grpObjsSpec)
        for grpObjSpec in grpObjsSpec:
            if not grpObjSpec: continue
            if '|' not in  grpObjSpec:
                self.logger.error('Invalid grouping object specificaiton: "%s" (expected format: "<type>|<value>")' % grpObjSpec)
                continue
            grpObjType, grpObjName = grpObjSpec.split('|')

            grpObjName = urllib2.unquote(grpObjName)

            #print('grpObjType, grpObjName = ', grpObjType, grpObjName)
            if grpObjType not in grpObjMap:
                self.logger.error('Don\'t know how to handle grouping object '
                    'specification: %s' % grpObjSpec)
                return []
            apiObjTypeName, objClass = grpObjMap[grpObjType]
            #if not objClass:
            #    self.logger.error('Mapping %s: not yet implemented' % grpObjSpec)
            #    continue

            grpObj = None
            if grpObjType == 'VN':       # Vnic specific
                self.logger.info2('Mapping Vnic object %s' % grpObjSpec)
                vnicNameSplitted = grpObjName.split()
                vmName, ifNum = vnicNameSplitted[0], int(vnicNameSplitted[-1])-1
                grpObj = vmObj = self.mgr.vslibVc.getByName(objClass, vmName)
                if vmObj:
                    vnicUuid = '%s.%03d' % (vmObj.config.instanceUuid, ifNum)
                    rList.append(OD({'type':apiObjTypeName,'value':vnicUuid}))
            elif grpObjType in ['i4', 'i6']:  # Vnic specific
                grpObj = {'type':{'i4':'Ipv4Address','i6':'Ipv6Address'}[grpObjType], 'value':grpObjName}
                rList.append(grpObj)
            elif objClass and objClass.__name__.startswith('vim.'):
                ''' VC grouping objects '''
                self.logger.info2('Mapping VC grouping object %s' % grpObjSpec)
                grpObj = self.mgr.vslibVc.getByName(objClass, grpObjName)
                if grpObj:
                    rList.append(OD({'type':apiObjTypeName,'value':grpObj._moId}))
            else:
                ''' NSXV grouping objects '''
                self.logger.info2('Mapping NSXV grouping object %s' % grpObjSpec)
                self.logger.info2('%s %s %s' % (objClass, grpObjName, PCache))
                oid = self.mgr.n2oid(grpObjName, objClass, PCache=PCache)
                objClassName = objClass.__name__
                #print('>>>>', objClassName)
                if not oid:
                    self.logger.info3('Refreshing NSXV grouping object %s' % grpObjSpec)
                    oid = self.mgr.n2oid(grpObjName, objClass, refresh=True, PCache=PCache)
                if oid:
                    if grpObjType == 'DG':       # DirectoryGroup specific
                        rList.append(OD({'type':apiObjTypeName, 'value':
                            'directory_group-%s'%oid}))
                        self.logger.info2('Mapping NSXV grouping object %s to %s' % (grpObjSpec, oid))
                    else:
                        rList.append(OD({'type':apiObjTypeName,'value':oid}))
                        self.logger.info2('Mapping NSXV grouping object %s to %s' % (grpObjSpec, oid))
                grpObj = oid
            if not grpObj:
                self.logger.error('Cannot find object with spec: "%s":- %s "%s"' %
                    (grpObjSpec, grpObjMap[grpObjType][0], grpObjName))

        self.logger.info1('return(%s)' % rList)
        return rList


class Manager(restlib.RestConnect, Network_object):
    rest_api = {
        'getVcCfg': Api('get',    '/api/2.0/services/vcconfig', '')
    }
    def __init__(self, mgrIp, user='admin', password='Vmware123!',
            content_type='application/xml', accept='application/xml',
            verify=True,
            logLevel=logging.INFO, requestsLogLevel=logging.WARNING,
            logFile=None, logger=None, vuser=None, vpasswd='Vmware123!',
            connectVC=True):
        super(Manager, self).__init__(
            url_prefix='https://%s' % mgrIp,
            user=user, password=password,
            content_type=content_type, accept=accept,
            verify=verify,
            logLevel=logLevel, requestsLogLevel=requestsLogLevel,
            logFile=logFile, logger=logger)
        self.mgrIp = mgrIp
        self.logFile = logFile
        self.logLevel = logLevel
        self.pCache = {c:'' for c in subClassNames(Network_element)}
        self._vc = None         ;# deplicated, for self.vc.* use self.* instead
        self._vslibVc = None    ;# use by property self.vslibVc
        self._vcSi = None       ;# use by property self.vcSi
        self._vcInv = None      ;# use by property self.vsInv
        self._objds = {}        ;# DirectoryGroup Security_group Ipset Logical_switch Macset Security_tag
        self._n2oidCache = {}        ;#

        self.pcacheMap = {}

        #self.logger.info('Getting vCenter info from NSX manager')
        self.mgr = self
        r = self.doRestApi('getVcCfg')
        vcCfg = xmltodict.parse(r.text)['vcInfo']
        #pprint_od(vcCfg)
        if connectVC:
            if 'ipAddress' in vcCfg:
                self.vcIp = vcCfg['ipAddress']
                self.vcUser = vuser or vcCfg['userName']
                self.vcInfo = VcenterInfo(self.vcIp, self.vcUser, vpasswd)
            else:
                self.logger.warning('vCenter not configured on NSX manager')
        self.vcPass = vpasswd

    def objd(self, objClass, recreate=False):   # Manager
        if recreate and objClass in self._objds:
            self.logger.info('Deleteing object %s' % objClass)
            del self._objds[objClass]
        if objClass not in self._objds:
            self.logger.info4('Creating shared %s' % objClass)
            #print(traceback.print_stack())
            self._objds[objClass] = objClass(self)
        return self._objds[objClass]

    def n2oid(self, name, classRef, refresh=False, PCache='w'):         # Manager
        ''' classRef can either be a actual class ref or string represeation of the class ref
            the Manager.n2oid redirects the call to classRef version of n2oid
        '''
        if isinstance(classRef, str):
            classRef = eval(classRef)
        return classRef(self.mgr).n2oid(name, refresh=refresh, PCache=PCache)

    def ngs2oids(self, namesGlob, classRef, refresh=True, PCache='w'):  # Manager --- work in progress
        '''namesGlob to oids mapping'''
        ngsOidDict = {}
        for nameGlob in listify(namesGlob):
            ngsOidDict.update(self.ng2oids(nameGlob, classRef, refresh=refresh, PCache=PCache))
            refresh = False
        return ngsOidDict

    def ng2oids(self, nameGlob, classRef, refresh=False, PCache='w'):   # Manager
        ''' classRef can either be a actual class ref or string represeation of the class ref
            the Manager.ng2oids redirects the call to classRef version of ng2oids
        '''
        if isinstance(classRef, str):
            classRef = eval(classRef)
        return classRef(self.mgr).ng2oids(nameGlob, refresh=refresh, PCache=PCache)

    @property
    def vslibVc(self):
        if not self._vslibVc:
            self.logger.info2('Connecting to vCenter: %s w/user: %s' % (self.vcIp, self.vcUser))
            self._vslibVc = vslib.Vcenter(self.vcIp, self.vcUser, self.vcPass,
            logLevel=logging.debug, logger=self.logger)
            #logLevel=self.logLevel, logger=self.logger)
            self._vcSi = self._vslibVc.si
            self._vcInv = self._vslibVc.inv
        return self._vslibVc

    @property
    def vcSi(self):
        if not self._vcSi:
            self.vslibVc
        return self._vcSi

    @property
    def vcInv(self):
        if not self._vcInv:
            self.vslibVc
        return self._vcInv

    @property
    def vc(self):
        assert False, 'Manager.vc should no longer be use!!!'
        if not self._vc:
            if not self.vcIp or not self.vcUser or self.vcIp=='0.0.0.0':
                self.logger.error('Cannot get vCenter information from NSX manager')
                self.logger.error('Did you register your manager to  vCenter?')
            else:
                try:
                    self.vcInfo = VcenterInfo(self.vcIp, self.vcUser, self.vcPass)
                except Exception as e:
                    self.logger.error('Cannot get vCenter information from NSX manager')
                    self.logger.error('Did you register your manager to  vCenter?')
                    self.logger.error(fmtExceptionInfo(e))
        return self._vc

    def findVcPgOrLsByName(self, name, tz=None):
        '''
        THIS NEED MORE WORK... NOT BING USING YET

        Find a the VC MO_ID for a given portgroup or logical switch by name
        Reuse the given vcenter inventory if provided, otherwise, connect to VC.
        '''
        si, inv = self.mgr.vcSi, self.mgr.vcInv

        pg = vs.getObjectFromVcenterInventory(inv = inv,
                vimtype = [vim.dvs.DistributedVirtualPortgroup],
                name = name)
        if pg:
            return pg._moId

        if tz:
            ls = nsxv.find_logical_switch_by_name(self, name, tz)
            if ls:
                pprint_od(ls)
                return ls['objectId']

        return None


class Network_element(Network_object):
    #__metaclass__  = abc.ABCMeta
    #list_brief_keys = ['name', 'objectId']
    jqTableSpec = JqTableSpec( '[.name, .objectId]', [])

    oidParentDepth = 2

    def oid2n(self, oid, refresh=False, PCache='w'):           # Network_element
        self.ng2oids('*')
        #pprint(self.mgr._n2oidCache[self.className]); pprint(oid)
        return cptutil.getKeyByValue(self.mgr._n2oidCache[self.className], oid)

    def n2oid(self, name, refresh=False, PCache='w'):           # Network_element
        name = re.sub(r'([\(\)])', r'\\\1', name)
        oids =  self.ng2oids(name, refresh=refresh, PCache=PCache).keys()
        return oids[0] if oids else ''

    def ngs2oids(self, namesGlob, refresh=True, PCache='w'):    # Network_element
        '''namesGlob to oids mapping'''
        ngsOidDict = {}
        for nameGlob in listify(namesGlob):
            ngsOidDict.update(self.ng2oids(nameGlob, refresh=refresh, PCache=PCache))
            refresh = False
        return ngsOidDict

    def ng2oids(self, nameGlob, refresh=False, PCache='w'):     # Network_element
        '''nameGlob to oids mapping'''
        def pageHandler(path, node):
            ''' handle paged GET response by issuing addition get request till response
                contains item index >= totalCount
                Calls nodeHandler() for each response r'''
            if node and 'pagingInfo' in node:
                pInfo = node['pagingInfo']
                pageSize, startIndex, totalCount = [int(pInfo[k])
                    for k in ['pageSize', 'startIndex', 'totalCount']]
                while totalCount > startIndex+pageSize:
                    newStartIndex = int(pInfo['pageSize'])+int(pInfo['startIndex'])
                    nItem = int(pInfo['pageSize'])
                    mgr.logger.info2('> pageSize, indext:newIndex, nItem, cumu/total: %4d, %4d:%-4d, %4d, %4d/%-4d' % (
                        pageSize, startIndex, newStartIndex, nItem, nItem+startIndex, totalCount))

                    restUrl = self.rest_api['get'].url
                    restMethod = self.rest_api['get'].method
                    joinChar = '&' if '?' in restUrl else '?'
                    restUrl = re.sub(r'(startIndex)=(\d*)', r'\1=%s'%newStartIndex, restUrl) \
                        if 'startIndex' in restUrl else '%s%cstartIndex=%d' % (restUrl, joinChar, newStartIndex)

                    r = self.doRestApi('get %s' % restUrl)
                    xmltodict.parse(r.text, item_depth=self.oidParentDepth, item_callback=nodeHandler)
                    newObjs = xmltodict.parse(r.text)

                    outerTag = self.rKeys[0]
                    pInfo = newObjs[outerTag]['pagingInfo']
                    newNItem = len(newObjs[outerTag][self.rKeys[1]])
                    pageSize, startIndex = [int(pInfo[k]) for k in ['pageSize', 'startIndex']]
                    runTotal   = startIndex + newNItem
                    mgr.logger.info2('< pageSize,      startIndex, nItem, cumu/total: %4d, %9d, %4d, %4d/%-4d' % (
                        pageSize, startIndex, newNItem, newNItem+startIndex, totalCount ))
            return True

        def nodeHandler(path, node):
            ''' populate self.mgr._n2oidCache '''
            #print('path=%s node=%d,%s' % (path, len(node), node))
            #if 'name' in node and ('objectId' in node or 'id' in node):
            if 'name' in node:
                idTags = [k for k in node if k in listify(['objectId', 'id'])]

                if node['name'] in self.mgr._n2oidCache[self.className]:
                    mgr.logger.warning('Duplicate %s name %s found (id=%s)' %
                        (self.className, node['name'], node[idTag]))
                    #print(traceback.print_stack())

                if not idTags:
                    idTags = [k for k in node.keys() if k.lower().endswith('id')]
                #print('idTags=%s'%idTags)
                self.mgr._n2oidCache[self.className].update( {node['name']:node[idTags[0]]} )
            return True

        mgr = self.mgr
        cacheKey = '%s,%s' % ('n2oid',self.className)
        cacheHit = False

        self.logger.info3('nameGlob=%s refresh=%s PCache=%s' % (nameGlob, refresh, PCache))
        if refresh or self.className not in mgr._n2oidCache:
            ##print('110 >>>> EMPTYING mgr._n2oidCache[%s]', self.className)
            mgr._n2oidCache[self.className] = {}

        mCacheEmpty = bool(not mgr._n2oidCache[self.className])
        #print('114 >>>> refresh=%s, PCache=%s mCacheEmpty=%s' % (refresh, PCache, mCacheEmpty))
        #pprint(mgr._n2oidCache[self.className])
        if refresh or (mCacheEmpty and not 'r' in PCache):
            r = self.doRestApi('get')
            mgr.logger.info3('Refreshihng %s mCache', self.className)
            mgr.logger.debug('%s got response from mgr', self)
            xmltodict.parse(r.text, item_depth=1, item_callback=pageHandler)
            xmltodict.parse(r.text, item_depth=self.oidParentDepth, item_callback=nodeHandler)
            mgr.logger.debug('%s done parsing response', self)

            # update pCache whenever new info read from mgr
            cptutil.Cache(self.mgr.mgrIp, logger=self.logger).write(cacheKey, mgr._n2oidCache[self.className])
        else:
            mgr.logger.info3('Reading %s from pCache', self.className)
            cacheHit, n2oidPCacheDict = cptutil.Cache(self.mgr.mgrIp, logger=self.logger).read(cacheKey,
                rDict=mgr._n2oidCache, rKey=self.className)
            mgr._n2oidCache[self.className] = n2oidPCacheDict
        n2oidDict = mgr._n2oidCache[self.className]
        #print('n2oidDict='); pprint_json(n2oidDict)
        #print('118 >>>>', self.className, n2oidDict)


        #self.logger.alert('nameGlob=%s'%nameGlob)
        rDict = {n2oidDict[k]:k for k in n2oidDict if isGlobMatched(nameGlob, k)}
        #print('rDict='); pprint_json(rDict)
        return rDict

    def confirmCert(self, r, xml, restMethod, restUrl):
        m = re.search('<details>([0-9a-fA-F:]+)</details>', r.text)
        if m:
            thumbprint = m.group(1)
            ssoOd = xmltodict.parse(xml)
            ssoOd['ssoConfig']['certificateThumbprint'] = thumbprint
            xml = xmltodict.unparse(ssoOd)

            self.logger.info('Confirm server thumbprint %s...' % thumbprint[:12])
            self.logger.debug('%s: REST CALL %s %s' % (type(self), restMethod, restUrl))
            self.logger.debug('%s: REST BODY xml=%s' % (type(self), xml))
            r = getattr(self.mgr, restMethod)(restUrl, data=xml)

            if r.status_code >= 400:
                self.mgr.responseError(r)

    def config(self, data, idBy='objectId', checkExist=True, confirmCert=False, **kwargs):
        '''
        Create a new <class> identified by objName if it doesn't exist
        '''
        #''' extract kwargs to local namesapce '''
        #exec('\n'.join('%s=kwargs["%s"]' % (k, k) for k in kwargs.keys()))

        objName = getYamlObjName(data, self.yamlObjNamePath)
        self.logger.info('Configuring %s' % objName)
        if checkExist and self.find_by_name(name = objName, results=idBy):
            self.logger.error('%s with name "%s" already exist' % \
                (self.className, objName))
            return None

        restApiKey = 'cfgUniversal' if checkIsUniversal(data['yaml']) else 'cfg'
        restUrl = self.rest_api[restApiKey].url
        restMethod = self.rest_api[restApiKey].method

        self.logger.debug('%s: REST CALL %s %s' % (type(self), restMethod, restUrl))
        self.logger.debug('%s: REST BODY xml=%s' % (type(self), data['xml']))
        r = getattr(self.mgr, restMethod)(restUrl, data=data['xml'])

        if confirmCert and r.status_code == 403:
            self.confirmCert(r, data['xml'], restMethod, restUrl)
        elif r.status_code >= 400:
            self.mgr.responseError(r)

    def prRespText(self, rText, fmt):
        if   fmt=='raw':    print(rText)
        elif fmt=='yaml':
            fullOd = xmltodict.parse(rText)
            pprint_yaml(byteify(fullOd))
        elif fmt=='json':
            fullOd = xmltodict.parse(rText)
            pprint_od(fullOd)
        elif fmt=='xml':    pprint_xml(rText)

    def jqTable(self, jsonStr='', nameGlob='', jqFilter='', apiKey='', findMethod='list',
            nameTag='name', display=True, mgr=None, **kwargs):
        mgr = mgr or self.mgr
        ''' format json to prettytable  '''
        #print('jsonStr ='); pprint_od(jsonStr)

        # extract kwargs to local namesapce
        exec('\n'.join('%s=kwargs["%s"]' % (k, k) for k in kwargs.keys()))

        if isinstance(jsonStr, list):
            jsonStr = json.dumps(jsonStr)

        if not jqFilter and hasattr(self, 'ptblFmts') and 'list' in self.ptblFmts:
            jqFilter = jqFilter or self.ptblFmts['list'].jqFilter
        #print('jqFilter = %s' % jqFilter)

        if jsonStr and isinstance(jsonStr, basestring):
            jsonDict = json.loads(jsonStr)
        elif apiKey:
            jqFilter = jqFilter or self.ptblFmts[apiKey].jqFilter
            restUrl = self.ptblFmts[apiKey].url
            if restUrl.count('%') >= 2:
                restUrl = eval(restUrl)
            jsonDict = xmltodict.parse(self.doRestApi(apiKey).text)
            #pprint_od(jsonDict)
        else:
            if hasattr(self, 'ptblFmts'):
                jqFilter = jqFilter or self.ptblFmts['list'].jqFilter
                restUrl = self.ptblFmts['list'].url
            else:
                self.logger.warning('jqFilter not defined')
            jsonDict = xmltodict.parse(self.doRestApi(apiKey).text)
        self.logger.info2('API returns: %s' % pformat(jsonDict))

        if nameGlob:
            nameRe = cptutil.globToRe(nameGlob)
            nameRe = re.sub(r'\\', r'\\\\\\\\', nameRe, count=0)    # due to 2 extra level of substitution
            jqFilter = re.sub(r'(\.%s)'%nameTag, '(\\1|if test("%s") then . else empty end)'%nameRe,
                jqFilter, 1)

        if jqFilter=='.':
            if display:
                pprint(jsonDict)
            rows = jsonDict
        else:
            rows = pyjq.all(jqFilter, jsonDict)
            self.logger.info2('rows: %s' % pformat(rows))
            ptbl = cptutil.fmtDictsAsPrettytable(rows, colSortKeys=re.findall(r'"([^"]*)"\s*:', jqFilter))
            if ptbl:
                if display:
                    print(ptbl)
                if 'result_count' in jsonDict:
                    if display:
                        print('Count: %s (Total:%d)' % ((ptbl.rowcount, jsonDict['result_count'])
                            if ptbl else (0,0)))
                    actualCount = len(jsonDict['results'])
                    if (not nameGlob or nameGlob=='*'):
                        if actualCount!=jsonDict['result_count']:
                            self.logger.warning(
                                'reported result_count(%d) != actual result_count(%d)'
                                % (jsonDict['result_count'], actualCount) )
                        if ptbl.rowcount!=actualCount:
                            self.logger.warning(
                                'Something went wrong, got %d entries, %d entries displayed'
                                % (actualCount, ptbl.rowcount))
                else:
                    if display:
                        print('Count: %s' % ptbl.rowcount)
            #else:
            #    if display:
            #        print('Count: 0')

        #pprint_od(rows)
        return rows, ptbl

    def fmtJqTable(self, jsonList, nameGlob=None):
        ''' this is an older method, should migrate to jqTable '''
        if not jsonList:
            self.logger.warning('No %s found' % self.__class__.__name__)
            return

        jqFilterType = 'object' if self.jqTblSpec.jqFilter.strip().endswith('}') else 'array'

        if hasattr(self, 'jqTblSpec') and jqFilterType=='object':
            nameFilter = 'select(.name|test("%s")) |' % (cptutil.globToRe(nameGlob)) if nameGlob else ''
            jqFilter = 'if type=="array" then .[] else select(.) end | %s %s' % (
                nameFilter, self.jqTblSpec.jqFilter)

            #print(jqFilter)
            #pprint_od(jsonList)
            rows = pyjq.all(jqFilter, jsonList)
            ptbl = cptutil.fmtDictsAsPrettytable(rows, colSortKeys=re.findall(r'"([^"]*)"\s*:', jqFilter))
            if ptbl:
                print(ptbl)
            print("Count: %s" % ptbl.rowcount if ptbl else 0)

            if len(jsonList)!=len(rows) and not nameGlob:
                self.logger.warning('%s items found, only %s items included in the output table' % (
                    len(jsonList), len(rows)))
                self.logger.warning('Some items seems to be missing')

        elif hasattr(self, 'jqTblSpec') and jqFilterType=='array':
            jqFilter = 'if type=="array" then .[] else select(.) end | %s' % (self.jqTblSpec.jqFilter)

            reo = re.search('\[(.*)\]\s*$', self.jqTblSpec.jqFilter)
            jqKeys = [e.strip() for e in reo.group(1).split(',')]
            #print('jqKeys>>>', jqKeys)
            if self.jqTblSpec.headings:
                headings = self.jqTblSpec.headings
            else:
                try:
                    # attempt to create headings from list of keys
                    headings = [s.strip(' .') for s in reo.group(1).split(',')]
                    #headings = [re.sub('.*\.', '...', h) if '.' in h else h for h in headings]
                    headings = [re.sub(r'(.).*\.', r'\1...', h) if '.' in h else h for h in headings]
                    if len(set(headings)) != len(headings):
                        headings = ['%s(%d)'%(h,i) for i,h in enumerate(headings)]
                except:
                    headings = ['FIELD-%d'%i for i in range(len(self.jqTblSpec.jqFilter.split(',')))]

            ptbl = PrettyTable(headings)
            try:
                ptbl.sortby=headings[0]
                ptbl.sort_key=lambda x:cptutil.alnum_keys(x[0])
            except:
                self.mgr.logger.warning('Problem on prettytable column sortihng: %s' %
                    sys.exc_info()[0])

            rows=pyjq.all(jqFilter, jsonList)
            self.mgr.logger.info4('jsonList: %s' % pformat_od(jsonList))
            self.mgr.logger.info4('jqFilter: %s' % jqFilter)
            self.mgr.logger.info4('rows: %s' % rows)
            self.mgr.logger.info4('nameGlob: %s' % nameGlob)
            if nameGlob and '.name' in jqKeys:
                nameIdx = jqKeys.index('.name')
                nameRe = cptutil.globToRe(nameGlob)
                rows = pyjq.all('.[]|select(.[%s]|match("%s"))'%(nameIdx,nameRe), rows)

            for entry in byteify(rows):
                row = [','.join(c) if isinstance(c,list) else c for c in entry]
                row = [',\n'.join(c.split(',')) if c and len(c)>40 else c for c in row]
                ptbl.add_row(row)
            ptbl.align = 'l'

            print('%s:' % self.className)
            if ptbl._rows:
                print(ptbl)
            print('Count: %d' % ptbl.rowcount)

    def list(self, brief=False, fmt=None, nameGlob=None, PCache=''):    # Network_element
        od = self.find(PCache=PCache)

        doListBrief = getattr(self, 'list_brief_keys', None) and (brief or fmt=='brief' or not fmt)
        doListBrief = (brief or fmt=='brief' or not fmt)
        if not doListBrief and not fmt: fmt = 'yaml'

        if doListBrief:
            if hasattr(self, 'jqTableSpec'):
                #self.fmtJqTable(xmltodict.parse(self.rawFindRespText), nameGlob=nameGlob)
                self.fmtJqTable(self.cachedObjs, nameGlob=nameGlob)
            else:
                self.list_brief(nameGlob=nameGlob)
        elif fmt=='yaml':   pprint_yaml(byteify(xmltodict.parse(self.rawFindRespText)))
        elif fmt=='json':   pprint_od(xmltodict.parse(self.rawFindRespText))
        elif fmt=='xml':    pprint_xml(self.rawFindRespText)
        elif fmt=='raw':    print(self.rawFindRespText)

    def get_brief(self, obj, list_brief_keys=None):
        if not list_brief_keys:
            list_brief_keys = self.list_brief_keys
        attrs = []
        for k in list_brief_keys:
            withTuple = 0
            #print('k=%s'%str(k))
            if isinstance(k, list):
                iObj = obj
                iList =[]
                for kk in k:
                    if isinstance(kk, tuple):
                        withTuple = 1
                        iiObjs=listify(iObj)
                        for iiObj in iiObjs:
                            iiList =[]
                            for kkk in kk:
                                iiList.append(iiObj[kkk])
                            iList.append(iiList)
                        #attrs.append(iList)
                        #attrs.append('; '.join(byteify(iList[0]))); problem handling NONE in list
                        attrs.append(byteify(iList[0]))
                    else:
                        iObj = iObj[kk] if kk in iObj else ''
                if withTuple==0:
                    attrs.append(iObj)
            elif isinstance(k, tuple):
                iObj = obj
                iList =[]
                for kk in k:
                    if isinstance(kk, tuple):
                        #print('iObj=%s kk=%s' % (iObj, kk))
                        allInnerKeysFound = True
                        for kkk in kk:
                            if kkk not in iObj:
                                allInnerKeysFound = False
                        if not allInnerKeysFound:
                            #print('BREAKING.....')
                            break
                        withTuple = 1
                        iiObjs=listify(iObj)
                        for iiObj in iiObjs:
                            iiList =[]
                            for kkk in kk:
                                #print('    kkk=%s' % kkk)
                                iiList.append(iiObj[kkk])
                            iList.append(iiList)
                        #print('1 attrs.append(iList)')
                        #print(iList[0], type(iList[0]))
                        #attrs.append('; '.join(byteify(iList[0]))); problem handling NONE in list
                        attrs.append(byteify(iList[0]))
                    else:
                        iObj = iObj[kk] if kk in iObj else ''
                if withTuple==0:
                    #print('2 attrs.append(iObj)')
                    #### THIS NEED to be worked on, I ak bypassing OrderedDict
                    if not isinstance(iObj, collections.OrderedDict):
                        attrs.append(iObj)
            else:
                attrs.append(obj[k] if k in obj else '')
            #print('>>> attr =', attrs)
        return attrs
        ents.append(attrs)

    def list_brief(self, nameGlob=None, **kwargs):      # class Network_element()
        ''' extract kwargs to local namesapce '''
        exec('\n'.join('%s=kwargs["%s"]' % (k, k) for k in kwargs.keys()))

        if not hasattr(self, 'list_brief_keys') and 'list_brief_keys' not in locals():
            print('ERROR: list_brief_keys NOT defined')
            return
        ents = []

        if not self.cachedObjs:
            self.logger.warning('No %s found' % self.__class__.__name__)
            return

        if 'list_brief_keys' not in locals():
            list_brief_keys = self.list_brief_keys

        tblHdrs = []
        sortByCol = 'name' if 'name' in list_brief_keys else list_brief_keys[0]
        for h in list_brief_keys:
            if isinstance(h, (tuple, list)):
                cPfix = h[0]
                for hh in h:
                    if isinstance(hh, (tuple, list)):
                        tblHdrs.append('%s_%s' % (cPfix,str(hh)))  ;# fields in nested list
                        break
                else:
                    tblHdrs.append('..._%s' % str(hh))      ;# field is last element of simple list
            else:
                tblHdrs.append(h)               ;# regular fields


        ptbl = PrettyTable(tblHdrs)
        ptbl.align = 'l'
        ptbl.sortby = sortByCol
        for obj in self.cachedObjs:
            if nameGlob and not isGlobMatched(nameGlob, obj['name']): continue
            attrs = self.get_brief(obj)
            ents.append(attrs)

            for i in xrange(len(attrs), len(tblHdrs)):
                attrs.append('')
            ptbl.add_row(attrs)
            #print('#####>', cptutil.toUtf8List(attrs))
        ents = cptutil.toUtf8List(ents)
        #pprint(ents)

        print('%s:' % self.className)
        if ptbl._rows:
            print(ptbl)
        print('Count: %d' % ptbl.rowcount)

    def show(self, objNames, fmt='yaml', idByObjectId=True, PCache=''):              # class Network_object()
        apiKey = 'getone' if 'getone' in self.rest_api else 'get'
        for objName in listify(objNames):
            objectIds = self.find_by_name(objName, results='objectId', matchMethod='glob', PCache=PCache) \
                if idByObjectId else objNames
            if objectIds:
                for objectId in objectIds:
                    self.logger.info('%s %s (%s)' % (self.__class__.__name__, objName, objectId))
                    r = self.doRestApi(apiKey, objectId=objectId)
                    self.prRespText(r.text, fmt)
                    #print(pprint_xmlInYaml(r.text))
            else:
                self.logger.warning('%s %s NOT FOUND' % (self.__class__.__name__, objName))


    def show_by_name2(self, name, idBy, matchMethod=None, **kwargs):
        '''
        Show a network element by name
        '''
        ''' extract kwargs to local namesapce '''
        exec('\n'.join('%s=kwargs["%s"]' % (k, k) for k in kwargs.keys()))


        if idBy:
            objectId = self.find_by_name(name, results=idBy, matchMethod=matchMethod)
        else:
            objectId = name

        if not objectId:
            print("ERROR: can't find object: %s" % name)
            return

        objectIds = listify(objectId)

        key = 'getone' if 'getone' in self.rest_api else 'get'
        restMethod = self.rest_api[key].method

        for objectId in objectIds:
            if key == 'getone':
                restUrl = self.rest_api[key].url
                if restUrl.count('%') >= 2: restUrl = eval(restUrl)

                r = getattr(self.mgr, restMethod)(restUrl)
                if not (200 <= r.status_code <= 204):
                    print("HTTP return code for delete is not 20x: %d" % r.status_code)
                    self.mgr.responseError(r)

                xmlDict = xmltodict.parse(r.text)
                #print(r.text)
                #pprint_od(xmlDict)
                print(yaml.safe_dump(json.loads(json.dumps(xmlDict))))
            else:
                restUrl = self.rest_api[key].url
                if restUrl.count('%') >= 2: restUrl = eval(restUrl)

                r = getattr(self.mgr, restMethod)(restUrl)
                if not (200 <= r.status_code <= 204):
                    print("HTTP return code for delete is not 20x: %d" % r.status_code)
                    self.mgr.responseError(r)

                xmlDict = xmltodict.parse(r.text)
                #pprint_od(xmlDict)
                print(yaml.safe_dump(json.loads(json.dumps(xmlDict))))


    def delete(self, objNames, idBy='objectId', retryParams=None, **kwargs):      # Network_element
        ''' idBy: objectId
            idBy: '' mean objNames are objectIds '''
        exec('\n'.join('%s=kwargs["%s"]' % (k, k) for k in kwargs.keys()))
        if 'force' not in kwargs:
            kwargs['force'] = False

        rList = []
        objNames = listify(objNames)
        #print('>>> objNames=%s'%objNames)
        for objName in objNames:
            #print('>> objName=%s'%objName)
            ngOidDict = self.mgr.ng2oids(objName, self.className, refresh=True)
            #if idBy=='objectId':
            #    objList = self.find_by_name(objName, results=idBy, matchMethod='glob')
            if ngOidDict:
                for objectId,objName in ngOidDict.items():
                    if idBy=='objectId':
                        self.logger.info('deleting %s %s(%s)' % (
                            self.__class__.__name__, objName, objectId))
                    else:
                        self.logger.info('deleting %s %s' % ( self.__class__.__name__, objectId))
                    r = self.doRestApi('del', objectId=objectId, retryParams=retryParams, **kwargs)
                    self.logger.info('deleted  %s %s(%s)' % (self.__class__.__name__, objName, objectId))
                    rList.append(r)
            else:
                self.logger.warning('%s %s does not exist' % (self.__class__.__name__, objName))
        return rList

    def delete_by_name2(self, name, idBy, matchMethod=None, **kwargs):
        '''
        Delete a network element by name
        Optionally objectId can be specied, name will be ignored in this case
        '''

        ''' extract kwargs to local namesapce '''
        exec('\n'.join('%s=kwargs["%s"]' % (k, k) for k in kwargs.keys()))

        if idBy:
            objectId = self.find_by_name(name, results=idBy, matchMethod=matchMethod)
        else:
            objectId = name

        if not objectId:
            self.logger.error("can't find %s to delete: %s" % (self.className, name))
            return

        restMethod = self.rest_api['del'].method
        if idBy:
            objs = listify(self.find_by_name(name, results=None, matchMethod=matchMethod))
        else:
            objs = [{idBy: name, 'name': name}]

        for  obj in objs:
            if obj:
                #objectId, objectName = obj['objectId'], obj['name']
                objectId, objectName = obj[idBy], obj['name']
                self.logger.info('deleting %s (%s)' % (objectName, objectId))
                restUrl = self.rest_api['del'].url
                if restUrl.count('%') >= 2: restUrl = eval(restUrl)
                r = getattr(self.mgr, restMethod)(restUrl)
                self.logger.debug('restResult:%s' % pformat(r))
                self.logger.debug('restResult.header:%s' % pformat(r.headers))
                if not (200 <= r.status_code <= 204):
                    #print("HTTP return code for delete is not 20x: %d" %r.status_code)
                    self.logger.error('%s (%s) API call return %d' % (
                            objectName, objectId, r.status_code))
                    self.mgr.responseError(r)
                else:
                    self.logger.info('deleted %s (%s)' % (objectName, objectId))

                if hasattr(self, 'edgeJobStatus'):
                    self.edgeJobStatus(r)
            else:
                self.logger.error('%s %s not found' % (self.className, name))

    def delete_all(self, **kwargs):
        if 'delall' in self.rest_api:
            self.logger.info('delete all %s (Just kidding)' % self.__class__.__name__)
            #restUrl = self.rest_api['delall'].url
            #restMethod = self.rest_api['delall'].method
            #print('restUrl='+restUrl)
            #print('restMethod='+restMethod)
            return
        objs = self.find()
        if objs:
            for obj in objs:
                self.logger.info('deleting %s(%s): %s' % (self.__class__.__name__, obj['name']))
                self.delete_by_name(obj['name'], idBy='objectId')


class Network_service(Network_object):
    #__metaclass__  = abc.ABCMeta

    def _enable_service(self, restUrl, action, **kwargs):
        '''
        service configure according to 'action':
            'get':  return service config (XML)
            'true:  get service config, chnage service to enable
            'false' get service config, chnage service to diaable
        '''

        ''' extract kwargs to local namesapce '''
        exec('\n'.join('%s=kwargs["%s"]' % (k, k) for k in kwargs.keys()))

        ''' obbtain Rest Method for GET '''
        restMethod = self.s_rest_api['get'].method
        self.logger.debug('restUrl=%s' % restUrl)
        self.logger.debug('restMethod=%s' % restMethod)

        r = getattr(self.mgr, restMethod)(restUrl)
        if not (200 <= r.status_code <= 204):
            print("HTTP return code is not 20x: %d" %r.status_code)
            print('restUrl =', restUrl)
            self.mgr.responseError(r)
        self.logger.debug('r.text=%s' % r.text)

        ''' return config and done '''
        if action == 'get':
            return r.text
        elif action == 'get_brief':
            xmlDict = xmltodict.parse(r.text)
            briefDict = {'enabled': getDictValueByKeyPath(xmlDict, self.sKeys)}
            return toUtf8Dict(briefDict)

        ''' apply action '''
        xmlDict = xmltodict.parse(r.text)
        self.logger.debug('xmlDict(before)=%s' % str(xmlDict))
        setDictValueByKeyPath(xmlDict, self.sKeys, action)
        self.logger.debug('xmlDict(after)=%s' % str(xmlDict))
        xml = xmltodict.unparse(xmlDict)

        ''' obbtain Rest URL/method for CONFIG '''
        restUrl = self.s_rest_api['cfg'].url
        if restUrl.count('%') >= 2: restUrl = eval(restUrl)
        restMethod = self.s_rest_api['cfg'].method
        self.logger.debug('restUrl=%s' % restUrl)
        self.logger.debug('restMethod=%s' % restMethod)
        self.logger.debug('xml=%s' % xml)

        r = getattr(self.mgr, restMethod)(restUrl, data=xml)
        if not (200 <= r.status_code <= 204):
            print("HTTP return code is not 20x: %d" %r.status_code)
            print('restUrl =', restUrl)
            print('xml =', xml)
            self.mgr.responseError(r)

    def enable_service(self, edgeName, action):
        objectId = self.find_by_name(edgeName)
        self.logger.debug('config() edgeName: %s esgId: %s' % \
            (edgeName,objectId))

        ''' obbtain Rest URL for GET '''
        restUrl = self.s_rest_api['get'].url
        if restUrl.count('%') >= 2: restUrl = eval(restUrl)

        return self._enable_service(restUrl, action, objectId=objectId)

    def enable_global_service(self, action):
        ''' obbtain Rest URL for GET '''
        restUrl = self.s_rest_api['get'].url
        if restUrl.count('%') >= 2: restUrl = eval(restUrl)

        return self._enable_service(restUrl, action)

class Job(Network_element):
    rest_api = {
        'job':    Api('get', '"/api/2.0/services/taskservice/job/%s"%objectId', ''),
        'getone': Api('get', '"/api/2.0/services/taskservice/job/%s"%objectId', ''),
        'get':    Api('get',  '/api/2.0/services/taskservice/job', ''),
    }
    rKeys = ['jobInstances', 'jobInstance']
    #jqTableSpec = JqTableSpec( '[.name, .id, .ipAddress, .taskInstances, .status]', [] )
    jqTblSpec = JqTblSpec('''{
        "name":          .name,
        "id":            .id,
        "ipAddress":     .ipAddress,
        "taskInstances": .taskInstances,
        "status":        .status,
    }''', '')


    def jobShowAll(self):
        print('Ha Ha, this is not working!')
        r = self.doRestApi('get')

    def jobStatus(self, objectIds):
        for objectId in listify(objectIds):
            curStatus = ''
            finalStates = ['COMPLETED', 'FAILED_ABORT']
            while curStatus not in finalStates:
                r = self.doRestApi('job', objectId=objectId)
                rText = r.text.encode('ascii', 'ignore')
                #cptutil.pprint_xml(rText)

                if '<jobInstances/>' in rText:
                    self.logger.error('ERROR: Job %s not found' % objectId)
                    return rText

                jobInst = byteify(xmltodict.parse(rText)['jobInstances']['jobInstance'])
                #taskInsts = jobInst['taskInstances']
                jobStatus = jobInst['status']
                #pprint(jobInst)

                while jobStatus == 'QUEUED':
                    time.sleep(1)
                    r = self.doRestApi('job', objectId=objectId)
                    rText = r.text.encode('ascii', 'ignore')
                    jobInst = byteify(xmltodict.parse(rText)['jobInstances']['jobInstance'])
                    #taskInsts = jobInst['taskInstances']
                    jobStatus = jobInst['status']
                    #pprint(jobInst)

                jobStatDict = byteify(xmltodict.parse(rText)['jobInstances']['jobInstance']['taskInstances']['taskInstance'])
                #pprint(jobStatDict)
                taskName = jobStatDict['name']
                if jobStatDict['taskStatus'] != curStatus:
                    logMsg = '%s: %s: %s' % (objectId, taskName, jobStatDict['taskStatus'])
                    self.logger.info(logMsg)
                    curStatus = jobStatDict['taskStatus']
                if curStatus not in finalStates:
                    time.sleep(5)
            return rText

class Controller(Network_element):
    yamlObjNamePath = ['yaml', 'controllerSpec', 0, 'name']
    rest_api = {
        'get': Api('get',     '/api/2.0/vdn/controller', ''),
        'cfg': Api('post',    '/api/2.0/vdn/controller', ''),
        'del': Api('delete', '"/api/2.0/vdn/controller/%s?forceRemoval=%s"%(objectId,forceRemoval)', ''),
        'job': Api('get',    '"/api/2.0/vdn/controller/progress/%s"%objectId', ''),
        'syslogserver_get':   Api('get', '"/api/2.0/vdn/controller/%s/syslog"%objectId', ''),
        'syslogserver_set':   Api('post', '"/api/2.0/vdn/controller/%s/syslog"%objectId', ''),
        'syslogserver_clear': Api('delete', '"/api/2.0/vdn/controller/%s/syslog"%objectId', ''),
    }
    rKeys = ['controllers', 'controller']
    jqTblSpec = JqTblSpec('''{
        "name":     .name,
        "id":       .id,
        "ipAddress":.ipAddress,
        "status":   .status,
        "hostName": .hostInfo.name,
        "vmName":   .virtualMachineInfo.name,
    }''', '')
    jqTblSpec = JqTblSpec('[.name, .id, .ipAddress, .status, .hostInfo.name, .virtualMachineInfo.name]', [])


    #+HINT_hostName:         hostId:         50.4.0.46
    # HINT_ipPoolName:       ipPoolId:       Rack4-CP 20.4.21.0
    #+HINT_resourcePoolName: resourcePoolId: cluster1
    #+HINT_datastoreName:    datastoreId:    nsx_nfs2
    #+HINT_networkName:      networkId:      vlan2021
    #def config(self, data, vc):
    #    '''
    #    Create a new Controller if it doesn't exist and return jobId
    #    otherwise return None
    #    '''
    #    yml = data['yaml']['controllerSpec'][0]
    #    if self.find_by_name(yml['name'], results='id', idBy='id'):
    #        self.logger.error('Controller with name "%s" already exist' % yml['name'])
    #        return None

    #    #pprint(yml)
    #    swapXmlTag(self, yml)

    #    #print(yml)

    #    datacopy = copy.deepcopy(data['yaml'])
    #    self.logger.info('Controller.config() Recreating XML for API post with new values from VC')
    #    newdata, begin,end  = yaml_to_xml(yml = datacopy, top = True)
    #    #print(json.dumps(newdata[0]['yaml'], indent=4))
    #    self.logger.info('Controller.config() Posting Controller create to NSX Manager')

    #    restUrl = self.rest_api['cfg'].url
    #    restMethod = self.rest_api['cfg'].method
    #    self.logger.debug('%s: REST CALL %s %s' % (type(self), restMethod, restUrl))

    #    self.logger.debug('%s: REST BODY xml=%s' % (type(self), data['xml']))
    #    r = getattr(self.mgr, restMethod)(restUrl, data=newdata[0]['xml'])

    #    if r.status_code >= 400:
    #        self.mgr.responseError(r)
    #    return r.text

    def configMultiple(self, ymlFile, ctrNames):
        self.logger.info('Configure ctr based on %s' % ymlFile)
        objects, begin, end = readYmlFile(ymlFile, self.mgr.logger)
        jobIds = []
        for obj in objects:
            ctrName = obj['yaml']['controllerSpec'][0]['name']
            if not ctrNames or ctrName in ctrNames:
                self.logger.info("Creating controller %s" % ctrName)
                yml = obj['yaml']['controllerSpec'][0]
                if self.find_by_name(yml['name'], results='id', idBy='id'):
                    self.logger.error('Controller with name "%s" already exist' % yml['name'])
                    return None

                self.logger.info('Controller.config() Recreating XML for API post with new values from VC')
                swapXmlTag(self, yml)
                datacopy = copy.deepcopy(obj['yaml'])
                newdata, begin,end  = yaml_to_xml(yml = datacopy, top = True)

                self.logger.info('Controller.config() Posting Controller create to NSX Manager')
                r = self.doRestApi('cfg', data=newdata[0]['xml'])
                jobId = r.text

                if jobId:
                    self.logger.info("Creating controller %s: %s" % (ctrName, jobId))
                    self.ctrDeployStatus(jobId)


    def delete(self, ctrNames, idBy='', **kwargs):      # Controller
        rList = super(Controller, self).delete(ctrNames, idBy=idBy, **kwargs)
        jobd = Job(self.mgr)
        for r in rList:
            jobd.jobStatus(r.text)
        #jobd.jobStatus2([r.text for r in rLsit])

    def ctrDeployStatus(self, objectId):
        # status: NotStart PushingFile PoweringOn WaitingForToolRunning Unknown Success
        deployStatus = ''
        progress = '0'
        finalStates = ['Success', 'Failure']
        while deployStatus not in finalStates:
            r = self.doRestApi('job', objectId=objectId)

            jobStatDict = byteify(xmltodict.parse(r.text)['controllerDeploymentInfo'])
            #pprint(jobStatDict)
            if jobStatDict:
                if jobStatDict['status']!=deployStatus or (
                        'progress' in jobStatDict and jobStatDict['progress']!=progress):
                    logMsg = objectId
                    logMsg += ' status=%s' % jobStatDict['status']
                    if 'progress' in jobStatDict:
                        progress = jobStatDict['progress']
                        logMsg += ' progress=%s%%' % jobStatDict['progress']
                    deployStatus = unicode(jobStatDict['status'])
                    logFn = self.logger.error if deployStatus == 'Failure' else self.logger.info
                    logFn(logMsg)
                    #if 'exceptionMessage' in jobStatDict:
                    #    self.logger.error(jobStatDict['exceptionMessage'])
                if deployStatus not in finalStates:
                    time.sleep(5)
            else:
                self.logger.error('Cannot get details from jobId %s' % objectId)
                break
        return r.text

    def ctrOp(self, op, ctrIds, syslogServer=None, syslogTcp=False):
        ''' op: syslogserver_get, syslogserver_set, syslogserver_clear '''

        xml = ''
        for ctrId in ctrIds:
            objectId = ctrId
            if op == 'syslogserver_set':
                syslogProtocol = 'TCP' if syslogTcp else 'UDP'
                xml = xw(
                        xw('%s' % syslogServer, ['syslogServer'])+
                        xw('514', ['port'])+
                        xw('%s' % syslogProtocol, ['protocol'])+
                        xw('INFO', ['level']),
                    ['controllerSyslogServer'])
                r = self.doRestApi(op, data=xml, objectId=objectId)
            elif op in ['syslogserver_get', 'syslogserver_clear']:
                r = self.doRestApi(op, objectId=objectId)
                return r.text
            elif op == 'reset':
                r = self.doRestApi('get')
                ctrsOd = xmltodict.parse(r.text)
                #pprint_od(ctrsOd); exit()
                for ctr in cptutil.listify(ctrsOd['controllers']['controller']):
                    cid, vmId = ctr['id'], ctr['virtualMachineInfo']['objectId']
                    if ctrId == cid:
                        ctrName = ctr['name'] if 'name' in ctr else ''
                        vm = self.mgr.vslibVc.moid2mo(vmId)
                        self.logger.info('Reset controller %s(%s) %s(%s)' % (cid, ctrName, vmId, vm.name))
                        vslib.loopVcObjActionForTargets('vm', 'vmOp', [vm.name], self.mgr.vslibVc, True, 'power_reset')

    def show(self, objNames, fmt='yaml'):                       # class Controller
        rText = self.doRestApi('get').text
        fullOd = byteify(xmltodict.parse(rText))
        for ctrOd in fullOd['controllers']['controller']:
            if ctrOd['id'] in objNames:
                self.logger.info('Show Controller %s (%s)' % (ctrOd['name'], ctrOd['id']))
                ctrXml = xmltodict.unparse({'controller':ctrOd})
                if   fmt=='raw':    print(ctrXml)
                elif fmt=='yaml':   pprint_yaml({'controller':ctrOd})
                elif fmt=='json':   pprint_od({'controller':ctrOd})
                elif fmt=='xml':    pprint_xml(ctrXml)


class Edge(Network_element):
    '''
    edge: Reference to edge object
    interfaces: a List of dictionaries describing the edge's interfaces
    '''
    rest_api = {
        'get':          Api('get',       '/api/4.0/edges/', ''),
        'getone':       Api('get',      '"/api/4.0/edges/%s"%objectId', ''),
        'del':          Api('delete',   '"/api/4.0/edges/%s?async=true"%objectId', ''),

        'changeSize':   Api('post',     '"/api/4.0/edges/%s/appliances/?size=%s"%(objectId, newEdgeSize)', ''),
        'getConfig':    Api('get',      '"/api/4.0/edges/%s/appliances/"%objectId', ''),

        'status':       Api('get',    '"/api/4.0/edges/%s/status"%objectId', ''),
        'haAppStatus':  Api('get',    '"/api/4.0/edges/%s/appliances/%s"%(objectId,haIdex)', ''),
        'haAppCfg':     Api('put',    '"/api/4.0/edges/%s/appliances/%s"%(objectId,haIdex)', ''),

        'haCfgGet':  Api('get',    '"/api/4.0/edges/%s/highavailability/config"%objectId', ''),
        'haCfg':     Api('put',    '"/api/4.0/edges/%s/highavailability/config"%objectId', ''),
        'haCfgDel':  Api('delete', '"/api/4.0/edges/%s/highavailability/config"%objectId', ''),
    }
    rKeys = ['pagedEdgeList', 'edgePage', 'edgeSummary']
    jqTblSpec = JqTblSpec('''{
        "name":         .name,
        "objectId":     .objectId,
        "edgeType":     .edgeType,
        "activVmMoid":  .appliancesSummary.vmMoidOfActiveVse,
        "activeVmHost": .appliancesSummary.hostNameOfActiveVse,
    }''', '')

    edge = None
    interfaces = None
    oidParentDepth = 3

    def __init__(self, mgr, name=None, *args, **kwargs):
        super(Edge, self).__init__(mgr, *args, **kwargs)
        if name:
            self.edge = self.find_by_name(name, results=None)
            if not self.edge:
                raise ValueError("Can't find Edge by name: %s" %name)

    def operation(self, edgeNames, action, **kwargs):
        ''' extract kwargs to local namesapce '''
        exec('\n'.join('%s=kwargs["%s"]' % (k, k) for k in kwargs.keys()))

        for edgeName in edgeNames:
            objectId = self.find_by_name(edgeName, logError=True)
            if action in ['changeSize']:
                self.logger.info('Changing size for EDGE %s to %s' % (edgeName, newEdgeSize))
                r = self.doRestApi(action, objectId=objectId, newEdgeSize=newEdgeSize, data='')
                self.logger.info('Changed  size for EDGE %s to %s' % (edgeName, newEdgeSize))
            elif action in ['getConfig']:
                r = self.doRestApi(action, objectId=objectId)
                print(cptutil.StringData(r.text))

    def haOp(self, op, edgeNames, args=None):
        def prHaInfo(objectId, isHaEnabled):
            appVm = {}
            r = self.doRestApi('status', objectId=objectId)
            haOd = xmltodict.parse(r.text)['edgeStatus']

            if 'activeVseHaIndex' in haOd:
                activeVseHaIndex = haOd['activeVseHaIndex']
                systemStatus = haOd['systemStatus']

                self.logger.info('EdgeName:%s haEnabled:%s activeVseHaIndex:%s, status:%s' %
                    (edgeName, isHaEnabled, activeVseHaIndex, systemStatus))
                cols = ['highAvailabilityIndex', 'haAdminState', 'vmId', 'vmHostname', 'hostName', ]
                attrs = copy.copy(cols)
                attrs.extend(['resourcePoolId', 'datastoreId', 'edgeId', 'hostId'])
                ptbl = PrettyTable(cols)
                ptbl.align = 'l'
                for haIndex in ['0','1']:
                    appVm[haIndex] = {}
                    #print('objectId=%s, haIndex=%s' % (objectId, haIndex))
                    r = self.doRestApi('haAppStatus', objectId=objectId, haIdex=haIndex)
                    #print(cptutil.StringData(r.text))
                    haOd = xmltodict.parse(r.text)['appliance']
                    haOd['haAdminState'] = haOd.get('haAdminState', '')
                    haOd['hostName'] = haOd.get('hostName', '')
                    haOd['hostId'] = haOd.get('hostId', '')
                    row = [haOd[k] for k in cols]
                    if haIndex==activeVseHaIndex:
                        row[0] = row[0]+'*'
                    for k in attrs:
                        appVm[haIndex][k] = haOd[k]
                    ptbl.add_row(row)
                print(ptbl)
                return activeVseHaIndex, appVm
            else:
                self.logger.warning('HA not enabled on %s' % objectId)
                return None, None

        for edgeNameG in edgeNames:
            objectIds = self.find_by_name(edgeNameG, matchMethod='glob')
            objectIds = sorted(objectIds, key=lambda o: self.cDictByOid[o])
            for objectId in objectIds:
                edgeName = self.cDictByOid[objectId]
                r = self.doRestApi('haCfgGet', objectId=objectId)
                haCfgOd = xmltodict.parse(r.text)['highAvailability']
                isHaEnabled = haCfgOd['enabled']=='true'

                if op=='ha_status':
                    if not isHaEnabled:
                        self.logger.warning('HA not enabled on %s' % edgeName)
                        continue
                    activeVseHaIndex, appVm = prHaInfo(objectId, isHaEnabled)
                elif op=='ha_switchOver':
                    if not isHaEnabled:
                        self.logger.error('HA not enabled on %s' % edgeName)
                        continue

                    activeVseHaIndex, appVm = prHaInfo(objectId, isHaEnabled)
                    actIdx, sbyIdx = activeVseHaIndex, str((int(activeVseHaIndex)+1)%2)
                    self.logger.info('EdgeName: switching active Edge from %s to %s' % (actIdx, sbyIdx))

                    taskTuples = [(actIdx, 'down'), (sbyIdx, 'up')]
                    taskTuples = [(sbyIdx, 'up'), (actIdx, 'down'), (actIdx, 'up')]
                    for idx, admState in taskTuples:
                        self.logger.info('Changing %s haAdminState to %s' %
                            (appVm[idx]['vmHostname'], admState))
                        # make srue current config is copie over
                        xml = xw(
                            xw(idx, ['highAvailabilityIndex'])
                            +xw(admState, ['haAdminState'])
                            +xw(appVm[idx]['vmId'], ['vmId'])
                            +xw(appVm[idx]['resourcePoolId'], ['resourcePoolId'])
                            +xw(appVm[idx]['datastoreId'], ['datastoreId']),
                            ['appliance'])
                        #print(xml)
                        r = self.doRestApi('haAppCfg', objectId=objectId, haIdex=idx, data=xml)
                        #print(cptutil.StringData(r.text))
                        self.logger.info('Changed  %s haAdminState to %s' % (appVm[idx]['vmHostname'], admState))
                    prHaInfo(objectId, isHaEnabled)
                elif op=='ha_getConfig':
                    tags = ['enabled', 'declareDeadTime', 'log-enable', 'logLevel', 'security']
                    ptbl = PrettyTable(tags)
                    ptbl.align = 'l'
                    row = [haCfgOd['enabled'],
                        haCfgOd['declareDeadTime'],
                        haCfgOd['logging']['enable'],
                        haCfgOd['logging']['logLevel'],
                        haCfgOd['security']['enabled']]
                    ptbl.add_row(row)
                    print(ptbl)
                elif op in ['ha_enable', 'ha_disable']:
                    self.logger.info('%s for EDGE %s' % (op, edgeName))
                    declareDeadTime = args.deadTime
                    haEnable = 'true' if op=='ha_enable' else 'false'
                    xml = xw(
                        xw(haEnable, ['enabled'])
                        +xw(declareDeadTime, ['declareDeadTime']) if declareDeadTime else ''
                        ,['highAvailability'])
                    r = self.doRestApi('haCfg', objectId=objectId, data=xml)
                    self.logger.info('%s for EDGE %s: DONE' % (op, edgeName))
                elif op=='ha_delete':
                    self.logger.info('%s for EDGE %s' % (op, edgeName))
                    r = self.doRestApi('haCfgDel', objectId=objectId)
                    self.logger.info('%s for EDGE %s: DONE' % (op, edgeName))


    def edgeJobStatus(self, r):
        if 'location' not in r.headers: return

        edgeJobStatusRestUrl = r.headers['location']
        self.rest_api['edgeJobStatus'] =  Api('get', edgeJobStatusRestUrl, '')
        m = re.search('/api/4.0/edges/jobs/(jobdata-\w+)$', edgeJobStatusRestUrl)
        if not m: return
        jobId = m.group(1)

        # /api/4.0/edges/jobs/jobdata-5180
        restMethod = 'get'
        self.logger.info('jobUrl: %s' % edgeJobStatusRestUrl)

        # status: QUEUED RUNNING COMPLETED
        jobStatus = ''
        completedStates = ['COMPLETED', 'FAILED']
        while jobStatus not in completedStates:
            r = self.doRestApi('edgeJobStatus')
            jobStatDict = xmltodict.parse(r.text)['edgeJob']
            if unicode(jobStatDict['status']) != jobStatus:
                logMsg = '%s %s' % (jobId, jobStatDict['status'])
                if 'message' in jobStatDict:
                    logMsg += ' '+jobStatDict['message']
                if jobStatDict['status'] == 'FAILED':
                    self.logger.error(logMsg)
                else:
                    self.logger.info(logMsg)
                jobStatus = unicode(jobStatDict['status'])
            if jobStatus not in completedStates:
                time.sleep(2)
        return r.text

    def get_interface_list(self, reuse=False):
        '''
        Get the list of interfaces for this edge, returns None if edge is None
        If reuse is true and self.interfaces is not None, then just return
        the existing self.interfaces.  Otherwise, retrieve a new set and store
        the list of interfaces in self.interfaces and return it.
        '''
        if not self.edge:
            return None
        if reuse and self.interfaces:
            return self.interfaces

        intUrl = "/api/4.0/edges/%s/interfaces"%self.edge['objectId']
        r = getattr(self.mgr, 'get')(intUrl)
        if r.status_code >= 400:
            self.mgr.responseError(r)
        ifaces = xmltodict.parse(r.text)
        if not 'interfaces' in ifaces or not 'interface' in ifaces['interfaces']:
            self.interfaces == None
        else:
            self.interfaces=ifaces['interfaces']['interface']
        return self.interfaces

    def find_interface_by_name(self, name, reuse=False):
        '''
        Find an return an interface object by name. If reuse is true and
        self.interfaces exist, then do not retrieve the list of interfaces
        again; reuse should be set to true if there's been no changes to
        the edge definition after the previous retrieval.
        '''

        if not self.edge:
            return None
        if not reuse:
            self.get_interface_list(reuse=False)

        for i in self.interfaces:
            if i['name'] == name:
                return i
        return None

    def get_interface_ip(self, interface):
        '''
        Returns the primary address of the given interface.  Interface can be
        retrieved using self.find_interface_by_name()
        '''

        return interface['addressGroups']['addressGroup']['primaryAddress']

class Edge_esg(Edge):
    '''
    ESG edge
    '''
    rest_api = {
        'get'          : Api('get',    '/api/4.0/edges', ''),
        'cfg'          : Api('post',   '/api/4.0/edges?async=true', ''),
        'del'          : Api('delete', '"/api/4.0/edges/%s?async=true"%objectId', ''),
        'getone'       : Api('get',    '"/api/4.0/edges/%s"%objectId', ''),
        'update'       : Api('put',    '"/api/4.0/edges/%s?async=true"%objectId', ''),
        'getSysCtl'    : Api('get',    '"/api/4.0/edges/%s/systemcontrol/config"%objectId', ''),
        'setSysCtl'    : Api('put',    '"/api/4.0/edges/%s/systemcontrol/config"%objectId', ''),
        'getDhcpRelay' : Api('get',    '"/api/4.0/edges/%s/dhcp/config/relay"%objectId', ''),
        'setDhcpRelay' : Api('put',    '"/api/4.0/edges/%s/dhcp/config/relay"%objectId', ''),
        'delDhcpRelay' : Api('delete', '"/api/4.0/edges/%s/dhcp/config/relay"%objectId', ''),
        'getIfStat'    : Api('get',    '"/api/4.0/edges/%s/statistics/interfaces"%objectId', ''),

        'getLb'        : Api('get',    '"/api/4.0/edges/%s/loadbalancer/config"%esgId', ''),
        'modLb'        : Api('put',    '"/api/4.0/edges/%s/loadbalancer/config"%esgId', ''),
        'delLb'        : Api('delete', '"/api/4.0/edges/%s/loadbalancer/config"%esgId', ''),

        'getLbAppProfs': Api('get',    '"/api/4.0/edges/%s/loadbalancer/config/applicationprofiles"%esgId', ''),
        'getLbAppProf' : Api('get',    '"/api/4.0/edges/%s/loadbalancer/config/applicationprofiles/%s"%(esgId,appProfId)', ''),
        'modLbAppProf' : Api('put',    '"/api/4.0/edges/%s/loadbalancer/config/applicationprofiles/%s"%(esgId,appProfId)', ''),
        'delLbAppProf' : Api('delete', '"/api/4.0/edges/%s/loadbalancer/config/applicationprofiles/%s"%(esgId,appProfId)', ''),

        'getLbAppRules': Api('get',    '"/api/4.0/edges/%s/loadbalancer/config/applicationrules"%esgId', ''),
        'delLbAppRules': Api('delete', '"/api/4.0/edges/%s/loadbalancer/config/applicationrules"%esgId', ''),
        'getLbAppRule' : Api('get',    '"/api/4.0/edges/%s/loadbalancer/config/applicationrules/%s"%(esgId,appRuleId)', ''),
        'appLbAppRule' : Api('post',   '"/api/4.0/edges/%s/loadbalancer/config/applicationrules"%esgId', ''),
        'modLbAppRule' : Api('put',    '"/api/4.0/edges/%s/loadbalancer/config/applicationrules/%s"%(esgId,appRuleId)', ''),
        'delLbAppRule' : Api('delete', '"/api/4.0/edges/%s/loadbalancer/config/applicationrules/%s"%(esgId,appRuleId)', ''),

        'appLbMonitor' : Api('post',   '"/api/4.0/edges/%s/loadbalancer/config/monitors"%esgId)', ''),
        'modLbMonitor' : Api('put',    '"/api/4.0/edges/%s/loadbalancer/config/monitors/%s"%(esgId,monitorId)', ''),
        'delLbMonitor' : Api('delete', '"/api/4.0/edges/%s/loadbalancer/config/monitors/%s"%(esgId,monitorId)', ''),
        'delLbMonitors': Api('delete', '"/api/4.0/edges/%s/loadbalancer/config/monitors"%esgId)', ''),
        'getLbMonitor' : Api('get',    '"/api/4.0/edges/%s/loadbalancer/config/monitors/%s"%(esgId,monitorId)', ''),
        'getLbMonitors': Api('get',    '"/api/4.0/edges/%s/loadbalancer/config/monitors"%esgId)', ''),

        'appLbVsvr'   : Api('post',   '"api/4.0/edges/%s/loadbalancer/config/virtualservers"%esgId)', ''),
        'modLbVsvr'   : Api('put',    '"api/4.0/edges/%s/loadbalancer/config/virtualservers/%s"%(esgId,vsvrId)', ''),
        'delLbVsvr'   : Api('delete', '"api/4.0/edges/%s/loadbalancer/config/virtualservers/%s"%(esgId,vsvrId)', ''),
        'delLbVsvrs'  : Api('delete', '"api/4.0/edges/%s/loadbalancer/config/virtualservers"%esgId)', ''),
        'getLbVsvr'   : Api('get',    '"api/4.0/edges/%s/loadbalancer/config/virtualservers/%s"%(esgId,vsvrId)', ''),
        'getLbVsvrs'  : Api('get',    '"api/4.0/edges/%s/loadbalancer/config/virtualservers"%esgId)', ''),

        'appLbPool'   : Api('post',   '"api/4.0/edges/%s/loadbalancer/config/pools"%esgId)', ''),
        'modLbPool'   : Api('put',    '"api/4.0/edges/%s/loadbalancer/config/pools/%s"%(esgId,poolId)', ''),
        'delLbPool'   : Api('delete', '"api/4.0/edges/%s/loadbalancer/config/pools/%s"%(esgId,poolId)', ''),
        'delLbPools'  : Api('delete', '"api/4.0/edges/%s/loadbalancer/config/pools"%esgId)', ''),
        'getLbPool'   : Api('get',    '"api/4.0/edges/%s/loadbalancer/config/pools/%s"%(esgId,poolId)', ''),
        'getLbPools'  : Api('get',    '"api/4.0/edges/%s/loadbalancer/config/pools"%esgId)', ''),

        'getLbStaticstics': Api('get',  '"api/4.0/edges/%s/loadbalancer/statistics"%esgId)', ''),
        'modLbAccMode'    : Api('post', '"api/4.0/edges/%s/loadbalancer/acceleration?enable=%s"%(esgId,enable)', ''),
        'modLbMbrCond'    : Api('post', '"api/4.0/edges/%s/loadbalancer/config/members/%s?enable=%s"%(esgId,mbrId,enable)', ''),
    }

    def dhcpRelayOp(self, edgeName, action='get', data=None):
        objectId = self.find_by_name(edgeName, results='objectId')
        if action=='get':
            r = self.doRestApi('getDhcpRelay', objectId=objectId)
            return r.text
        elif action=='delete':
            self.logger.info("Deleting DHCP relay for %s", edgeName)
            r = self.doRestApi('delDhcpRelay', objectId=objectId)
        elif action=='config':
            self.logger.info("Configurating DHCP relay for %s", edgeName)
            r = self.doRestApi('setDhcpRelay', objectId=objectId, data=data['xml'])
            self.logger.info("Configurated DHCP relay for %s", edgeName)
            return r.text

    def showVnicStat(self, esgName, vnicNo):
        edgeId = self.find_by_name(esgName)
        r = self.doRestApi('getIfStat', objectId=edgeId)

        rObjs = xmltodict.parse(r.text)
        statistic = rObjs["statistics"]["data"]["statistic"]

        ptbl = PrettyTable(['time', 'in-Kbps', 'out-Kbps'])
        ptbl.align = 'l'
        for s in statistic:
            if s["vnic"]==str(vnicNo):
                ptbl.add_row([
                    time.strftime('%D %T', time.localtime(float(s["timestamp"]))),
                    s["in"], s["out"]])
        print(ptbl)
        print('Count: %d entries for vnic%d' % (ptbl.rowcount, vnicNo))

#    def config(self, data, args, update=True):
#        '''
#        Configure or Update an ESG.  Note that the API called is the same
#        for DLR, but the contents are different.  So this method
#        will not work for DLR creation.
#
#        if update: update config if edge already exists, else do nothing
#        '''
#
#        yml = data['yaml']['edge'][0]
#        edgeName = yml['name']
#
#        featureMap = {}
#        vnicRpfs = {}
#
#        self.edge = self.find_by_name(yml['name'], results=None)
#        if self.edge and not update:
#            self.logger.error("ESG with name of %s exists, cannot create" % edgeName)
#            return None
#        elif update and not self.edge:
#            self.logger.error("ESG with name of %s does not exists, cannot update" % edgeName)
#            return None
#
#        op = 'update' if update else 'cfg'
#        restUrl = self.rest_api[op].url
#        restMethod = self.rest_api[op].method
#        objectId = ''
#        if update:
#            objectId = self.edge['objectId']
#            restUrl = eval(restUrl)
#        #if self.edge:
#        #    restUrl = self.rest_api['update'].url
#        #    objectId = self.edge['objectId']
#        #    restUrl = eval(restUrl)
#        #    restMethod = self.rest_api['update'].method
#        #else:
#        #    restUrl = self.rest_api['cfg'].url
#        #    restMethod = self.rest_api['cfg'].method
#
#        si, inv = self.mgr.vcSi, self.mgr.vcInv
#
#        '''
#        #print('----------------')
#        swapXmlTag(self, data['yaml']['edge'][0],
#            [('HINT_datacenter',   'HINT_DATACENTER_datacenterMoid')])
#        #pprint(data['yaml']['edge'][0]); exit()
#
#        '''
#        if 'HINT_datacenter' in yml:
#            dc = vs.getObjectFromVcenterInventory(
#                    inv = inv,
#                    vimtype = [vim.Datacenter],
#                    name = yml['HINT_datacenter'])
#            if not dc:
#                raise ValueError('Cannot find id for datacenter: ' +
#                        yml['HINT_datacenter'])
#            else:
#                yml['datacenterMoid'] = dc._moId
#                yml.pop('HINT_datacenter', None)
#
#
#        swapXmlTag(self, data['yaml']['edge'][0]['appliances']['appliance'], [
#            ('HINT_clusterName',   'HINT_CLUSTER_resourcePoolId'),
#            ('HINT_datastoreName', 'HINT_DATASTORE_datastoreId'),
#            ('HINT_hostname',      'HINT_HOST_hostId'),
#            ('HINT_vmFolderName',  'HINT_FOLDER_vmFolderId'),
#            ])
#        #pprint(data['yaml']['edge'][0])
#        #exit()
#
#        #print(json.dumps(appliance, indent=4))
#
#        if 'vnics' in yml:
#            pprint(yml['vnics']); exit()
#            vnics = listify(yml['vnics']['vnic'])
#            #for i in yml['vnics']:
#            for i in range(len(vnics)):
#                #inter = i['vnic']
#                inter = vnics[i]
#                if 'HINT_portgroup' in inter:
#                    pg = nsxv.find_portgroup_or_logical_switch_by_name(
#                            mgr = self.mgr,
#                            data = data,
#                            args = args, inv = inv,
#                            name = inter['HINT_portgroup'],
#                            tz = inter['HINT_transportzone'] if \
#                                    'HINT_transportzone' in inter
#                            else None)
#                    if pg:
#                        inter['portgroupId'] = pg
#                        #inter.pop('HINT_portgroup', None)
#                    else:
#                        msg = 'Cannot find portgroup %s' % inter['HINT_portgroup']
#                        if 'HINT_transportzone' in inter:
#                            msg +=  'in transport-zone %s' % inter['HINT_transportzone']
#                        raise ValueError(msg)
#                if 'HINT_rpfilter' in inter:
#                    vnicRpfs[inter['index']] = inter['HINT_rpfilter']
#            if vnicRpfs:
#                featureMap['rpf'] = vnicRpfs
#
#        if 'features' in yml:
#            if 'routing' in yml['features']:
#                if 'staticRouting' in yml['features']['routing']:
#                    if 'staticRoutes' in yml['features']['routing']['staticRouting']:
#                        for route in yml['features']['routing']\
#                                ['staticRouting']['staticRoutes']:
#                            if not 'HINT_vnic' in route:
#                                continue
#                            for i in yml['vnics']:
#                                if i['vnic']['HINT_portgroup']==\
#                                        route['HINT_vnic']:
#                                    route['vnic'] = i['vnic']['HINT_portgroup']
#                                    break
#                            if not 'vnic' in route:
#                                raise ValueError(
#                                      "Static route %s needs to specify vnic")
#                if 'ospf' in yml['features']['routing']:
#                    if 'ospfInterfaces' in yml['features']['routing']['ospf']:
#                        for iface in yml['features']['routing']\
#                                ['ospf']['ospfInterfaces']:
#                            if not 'HINT_vnic' in iface['ospfInterface']:
#                                continue
#                            for i in yml['vnics']:
#                                if i['vnic']['HINT_portgroup']==\
#                                        iface['ospfInterface']['HINT_vnic']:
#                                    iface['ospfInterface']['vnic'] = \
#                                            i['vnic']['index']
#                                    break
#                            if not 'vnic' in iface['ospfInterface']: raise ValueError(
#                                        "Edge %s OSPF nic not found."
#                                        %(yml['name']))
#            if 'loadBalancer' in yml['features']:
#                if update:
#                    ymlLbDict = {'loadBalancer':data['yaml']['edge'][0]['features']['loadBalancer']}
#                    #print('orgDict:'); pprint(ymlLbDict)
#                    if 'pool' in ymlLbDict['loadBalancer']:
#                        for pool in listify(ymlLbDict['loadBalancer']['pool']):
#                            unmappedTags = swapXmlTag(self, pool['member'])
#                    #print('modDict:'); pprint(ymlLbDict)
#                    if 'applicationProfile' in ymlLbDict['loadBalancer']:
#                        for appProf in listify(ymlLbDict['loadBalancer']['applicationProfile']):
#                            if 'clientSsl' in appProf:
#                                unmappedTags = swapXmlTag(self, appProf['clientSsl'],
#                                    certScopeId=self.edge['objectId'])
#                    #print('MODDict:'); pprint(ymlLbDict)
#                    featureMap['loadBalancer'] = ymlLbDict
#
#
#                    self.logger.info("Configurating load balancer")
#                    ymlLbDict = featureMap['loadBalancer']
#                    esgLbXml = xmltodict.unparse(ymlLbDict)
#                    #print('MODXML:'); print(esgLbXml)
#                    r = self.doRestApi('modLb', esgId=objectId, data=esgLbXml)
#                    esgXml = r.text
#                    self.logger.info("Configurated  load balancer")
#                    # this is the correct exit point for LB
#                    exit()
#
#
#                    r = self.doRestApi('getone', objectId=objectId)
#                    esgXml = r.text
#                    esgOd = xmltodict.parse(esgXml)
#                    lb = esgOd['edge']['features']['loadBalancer']
#                    #print('liveEsg:'); pprint_od(lb)
#                    #print('yamlEsg:'); print(type(data['yaml']['edge'][0]['features']['loadBalancer']['monitor']))
#                    #print('yamlEsg:'); pprint_od(data['yaml']['edge'][0]['features']['loadBalancer'])
#                    ##pprint_od(esgOd['edge']['features']['loadBalancer'])
#                    ##pprint(data['yaml']['edge'][0]['features']['loadBalancer'])
#
#                    esgOd['edge']['features']['loadBalancer'] = \
#                        data['yaml']['edge'][0]['features']['loadBalancer']
#                    #print("### 'edge']['features']:")
#                    pprint_od(esgOd['edge']['features'])
#                    #esgXml = xmltodict.unparse(esgOd)
#                else:
#                    del data['yaml']['edge'][0]['features']['loadBalancer']
#
#
#        datacopy = copy.deepcopy(data['yaml'])
#        #pprint(datacopy)
#        self.logger.info("Recreating XML for API post with new values from VC")
#        newdata, begin,end  = yaml_to_xml(yml = datacopy, top = True)
#        #print(json.dumps(newdata[0]['yaml'], indent=4))
#        self.logger.info("Posting edge update to NSX Manager")
#
#        '''
#        r = getattr(self.mgr, restMethod)(restUrl, data=newdata[0]['xml'])
#        #r = getattr(self.mgr, restMethod)(restUrl, data=esgXml)
#
#        if r.status_code >= 400:
#            self.mgr.responseError(r)
#            r.raise_for_status()
#        '''
#        r = self.doRestApi(op, esgId=objectId, data=newdata[0]['xml'])
#        jobRet = self.edgeJobStatus(r)
#
#        jobRetOD = xmltodict.parse(jobRet)
#        for rDict in listify(jobRetOD['edgeJob']['result']):
#            if rDict['key']=='edgeId':
#                edgeId = rDict['value']
#                objectId = edgeId
#
#        for feature in featureMap:
#            if feature == 'loadBalancer':
#                self.logger.info("Configurating load balancer")
#                ymlLbDict = featureMap['loadBalancer']
#                esgLbXml = xmltodict.unparse(ymlLbDict)
#                #print('MODXML:'); print(esgLbXml)
#                r = self.doRestApi('modLb', esgId=objectId, data=esgLbXml)
#                esgXml = r.text
#            elif feature == 'rpf':
#                self.logger.info('config rp_filter for vnic %s' % vnicRpfs.keys())
#                #vnicRpfs = featureMap['rpf']
#                xml = ''
#                for vnic in vnicRpfs:
#                    xml += xw('sysctl.net.ipv4.conf.vNic_%d.rp_filter=%d' %
#                        (vnic,vnicRpfs[vnic]), ['property'])
#                xml = xw(xml, ['systemControl'])
#                r = self.doRestApi('setSysCtl', objectId=objectId, data=xml)
#                self.logger.info('rp_filter config completed')
    def config(self, data, args, update=True):
        '''
        Configure or Update an ESG.  Note that the API called is the same
        for DLR, but the contents are different.  So this method
        will not work for DLR creation.

        if update: update config if edge already exists, else do nothing
        '''

        yml = data['yaml']['edge'][0]

        vnicRpfs = {}

        self.edge = self.find_by_name(yml['name'], results=None)
        if not update and self.edge:
            self.logger.error("ESG with name of %s exists, not updating"%yml['name'])
            return None

        if self.edge:
            restUrl = self.rest_api['update'].url
            objectId = self.edge['objectId']
            restUrl = eval(restUrl)
            restMethod = self.rest_api['update'].method
        else:
            restUrl = self.rest_api['cfg'].url
            restMethod = self.rest_api['cfg'].method

        #print('===============')
        #print('self=', self)
        #print('vc=', self.mgr.vc)
        #print('si=', self.mgr.vc.si)
        #print('inv=', self.mgr.vc.inv)
        #si, inv = connect_to_vcenter(args)
        si, inv = self.mgr.vcSi, self.mgr.vcInv

        #className = vslib.vimClassNameToShortVimTypeName(vim.Datacenter)
        #mo = eval(className)(vc)

        #dcObj = vslib.Datacenter(self.mgr.vc)
        #print('dcName =', yml['HINT_datacenter'])
        #dcMo = dcObj.find_by_name(yml['HINT_datacenter'])
        #print('dcMo =', dcMo)
        #exit()

        if 'HINT_datacenter' in yml:
            dc = vs.getObjectFromVcenterInventory(
                    inv = inv,
                    vimtype = [vim.Datacenter],
                    name = yml['HINT_datacenter'])
            if not dc:
                raise ValueError('Cannot find id for datacenter: ' +
                        yml['HINT_datacenter'])
            else:
                yml['datacenterMoid'] = dc._moId
                yml.pop('HINT_datacenter', None)

        appliance = yml['appliances']['appliance']
        #print(json.dumps(appliance, indent=4))
        if 'HINT_clusterName' in appliance:
            cluster = vs.getObjectFromVcenterInventory(
                    inv = inv ,
                    vimtype = [vim.ClusterComputeResource],
                    name = appliance['HINT_clusterName'])

            if not cluster:
                raise ValueError('Cannot find cluster id for cluster name: ' +
                        appliance['HINT_clusterName'])
            else:
                self.logger.info("Cluster id for %s: %s" %
                    (appliance['HINT_clusterName'], cluster._moId))
                appliance['resourcePoolId'] = cluster._moId
                appliance.pop('HINT_clusterName', None)



        if 'HINT_datastoreName' in appliance:
            datastore = vs.getObjectFromVcenterInventory(
                    inv = inv,
                    vimtype = [vim.Datastore],
                    name = appliance['HINT_datastoreName'])
            if not datastore:
                raise ValueError('Cannot find datastore id for: ' +
                        appliance['HINT_datastoreName'])
            else:
                self.logger.info("Datastore id for %s: %s"
                    %(appliance['HINT_datastoreName'], datastore._moId))
                appliance['datastoreId'] = datastore._moId
                appliance.pop('HINT_datastoreName', None)

        if 'HINT_hostname' in appliance:
            host = vs.getObjectFromVcenterInventory(
                    inv = inv,
                    vimtype = [vim.HostSystem],
                    name = appliance['HINT_hostname'])
            if not host:
                raise ValueError('Cannot find host id for: '
                        + appliance['HINT_hostname'])
            else:
                self.logger.info("Host id for %s: %s" %
                    (appliance['HINT_hostname'], host._moId))
                appliance['hostId'] = host._moId
                appliance.pop('HINT_hostname', None)

        if 'HINT_vmFolderName' in appliance:
            folder = vs.getObjectFromVcenterInventory(
                    inv = inv,
                    vimtype = [vim.Folder],
                    name = appliance['HINT_vmFolderName'])
            if not folder:
                raise ValueError('Cannot find folder: ' +
                        appliance['HINT_vmFolderName'])
            else:
                self.logger.info("Folder id for %s: %s" %
                    (appliance['HINT_vmFolderName'], folder._moId))
                appliance['vmFolderId'] = folder._moId
                appliance.pop('HINT_vmFolderName', None)


        #print(json.dumps(appliance, indent=4))

        if 'vnics' in yml:
            for i in yml['vnics']:
                inter = i['vnic']
                if 'HINT_portgroup' in inter:
                    pg = nsxv.find_portgroup_or_logical_switch_by_name(
                            mgr = self.mgr,
                            data = data,
                            args = args, inv = inv,
                            name = inter['HINT_portgroup'],
                            tz = inter['HINT_transportzone'] if \
                                    'HINT_transportzone' in inter
                            else None)
                    if pg:
                        inter['portgroupId'] = pg
                        #inter.pop('HINT_portgroup', None)
                    else:
                        msg = 'Cannot find portgroup %s' % inter['HINT_portgroup']
                        if 'HINT_transportzone' in inter:
                            msg +=  'in transport-zone %s' % inter['HINT_transportzone']
                        raise ValueError(msg)
                if 'HINT_rpfilter' in inter:
                    vnicRpfs[inter['index']] = inter['HINT_rpfilter']

        if 'features' in yml:
            if 'routing' in yml['features']:
                if 'staticRouting' in yml['features']['routing']:
                    if 'staticRoutes' in yml['features']['routing']['staticRouting']:
                        for route in yml['features']['routing']\
                                ['staticRouting']['staticRoutes']:
                            if not 'HINT_vnic' in route:
                                continue
                            for i in yml['vnics']:
                                if i['vnic']['HINT_portgroup']==\
                                        route['HINT_vnic']:
                                    route['vnic'] = i['vnic']['HINT_portgroup']
                                    break
                            if not 'vnic' in route:
                                raise ValueError(
                                      "Static route %s needs to specify vnic")
                if 'ospf' in yml['features']['routing']:
                    if 'ospfInterfaces' in yml['features']['routing']['ospf']:
                        for iface in yml['features']['routing']\
                                ['ospf']['ospfInterfaces']:
                            if not 'HINT_vnic' in iface['ospfInterface']:
                                continue
                            for i in yml['vnics']:
                                if i['vnic']['HINT_portgroup']==\
                                        iface['ospfInterface']['HINT_vnic']:
                                    iface['ospfInterface']['vnic'] = \
                                            i['vnic']['index']
                                    break
                            if not 'vnic' in iface['ospfInterface']: raise ValueError(
                                        "Edge %s OSPF nic not found."
                                        %(yml['name']))

        datacopy = copy.deepcopy(data['yaml'])
        self.logger.info("Recreating XML for API post with new values from VC")
        newdata, begin,end  = yaml_to_xml(yml = datacopy, top = True)
        #print(json.dumps(newdata[0]['yaml'], indent=4))
        #print(newdata[0]['xml'])
        self.logger.info("Posting edge update to NSX Manager")

        '''
        r = requests.post(url = url,
                headers = headers,
                auth = auth,
                data = newdata[0]['xml'],
                verify=False)
        '''
        #print(newdata[0]['xml']; exit())
        #return
        r = getattr(self.mgr, restMethod)(restUrl, data=newdata[0]['xml'])

        if r.status_code >= 400:
            self.mgr.responseError(r)
            r.raise_for_status()
        jobRet = self.edgeJobStatus(r)

        #jobRetOD = xmltodict.parse(jobRet)
        #for rDict in jobRetOD['edgeJob']['result']:
        #    if rDict['key']=='edgeId':
        #        edgeId = rDict['value']
        #        objectId = edgeId

        # configure rpf
        if vnicRpfs:
            self.logger.info('config rp_filter for vnic %s' % vnicRpfs.keys())
            restUrl = eval(self.rest_api['setSysCtl'].url)
            restMethod = self.rest_api['update'].method
            xml = ''
            for vnic in vnicRpfs:
                xml += xw('sysctl.net.ipv4.conf.vNic_%d.rp_filter=%d' %
                    (vnic,vnicRpfs[vnic]), ['property'])
            xml = xw(xml, ['systemControl'])
            #print('xml =', xml)
            r = getattr(self.mgr, restMethod)(restUrl, data=xml)
            if r.status_code >= 400:
                self.mgr.responseError(r)
                r.raise_for_status()
            self.logger.info('rp_filter config completed')



class Edge_dlr(Edge):
    '''
    DLR edge

    Primary ifference between DLR and ESG edge is in the interface
    specification
    '''
    rest_api = {
        'get' : Api('get', '/api/4.0/edges', ''),
        'cfg' : Api('post', '/api/4.0/edges?async=true', ''),
        'cfgUniversal' : Api('post', '/api/4.0/edges?async=true&isUniversal=true', ''),
        'update' : Api('put', '"/api/4.0/edges/%s?async=true"%objectId', '')
    }

#    def config(self, data, args, update=True):
#        '''
#        Configure or Update a DLR.  Note that the API called is the same
#        for ESG, but the contents are different.  So this method
#        will not work for ESG creation.
#
#        if update: update config if edge already exists, else do nothing
#        '''
#
#        yml = data['yaml']['edge'][0]
#        edgeName = yml['name']
#
#        self.edge = self.find_by_name(yml['name'], results=None, refresh=True)
#        if self.edge and not update:
#            self.logger.error("DLR with name of %s exists, cannot create" % edgeName)
#            return None
#        elif update and not self.edge:
#            self.logger.error("DLR with name of %s does not exists, cannot update" % edgeName)
#            return None
#
#        if self.edge:
#            restUrl = self.rest_api['update'].url
#            objectId = self.edge['objectId']
#            restUrl = eval(restUrl)
#            restMethod = self.rest_api['update'].method
#            if not self.get_interface_list():
#                print("no interfaces found")
#                return
#        elif checkIsUniversal(data['yaml']):
#            restUrl = self.rest_api['cfgUniversal'].url
#            restMethod = self.rest_api['cfgUniversal'].method
#        else:
#            restUrl = self.rest_api['cfg'].url
#            restMethod = self.rest_api['cfg'].method
#
#        si, inv = self.mgr.vcSi, self.mgr.vcInv
#
#        if 'mgmtInterface' in yml:
#            mgmt = yml['mgmtInterface']
#            if 'HINT_portgroup' in mgmt:
#                self.logger.info('mapping HINT_portgroup %s' % mgmt['HINT_portgroup'])
#                args.vcenter, args.vuser, args.vpasswd = self.mgr.vcIp, self.mgr.vcUser, self.mgr.vcPass
#                pg = nsxv.find_portgroup_or_logical_switch_by_name(mgr = self.mgr,
#                        data = data, args = args,
#                        name = mgmt['HINT_portgroup'],
#                        tz = mgmt['HINT_transportzone'] \
#                                if 'HINT_transportzone' in mgmt
#                        else None)
#                if pg:
#                    mgmt['connectedToId'] = pg
#                else:
#                    raise ValueError('Cannot find the portgroup or LS "%s" for '
#                            'mgmt interface' % mgmt['HINT_portgroup'])
#
#        if 'HINT_datacenter' in yml:
#            self.logger.info('mapping HINT_datacenter %s' % yml['HINT_datacenter'])
#            dc = vs.getObjectFromVcenterInventory(
#                    inv = inv,
#                    vimtype = [vim.Datacenter],
#                    name = yml['HINT_datacenter'])
#            if not dc:
#                raise ValueError('Cannot find id for datacenter: ' +
#                        yml['HINT_datacenter'])
#            else:
#                yml['datacenterMoid'] = dc._moId
#                yml.pop('HINT_datacenter', None)
#
#        if 'appliance' in yml['appliances']:
#            appliance = yml['appliances']['appliance']
#
#            if 'HINT_clusterName' in appliance:
#                self.logger.info('mapping HINT_clusterName %s' % appliance['HINT_clusterName'])
#                cluster = vs.getObjectFromVcenterInventory(
#                        inv = inv ,
#                        vimtype = [vim.ClusterComputeResource],
#                        name = appliance['HINT_clusterName'])
#
#                if not cluster:
#                    raise ValueError('Cannot find cluster id for cluster name: ' +
#                            appliance['HINT_clusterName'])
#                else:
#                    self.logger.info('mapped  HINT_clusterName %s: %s' %
#                        (appliance['HINT_clusterName'], cluster._moId))
#                    appliance['resourcePoolId'] = cluster._moId
#                    appliance.pop('HINT_clusterName', None)
#
#
#
#            if 'HINT_datastoreName' in appliance:
#                self.logger.info('mapping HINT_datastoreName %s' % appliance['HINT_datastoreName'])
#                datastore = vs.getObjectFromVcenterInventory(
#                        inv = inv,
#                        vimtype = [vim.Datastore],
#                        name = appliance['HINT_datastoreName'])
#                if not datastore:
#                    raise ValueError('Cannot find datastore id for: ' +
#                            appliance['HINT_datastoreName'])
#                else:
#                    self.logger.info('mapped  HINT_datastoreName %s: %s' %
#                        (appliance['HINT_datastoreName'],  datastore._moId))
#                    appliance['datastoreId'] = datastore._moId
#                    appliance.pop('HINT_datastoreName', None)
#
#            if 'HINT_hostname' in appliance:
#                self.logger.info('mapping HINT_hostname %s' % appliance['HINT_hostname'])
#                host = vs.getObjectFromVcenterInventory(
#                        inv = inv,
#                        vimtype = [vim.HostSystem],
#                        name = appliance['HINT_hostname'])
#                if not host:
#                    raise ValueError('Cannot find host id for: '
#                            + appliance['HINT_hostname'])
#                else:
#                    self.logger.info('mapped  HINT_hostname %s: %s' %
#                        (appliance['HINT_hostname'], host._moId))
#                    appliance['hostId'] = host._moId
#                    appliance.pop('HINT_hostname', None)
#
#            if 'HINT_vmFolderName' in appliance:
#                self.logger.info('mapping HINT_vmFolderName %s' % appliance['HINT_vmFolderName'])
#                folder = vs.getObjectFromVcenterInventory(
#                        inv = inv,
#                        vimtype = [vim.Folder],
#                        name = appliance['HINT_vmFolderName'])
#                if not folder:
#                    raise ValueError('Cannot find folder: ' +
#                            appliance['HINT_vmFolderName'])
#                else:
#                    self.logger.info('mapped  HINT_vmFolderName %s: %s' %
#                        (appliance['HINT_vmFolderName'], folder._moId))
#                    appliance['vmFolderId'] = folder._moId
#                    appliance.pop('HINT_vmFolderName', None)
#
#        if 'interfaces' in yml:
#            if update:
#                self.get_interface_list(reuse = False)
#            else:
#                ls=Logical_switch(mgr=self.mgr, get=True)
#
#            interfaces = listify(yml['interfaces']['interface'])
#            #for i in yml['interfaces']:
#            for i in range(len(interfaces)):
#                #inter = i['interface']
#                inter = interfaces[i]
#                if update:
#                    if not 'HINT_portgroup' in inter and not 'index' in inter:
#                        self.logger.error("For DLR update, atleast HINT_portgroup or index must be provided")
#                        raise ValueError("Missing portgroup or index for DLR interface update")
#                    if 'HINT_portgroup' in inter:
#                        self.logger.info('mapping HINT_portgroup %s' % inter['HINT_portgroup'])
#                        nic = self.find_interface_by_name(
#                                name=inter['HINT_portgroup'],
#                                reuse = True)
#                        if nic:
#                            self.logger.info('mapped  HINT_portgroup %s: %s' %
#                                (inter['HINT_portgroup'], nic['connectedToId']))
#                            inter['connectedToId'] = nic['connectedToId']
#                            inter['index'] = nic['index']
#                            continue
#                        else:
#                            raise ValueError('Cannot find interface to update: '
#                                    + inter['HINT_portgroup'])
#                else:
#                    if 'HINT_portgroup' in inter:
#                        self.logger.info('mapping HINT_portgroup %s' % inter['HINT_portgroup'])
#                        pg = ls.find_switch_by_name(name=inter['HINT_portgroup'],
#                                reuse = True)
#                        if pg:
#                            self.logger.info('mapped  HINT_portgroup %s: %s' %
#                                (inter['HINT_portgroup'], pg['objectId']))
#                            inter['connectedToId'] = pg['objectId']
#                            continue
#                        if not pg:
#                            raise ValueError('Cannot find portgroup %s'%inter['HINT_portgroup'])
#
#        ospf = None
#        dhcprelay = None
#        routing = None
#
#        # Note that if interfaces have changed, then this lookup will not work
#        if 'features' in yml:
#
#            # Check that we are not creating...this
#            # part needs to be done through update
#            if 'routing' in yml['features']:
#                # =====Global routing block=========
#                if 'routingGlobalConfig' in yml['features']['routing'] \
#                        and not update:
#                    routing = yml['features']['routing'].pop('routingGlobalConfig')
#
#                #  ========OSPF Block=============
#
#
#                if 'ospf' in yml['features']['routing'] and not update:
#                    ospf = yml['features']['routing'].pop('ospf')
#                elif 'ospf' in yml['features']['routing'] and update:
#                    if 'ospfInterfaces' in yml['features']['routing']['ospf']:
#                        for iface in yml['features']['routing']\
#                                ['ospf']['ospfInterfaces']:
#                            if not 'HINT_vnic' in iface['ospfInterface']:
#                                continue
#                            nic = self.find_interface_by_name(
#                                    name=iface['ospfInterface']['HINT_vnic'],
#                                    reuse = False)
#                            if not nic:
#                                raise ValueError("DLR %s does not have nic %s"\
#                                        %(yml['name'],\
#                                        iface['ospfInterface']['HINT_vnic']))
#                            iface['ospfInterface']['vnic'] = nic['index']
#                #  ========end OSPF Block=============
#
#            if 'dhcp' in yml['features']:
#                # taking this out for now, it doesn't work PR 1452523
#                #yml['features']['dhcp'].pop('relay')
#                if 'relay' in yml['features']['dhcp'] and not update:
#                    dhcprelay = yml['features']['dhcp'].pop('relay')
#                elif 'relay' in yml['features']['dhcp'] and update:
#                    if 'relayAgents' in yml['features']['dhcp']['relay']:
#                        for agent in yml['features']['dhcp']\
#                                ['relay']['relayAgents']:
#                            agentObj = agent['relayAgent']
#                            if 'HINT_nic' in agentObj:
#                                iface = self.find_interface_by_name(
#                                    agentObj['HINT_nic'])
#                                if not iface:
#                                    raise ValueError(
#                                            "Can't find interface by name: %s"
#                                            %agentObj['HINT_nic'])
#                                else:
#                                    agentObj['vnicIndex'] = iface['index']
#                                    agentObj['giAddress'] = self.get_interface_ip(iface)
#
#        datacopy = copy.deepcopy(data['yaml'])
#
#        bug1753727 = False
#        if update and bug1753727:
#            orgDlrName = datacopy['edge'][0]['name']
#            del datacopy['edge'][0]['name']
#
#        self.logger.info('Recreating XML for API post with new values from VC')
#        newdata, begin,end  = yaml_to_xml(yml = datacopy, top = True)
#        #pprint_xml(newdata[0]['xml'])
#        self.logger.info('Posting DLR update to NSX Manager')
#
#        self.logger.debug('%s: REST CALL %s %s' % (type(self), restMethod, restUrl))
#        self.logger.debug('%s: REST BODY xml=%s' % (type(self), pformat_xmlInYaml(newdata[0]['xml'])))
#
#        r = getattr(self.mgr, restMethod)(restUrl, data=newdata[0]['xml'])
#        if r.status_code >= 400:
#            self.mgr.responseError(r)
#            r.raise_for_status()
#        self.edgeJobStatus(r)
#
#        if update and bug1753727:
#            self.logger.warning('Posting SECOND DLR update to NSX Manager with DLR name this time (Bug 1753727)')
#            datacopy['edge'][0]['name'] = orgDlrName
#            newdata, begin,end  = yaml_to_xml(yml = datacopy, top = True)
#            r = self.doRestApi('update', data=newdata[0]['xml'], objectId=objectId)
#            self.edgeJobStatus(r)
#
#        doUpdate = False
#        if routing:
#            yml['features']['routing']['routingGlobalConfig'] = routing
#            doUpdate = True
#        if ospf:
#            yml['features']['routing']['ospf'] = ospf
#            doUpdate = True
#        if dhcprelay:
#            yml['features']['dhcp']['relay'] = dhcprelay
#            doUpdate = True
#
#        if doUpdate:
#            self.logger.info('Config has features that need to be updated...')
#            self.config(data = data, args = args, update=True)
    def config(self, data, args, update=True):
        '''
        Configure or Update a DLR.  Note that the API called is the same
        for ESG, but the contents are different.  So this method
        will not work for ESG creation.

        if update: update config if edge already exists, else do nothing
        '''

        yml = data['yaml']['edge'][0]

        self.edge = self.find_by_name(yml['name'], results=None, refresh=True)
        if not update and self.edge:
            self.logger.error("DLR with name of %s exists, not updating"%yml['name'])
            return None
        elif update and not self.edge:
            self.logger.error("Updating, but edge not found")
            return None

        if self.edge:
            restUrl = self.rest_api['update'].url
            objectId = self.edge['objectId']
            restUrl = eval(restUrl)
            restMethod = self.rest_api['update'].method
            if not self.get_interface_list():
                print("no interfaces found")
                return
        elif checkIsUniversal(data['yaml']):
            restUrl = self.rest_api['cfgUniversal'].url
            restMethod = self.rest_api['cfgUniversal'].method
        else:
            restUrl = self.rest_api['cfg'].url
            restMethod = self.rest_api['cfg'].method

        #si, inv = connect_to_vcenter(args)
        si, inv = self.mgr.vcSi, self.mgr.vcInv

        if 'mgmtInterface' in yml:
            mgmt = yml['mgmtInterface']
            if 'HINT_portgroup' in mgmt:
                self.logger.info('mapping HINT_portgroup %s' % mgmt['HINT_portgroup'])
                args.vcenter, args.vuser, args.vpasswd = self.mgr.vcIp, self.mgr.vcUser, self.mgr.vcPass
                pg = nsxv.find_portgroup_or_logical_switch_by_name(mgr = self.mgr,
                        data = data, args = args,
                        name = mgmt['HINT_portgroup'],
                        tz = mgmt['HINT_transportzone'] \
                                if 'HINT_transportzone' in mgmt
                        else None)
                if pg:
                    mgmt['connectedToId'] = pg
                else:
                    raise ValueError('Cannot find the portgroup or LS "%s" for '
                            'mgmt interface' % mgmt['HINT_portgroup'])

        if 'HINT_datacenter' in yml:
            self.logger.info('mapping HINT_datacenter %s' % yml['HINT_datacenter'])
            dc = vs.getObjectFromVcenterInventory(
                    inv = inv,
                    vimtype = [vim.Datacenter],
                    name = yml['HINT_datacenter'])
            if not dc:
                raise ValueError('Cannot find id for datacenter: ' +
                        yml['HINT_datacenter'])
            else:
                yml['datacenterMoid'] = dc._moId
                yml.pop('HINT_datacenter', None)

        if 'appliance' in yml['appliances']:
            appliance = yml['appliances']['appliance']

            if 'HINT_clusterName' in appliance:
                self.logger.info('mapping HINT_clusterName %s' % appliance['HINT_clusterName'])
                cluster = vs.getObjectFromVcenterInventory(
                        inv = inv ,
                        vimtype = [vim.ClusterComputeResource],
                        name = appliance['HINT_clusterName'])

                if not cluster:
                    raise ValueError('Cannot find cluster id for cluster name: ' +
                            appliance['HINT_clusterName'])
                else:
                    self.logger.info('mapped  HINT_clusterName %s: %s' %
                        (appliance['HINT_clusterName'], cluster._moId))
                    appliance['resourcePoolId'] = cluster._moId
                    appliance.pop('HINT_clusterName', None)



            if 'HINT_datastoreName' in appliance:
                self.logger.info('mapping HINT_datastoreName %s' % appliance['HINT_datastoreName'])
                datastore = vs.getObjectFromVcenterInventory(
                        inv = inv,
                        vimtype = [vim.Datastore],
                        name = appliance['HINT_datastoreName'])
                if not datastore:
                    raise ValueError('Cannot find datastore id for: ' +
                            appliance['HINT_datastoreName'])
                else:
                    self.logger.info('mapped  HINT_datastoreName %s: %s' %
                        (appliance['HINT_datastoreName'],  datastore._moId))
                    appliance['datastoreId'] = datastore._moId
                    appliance.pop('HINT_datastoreName', None)

            if 'HINT_hostname' in appliance:
                self.logger.info('mapping HINT_hostname %s' % appliance['HINT_hostname'])
                host = vs.getObjectFromVcenterInventory(
                        inv = inv,
                        vimtype = [vim.HostSystem],
                        name = appliance['HINT_hostname'])
                if not host:
                    raise ValueError('Cannot find host id for: '
                            + appliance['HINT_hostname'])
                else:
                    self.logger.info('mapped  HINT_hostname %s: %s' %
                        (appliance['HINT_hostname'], host._moId))
                    appliance['hostId'] = host._moId
                    appliance.pop('HINT_hostname', None)

            if 'HINT_vmFolderName' in appliance:
                self.logger.info('mapping HINT_vmFolderName %s' % appliance['HINT_vmFolderName'])
                folder = vs.getObjectFromVcenterInventory(
                        inv = inv,
                        vimtype = [vim.Folder],
                        name = appliance['HINT_vmFolderName'])
                if not folder:
                    raise ValueError('Cannot find folder: ' +
                            appliance['HINT_vmFolderName'])
                else:
                    self.logger.info('mapped  HINT_vmFolderName %s: %s' %
                        (appliance['HINT_vmFolderName'], folder._moId))
                    appliance['vmFolderId'] = folder._moId
                    appliance.pop('HINT_vmFolderName', None)

        if 'interfaces' in yml:
            if update:
                self.get_interface_list(reuse = False)
            else:
                ls=Logical_switch(mgr=self.mgr, get=True)

            for i in yml['interfaces']:
                inter = i['interface']
                if update:
                    if not 'HINT_portgroup' in inter and not 'index' in inter:
                        self.logger.error("For DLR update, atleast HINT_portgroup or index must be provided")
                        raise ValueError("Missing portgroup or index for DLR interface update")
                    if 'HINT_portgroup' in inter:
                        self.logger.info('mapping HINT_portgroup %s' % inter['HINT_portgroup'])
                        nic = self.find_interface_by_name(
                                name=inter['HINT_portgroup'],
                                reuse = True)
                        if nic:
                            self.logger.info('mapped  HINT_portgroup %s: %s' %
                                (inter['HINT_portgroup'], nic['connectedToId']))
                            inter['connectedToId'] = nic['connectedToId']
                            inter['index'] = nic['index']
                            continue
                        else:
                            raise ValueError('Cannot find interface to update: '
                                    + inter['HINT_portgroup'])
                else:
                    if 'HINT_portgroup' in inter:
                        self.logger.info('mapping HINT_portgroup %s' % inter['HINT_portgroup'])
                        pg = ls.find_switch_by_name(name=inter['HINT_portgroup'],
                                reuse = True)
                        if pg:
                            self.logger.info('mapped  HINT_portgroup %s: %s' %
                                (inter['HINT_portgroup'], pg['objectId']))
                            inter['connectedToId'] = pg['objectId']
                            continue
                        if not pg:
                            raise ValueError('Cannot find portgroup %s'%inter['HINT_portgroup'])

        ospf = None
        dhcprelay = None
        routing = None

        # Note that if interfaces have changed, then this lookup will not work
        if 'features' in yml:

            # Check that we are not creating...this
            # part needs to be done through update
            if 'routing' in yml['features']:
                # =====Global routing block=========
                if 'routingGlobalConfig' in yml['features']['routing'] \
                        and not update:
                    routing = yml['features']['routing'].pop('routingGlobalConfig')

                #  ========OSPF Block=============


                if 'ospf' in yml['features']['routing'] and not update:
                    ospf = yml['features']['routing'].pop('ospf')
                elif 'ospf' in yml['features']['routing'] and update:
                    if 'ospfInterfaces' in yml['features']['routing']['ospf']:
                        for iface in listify(yml['features']['routing']\
                                ['ospf']['ospfInterfaces']):
                            if not 'HINT_vnic' in iface['ospfInterface']:
                                continue
                            nic = self.find_interface_by_name(
                                    name=iface['ospfInterface']['HINT_vnic'],
                                    reuse = False)
                            if not nic:
                                raise ValueError("DLR %s does not have nic %s"\
                                        %(yml['name'],\
                                        iface['ospfInterface']['HINT_vnic']))
                            iface['ospfInterface']['vnic'] = nic['index']
                #  ========end OSPF Block=============

            if 'dhcp' in yml['features']:
                # taking this out for now, it doesn't work PR 1452523
                #yml['features']['dhcp'].pop('relay')
                if 'relay' in yml['features']['dhcp'] and not update:
                    dhcprelay = yml['features']['dhcp'].pop('relay')
                elif 'relay' in yml['features']['dhcp'] and update:
                    if 'relayAgents' in yml['features']['dhcp']['relay']:
                        for agent in yml['features']['dhcp']\
                                ['relay']['relayAgents']:
                            agentObj = agent['relayAgent']
                            if 'HINT_nic' in agentObj:
                                iface = self.find_interface_by_name(
                                    agentObj['HINT_nic'])
                                if not iface:
                                    raise ValueError(
                                            "Can't find interface by name: %s"
                                            %agentObj['HINT_nic'])
                                else:
                                    agentObj['vnicIndex'] = iface['index']
                                    agentObj['giAddress'] = self.get_interface_ip(iface)

        datacopy = copy.deepcopy(data['yaml'])

        bug1753727 = False
        if update and bug1753727:
            orgDlrName = datacopy['edge'][0]['name']
            del datacopy['edge'][0]['name']

        self.logger.info('Recreating XML for API post with new values from VC')
        newdata, begin,end  = yaml_to_xml(yml = datacopy, top = True)
        #pprint_xml(newdata[0]['xml'])
        self.logger.info('Posting DLR update to NSX Manager')

        self.logger.debug('%s: REST CALL %s %s' % (type(self), restMethod, restUrl))
        self.logger.debug('%s: REST BODY xml=%s' % (type(self), pformat_xmlInYaml(newdata[0]['xml'])))

        r = getattr(self.mgr, restMethod)(restUrl, data=newdata[0]['xml'])
        if r.status_code >= 400:
            self.mgr.responseError(r)
            r.raise_for_status()
        self.edgeJobStatus(r)

        if update and bug1753727:
            self.logger.warning('Posting SECOND DLR update to NSX Manager with DLR name this time (Bug 1753727)')
            datacopy['edge'][0]['name'] = orgDlrName
            newdata, begin,end  = yaml_to_xml(yml = datacopy, top = True)
            r = self.doRestApi('update', data=newdata[0]['xml'], objectId=objectId)
            self.edgeJobStatus(r)

        doUpdate = False
        if routing:
            yml['features']['routing']['routingGlobalConfig'] = routing
            doUpdate = True
        if ospf:
            yml['features']['routing']['ospf'] = ospf
            doUpdate = True
        if dhcprelay:
            yml['features']['dhcp']['relay'] = dhcprelay
            doUpdate = True

        if doUpdate:
            self.logger.info('Config has features that need to be updated...')
            self.config(data = data, args = args, update=True)


class Ippool(Network_element):
    yamlObjNamePath = ['yaml', 'ipamAddressPool', 0, 'name']
    rest_api = {
        'get' : Api('get', '/api/2.0/services/ipam/pools/scope/globalroot-0', ''),
        'del' : Api('delete', '"/api/2.0/services/ipam/pools/%s"%objectId', ''),
        'cfg' : Api('post', '/api/2.0/services/ipam/pools/scope/globalroot-0', ''),
    }
    rKeys = ['ipamAddressPools', 'ipamAddressPool']
    jqTblSpec = JqTblSpec('''def listify:if type=="array" then .[] else select(.) end; {
        "name":         .name,
        "objectId":     .objectId,
        "ipRanges":     [.ipRanges.ipRangeDto| listify|[.startAddress,.endAddress]|join("-")]| join(",\n")
    }''', '')


class Ipset(Network_element):
    yamlObjNamePath = ['yaml', 'ipset', 0, 'name']
    rest_api = {
        'cfg':    Api('post',    '/api/2.0/services/ipset/globalroot-0', ''),
        'get':    Api('get',     '/api/2.0/services/ipset/scope/globalroot-0', ''),
        'getone': Api('get',    '"/api/2.0/services/ipset/%s"%objectId', ''),
        'update': Api('put',    '"/api/2.0/services/ipset/%s"%objectId', ''),
        'del':    Api('delete', '"/api/2.0/services/ipset/%s"%objectId', ''),
    }
    rKeys = ['list', 'ipset']
    #jqTableSpec = JqTableSpec('[.name, .objectId, .value|split(",")|sort|join(",")]',
    #    ['name', 'objectId', 'IPs'])
    jqTblSpec = JqTblSpec('''{
        "name":     .name,
        "objectId": .objectId,
        "IPs":      (.value | if . then split(",")|sort|join("\n") else "" end)
    }''', '')


    def create(self, ipsetName, ipsetValue):
        jDict = {'name':ipsetName, 'inheritanceAllowed':'true'}
        if ipsetValue:
            jDict['value'] = ipsetValue
        jDict = {'ipset':jDict}
        xml = xmltodict.unparse(jDict)
        self.logger.info('Creating IPSET %s' % ipsetName)
        r = self.doRestApi('cfg', data=xml)
        if r.ok:
            self.logger.info('Created  IPSET %s' % ipsetName)

    def toT(self,name):
        ips = self.find()
        for i in ips:
            if name and i['name'] != name:
                continue
            if 'value' in i.keys():
                print("--name \'" +i['name']+"\' --ips "), (' '.join(i['value'].split(',')))
            else:
                print("--name \'" +i['name']+"\'")

            
    def modify(self, ipsetName, ipsetModsSpec):         # Ipset
        '''
            # Ipset.modify(ipsetModsSpec)
            EBNF Syntax:
                ipsetModSpecs ::= ipsetModSpec {";", ipsetModSpec}
                ipsetModSpec  ::= op, ips
                op            ::= '+' | '-' | '~' | '!' | '#'
                ips           ::= ipSpec {",", ipSpec}
                ipSpec        ::= ip | ip, '/', snMaskLength | ip, '-', ip
            Summary:
                <op><ips>
                <op><ips>
            Exampe:
                '+192.168.0.0/24,1.2.1.1; -1.1.1.1,1.1.1.2'
                '#Replacement; =1.2.3.4,4.3.2.1'
                '+192.168.0.0/24, +2.2.2.2-2.2.2.254'
        '''

        ipsetOid = ipsetName.split(':')[1] if ':' in ipsetName else self.n2oid(ipsetName)
        r = self.doRestApi('getone', objectId=ipsetOid)
        od = xmltodict.parse(r.text)

        ipsetModSpecs = ipsetModsSpec.split(';')
        for ipsetModSpec in [s.strip() for s in ipsetModSpecs]:
            op, value = ipsetModSpec[0], ipsetModSpec[1:]
            if op=='=':
                od['ipset']['value'] = value
            elif op=='+':
                ipsOrg = set(od['ipset']['value'].split(','))
                ipsNew = set(value.split(','))
                od['ipset']['value'] = ','.join(list(ipsOrg|ipsNew))
            elif op in ['-', '!', '~']:
                ipsOrg = set(od['ipset']['value'].split(','))
                ipsNew = set(value.split(','))
                od['ipset']['value'] = ','.join(list(ipsOrg-ipsNew))
            elif op == '#':
                pass
            else:
                self.logger.warning('Unknow ipsetModSpec operator: "%s"' % op)
        xml = xmltodict.unparse(od)

        self.logger.info('Updating IPSET %s' % ipsetName)
        r = self.doRestApi('update', objectId=ipsetOid, data=xml)
        if r.ok:
            self.logger.info('Updated  IPSET %s' % ipsetName)


class Macset(Network_element):
    rest_api = {
        'cfg':    Api('post',   '/api/2.0/services/macset/globalroot-0', ''),
        'get':    Api('get',    '/api/2.0/services/macset/scope/globalroot-0', ''),
        'getone': Api('get',    '"/api/2.0/services/macset/%s"%objectId', ''),
        'del':    Api('delete', '"/api/2.0/services/macset/%s"%objectId', ''),
    }
    rKeys = ['list', 'macset']
    jqTblSpec = JqTableSpec('[.name, .objectId, .value | split(",") | sort | join(",") ]', ['name', 'objectId', 'MACs'])
    jqTblSpec = JqTblSpec('''{
        "name":     .name,
        "objectId": .objectId,
        "MACs":     (.value | if . then split(",")|sort|join("\n") else "" end)
    }''', '')

    def create(self, macsetName, macsetValue):
        xml = xw(
                xw(macsetName, ['name'])+
                xw(macsetValue, ['value'])+
                xw('true', ['inheritanceAllowed']),
            ['macset'])
        self.logger.info('Posting MACSET %s creation request to NSX Manager' % macsetName)
        r = self.doRestApi('cfg', data=xml)
        if r.ok:
            self.logger.info('MACSET %s created' % macsetName)


class DirectoryGroup(Network_element):
    #value: directory_group-5
    rKeys = ['aiDirectoryGroups', 'aiDirectoryGroup']
    jqTblSpec = JqTblSpec('''{
        "name":     .name,
        "id":       .id,
        "domain":   .domain,
        "sid":      .sid,
    }''', '')
    jqTblSpec = JqTableSpec('[.name, .id, .domain, .sid]', [])


    rest_api = {
        'get' :    Api('get', '/api/3.0/ai/directorygroup', ''),
        'getone' : Api('get', '"/api/3.0/ai/directorygroup/%s"%objectId', ''),
    }


class Transport_zone(Network_element):
    rest_api = {
        'get': Api('get', '/api/2.0/vdn/scopes', ''),
        'cfg': Api('post', '/api/2.0/vdn/scopes', ''),
        'cfgUniversal': Api('post', '/api/2.0/vdn/scopes?isUniversal=true', ''),
        'del': Api('delete', '"/api/2.0/vdn/scopes/%s"%objectId', ''),
        'repair': Api('post', '"/api/2.0/vdn/scopes/%s"%objectId', ''),
    }
    rKeys = ['vdnScopes', 'vdnScope']
    jqTblSpec = JqTableSpec(
        '[.name, .objectId, .controlPlaneMode, .virtualWireCount, '
            '[[.clusters.cluster|if type=="array" then .[] else select(.) end|.cluster.name]|join(",")]]',
        ['name', 'objectId', 'controlPlaneMode', 'lsCnt', 'clusters']
    )
    jqTblSpec = JqTblSpec('''{
        "name":             .name,
        "objectId":         .objectId,
        "controlPlaneMode": .controlPlaneMode,
        "virtualWireCount": .virtualWireCount,
        "clusters":         ([.clusters.cluster|if type=="array" then .[] else select(.) end | .cluster.name] | join(","))
    }''', '')

    def repair(self, tz):
        pass

    def config(self, data, **kwargs):
        ''' Configure TZ/UTZ '''
        tzName = data['yaml']['vdnScope'][0]['name']
        #vc = self.mgr.vc

        obj = self.find_by_name(tzName, results=None)
        if obj:
            self.logger.error('Transport Zone %s already exist' % tzName)
            return(97)

        vdnScope = data['yaml']['vdnScope'][0]
        self.logger.info('Creating Tranxport Zone %s' % tzName)
        swapXmlTag(self, vdnScope)

        datacopy = copy.deepcopy(data['yaml'])
        self.logger.info('Recreating XML for API post with new values from VC')
        newdata, begin,end  = yaml_to_xml(yml = datacopy, top = True)
        #print(json.dumps(newdata[0]['yaml'], indent=4))
        #print(newdata[0]['xml'])
        self.logger.info('Posting TZ create to NSX Manager')

        restApiKey = 'cfgUniversal' if checkIsUniversal(data['yaml']) else 'cfg'
        restUrl = self.rest_api[restApiKey].url
        restMethod = self.rest_api[restApiKey].method

        self.logger.debug('%s: REST CALL %s %s' % (type(self), restMethod, restUrl))
        self.logger.debug('%s: REST BODY xml=%s' % (type(self), newdata[0]['xml']))
        r = getattr(self.mgr, restMethod)(restUrl, data=newdata[0]['xml'])

        if r.status_code >= 400:
            self.mgr.responseError(r)
        vdnscopy = r.text
        return vdnscopy


    def show_by_name_brief(self, name, idBy):
        obj = self.find_by_name(name, results=None)
        if not obj:
            self.logger.error("can't find object: %s" %name)
            return
        attrs = self.get_brief(obj)
        pprint(attrs)

class Segment(Network_element):
    ''' Segement class is for managing VNI and Universal VNI Pools '''
    yamlObjNamePath = ['yaml', 'segmentRange', 0, 'name']
    rest_api = {
        'get': Api('get', '/api/2.0/vdn/config/segments', ''),
        'del': Api('delete', '"/api/2.0/vdn/config/segments/%s"%objectId', ''),
        'cfg': Api('post', '/api/2.0/vdn/config/segments', ''),
        'cfgUniversal': Api('post', '/api/2.0/vdn/config/segments?isUniversal=true', ''),
    }
    rKeys = ['segmentRanges', 'segmentRange']
    jqTblSpec = JqTableSpec('[.name, .id, .begin, .end, .isUniversal]', [])
    jqTblSpec = JqTblSpec('''{
        "name":         .name,
        "objectId":     .id,
        "begin-end":    (.begin+"-"+.end),
        "isUniversal":  .isUniversal,
    }''', '')

    def create(self, segCreateSpecs):
        '''
            # Segment.create(segCreateSpecs)
            EBNF Syntax:
                segCreateSpecs  ::= segCreateSpec, {";", segCreateSpec}
                segCreateSpec   ::= segName, "|", segSpec
                segSpec         ::= segId, "-", segId
                segId           ::= 1..16777215
            Summary:
                <segName>|<segId>:<segId> [; <segName>|<segId>:<segId>]
            Exampe:
                'segTest000:50000-50001'
                'segTest001:50002-50003; segTest002:50004-50005'
    '''
        for segSpec in segCreateSpecs.split(';'):
            segName, segRange = segSpec.split(':')
            segBegin, segEnd = segRange.split('-')
            segDict = {'segmentRange': {
                'name': segName.strip(),
                'begin': segBegin.strip(),
                'end': segEnd.strip(),
            } }
            xml = xmltodict.unparse(segDict)
            pprint(segDict)
            r = self.doRestApi('cfg', data=xml)
            if r.ok:
                self.logger.info('Created Segement %s' % segName)

class Multicast(Network_element):
    ''' Multicast class is for managing VNI and Universal VNI Pools '''
    yamlObjNamePath = ['yaml', 'multicastRange', 0, 'name']
    rest_api = {
        'get':          Api('get',     '/api/2.0/vdn/config/multicasts', ''),
        'del':          Api('delete', '"/api/2.0/vdn/config/multicasts/%s"%objectId', ''),
        'cfg':          Api('post',    '/api/2.0/vdn/config/multicasts', ''),
        'cfgUniversal': Api('post',    '/api/2.0/vdn/config/multicasts?isUniversal=true', ''),
    }
    rKeys = ['multicastRanges', 'multicastRange']
    #jqTableSpec = JqTableSpec(
    #    '[.name, .id, [[.begin,.end]|join("-")], .isUniversal ]',
    #    ['name', 'id', 'ipRanges', 'isUniversal']
    #)
    jqTblSpec = JqTblSpec('''{
        "name":         .name,
        "id":           .id,
        "ipRanges":     [.begin,.end]|join("-"),
        "isUniversal":  .isUniversal,
    }''', '')


class Dvs(Network_element):
    rest_api = {
        'get' : Api('get', '/api/2.0/vdn/switches', ''),
        'cfg' : Api('post', '/api/2.0/vdn/switches', ''),
        'del' : Api('delete', '"/api/2.0/vdn/switches/%s"%objectId', ''),

    }
    rKeys = ['vdsContexts', 'vdsContext' ]
    #jqTableSpec = JqTableSpec(
    #    '[.switch.name, .switch.objectId, .switch.scope.name, .mtu, .teaming]',
    #    ['name', 'objectId', 'scope', 'mtu', 'teaming']
    #)
    jqTblSpec = JqTblSpec('''{
        "name":    .name,
        "objectId":.objectId,
        "scope":   .scope,
        "mtu":     .mtu,
        "teaming": .teaming,
    }''', '')

    oidParentDepth = 3


class Logical_switch(Network_element):
    rest_api = {
        'cfg':          Api('post',   '"/api/2.0/vdn/scopes/%s/virtualwires"%objectId', ''),
        'cfgUniversal': Api('post',    '/api/2.0/vdn/scopes/universalvdnscope/virtualwires', ''),
        'getTz':        Api('get',    '"/api/2.0/vdn/scopes/%s/virtualwires"%objectId', ''),
        'get':          Api('get',     '/api/2.0/vdn/virtualwires?pagesize=10000', ''),
        'getone':       Api('get',    '"/api/2.0/vdn/virtualwires/%s"%objectId', ''),
        'update':       Api('put',    '"/api/2.0/vdn/virtualwires/%s"%objectId', ''),
        'backing':      Api('post',   '"/api/2.0/vdn/virtualwires/%s/backing?action=%s"%(objectId,action)', ''),
        'del':          Api('delete', '"/api/2.0/vdn/virtualwires/%s"%objectId', ''),
        'feature':      Api('put',    '"/api/2.0/xvs/networks/%s/features"%objectId', ''),

    }
    rKeys = ['virtualWires', 'dataPage', 'virtualWire']
    #jqTblSpec = JqTableSpec(
    #    '[.name, .objectId, .vdnId, '
    #    '(.vdsContextWithBacking | ([if type=="array" then .[] else select(.) end | .switch.name]|join(","))), '
    #    '(.vdsContextWithBacking | ([if type=="array" then .[] else select(.) end | .mtu]|join(","))), '
    #    '.controlPlaneMode, .macLearningEnabled ]',
    #    ['name', 'objectId', 'vdnId', 'dvsName', 'mtu', 'cpMode', 'macLearn']
    #)
    jqTblSpec = JqTblSpec('''def listify:if type=="array" then .[] else select(.) end; {
        "name":.name,
        "objectId": .objectId,
        "vdnId":    .vdnId,
        "swName":   (.vdsContextWithBacking | ([listify | .switch.name]|join(","))),
        "mtu":      (.vdsContextWithBacking | ([listify | .mtu]|join(","))),
        "cpMode":   .controlPlaneMode,
        "macLearn": .macLearningEnabled,
    }''', '')


    yamlObjNamePath = ['yaml', 'virtualWireCreateSpec', 0, 'name']
    switch = None
    switches = None
    oidParentDepth = 3

    def __init__(self, mgr, name=None,get=False,*args,**kwargs):
        super(Logical_switch, self).__init__(mgr, *args, **kwargs)
        if name:
            self.switch = self.find_by_name(name, results=None)
        if get:
            self.switches = self.get_all_switches(reuse = False)

    def get_all_switches(self, tz=None, reuse=False):
        if reuse and self.switches:
            return self.switches

        objectId = ''
        restApiKey = 'get'
        if tz:
            tzd = Transport_zone(self.mgr, logger=self.logger)
            #print('tz=%s'%tz)
            objectId = tzd.find_by_name(tz)
            #print('tzObjectId=%s'%objectId)
            restApiKey = 'getTz'

        r = self.doRestApi(restApiKey, objectId=objectId, headers={'Accept': 'application/json'})
        sw = json.loads(r.text)

        if not 'dataPage' in sw:
            return None
        if not 'data' in sw['dataPage']:
            # the Transport Zone has no logical switches
            return None
        if sw['dataPage']['pagingInfo']['totalCount'] == 0:
            return None
        else:
            self.switches = sw['dataPage']['data']

        return self.switches

    def find_switch_by_name(self, name, tz=None, reuse=False):
        if not reuse or not self.switches:
            self.get_all_switches(tz=tz, reuse=reuse)

        if not self.switches:
            return None

        for s in self.switches:
            if s['name'] == unicode(name):
                return s
        return None

    def find_switch_by_pgname(self, name, tz=None, reuse=False):
        if not reuse:
            self.get_all_switches(tz=tz, reuse=reuse)
        for s in self.switches:
            if s['objectId'] == unicode(name):
                return s
        return None

    def config(self, data, idBy='objectId', checkExist=True):
        lsName = getYamlObjName(data, self.yamlObjNamePath)
        if checkExist and self.find_by_name(name = lsName, results=idBy):
            self.logger.warning('%s with name "%s" already exist' % \
                (self.className, lsName))
            return None

        swapXmlTag(self, data['yaml']['virtualWireCreateSpec'][0],
            [('HINT_transportzone','HINT_TRANSPORTZONE_objectId_HIDDEN')])
        newdata,begin,end = yaml_to_xml(yml=data['yaml'], top = True)
        objectId = newdata[0]['yaml']['virtualWireCreateSpec'][0]['objectId_HIDDEN']

        restApiKey = 'cfgUniversal' if checkIsUniversal(data['yaml']) else 'cfg'
        r = self.doRestApi(restApiKey, data=newdata[0]['xml'], objectId=objectId)
        lsId = r.text
        self.logger.info("Logical switch %s created as %s" % (lsName, lsId))

        self.logger.info("Enabling Learning, Discovery for LS: %s" % lsName)
        xml = xw(
                xw('true', ['enabled', 'ipDiscoveryConfig'])+
                xw('true', ['enabled', 'macLearningConfig']),
            ['networkFeatureConfig'], True)
        r = self.doRestApi('feature', data=xml, objectId=lsId)
        self.logger.info("Enabled  Learning, Discovery for LS: %s" % lsName)

        return (lsName, lsId)

    def backing(self, action, lsNames, PCache='w'):                  # Logical_switch
        ngsOidDict = self.ngs2oids(lsNames, refresh=('r' not in PCache), PCache=PCache)
        for lsId,lsName in sorted(ngsOidDict.items(), key=lambda l:l[1]):
            self.logger.info('%sing LS backing: %s (%s)' % (action,lsName,lsId))
            r = self.doRestApi('backing', objectId=lsId, action=action)
            if not self.mgr.checkForError(r):
                self.logger.info('%sed  LS backing: %s (%s)' % (action.rstrip('e'),lsName,lsId))

    def update(self, lsNames, featureDict, PCache='w'):                  # Logical_switch
        ngsOidDict = self.ngs2oids(lsNames, refresh=('r' not in PCache), PCache=PCache)
        #ngsOidDict = self.mgr.ngs2oids(lsNames, 'Logical_switch', refresh=('r' not in PCache), PCache=PCache)
        for lsId,lsName in sorted(ngsOidDict.items(), key=lambda l:l[1]):
            features = ','.join([k for k in featureDict.keys() if featureDict[k]])
            self.logger.info('updating LS feature %s: %s' % (features,lsName))
            r = self.doRestApi('getone', objectId=lsId)
            lsDict= xmltodict.parse(r.text)
            if featureDict['cpmode']:
                lsDict['virtualWire']['controlPlaneMode'] = '%s_MODE'%featureDict['cpmode'].upper()
                lsXml= xmltodict.unparse(lsDict)
            r = self.doRestApi('update', objectId=lsId, data=lsXml)
            if not self.mgr.checkForError(r):
                self.logger.info('updated  LS feature %s: %s' % (features,lsName))

class Edge_routing(Network_service, Edge):
    s_rest_api = {
        'get' : Api('get', '"/api/4.0/edges/%s/routing/config"%objectId', ''),
        'cfg' : Api('put', '"/api/4.0/edges/%s/routing/config"%objectId', ''),
    }
    sKeys = ['routingGlobalConfig', 'ecmp']
    list_brief_keys = ['enabled']

class Edge_dns(Network_service, Edge):
    '''
    DNS configuration for specified edge.
    Supports:
        cfg: Configure syslog for a specified edge
    '''
    s_rest_api = {
        'cfg' : Api('put', '"/api/4.0/edges/%s/dnsclient"%objectId','')
    }

    def __init__(self, mgr, name = None, *args, **kwargs):
        Edge.__init__(self, mgr, name=name, *args, **kwargs)

    def config(self, data):
        '''
        Configures DNS for the specified edge using the the XML content
        in data
        '''

        objectId = self.edge['objectId']
        restUrl = self.s_rest_api['cfg'].url
        restUrl = eval(restUrl)
        restMethod = self.s_rest_api['cfg'].method
        print(restUrl)
        r = getattr(self.mgr, restMethod)(restUrl, data=data['xml'])

        if r.status_code >= 400:
            self.mgr.responseError(r)



class Edge_syslog(Network_service, Edge):
    '''
    Syslog configuration for specified edge.
    Supports:
        get: Syslog info for specified edge
        del: Delete syslog config for specified edge
        cfg: Configure syslog for a specified edge
    '''
    s_rest_api = {
        'get' : Api('get', '"/api/4.0/edges/%s/syslog/config"%objectId',''),
        'del' : Api('delete', '"/api/4.0/edges/%s/syslog/config"%objectId',''),
        'cfg' : Api('put', '"/api/4.0/edges/%s/syslog/config"%objectId','')
    }

    def __init__(self, mgr, name = None, *args, **kwargs):
        Edge.__init__(self, mgr, name=name, *args, **kwargs)

    def delete(self, edgeName):                         # Edge_syslog
        '''
        Delete syslog configuration for the specified edge
        '''
        restUrl = self.s_rest_api['del'].url
        restMethod = self.s_rest_api['del'].method

        objectId = self.find_by_name(edgeName, results='objectId')
        if not objectId:
            mLogger.info("Can't find edge by name: %s" %edgeName)
            raise ValueError("Can't find edge by name: %s" %edgeName)
        restUrl = eval(restUrl)

        r = getattr(self.mgr, restMethod)(restUrl)
        if not (200 <= r.status_code <= 204):
            print("HTTP return code for delete is not 20x: %d" %r.status_code)
            self.mgr.responseError(r)

        return None

    def config(self, data):
        '''
        Configures syslog for the specified edge using the the XML content
        in data
        '''

        objectId = self.edge['objectId']
        restUrl = self.s_rest_api['cfg'].url
        restUrl = eval(restUrl)
        restMethod = self.s_rest_api['cfg'].method
        r = getattr(self.mgr, restMethod)(restUrl, data=data['xml'])

        if r.status_code >= 400:
            self.mgr.responseError(r)



class Edge_dhcprelay(Network_service, Edge):
    '''
    DHCP Relay config for an NSX Edge.
    Supports:
        get: DHCP info for specified edge
        del: DHCP info for specified edge
        cfg: Edit DHCP for an edge...i.e. configure it

    '''
    s_rest_api = {
        'get' : Api('get', '"/api/4.0/edges/%s/dhcp/config/relay"%objectId',''),
        'del' : Api('delete', '"/api/4.0/edges/%s/dhcp/config/relay"%objectId',''),
        'cfg' : Api('put', '"/api/4.0/edges/%s/dhcp/config/relay"%objectId','')
    }

    def __init__(self, mgr, name = None, *args, **kwargs):
        Edge.__init__(self, mgr, name=name, *args, **kwargs)

    def delete(self, edgeName):                         # Edge_dhcprelay
        '''
        Delete DHCP relay configuration for the specified edge
        '''
        restUrl = self.s_rest_api['del'].url
        restMethod = self.s_rest_api['del'].method

        objectId = self.find_by_name(edgeName, results='objectId')
        if not objectId:
            mLogger.info("Can't find edge by name: %s" %edgeName)
            raise ValueError("Can't find edge by name: %s" %edgeName)
        restUrl = eval(restUrl)

        r = getattr(self.mgr, restMethod)(restUrl)
        if not (200 <= r.status_code <= 204):
            print("HTTP return code for delete is not 20x: %d" %r.status_code)
            self.mgr.responseError(r)

        return None


    def config(self, data):
        '''
        Configures DHCP relay for the specified edge using the the XML content
        in data
        '''

        yml = data['yaml']


        for relay in yml['relay']:
            for agent in relay['relayAgents']:
                agentObj = agent['relayAgent']
                if 'HINT_nic' in agentObj:
                    iface = self.find_interface_by_name(agentObj['HINT_nic'])
                    if not iface:
                        raise ValueError("Can't find interface by name: %s"
                                %agentObj['HINT_nic'])
                    else:
                        agentObj['vnicIndex'] = iface['index']
                        agentObj['giAddress'] = self.get_interface_ip(iface)

        datacopy=copy.deepcopy(data['yaml'])
        newdata, begin, end = yaml_to_xml(yml = datacopy, top = True)



        objectId = self.edge['objectId']
        restUrl = self.s_rest_api['cfg'].url
        restUrl = eval(restUrl)
        restMethod = self.s_rest_api['cfg'].method
        r = getattr(self.mgr, restMethod)(restUrl, data=newdata[0]['xml'])

        if r.status_code >= 400:
            self.mgr.responseError(r)





class Edge_ecmp(Network_service, Edge):
    s_rest_api = {
        'get' : Api('get', '"/api/4.0/edges/%s/routing/config/global"%objectId', ''),
        'cfg' : Api('put', '"/api/4.0/edges/%s/routing/config/global"%objectId', ''),
    }
    sKeys = ['routingGlobalConfig', 'ecmp']
    list_brief_keys = ['enabled']


class Edge_ospf(Network_service, Edge):
    s_rest_api = {
        'get' : Api('get', '"/api/4.0/edges/%s/routing/config/ospf"%objectId', ''),
        'cfg' : Api('put', '"/api/4.0/edges/%s/routing/config/ospf"%objectId', ''),
    }
    sKeys = ['ospf','enabled']
    list_brief_keys = ['enabled']


class Edge_bgp(Network_service, Edge):
    s_rest_api = {
        'get' : Api('get', '"/api/4.0/edges/%s/routing/config/bgp"%objectId', ''),
        'cfg' : Api('put', '"/api/4.0/edges/%s/routing/config/bgp"%objectId', ''),
    }
    sKeys = ['bgp','enabled']


class Edge_fw(Network_service, Edge):
    s_rest_api = {
        'get' : Api('get', '"/api/4.0/edges/%s/firewall/config"%objectId', ''),
        'cfg' : Api('put', '"/api/4.0/edges/%s/firewall/config"%objectId', ''),
    }
    sKeys = ['firewall','enabled']
    list_brief_keys = ['enabled']


class Edge_lb(Network_service, Edge):
    s_rest_api = {
        'get' : Api('get', '"/api/4.0/edges/%s/loadbalancer/config"%objectId', ''),
        'cfg' : Api('put', '"/api/4.0/edges/%s/loadbalancer/config"%objectId', ''),
        'del' : Api('delete', '"/api/4.0/edges/%s/loadbalancer/config"%objectId', ''),
    }
    sKeys = ['loadBalancer', 'enabled']
    list_brief_keys = [
        ['loadBalancer', 'enabled'],
        ['loadBalancer', 'virtualServer', ('name', 'enabled', 'ipAddress', 'protocol', 'port')],
        ['loadBalancer', 'pool', ('name', 'transparent')],
        ['loadBalancer', 'applicationProfile', ('name', 'sslPassthrough', 'template', 'serverSslEnabled')],
    ]

    def show_by_name_brief(self, name):
        obj = xmltodict.parse(self.enable_service(name, action='get'))
        pprint_od(obj)
        if not obj:
            print("can't find to object: %s" %name)
            return
        print('calling self.get_brief(obj)')
        #pprint_od(obj)
        attrs = self.get_brief(obj)
        pprint(attrs)


class Dlr_interface(Network_element):
    rest_api = {
        'get' : Api('get',      '"/api/4.0/edges/%s/interfaces"%objectId', ''),
        'cfg' : Api('post',     '"/api/4.0/edges/%s/interfaces"%objectId', ''),
        'del' : Api('delete',   '"/api/4.0/edges/%s/interfaces/%s"%(edgeId,ifIndex)',  ''),
        'add' : Api('post',     '"/api/4.0/edges/%s/interfaces?action=patch"%objectId', ''),
        'update' : Api('put',     '"/api/4.0/edges/%s/interfaces/%s"%(objectId,ifIdx)', ''),
    }
    rKeys = ['interfaces', 'interface']
    jqTblSpec = JqTblSpec('''{
        "index":        .index,
        "name":         .name,
        "connectedTo":  .connectedToName,
        "isConnected":  .isConnected,
        "type":         .type,
        "mtu":          .mtu,
        "subnet":       (.addressGroups.addressGroup|.primaryAddress+"/"+.subnetPrefixLength),
    }''', '')

    def list(self, brief=False, edgeName=''):                   # Dlr_interface
        edgeObjId = Edge(self.mgr).find_by_name(name=edgeName)
        od = self.find(objectId=edgeObjId, refresh=True)

        if brief:
            print('DLR %s (%s):' % (edgeName, edgeObjId))
            self.fmtJqTable(od)
        else:
            pprint_od(od)

    def add(self, dlrName, lsName, ifIp, snPfixLen,             # Dlr_interface
            mtu=1500, isConnected=True, ifName='', ifType='internal',
            PCache=''):
        edgeObjId = Edge(self.mgr).find_by_name(name=dlrName)
        lsId = Logical_switch(self.mgr).find_by_name(lsName, PCache=PCache)

        ifName = ifName or lsName
        self.logger.info('Adding interface "%s" to DLR "%s" (%s %s/%s)' %
            (ifName, dlrName, lsName, ifIp, snPfixLen))

        ifDict = {
                'interfaces': {
                    'interface': {
                    'name': ifName,
                    'addressGroups': {
                        'addressGroup': {
                            'primaryAddress': ifIp,
                            'subnetPrefixLength': snPfixLen,
                        },
                    },
                    'mtu': mtu,
                    'type': ifType,
                    'isConnected': {True:'true', False:'false'}[isConnected],
                    'connectedToId': lsId
                }
            }
        }
        xml = xmltodict.unparse(ifDict)
        r = self.doRestApi('add', data=xml, objectId=edgeObjId)
        if not self.mgr.checkForError(r):
            self.logger.info('Added  interface "%s" to DLR "%s" (%s %s/%s)' %
                (ifName, dlrName, lsName, ifIp, snPfixLen))

    def connect(self, dlrName, ifNameGlob, action='connect'):
        edgeObjId = Edge(self.mgr).find_by_name(name=dlrName)
        r = self.doRestApi('get', objectId=edgeObjId)
        ifsDict = byteify(xmltodict.parse(r.text))['interfaces']['interface']
        ifsDict = [ifDict for ifDict in ifsDict if isGlobMatched(ifNameGlob, ifDict['name'])]
        for ifDict in ifsDict:
            ifName=ifDict['name']
            self.logger.info('%sing interface "%s" on DLR "%s"' % (action, ifName, dlrName))
            ifDict['isConnected'] = {'connect':'true', 'disconnect':'false'}[action]
            xml = xmltodict.unparse({'interface':ifDict})
            r = self.doRestApi('update', data=xml, objectId=edgeObjId, ifIdx=ifDict['index'])
            if not self.mgr.checkForError(r):
                self.logger.info('%sed  interface "%s" on DLR "%s"' % (action, ifName, dlrName))


class Esg_interface(Network_element):
    rest_api = {
        'get' : Api('get', '"/api/4.0/edges/%s/vnics"%objectId', ''),      # for ESG
    }
    rKeys = ['vnics', 'vnic']
    jqTblSpec = JqTblSpec('''{
        "label":        .label,
        "name":         .name,
        "connectedTo":  .connectedToName,
        "isConnected":  .isConnected,
        "type":         .type,
        "mtu":          .mtu,
        "subnet":       (.addressGroups.addressGroup|.primaryAddress+"/"+.subnetPrefixLength),
    }''', '')



    def list(self, brief=False, edgeName=''):                           # Esg_interface
        edged = Edge(self.mgr, logger=self.logger)
        edgeObjId = edged.find_by_name(name=edgeName)
        od = self.find(objectId=edgeObjId, refresh=True)

        if brief:
            print('ESG %s (%s):' % (edgeName, edgeObjId))
            self.fmtJqTable(od)
        else:
            pprint_od(od)


class Application_group(Network_element):
    rest_api = {
        'get':    Api('get',    '/api/2.0/services/applicationgroup/scope/globalroot-0', ''),
        'getone': Api('get',   '"/api/2.0/services/applicationgroup/%s"%objectId', ''),
        'cfg':    Api('post',   '/api/2.0/services/applicationgroup/globalroot-0', ''),
        'del':    Api('delete','"/api/2.0/services/applicationgroup/%s"%objectId', ''),
        'addMbr': Api('put',   '"/api/2.0/services/applicationgroup/%s/members/%s"%(objectId,mObjectId)', ''),
        'delMbr': Api('delete','"/api/2.0/services/applicationgroup/%s/members/%s"%(objectId,mObjectId)', ''),
        'modify': Api('put',   '"/api/2.0/services/applicationgroup/%s"%objectId', ''),
    }
    rKeys = ['list', 'applicationGroup']
    jqTblSpec = JqTblSpec('''{
        "name":     .name,
        "objectId": .objectId,
        "members":  [.member | if type=="array" then .[] else select(.) end | .name] | join("\n")
    }''', '')


    def agOp(self, op, agsSpec):
        appd = Application(self.mgr)
        msgDict = {
            'delMbr': {'verb':'Removing', 'conj':'from'},
            'addMbr': {'verb':'Adding', 'conj':'to'} }
        for agSpec in agsSpec.split(';'):
            agSpec = agSpec.strip()
            if not agSpec: continue
            agName, appMbrsSpec, agMbrsSpec = agSpec.split(':')
            if op == 'create':
                xml = xw('%s'%agName, ['name', 'applicationGroup'])
                self.logger.info('Creating Application %s' % agName)
                r = self.doRestApi('cfg', data=xml)
                agObjectId = r.text
                if r.ok:
                    self.logger.info('Application group %s created: %s' % (agName, agObjectId))
                else:
                    self.logger.error('FAILED to create Application group %s' % (agName))
                    return
                agMbrsSpec = ','.join(['+%s'%n for n in agMbrsSpec.split(',') if n.strip()])
                appMbrsSpec = ','.join(['+%s'%n for n in appMbrsSpec.split(',') if n.strip()])
            elif op == 'modify':
                agObjectId = self.n2oid(agName)
            if op in ['modify', 'create']:
                for agMbrModSpec in agMbrsSpec.split(','):
                    agMbrModSpec = agMbrModSpec.strip()
                    if not agMbrModSpec: continue
                    if agMbrModSpec[0] not in ['+', '-']:
                        self.logger.error('Invalid AG modification spec: "%s", '
                            'must start with "+" or "-"' % agMbrModSpec)
                        continue
                    modMbrOp = {'+':'addMbr', '-':'delMbr'}[agMbrModSpec[0]]
                    agMbrName = agMbrModSpec[1:]
                    agMbrOid = self.n2oid(agMbrName)
                    if not agMbrOid:
                        self.logger.warning('AG %s not found' % agMbrName)
                        continue
                    r = self.doRestApi(modMbrOp, objectId=agObjectId, mObjectId=agMbrOid)
                    msgDict[modMbrOp].update({'agMbrName':agMbrName, 'agName':agName})
                    self.logger.info('{verb} AppGroup "{agMbrName}" {conj} '
                        'AppGroup {agName}'.format(**msgDict[modMbrOp]))
                for appMbrModSpec in appMbrsSpec.split(','):
                    appMbrModSpec = appMbrModSpec.strip()
                    if not appMbrModSpec: continue
                    if appMbrModSpec[0] not in ['+', '-']:
                        self.logger.error('Invalid APP modification spec: "%s", '
                            'must start with "+" or "-"' % appMbrModSpec)
                        continue
                    modMbrOp = {'+':'addMbr', '-':'delMbr'}[appMbrModSpec[0]]
                    appMbrName = appMbrModSpec[1:]
                    appMbrOid = appd.n2oid(appMbrName)
                    if not appMbrOid:
                        self.logger.warning('APP %s not found' % appMbrName)
                        continue
                    r = self.doRestApi(modMbrOp, objectId=agObjectId, mObjectId=appMbrOid)
                    msgDict[modMbrOp].update({'appMbrName':appMbrName, 'agName':agName})
                    self.logger.info('{verb} Application "{appMbrName}" {conj} '
                        'AppGroup {agName}'.format(**msgDict[modMbrOp]))

    def agOp0(self, op, agName, appSpec, agSpec, appAgSpec):
        mOp = op
        if op == 'create':
            xml = xw('%s'%agName, ['name', 'applicationGroup'])
            self.logger.info('Creating Application service %s creation request to NSX Manager' % agName)
            r = self.doRestApi('cfg', data=xml)
            agObjectId = r.text
            if r.ok:
                self.logger.info('Application group service %s created: %s' % (agName, agObjectId))
            else:
                return
            mOp = 'addMbr'
        else:
            agObjectId = self.find_by_name(agName)

        checkList = {n.strip():False for n in appAgSpec.split(';') if n}

        msgDict = {'verb':'Removing', 'conj':'from'} if mOp=='delMbr' else {'verb':'Adding', 'conj':'to'}
        agd = Application_group(self.mgr)
        aNames = ';'.join([agSpec, appAgSpec])
        for aName in aNames.split(';'):
            aName = aName.strip()
            if not aName: continue
            aObjectId = agd.find_by_name(aName)
            if aObjectId:
                msgDict.update({'aName':aName, 'agName':agName})
                self.logger.info('{verb} Application "{aName}" {conj} AppGroup {agName}'.format(**msgDict))
                r = self.doRestApi(mOp, objectId=agObjectId, mObjectId=aObjectId)
                if aName in checkList:
                    checkList[aName] = True
            elif aName in agSpec:
                self.logger.warning('Application group "%s" not found' % aName)

        appd = Application(self.mgr)
        aNames = ';'.join([appSpec, appAgSpec])
        for aName in aNames.split(';'):
            aName = aName.strip()
            if not aName: continue
            aObjectId = appd.find_by_name(aName)
            if aObjectId:
                msgDict.update({'aName':aName, 'agName':agName})
                self.logger.info('{verb} AppGroup "{aName}" {conj} AppGroup {agName}'.format(**msgDict))
                r = self.doRestApi(mOp, objectId=agObjectId, mObjectId=aObjectId)
                if aName in checkList:
                    checkList[aName] = True
            elif aName in appSpec:
                self.logger.warning('Application service "%s" not found' % aName)

        for k in checkList:
            if not checkList[k]:
                self.logger.warning('"%s" is neither a valid Application Name nor Application Group Name' % k)

    def showBrief(self, agNamesGlob):               # class Application_group()
        ''' agNamesGlob: single agNameGlob or list of agNameGlob '''
        agNamesGlob = listify(agNamesGlob)
        ptbl = PrettyTable(['name/objeciId', 'member'])
        for agNameGlob in agNamesGlob:
            ags = self.find_by_name(agNameGlob, results=None, matchMethod='glob')
            ags = sorted(ags, key=lambda ag: ag['name'])
            for ag in ags:
                mptbl = ''
                if 'member' in ag:
                    mptbl = PrettyTable(['name', 'objectId'])
                    mptbl.align = 'l'
                    members = listify(ag['member'])
                    members = sorted(members, key=lambda m:m['name'])
                    for m in members:
                        mptbl.add_row([m['name'], m['objectId']])
                ptbl.add_row(['\n '.join([ag['name'], ag['objectId']]), mptbl])
                ptbl.align = 'l'
        print(ptbl)

    def list_brief(self, nameGlob='*', **kwargs):       # Application_group()
        self.showBrief(nameGlob)


    def toTPmAll(self, prefix=None, display=True):
        apps = self.find()
        for a in apps:
            self.toTPm(sgId=a['objectId'], prefix=prefix, display=display)
    def toTMpAll(self, prefix=None, display=True):
        apps = self.find()
        for a in apps:
            self.toTMp(sgId=a['objectId'], prefix=prefix, display=display)
    def toTPm(self,sgId=None,name=None,prefix=None, display=True):
        if sgId:
            app = self.getByObjectId(objectId=sgId)
            if app:
                app=app['applicationGroup']
        elif name:
            app = self.find_by_name(name=name, results=None)
        else:
            print("Must provide either objectId or name to toTPm()")
            return None

        if not app:
            print("Service group not found")
            return None

            
        if app['objectTypeName'] != 'ApplicationGroup':
            print("***ERROR: Expecting type of 'ApplicationGroup' but got %s with id %s"
                  %(app['objectTypeName'], app['objectId']))
            return None

        if prefix:
            newName = prefix+app['name']
        else:
            newName=app['name']

        if not 'member' in app:
            print("%s::" %newName)
            return

        appmembers=[]
        a = Application(mgr=self.mgr)
        for m in listify(app['member']):
            if m['objectTypeName'] == 'ApplicationGroup':
                print('****subgroup: %s' %m['name'])
                ag = self.toTPm(sgId=m['objectId'])
                appmembers+=ag['members']
            elif m['objectTypeName'] == 'Application':
                output = a.toT(sgId=m['objectId'], display=False)
                if not output:
                    print("Error: unhandled member %s conversion in appgroup %s"
                          %(m['name'], app['name']))
                    return None
                appmembers.append(output)
            else:
                print("ERROR: Unhandled member type %s in appgroup %s"
                      %(m['objectTypeName'],app['name']))
                return None

        svc={}
        svc['name'] = newName
        svc['members'] = appmembers
        if display:
            memstr = ''
            for am in appmembers:
                memstr = memstr+am+';'
            print("--spec '%s' %s" %(memstr, newName))
        return svc

    def toTMp(self,sgId=None,name=None,prefix=None,display=True):
        if sgId:
            app = self.getByObjectId(objectId=sgId)
            if app:
                app = app['applicationGroup']
        elif name:
            app = self.find_by_name(name=name, results=None)
        else:
            print("Must provide either objectId or name to toTPm()")
            return None

        if not app:
            print("Service group not found")
            return None

                  
        if app['objectTypeName'] != 'ApplicationGroup':
            print("***ERROR: Expecting type of 'ApplicationGroup' but got %s with id %s"
                  %(app['objectTypeName'], app['objectId']))
            return None

        if prefix:
            newName = prefix+app['name']
        else:
            newName=app['name']

        if not 'member' in app:
            print("%s::" %newName)
            return

        appmembers={}
        appmembers['groups'] = []
        appmembers['apps'] = []
        a = Application(mgr=self.mgr)
        for m in listify(app['member']):
            if prefix:
                gname=prefix+m['name']
            else:
                gname=m['name']=m['name']
            if m['objectTypeName'] == 'ApplicationGroup':
                #appmembers['groups'].append(gname)
                apg = self.toTMp(sgId=m['objectId'], prefix=prefix,display=False)
                #pprint_od(apg)
                for a in listify(apg['members']):
                    if len(a['groups']) > 0:
                        print("ERROR: groups more than 0 %s" %gname)
                    appmembers['apps']+=a['apps']
            elif m['objectTypeName'] == 'Application':
                appmembers['apps'].append(gname)
            else:
                print("ERROR: Unhandled member type %s in appgroup %s"
                      %(m['objectTypeName'],app['name']))
                return None

        svc={}
        svc['name'] = newName
        if 'description' in  app:
            desc = app['description']
            svc['description'] = app['description']
        else:
            desc = ''

        svc['members'] = appmembers
        if display:

            appstr=''
            grpstr=''
            for am in appmembers['groups']:
                if grpstr=='':
                    grpstr=am
                else:
                    grpstr=grpstr+','+am
            for am in appmembers['apps']:
                if appstr=='':
                    appstr=am
                else:
                    appstr=appstr+','+am
            print("%s:%s:%s::%s:" %(newName,desc,appstr,grpstr))
        return svc
            
        
class Application(Network_element):
    rest_api = {
        'get' : Api('get',     '/api/2.0/services/application/scope/globalroot-0', ''),
        'cfg' : Api('post',    '/api/2.0/services/application/globalroot-0', ''),
        'del' : Api('delete', '"/api/2.0/services/application/%s"%objectId', ''),
        'getone' : Api('get', '"/api/2.0/services/application/%s"%objectId', ''),
    }
    rKeys = ['list', 'application']
    #jqTableSpec = JqTableSpec(
    #    '[.name, .objectId, [[.element.applicationProtocol,.element.value]|join("/")]]',
    #    ['name', 'objectId', 'protocol/ports']
    #)
    jqTblSpec = JqTblSpec('''{
        "name":             .name,
        "objectId":         .objectId,
        "layer/appGuid":    [.layer,.element.appGuidName]|join("/"),
        "protocol/dPort/sPort":   [.element.applicationProtocol,.element.value,.element.sourcePort]|join("/") 
    }''', '')

    oidParentDepth = 2

    def create0(self, appName, appSpec):
        self.create('%s|%s' % (appName, appSpec))

    def create(self, appSpecs):
        '''
            NEW FORMAT:
              Syntax:
                <appName> "|" <layer2or3or4> "|" <protocol> ":" <dstPorts> ":" <srcPorts>
                <appName> "|" <layer7> "|" <appIdName> ":" <protocol> ":" <dstPorts> ":" <srcPorts>

                appTest020 | 2 | l2Protocol
                appTest030 | 3 | l3Protocol[:dPorts[:sPorts]]
                appTest040 | 4 | l4Protocol:dPorts[:sPorts]
                appTest070 | 7 | l7AppIdName[:l3Protocol[:dPorts[:sPorts]]]
              Examples:
                appTest021 | 2 | LLC;
                appTest031 | 3 | udp:53;
                appTest032 | 3 | udp:53:7001,7002;
                appTest033 | 3 | ESP;
                appTest034 | 3 | ICMP:redirect;
                appTest035 | 3 | IPV6ICMP:echo-reply;
                appTest041 | 4 | FTP:21;
                appTest042 | 4 | FTP:21:7001;
                appTest071 | 7 | DNS;
                appTest072 | 7 | DNS:UDP:53;
                appTest073 | 7 | DNS:UDP:53:7001'
            Deplicated FORMAT:
                appTest000 | tcp:80
                appTest001 | udp:8000,8080-8081
                appTest002 | icmp:echo-request
                appTest003 | tcp:53; appTest004| udp:53
                appTestArp | arp
        '''

        for appSpec in appSpecs.split(';'):
            appSpec = appSpec.strip()
            appComps = appSpec.split('|')
            appName = appComps.pop(0).strip()
            if len(appComps)==1:
                appComps.insert(0,'3')
            appLayer,appProtoPort = appComps
            if appLayer in ['2', '3', '4', '7']:
                self.logger.info('Creating layer%s application "%s"' % (appLayer,appName))
                comps = appProtoPort.split(':')
                appGuidName = comps.pop(0).upper() if appLayer == '7' else ''
                proto = comps.pop(0).upper() if comps else ''
                dPorts = comps.pop(0) if comps else ''
                sPorts = comps.pop(0) if comps else ''
                appDict = {
                    'application': {
                        'name': appName,
                        'layer': 'layer%s'%appLayer,
                    }
                }
                appElem = appDict['application']['element'] = {}
                if appGuidName:
                    appElem['appGuidName'] = appGuidName
                if proto:
                    appElem['applicationProtocol'] = proto
                if dPorts:
                    appElem['value'] = dPorts
                if sPorts:
                    appElem['sourcePort'] = sPorts
            else:
                self.logger.error('Layer %s application is not supported!' % appLayer)
            #pprint_json(appDict)
            xml = xmltodict.unparse(appDict)
            r = self.doRestApi('cfg', data=xml)
            if r.ok:
                self.logger.info('Created  layer%s application "%s"' % (appLayer,appName))

    def toTAll(self,prefix=None):
        apps=self.find()
        for a in apps:
            self.toT(sgId=a['objectId'], prefix=prefix)
    def toT(self, sgId=None, name=None, prefix=None, display=True):
        '''
        Convert to NSX-T policy manager input format
        '''

        if sgId:
            app = self.getByObjectId(objectId=sgId)
            if app:
                app=app['application']
        elif name:
            app = self.find_by_name(name=name, results=None)
        else:
            print("Must provide either objectId or name to ToT()")
            return None


        if not app:
            print("Service not found")
            return None

        if app['objectTypeName'] != 'Application':
            print("***ERROR: ServiceType not handled: name: %s objectId: %s"
                  %(app['name'], app['objectId']))
            return None
        else:
            if prefix:
                newName=prefix+app['name']
            else:
                newName=app['name']

            if not 'element' in app:
                output = '%s::'%newName
            else:
                proto = app['element']['applicationProtocol']
                val = app['element']['value']
                output="%s::%s:%s" %(newName,proto,val)
                if proto == 'TCP' or proto=='UDP':
                    if val == 'None':
                        val=''
                    output="%s::%s::%s" %(newName,proto,val)
                elif proto == 'FTP':
                    output="%-s::alg:FTP::21" %newName
                elif proto =='SUN_RPC_TCP':
                    output="%s::alg:SUN_RPC_TCP::111" %newName
                elif proto == 'MS_RPC_TCP':
                    output="%s::alg:MS_RPC_TCP::135" %newName
                elif proto == 'MS_RPC_UDP':
                    output="%s::alg:MS_RPC_UDP::135" %newName
                elif proto == 'ORACLE_TNS':
                    output="%s::alg:ORACLE_TNS::1521" %newName
                elif proto == 'SUN_RPC_UDP':
                    output="%s::alg:SUN_RPC_UDP::111" %newName
                elif proto == 'IGMP':
                    if 'IGMP V2 Membership Report' in app['name']:
                        output="%s::IGMP:V2_MEMBERSHIP_REPORT" %newName
                    elif 'IGMP V3 Membership Report' in app['name']:
                        output="%s::IGMP:V3_MEMBERSHIP_REPORT" %newName
                    elif 'IGMP Leave Group' in app['name']:
                        output="%s::IGMP:LEAVE_GROUP" %newName
                    elif 'IGMP Membership Query' in app['name']:
                        output="%s::IGMP:MEMBERSHIP_QUERY" %newName
                    else:
                        print("ERROR: Unhandled IGMP type: %s" %newName)
                        return None
                elif proto == 'ESP':
                    output="%s::IP:50" %newName
                elif proto == 'IPV6OPTS':
                    output="%s::IP:60" %newName
                elif proto == 'IPV6NONXT':
                    output="%s::IP:59" %newName
                elif proto == 'ICMP':
                    if val == 'destination-unreachable':
                        output="%s::ICMPv4:3" %newName
                    elif val == 'redirect':
                        output="%s::ICMPv4:5" %newName
                    elif val == 'time-exceeded':
                        output="%s::ICMPv4:11" %newName
                    elif val == 'echo-request':
                        output="%s::ICMPv4:8" %newName
                    elif val == 'router-advertisement':
                        output="%s::ICMPv4:9" %newName
                    elif val == 'router-solicitation':
                        output="%s::ICMPv4:10"%newName
                    elif val == 'source-quench':
                        output="%s::ICMPv4:4" %newName
                    elif val == 'echo-reply':
                        output="%s::ICMPv4:0" %newName
                    else:
                        print("ERROR: unhandled ICMPv4 type: %s: %s" %(newName,val))
                        return None
                elif proto == 'IPV6ICMP':
                    if val == 'router-renumbering':
                        output="%s::ICMPv6:138" %newName
                    elif val == 'node-information-query':
                        output="%s::ICMPv6:139" %newName
                    elif val == 'inverse-neighbor-discovery-solicitation':
                        output="%s::ICMPv6:141" %newName
                    elif val == 'version-2-multicast-listener':
                        output="%s::ICMPv6:143" %newName
                    elif val == ':home-agent-address-discovery-reply':
                        output="%s::ICMPv6:145" %newName
                    elif val == 'certification-path-advertisement':
                        output="%s::ICMPv6:149" %newName
                    elif val == 'multicast-router-termination':
                        output="%s::ICMPv6:153" %newName
                    elif val == 'fmipv6':
                        output="%s::ICMPv6:154" %newName
                    elif val == 'ilnpv6-locator-update':
                        output="%s::ICMPv6:156" %newName
                    elif val == 'duplicate-address-request':
                        output="%s::ICMPv6:157" %newName
                    elif val == 'duplicate-address-confirmation':
                        output="%s::ICMPv6:158" %newName
                    elif val == 'mpl-control':
                        output="%s::ICMPv6:159" %newName
                    elif val == 'rpl-control':
                        output="%s::ICMPv6:155" %newName
                    elif val == 'multicast-router-advertisement':
                        output="%s::ICMPv6:151" %newName
                    elif val == 'multicast-router-solicitation':
                        output="%s::ICMPv6:152" %newName
                    elif val == 'certification-path-solicitation':
                        output="%s::ICMPv6:148" %newName
                    elif val == 'mobile-prefix-solicitation':
                        output="%s::ICMPv6:146" %newName
                    elif val == 'node-information-response':
                        output="%s::ICMPv6:140" %newName
                    elif val == 'multicast-listener-done':
                        output="%s::ICMPv6:132" %newName
                    elif val == 'redirect':
                        output="%s::ICMPv6:137" %newName
                    elif val == 'time-exceeded':
                        output="%s::ICMPv6:3" %newName
                    elif val == 'neighbor-advertisement':
                        output="%s::ICMPv6:136" %newName

                    elif val == 'neighbor-solicitation':
                        output="%s::ICMPv6:135" %newName
                    elif val == 'parameter-problem':
                        output="%s::ICMPv6:4" %newName
                    elif val == 'router-advertisement':
                        output="%s::ICMPv6:134" %newName
                    elif val == 'echo-reply':
                        output="%s::ICMPv6:129" %newName
                    elif val == 'packet-too-big':
                        output="%s::ICMPv6:2" %newName
                    elif val == 'router-solicitation':
                        output="%s::ICMPv6:133" %newName
                    elif val == 'multicast-listener-report':
                        output="%s::ICMPv6:131" %newName
                    elif val == 'multicast-listener-query':
                        output="%s::ICMPv6:130" %newName
                    elif val == 'destination-unreachable':
                        output="%s::ICMPv6:1" %newName
                    elif val == 'echo-request':
                        output="%s::ICMPv6:128" %newName
                    elif val == 'home-agent-address-discovery-request':
                        output="%s::ICMPv6:144" %newName
                    elif val == 'inverse-neighbor-discovery-advertisement':
                        output="%s::ICMPv6:142" %newName
                    elif val == 'mobile-prefix-advertisement':
                        output="%s::ICMPv6:147" %newName
                    elif val == 'utilized-by-experimental-mobility-protocols':
                        output="%s::ICMPv6:150" %newName
                    elif val == 'home-agent-address-discovery-reply':
                        output="%s::ICMPv6:145" %newName
                    elif val == '':
                        output="%s::ICMPv6:140" %newName
                    elif val == '':
                        output="%s::ICMPv6:140" %newName
                    else:
                        print("ERROR: Unhandled ICMPv6 type: %s: %s"
                              %(newName,val))
                        return None
                else:
                    print("ERROR Proto: name: %s proto: %s val %s"
                          %(newName,proto,val))
                    return None
            if display:
                print(output)
            return output

                
class Security_tag(Network_element):
    rest_api = {
        'get':      Api('get',     '/api/2.0/services/securitytags/tag', ''),
        'create':   Api('post',    '/api/2.0/services/securitytags/tag', ''),
        'del':      Api('delete', '"/api/2.0/services/securitytags/tag/%s"%objectId', ''),
        'apply':    Api('put',    '"/api/2.0/services/securitytags/tag/%s/vm/%s"%(stObjectId,vmObjectId)', ''),
        'detach':   Api('delete', '"/api/2.0/services/securitytags/tag/%s/vm/%s"%(stObjectId,vmObjectId)', ''),
        'listVMs':  Api('get',    '"/api/2.0/services/securitytags/tag/%s/vm"%objectId', ''),
        'stsByVm':  Api('get',    '"/api/2.0/services/securitytags/vm/%s"%objectId', ''),
        'vmAssign': Api('post', '"/api/2.0/services/securitytags/vm/%s?action=ASSIGN_TAGS"%objectId', ''),
        'vmClear':  Api('post', '"/api/2.0/services/securitytags/vm/%s?action=CLEAR_ALL_TAGS"%objectId', ''),
    }
    rKeys = ['securityTags', 'securityTag']
    jqTblSpec = JqTblSpec('''{
        "name":          .name,
        "objectId":      .objectId,
    }''', '')


    def create(self, stNames):
        for stName in stNames:
            xml = xw(
                    xw('SecurityTag', ['objectTypeName'])+
                    xw('SecurityTag', ['typeName', 'type'])+
                    xw('%s' % stName, ['name'])+
                    xw('%s' % stName, ['description'])+
                    xw('', ['extendedAttributes']),
                ['securityTag'])

            self.logger.info('Creating security tags %s' % stName)
            r = self.doRestApi('create', data=xml)

    def listSTsByVMs(self, vmNames, brief=False, fmt=None, prStdout=True):
        ''' vmNames:
                vmName : str
                [vmName,...] : list of str
                (vmName,vmOid) : tuple of 2 str
                ((vmName,vmOid)] : list of tuple of 2 str 
        '''
        vmNames = listify(vmNames)
        tupList = [tuplify(e) for e in vmNames]
        self.logger.info4('Mapping vmNames to vmMoid: %s' % vmNames)
        tupList = [
            tup if len(tup)==2 else
                self.mgr.vslibVc.getByNamesGlob(vim.VirtualMachine, tup[0])
            for tup in tupList ]
        self.logger.info4('DONE Mapping vmNames to vmMoid: %s' % vmNames)
        tupList = [
            tup if len(tup)==2 else [(e.name, e._moId) for e in tup]
            for tup in tupList ]
        tupList = flatten(tupList)

        ptbl = PrettyTable(['vmName', 'vmMoid', 'STName'], sortby='vmName')
        ptbl.align = 'l'
        vmStsDict = {}
        if tupList:
            for vmName,vmMoid in tupList:
                r = self.doRestApi('stsByVm',  objectId=vmMoid)
                vmStsFullOd = byteify(xmltodict.parse(r.text))
                #print('>>>>>'); pprint_od(vmStsFullOd)
                if 'securityTags' in vmStsFullOd and vmStsFullOd['securityTags']:
                    vmStsOd = listify(vmStsFullOd['securityTags']['securityTag'])
                    vmStNames = [e['name'] for e in vmStsOd]
                    vmStsDict[vmName] = vmStNames
                    ptbl.add_row([vmName, vmMoid, ','.join(vmStNames)])
            if prStdout:
                if ptbl.rowcount:
                    print(ptbl)
                print('Count: %d' % ptbl.rowcount)
        else:
            self.logger.warning('VM %s not found' % vmNames)
        return vmStsDict

    def listVMs(self, stNames, brief=False, fmt=None, prStdout=True):
        ''' RETURN
                stVmDict: {stName:(stObjectId, vmName, vmObjectId)} '''
        stNames = listify(stNames)
        action = 'listVMs'
        stVmDict = {}
        ptbl = PrettyTable(['STname', 'VMname', 'objectId', 'scope_name', 'isUniversal'], sortby='STname')
        ptbl.align = 'l'
        if prStdout:
            self.logger.info('List VMs with securitytags %s' % stNames)
        for stName in sorted(stNames):
            stObjs = self.find_by_name(stName, results=None, matchMethod='glob')
            stTuples = [(e['name'], e['objectId']) for e in stObjs]
            stTuples = sorted(stTuples, key=lambda e: e[0])
            if stTuples:
                for stName, stObjectId in stTuples:
                    stVmDict[stName] = []
                    r = self.doRestApi('listVMs',  objectId=stObjectId)

                    if not fmt or fmt=='brief' or brief:
                        vmlOd = byteify(xmltodict.parse(r.text))
                        for vmEnt in listify(vmlOd['basicinfolist']['basicinfo']) if vmlOd['basicinfolist'] else []:
                            ptbl.add_row([stName, vmEnt['name'], vmEnt['objectId'], vmEnt['scope']['name'], vmEnt['isUniversal']])
                            stVmDict[stName].append((stObjectId, vmEnt['name'], vmEnt['objectId']))
                    else:
                        self.prRespText(r.text, fmt)
        if prStdout:
            if ptbl.rowcount:
                print(ptbl.get_string(sort_key=operator.itemgetter(0,1)))
            print('Count: %d' % ptbl.rowcount)
        del ptbl
        # returning stVmDict: {<stName>: [(stId, vmName, vmMoid),...]}
        return stVmDict

    def secTagOp(self, action, stNames, targetType, targetNames, retryParams=None):
        ''' action: apply, detach, vmAssign, vmClear '''

        targetNames = listify(targetNames)
        stNames = stNames.split(',')
        stObjectIds = []
        for stName in stNames:
            tagObjectId = self.find_by_name(stName)
            if action!='vmClear':
                if not tagObjectId:
                    self.logger.error('security tag %s not found' % stName)
                    return
                stObjectIds.append(tagObjectId)

        if targetType == 'cluster':
            clusterd = vslib.ClusterComputeResource(self.mgr.vslibVc)
            vmMos = clusterd.find_vmMos_by_clusters(targetNames)
            self.logger.info('Applying security tag %s to VM %s' %
                (stName, [vmMo.name for vmMo in vmMos]))
            vms = [(mo.name,mo._moId) for mo in vmMos]
        elif targetType == 'vm':
            vmMos = self.mgr.vslibVc.getByNamesGlob(vim.VirtualMachine, targetNames, refresh=False)
            vms = [(mo.name,mo._moId) for mo in vmMos]

        if action in ['apply', 'detach']:
            for stObjectId,vm in itertools.product(stObjectIds, vms):
                vmName, vmMoid = vm
                self.logger.info('%s security tag %s to/from VM %s' % (action, stName, vmName))
                r = self.doRestApi(action, stObjectId=stObjectId,
                    vmObjectId=vmMoid, retryParams=retryParams)
        elif action == 'vmAssign':
            dataDict = {'securityTags': {'securityTag': [{'objectId': stObjectId} 
                for stObjectId in stObjectIds] } }
            xml = xmltodict.unparse(dataDict, pretty=True)
            for vm in vms:
                vmName, vmMoid = vm
                self.logger.info('%s security tag %s to/from VM %s' % (action, stName, vmName))
                r = self.doRestApi(action, objectId=vmMoid, data=xml,
                    retryParams=retryParams)
        elif action == 'vmClear':
            for vm in vms:
                vmName, vmMoid = vm
                self.logger.info('%s security tags from VM %s' % (action, vmName))
                r = self.doRestApi(action, objectId=vmMoid, data='<?xml version="1.0"?><securityTags/>',
                    retryParams=retryParams)

class Security_group(Network_element):
    rest_api = {
        'get':          Api('get',        '/api/2.0/services/securitygroup/scope/globalroot-0', ''),
        'getByMbrType': Api('get',       '"/api/2.0/services/securitygroup/scope/globalroot-0/members/%s"%memberType', ''),
        'allmember':    Api('get',       '"/api/2.0/services/securitygroup/scope/globalroot-0/members/%s"%memberType', ''),
        'getone':       Api('get',       '"/api/2.0/services/securitygroup/%s"%objectId', ''),
        'del':          Api('delete',    '"/api/2.0/services/securitygroup/%s?force=%s"%(objectId,force)', ''),
        'cfg':          Api('post',       '/api/2.0/services/securitygroup/bulk/globalroot-0', ''),
        'create':       Api('post',       '/api/2.0/services/securitygroup/bulk/globalroot-0', ''),
        'modify':       Api('put',       '"/api/2.0/services/securitygroup/bulk/%s"%objectId', ''),
        'member_vm':    Api('get',   '"/api/2.0/services/securitygroup/%s/translation/virtualmachines"%objectId', ''),
        'member_ip':    Api('get',   '"/api/2.0/services/securitygroup/%s/translation/ipaddresses"%objectId', ''),
        'member_mac':   Api('get',   '"/api/2.0/services/securitygroup/%s/translation/macaddresses"%objectId', ''),
        'member_vnic':  Api('get',   '"/api/2.0/services/securitygroup/%s/translation/vnics"%objectId', ''),
        'vmMembership': Api('get',   '"/api/2.0/services/securitygroup/lookup/virtualmachine/%s"%objectId', ''),
        'policy':       Api('get',   '"/api/2.0/services/policy/securitygroup/%s/securitypolicies"%objectId', ''),
        'addVcMember':  Api('put',   '"/api/2.0/services/securitygroup/%s/members/%s?failIfExists=false"%(sgOid,mbrOid)', ''),
        'delVcMember':  Api('delete','"/api/2.0/services/securitygroup/%s/members/%s?failIfExists=false"%(sgOid,mbrOid)', ''),
    }
    rKeys = ['list', 'securitygroup']
    jqTblSpec = JqTblSpec('''def listify:if type=="array" then .[] else select(.) end; {
        "name/objectId": (.name+"\n "+.objectId),
        "member":        ([.member | listify |.name] |sort |join("\n")),
        "excludeMember": ([.excludeMember | listify |.name] |sort |join("\n")),
        "dynMemOp":      (if .dynamicMemberDefinition.dynamicSet then ([
            .dynamicMemberDefinition.dynamicSet  | listify | {
                "operator": .operator,
                "dynamicCriteria": ([
                    .dynamicCriteria | listify | {
                        "operator": .operator,
                        "key": .key,
                        "criteria": .criteria,
                        "value": .value,
                    }
                ])
            }
        ]) else "" end)
    }''', '')

    yamlObjNamePath = ['yaml', 'securitygroup', 0, 'name']

    logicOpMap = {'A':'AND', 'O':'OR'}
    grpObjKeyMap = {
        '' :'ENTITY',
        'E':'ENTITY',
        'V':'VM.NAME',
        'T':'VM.SECURITY_TAG',
        'H':'VM.GUEST_HOST_NAME',
        'O':'VM.GUEST_OS_FULL_NAME',
    }
    critMap = {
        '' :'belongs_to',
        'B':'belongs_to',
        '=':'=',
        '!':'!=',
        'C':'contains',
        'S':'starts_with',
        'E':'ends_with',
        'R':'similar_to',
    }

    def config(self,data,**args):
        ''' this is in for calling custom security_group
            config in this class. otherwise, it will call super class method'''

        flag = False
        for i in data['yaml']['securitygroup']:
            if 'HINT_securitygroup' in i:
                flag = True

        if flag == False:
            super(Security_group, self).config(data)
        elif flag == True:
            config_securitygroup(self.mgr,data,args=args)

    def sbux_insert(self,data,**args):

        ''' this is in for calling custom security_group
            sbux insert in this class. otherwise, it will call super class method'''

        flag = False
        for i in data['yaml']['securitygroup']:
            if 'HINT_securitygroup' in i:
                flag = True

        if flag == False:
            super(Security_group, self).config(data)
        elif flag == True:
            sg_list=sbux_insert_securitygroup(self.mgr,data,args=args)
            print("sg resturns ... %s" %sg_list)
            return sg_list

                
    def getSgMemberIpToT(self, name=None):
        sgs = self.find()
        for sg in sgs:
            if name and sg['name'] != name:
                continue
            vmMembers = []
            ips = self.doRestApi('member_ip', objectId=sg['objectId'])
            em = byteify(xmltodict.parse(ips.text))
            if em['ipNodes']:
                for e in listify(em['ipNodes']['ipNode']):
                    for ip in listify(e['ipAddresses']['string']):
                        vmMembers.append(ip)
            if len(vmMembers) == 0:
                print("ipset config --name \"%s_ipset\" " %(sg['name']))
            else:
                output = ' '.join(map(str,vmMembers))
                print("ipset config --name \"%s_ipset\" --ips %s" %(sg['name'], output))

            if 'description' in sg.keys() and sg['description'] != 'None':
                print('nsgroup config --name \"%s_ip\" --ips \"%s_ipset\" --desc \"%s\"'
                      %(sg['name'], sg['name'], sg['description']))
            else:
                print('nsgroup config --name \"%s_ip\" --ips \"%s_ipset\"'
                      %(sg['name'], sg['name']))

    def convertSgToT(self, name=None):
        sgs = self.find()
        for sg in sgs:
            if name and sg['name'] != name:
                continue

            contains=[]
            startswith=[]
            equals=[] 
            if 'dynamicMemberDefinition' in sg.keys():
                if len(listify(sg['dynamicMemberDefinition']['dynamicSet'])) > 1:
                    raise ValueError('convertSgToT: multi-dynamicSet not handled')
                for dynSet in listify(sg['dynamicMemberDefinition']['dynamicSet']):

                    setOperator = dynSet['operator']
                    for criteria in listify(dynSet['dynamicCriteria']):
                        critOperator=criteria['operator']
                        if criteria['key'] != 'VM.NAME':
                            raise ValueError('convertSgToT: dynamic criteria key type of %s not handled'
                                  %criteria['key'])

                        if criteria['criteria'] == 'contains':
                            contains.append(criteria['value'])
                        elif criteria['criteria'] == 'starts_with':
                            startswith.append(criteria['value'])
                        elif criteria['critera'] == '=':
                            equals.append(criteria['value'])
                        else:
                            raise ValueError('convertSgToT: dynamic criteria ops %s not handled' %criteria['criteria'])
                        if criteria['operator'] != 'OR':
                            raise ValueError('convertSgToT: criteria operator %s not handled' %critiera['operator'])

            ipsets = []
            sgroups = []
            vmnames = []
            if 'member' in sg.keys():
                for member in listify(sg['member']):
                    if member['objectTypeName'] == 'IPSet':
                        ipsets.append(member['name'])
                    elif member['objectTypeName'] == 'VirtualMachine':
                        vmnames.append(member['name'])
                    elif member['objectTypeName'] == 'SecurityGroup':
                        sgroups.append(member['name'])
                    else:
                        raise ValueError('convertSgToT: member type %s not handled'%member['value'])

            # Create SG to hold all the static VM members staticMemSg = None
            staticMemSg = ''
            if len(vmnames) > 0:
                index=0
                startslice=0
                sgCount=1
                staticMemberSG = []
                while index < len(vmnames):
                    staticMemSg = '%s_vmMembers%d' %(sg['name'],sgCount)
                    staticMemberSG.append(staticMemSg)
                    cmd = "nsgroup config --name \"%s\" --vmequal " %staticMemSg
                    index+=5
                    cmd = cmd + ' '.join('"' + vm + '"' for vm in vmnames[startslice:index])
                    startslice+=5
                    sgCount+=1
                    print(cmd)
                    
            if 'description' in sg.keys() and sg['description'] != 'None':
                cmd = "nsgroup config --name \"%s\" --desc \"%s\"" %(sg['name'], sg['description'])
            else:
                cmd = "nsgroup config --name \"%s\" " %sg['name']
                
            total = 0
            if len(contains)> 0:
                cmd = cmd + '--vmcontain ' + ' '.join('"' + vm + '"' for vm in contains)
                total+=len(contains)
            if len(startswith) > 0:
                cmd = cmd + ' --vmstart ' + ' '.join('"' + vm + '"' for vm in startswith)
                total+=len(startswith)
            if len(equals) > 0:
                cmd = cmd + ' --vmequal ' + ' '.join('"' + vm + '"' for vm in equals)
                total+=len(equals)
            if len(ipsets) > 0:
                cmd = cmd + ' --ips ' + ' '.join('"' + vm + '"' for vm in ipsets)
                total+=len(ipsets)
            if len(sgroups) > 0 and not staticMemSg:
                cmd = cmd + ' --nsgroups ' + ' '.join('"' + vm + '"' for vm in sgroups)
                total+=len(sgroups)
            if len(sgroups) > 0 and staticMemSg:
                cmd = cmd + ' --nsgroups ' + ' '.join('"' + vm + '"' for vm in sgroups) + ' ' + ' '.join('"' + vm + '"' for vm in staticMemberSG)
                total+=len(sgroups)
                total+=len(staticMemberSG)
            if len(sgroups) == 0 and staticMemSg:
                cmd = cmd + ' --nsgroups ' + ' '.join('"' + vm + '"' for vm in staticMemberSG)
                total+=len(staticMemberSG)
            if total > 5:
                pprint_od(sg)
                raise ValueError("Need to handle more than 5 criteria properly for sg %s" %sg[name])
            print(cmd)
                    
                    

    
    def sgOp(self, op, prStdout=True, fmt='brief', **kwargs):
        sgMbrTypeMap = {
            'cluster': 'ClusterComputeResource',
            'dc': 'Datacenter',
            'dg': 'DirectoryGroup',
            'dvpg': 'DistributedVirtualPortgroup',
            'ipset': 'IPSet',
            'ls': 'VirtualWire',
            'macset': 'MACSet',
            'net': 'Network',
            'respool': 'ResourcePool',
            'vapp': 'VirtualApp',
            'vm': 'VirtualMachine',
            'vnic': 'Vnic',
            'sg': 'SecurityGroup',
            'st': 'SecurityTag'}

        exec('\n'.join('%s=kwargs["%s"]' % (k, k) for k in kwargs.keys()))
        rDict = {}
        if op in ['policy', 'member_vm', 'member_ip', 'member_mac', 'member_vnic', ]:
            ptbl = PrettyTable(['securityGroup', 'effective Membership'])
            ptbl.align = 'l'
            jDicts = []
            for sgNameGlob in listify(sgNames):
                sgs = self.find_by_name(sgNameGlob, results=None, matchMethod='glob')
                sgTuples = [(e['name'], e['objectId']) for e in sgs]
                sgTuples = sorted(sgTuples, key=lambda e: e[0])
                if sgTuples:
                    for sgName,objectId in sgTuples:
                        #self.logger.info('Show effective membership for security group %s' % sgName)
                        #######objectId = self.find_by_name(sgName)
                        r = self.doRestApi(op, objectId=objectId)
                        emOd = byteify(xmltodict.parse(r.text))
                        #pprint(emOd)
                        jElem = {'name':sgName}
                        if op == 'member_vm':
                            elems = sorted([e['vmName'] for e in listify(emOd['vmnodes']['vmnode'])]) \
                                if emOd['vmnodes'] else []
                        elif op == 'member_ip':
                            elems=[]
                            if emOd['ipNodes']:
                                for e in listify(emOd['ipNodes']['ipNode']):
                                    for ip in listify(e['ipAddresses']['string']):
                                        elems.append(ip)
                        elif op == 'member_mac':
                            elems = sorted([e['macAddress'] for e in listify(emOd['macNodes']['macNode'])]) \
                                if emOd['macNodes'] else []
                        elif op == 'member_vnic':
                            elems = sorted([e['uuid'] for e in listify(emOd['vnicNodes']['vnicNode'])]) \
                                if emOd['vnicNodes'] else []
                        elif op=='policy':
                            elems = sorted([e['name'] for e in listify(emOd['securityPolicies']['securityPolicy'])]) \
                                if emOd['securityPolicies'] else []
                        jElem['members'] = sorted(elems)
                        ptbl.add_row([sgName, '\n'.join(elems)])
                        rDict.setdefault(sgName,[]).extend(elems)
                        jDicts.append(jElem)
            if prStdout:
                if fmt=='json':
                    pprint_json(jDicts)
                else:
                    print(ptbl)
                    print('Count: %d' % ptbl.rowcount)
        elif op=='vmMembership':
            vmd = vslib.VirtualMachine(self.mgr.vslibVc)
            ptbl = PrettyTable(['vmName', 'memberOfSG'])
            ptbl.align = 'l'
            for vmNameGlob in vmNames:
                vmMos = vmd.getByNamesGlob(vmNameGlob)
                #vmMoids = [vslib.shortMoid(vm._moId) for vm in vmMos]
                #vmNames = [vm.name for vm in vmMos]
                vmTuples = [(vslib.shortMoid(vm._moId), vm.name) for vm in vmMos]
                vmTuples = sorted(vmTuples, key=lambda e: e[0])
                for vmMoid,vmName in vmTuples:
                    self.logger.info('Show security group membership for VM %s' % vmName)
                    vmMoid = vslib.shortMoid(vmMoid)
                    r = self.doRestApi(op, objectId=vmMoid)
                    sgOd = byteify(xmltodict.parse(r.text))
                    #print(', '.join([sg['name'] for sg in sgOd['securityGroups']['securityGroups']['securitygroup']]))
                    sgs = [sg['name'] for sg in sgOd['securityGroups']['securityGroups']['securitygroup']]
                    ptbl.add_row([vmName, '\n'.join(sgs)])
            print(ptbl)
            print('Count: %d' % ptbl.rowcount)
        elif op=='allmember':
            r = self.doRestApi(op, memberType=sgMbrTypeMap[memberType])
            od = xmltodict.parse(r.text)
            pprint_od(od)
            ptbl = PrettyTable(['name', 'scope'])
            ptbl.align = 'l'
            for entry in listify(od['list']['basicinfo'] if od['list'] else []):
                objId = entry['objectId']
                objType = entry['objectTypeName'] if 'objectTypeName' in entry else entry['type']['typeName']
                objName = entry['name']
                objScopeType = entry['scope']['objectTypeName'] if 'scope' in entry else ''
                objScopeName = entry['scope']['name'] if 'scope' in entry else ''
                ptbl.add_row([objName, '%s:%s'%(objScopeType,objScopeName)])
            print(ptbl)
            print('Count: %d %s' % (ptbl.rowcount, memberType))
        else:
            self.logger.error('Unsupported operation %s' % op)
        return rDict

    def create0(self, args, extra, sgCreateParser):
        od = None
        if extra:
            rest = extra
            argsNs = vars(args)
            xml, od = fmtSgXml(self.mgr, argsNs, od, pretty=False)
            while rest:
                args,rest =  sgCreateParser.parse_known_args(rest,namespace=args)
                argsNs = vars(args); #argsNs['name']='test1'
                xml, od = fmtSgXml(self.mgr, argsNs, od, pretty=False)
        else:
            argsNs = vars(args)
            xml, od = fmtSgXml(self.mgr, argsNs, od, pretty=False)

        self.logger.info('Posting SG %s creation request to NSX Manager' % args.sgName)
        r = self.doRestApi('create', data=xml)

    def fmtSgXml(self, dic, d2=None, pretty=False):
        ''' convert a security group specification in dic to an XML string
            suitable for SG creation API
            dic holds member/excludedMember/dynamicMember criteria
            d2 holds OD for XML converstion, create if necessary
            d2 updated base on info from dic
            convert d2 to xml
            calls mapNsxvObjNameToId() to do mapping
        '''
        if not d2:
            d2 = {'securitygroup':dic}
            d2['securitygroup'] = OD()
            d2['securitygroup']['name'] = dic['sgName']

        memberType = dic['ns2']
        if memberType in ['member', 'excludeMember' ]:
            memberTag = dic['ns2']
            if memberTag not in d2['securitygroup']:
                d2['securitygroup'][memberTag] = []
            mType, mName = dic['memCrit'].split(':')
            self.logger.info('mapping %s %s(%s) to objectId' %
                (dic['ns2'], mType, mName))
            mObjId = mapNsxvObjNameToId(mgr, mType, mName)
            self.logger.info('mapped  %s %s(%s) to %s' %
                (dic['ns2'], mType, mName, mObjId))
            memDict = OD()
            memDict['objectTypeName'] = mType
            memDict['objectId'] = mObjId
            d2['securitygroup'][memberTag].append(memDict)
        elif memberType == 'dyn':
            d2['securitygroup']['dynamicMemberDefinition'] = OD()
            d2['securitygroup']['dynamicMemberDefinition']['dynamicSet'] = OD()
            d2['securitygroup']['dynamicMemberDefinition']['dynamicSet']['operator'] = dic['op']
            d2['securitygroup']['dynamicMemberDefinition']['dynamicSet']['dynamicCriteria'] = []
            for crit in dic['dynCrits']:
                cOp,cKey,cCrit,cVal = crit.split(':')
                critDic = {'operator': cOp,
                    'key': cKey,        # VM.SECURITY_TAG, VM.NAME, VM.GUEST_OS_FULL_NAME, VM.GUEST_HOST_NAME, ENTITY
                    'criteria': cCrit,  # =, !=, contains, 'does not contain', 'starts with', 'ends with', 'similar_to', 'belongs to' ('security group', 'cluster', 'logical switch', 'legacy port group', 'vApp', 'Datacenter')
                    'value': cVal,
                    'isValid': 'true'
                }
                d2['securitygroup']['dynamicMemberDefinition']['dynamicSet']['dynamicCriteria'].append(critDic)
        elif memberType == 'empty':
            pass

        xml = xmltodict.unparse(d2, pretty=pretty)
        return xml, d2

    def create2(self, sgName, catsSpec):
        self.logger.warning('This method is deprecated, use create instead')    # 2017-05-03
        return self.create(sgName, catsSpec)

    def create(self, sgName, catsSpec):                 # Security_group
        self.logger.info('Creating SG %s' % sgName)
        self.logger.debug('catsSpec: %s' % catsSpec)

        catsSpec = [e.strip() for e in catsSpec.split(';')] if catsSpec else []
        catsSpec = [e for e in catsSpec if e]

        sgDict = {'securitygroup':{'name':sgName}}

        for catSpec in catsSpec:
            mbrType = catSpec[0]
            if mbrType in ['M', 'E']:
                ''' M:I|IPSET-192.168.0.0/24,G|$SGName,V|vlan2026-vm0902 '''
                mbrSpec = catSpec.split(':')[1]
                memberTag = {'M':'member', 'E':'excludeMember'}[mbrType]
                rList = (self._procGrpObjs(mbrSpec))
                sgDict['securitygroup'][memberTag] = [{'objectId':d['value']} for d in rList]
            elif mbrType=='D':
                #catSpec = '''D:
                #    =OR,
                #        AND:VM.SECURITY_TAG:contains:abc,
                #        AND:ENTITY:belongs_to:I|IPSET-192.168.0.0/24,
                #    =AND,
                #        AND:ENTITY:belongs_to:domain-c255,
                #    =OR,
                #        AND:ENTITY:belongs_to:securitygroup-1,
                #        AND:VM.NAME:starts_with:vm-,
                #'''

                dynSetsSpec = catSpec.split('+')[1:]

                sgDict['securitygroup']['dynamicMemberDefinition'] = {'dynamicSet':[]}
                for dynSetSpec in dynSetsSpec:
                    # OR,
                    #    AND:ENTITY:belongs_to:G|cluster1,
                    #    AND:ENTITY:belongs_to:I|IPSET-192.168.0.0/24,
                    dynCritsSpec = dynSetSpec.split(',')
                    dynSetOp = self.logicOpMap[dynCritsSpec.pop(0)[0].upper()]

                    critDictList = []
                    for critSpec in dynCritsSpec:
                        critSpec = critSpec.strip()
                        if not critSpec: continue
                        comps = critSpec.strip().split(':')
                        if len(comps)!=4:
                            self.logger.error('Invalid criteria spec: %s' % critSpec)
                            self.logger.error('expect 4 colon seperated fields: <op>:<key>:<crit>:<val>')
                            continue
                        cOp,cKey,cCrit,cVal = comps

                        cOp = self.logicOpMap[cOp[0].upper()]
                        cKey = self.grpObjKeyMap.get(cKey, cKey)
                        cCrit = self.critMap.get(cCrit.upper(), cCrit)

                        if '|' in cVal:
                            rList = self._procGrpObjs(cVal)
                            cVal = rList[0]['value']
                        critDict = {'operator': cOp,
                            'key': cKey,
                            'criteria': cCrit,
                            'value': cVal,
                            'isValid': 'true'
                        }
                        critDictList.append(critDict)
                    dynDritDict = {'dynamicCriteria':critDictList, 'operator':dynSetOp}
                    sgDict['securitygroup']['dynamicMemberDefinition']['dynamicSet'].append(dynDritDict)

            else:
                self.logger.error('Invalid membership type specifiation: "%s"' % mbrType)
        xml = xmltodict.unparse(sgDict)
        r = self.doRestApi('create', data=xml)

        #self.cDictByOid = getattr(self, 'cDictByOid', {})
        #self.cDictByOname = getattr(self, 'cDictByOname', {})
        #self.cDictByOid[r.text] = sgName
        #self.cDictByOname[sgName] = r.text
        #print('self.cDictByOid = %s' % self.cDictByOid)
        #print('self.cDictByOname = %s' % self.cDictByOname)

        return r.text

    def modify(self, sgNames, catsSpecs):               # Security_group
        ''' modify Security_group '''
        #catsSpecs is either
        #  a string representing a catSpec to be applied to all sgNames
        #  list of string representing catSpecs to be applied to corresponding sgNames
        #catSpec = '''
        #    -M: G|SG-001,T|ST-001;
        #    +M: G|SG-001,T|ST-001;
        #    -E: I|IPSET-192.168.0.0/24;
        #    +E: I|IPSET-192.168.0.0/24;
        #    +D1, V:=:DEF, E::C|cluster4; -D2, V:=:ABC, E::A|vApp-test;
        #    +D1:AND, AND:T:=:T|ST_FUNC_FUNC12
        #    -D1:AND, AND:T:=:T|ST_FUNC_FUNC12
        #'''
        sgNames = listify(sgNames)
        if not isinstance(catsSpecs, list):
            catsSpecs = [catsSpecs for i in range(len(sgNames))]

        for sgName,catsSpec in zip(sgNames, catsSpecs):
            catsSpec = [e.strip() for e in catsSpec.split(';')] if catsSpec else []
            sgName = sgName.strip()
            if not sgName:
                continue
            self.logger.info('Modifying SG %s: %s' % (sgName, catsSpec))

            self.logger.debug('calling find_by_name(%s)' % sgName)
            sgObjectId = self.find_by_name(sgName)
            self.logger.debug('got find_by_name(%s): %s' % (sgName,sgObjectId))
            sgDict = self.getByObjectId(sgObjectId)
            self.logger.debug('got getByObjectId(%s)' % sgObjectId)

            self.logger.debug('found sgObjectId: %s' % sgObjectId)
            for catSpec in catsSpec:
                #print('catSpec: %s' % catSpec)
                catSpec = catSpec.strip()
                if not catSpec: continue
                ''' -M, A|vApp-test,C|cluster-test; '''
                modOp, mbrType = catSpec[0], catSpec[1] # eg: modOp='+' mbrType='M'
                modOp = {'~':'-', '!':'-'}.get(modOp, modOp)


                if mbrType in ['M', 'E']:
                    ''' -M:A|vApp-test,C|cluster-test; '''
                    mbrsSpec = catSpec[3:]
                    memberTag = {'M':'member', 'E':'excludeMember'}[mbrType]
                    #print('mbrsSpec: %s' % mbrsSpec)
                    rList = (self._procGrpObjs(mbrsSpec))
                    #print(catSpec, rList)
                    sgDict['securitygroup'][memberTag] = listify(sgDict['securitygroup'][memberTag]) \
                        if memberTag in sgDict['securitygroup'] else []
                    if modOp == '+':
                        sgDict['securitygroup'][memberTag].extend([{'objectId':d['value']} for d in rList])
                    elif modOp == '-':
                        curOids = [mbr['objectId'] for mbr in sgDict['securitygroup'][memberTag]]
                        delOids = [d['value'] for d in rList]
                        delIdxes = [idx for idx,curOid in enumerate(curOids) if curOid in delOids]
                        delIdxes.reverse()
                        for delIdx in delIdxes:
                            sgDict['securitygroup'][memberTag].pop(delIdx)
                elif mbrType=='D':
                    ''' modify SG000 -- +D1:AND, AND:T:=:T|ST_FUNC_FUNC12 '''
                    ''' modify SG000 -- -D1:AND, AND:T:=:T|ST_FUNC_FUNC12 '''
                    #print('>>> catSpec: ',  catSpec)    # +D1:AND, V:=:ABC, E::A|vApp-test;
                    comps = catSpec.split(',')          # [ '+D1:AND', 'V:=:ABC, E::A|vApp-test;'
                    #print('>>> comps=%s'%comps)
                    dynSetOpSpec = comps.pop(0).strip()

                    dynSetOpSpecComps = dynSetOpSpec.split(':')

                    dynSetOp= dynSetOpSpecComps[1]  # AND | OR
                    dynSetIdx = int(dynSetOpSpecComps[0][2:])-1   ;# 1 base dynSetIdx
                    #dynSetIdx = int(dynSetOpSpec[2:])-1   ;# 1 base dynSetIdx

                    emptyDynSetDict = {'dynamicCriteria':[],'operator':dynSetOp}
                    #print('>>> dynSetOpSpec=%s, dynSetIdx=%s, dynSetOp=%s' % (dynSetOpSpec, dynSetIdx, dynSetOp))
                    #print('sgDict["securitygroup"]='); pprint_od(sgDict['securitygroup'])
                    if 'dynamicMemberDefinition' not in sgDict['securitygroup']:
                        #print('MAKING EMPTY LIST FOR dynamicCriteria')
                        sgDict['securitygroup']['dynamicMemberDefinition'] = {'dynamicSet':[emptyDynSetDict]}
                    else:
                        sgDict['securitygroup']['dynamicMemberDefinition']['dynamicSet'] = \
                            listify(sgDict['securitygroup']['dynamicMemberDefinition']['dynamicSet'])

                    while len(sgDict['securitygroup']['dynamicMemberDefinition']['dynamicSet'])<=dynSetIdx:
                        #print('len of dynamicSet: %d' % len(sgDict['securitygroup']['dynamicMemberDefinition']['dynamicSet']))
                        sgDict['securitygroup']['dynamicMemberDefinition']['dynamicSet'].append(emptyDynSetDict)
                    #print('len of dynamicSet: %d' % len(sgDict['securitygroup']['dynamicMemberDefinition']['dynamicSet']))

                    curDynSet = sgDict['securitygroup']['dynamicMemberDefinition']['dynamicSet'][dynSetIdx]

                    tCritNormSpecs = []
                    for tCritSpec in comps:
                        print('|>> tCritSpec:', tCritSpec)
                        tCritSpec = tCritSpec.strip()
                        if not tCritSpec: continue
                        comps = tCritSpec.strip().split(':')
                        if len(comps)!=4:
                            self.logger.error('Invalid criteria spec: %s' % critSpec)
                            continue
                        tcOp,tcKey,tcCrit,tcGObjSpec = comps

                        tcVal = self._procGrpObjs(tcGObjSpec)[0]['value']
                        tCritNormSpec = '%s:%s:%s:%s' % (
                            self.logicOpMap[tcOp[0].upper()],
                            self.grpObjKeyMap.get(tcKey, tcKey),
                            self.critMap.get(tcCrit, tcCrit),
                            tcVal)
                        tCritNormSpecs.append(tCritNormSpec)
                        print('>>> tCritNormSpec: "%s" "%s"' % (tCritSpec, tCritNormSpec))
                    #pprint_od(curDynSet)

                    if modOp == '+':
                        ''' append elements of tCritNormSpecs to dynamicCriteria of curDynSet '''
                        print('I am here @ +:', tCritNormSpecs)
                        for tCritNormSpec in tCritNormSpecs:
                            comps = tCritNormSpec.strip().split(':')
                            cOp,cKey,cCrit,cVal = comps
                            critDict = {'operator': cOp,
                                'key': cKey,
                                'criteria': cCrit,
                                'value': cVal,
                                'isValid': 'true'
                            }
                            print('APPEND critDict:'); pprint(critDict)
                            curDynSet['dynamicCriteria'].append(critDict)
                        print('FINAL: curDynSet'); pprint_od(curDynSet)
                    elif modOp == '-':
                        ''' build normailzed current critira specs '''
                        cCritNormSpecs = []
                        for idx,cCrit in enumerate(curDynSet['dynamicCriteria']):
                            print( idx,cCrit)
                            cCritNormSpec = '%s:%s:%s:%s' % (
                                cCrit['operator'], cCrit['key'], cCrit['criteria'], cCrit['value'] )
                            cCritNormSpecs.append(cCritNormSpec)
                        ''' indexes of cCritNormSpecs elements to be deleted in reverse order'''
                        delIdxes = [idx for idx,cCritNormSpec in enumerate(cCritNormSpecs) if cCritNormSpec in tCritNormSpecs]
                        delIdxes.reverse()
                        ''' removed elements from cCritNormSpecs '''
                        for delIdx in delIdxes:
                            curDynSet['dynamicCriteria'].pop(delIdx)
                else:
                    self.logger.error('Invalid membership type specifiation: "%s"' % mbrType)
            xml = xmltodict.unparse(sgDict)
            r = self.doRestApi('modify', objectId=sgObjectId, data=xml)
            if r.ok:
                self.logger.info('Modified  SG %s' % sgName)

    def show(self, sgNames, brief=False, fmt=None, PCache=''):          # Security_group
        brief |= not fmt
        for sgName in sorted(sgNames):
            self.logger.info('show Security Group %s' % sgName)
            sgObjs = self.find_by_name(sgName, results=None, matchMethod='glob', PCache=PCache)
            sgObjs = sorted(sgObjs, key=lambda s:s['name'])
            if sgObjs:
                if brief or fmt=='brief':
                    ptbl = PrettyTable(['name/objId/scope', 'members'])
                    for sgObj in sgObjs:
                        pMemTblTbl = PrettyTable(['Members'])
                        pMemTbl = PrettyTable(['type', 'name', 'objectId'], sortby='name')
                        pExcMemTbl = PrettyTable(['type', 'name', 'objectId'], sortby='name')
                        pDynTblTbl = PrettyTable(['DynamicSet'])
                        ptbl.align = 'l'
                        pMemTblTbl.align = 'l'
                        pMemTbl.align = 'l'
                        pExcMemTbl.align = 'l'
                        pDynTblTbl.align = 'l'
                        if 'member' in sgObj:
                            for m in listify(sgObj['member']):
                                pMemTbl.add_row([m['objectTypeName'], m['name'], m['objectId']])
                            pMemTblTbl.add_row(['NormalMembers'])
                            pMemTblTbl.add_row([pMemTbl])
                        if 'excludeMember' in sgObj:
                            for m in listify(sgObj['excludeMember']):
                                pExcMemTbl.add_row([m['objectTypeName'], m['name'], m['objectId']])
                            pMemTblTbl.add_row(['ExcludedMembers'])
                            pMemTblTbl.add_row([pExcMemTbl])
                        if 'dynamicMemberDefinition' in sgObj:
                            pMemTblTbl.add_row(['DynamicMembership:'])
                            for idx,ms in enumerate(listify(sgObj['dynamicMemberDefinition']['dynamicSet'])):
                                pDynTblTbl.add_row(['dynamicCriteria%s' % ('(%s)'%ms['operator'] if idx else '')])
                                pDynMemTbl = PrettyTable(['op', 'key', 'criteria', 'name', 'value'])
                                pDynMemTbl.align = 'l'
                                for m in listify(ms['dynamicCriteria']):
                                    mObjName = m['object']['name'] if  'object' in m else ''
                                    #pDynMemTbl.add_row([m['operator'], m['key'], m['criteria'], m['object']['name'], m['value']])
                                    pDynMemTbl.add_row([m['operator'], m['key'], m['criteria'], mObjName, m['value']])
                                pDynTblTbl.add_row([pDynMemTbl])
                            pMemTblTbl.add_row([pDynTblTbl])

                        ptbl.add_row([
                            '\n '.join([sgObj['name'], sgObj['objectId'],
                                sgObj['scope']['id']]),
                            pMemTblTbl if pMemTblTbl._rows else ''
                            ])
                    print(ptbl)
                    print('Count: %d' % ptbl.rowcount)
                else:
                    for sgObj in sgObjs:
                        sgXml = xmltodict.unparse({'securitygroup':sgObj})
                        self.prRespText(sgXml, fmt)
            else:
                self.logger.error('Security Group %s not found' % sgName)


class Security_policy(Network_element):
    rest_api = {
        'get':      Api('get',     '/api/2.0/services/policy/securitypolicy/all', ''),
        'getone':   Api('get',    '"/api/2.0/services/policy/securitypolicy/%s"%objectId', ''),
        'update':   Api('put',    '"/api/2.0/services/policy/securitypolicy/%s"%objectId', ''),
        'del':      Api('delete', '"/api/2.0/services/policy/securitypolicy/%s?force=%s"%(objectId,force)', ''),
        'config':   Api('post',    '/api/2.0/services/policy/securitypolicy', ''),
    }
    rKeys = ['securityPolicies', 'securityPolicy']
    rCatMap = {'fw':'firewall', 'gi':'endpoint', 'ni': 'traffic_steering'}

    #select(.actionsByCategory.category|test("firewall")) | {
    # outsideSecondaryContainer
    jqTblSpec = JqTblSpec('''def listify:if type=="array" then .[] else select(.) end;
    def negatePfx:if . then "~" else "!" end;
    {
        "name/id":    (.name+"\n "+.objectId),
        "precedence": .precedence,
        "sg":         ([.securityGroupBinding | listify | .name]| join("\n")),
        "category/action": ([
            if .actionsByCategory.category=="firewall" then
            {
                "category/opts": (.actionsByCategory.category + "\n " + ([.attributesByCategory | listify | select(.category=="firewall") | .categoryAttribute | listify | .attributeName+":"+.attributeValue]| join("\n "))),
                "action": ([.actionsByCategory.action | listify | {
                    "rName/rOid":   (.name+"\n "+.objectId),
                    "act/dir/enable":      (.action+"\n "+.direction+"\n "+.isEnabled),
                    "2ndSgs2":      (negatePfx+
                        ([.secondarySecurityGroup |
                        listify | .name] | join(",\n"))),
                    "applications": (
                        "AG:"+([.applications.applicationGroup |
                            listify | .name] | join("\n   "))
                        +"\n"+
                        "AP:"+([.applications.application |
                            listify | .name] | join("\n   "))
                    ),
                    "tag": .tag
                }])
            }
            elif .actionsByCategory.category=="traffic_steering" then
            {
                "category": .actionsByCategory.category,
                "action": ([.actionsByCategory.action | listify | {
                    "rName/rOid":   (.name+"\n "+.objectId),
                    "direction":    (.direction),
    
                    "2ndSgs":       (negatePfx+
                        ([.secondarySecurityGroup |
                        listify | .name] | join(",\n"))),
                    "applications": (
                        "AG:"+([.applications.applicationGroup |
                            listify | .name] | join("\n   "))
                        +"\n"+
                        "AP:"+([.applications.application |
                            listify | .name] | join("\n   "))
                    ),
                    "svcProf":      .serviceProfile.name,
                }])
            }
            elif .actionsByCategory.category=="eventcontrol" then
            {
                "category": .actionsByCategory.category,
                "action": ([.actionsByCategory.action | listify | {
                    "serviceName/Id":       (.serviceName+"\n "+.serviceId),
                    "vendorTemplateName/Id":(.vendorTemplateName+"\n "+.vendorTemplateId),
                }])
            }
            else empty end
        ])

    }''', '')

    def showSpBrief(self, sp, ptbl):            # class Security_policy()
        pActionTblTbl = PrettyTable(['Actions'])
        pActionTblTbl.align = 'l'

        secGrpBindingNames = ''
        if 'securityGroupBinding' in sp:
            secGrpBindings = listify(sp['securityGroupBinding'])
            secGrpBindingNames = '\n'.join([sgb['name'] for sgb in secGrpBindings])

        if 'actionsByCategory' in sp:
            actionsCats = listify(sp['actionsByCategory'])
            for actionsCat in actionsCats:
                pActionTblTbl.add_row(['Action Category: %s:' % actionsCat['category']])
                if 'firewall' in actionsCat['category']:
                    #pprint_od(actionsCat)
                    spActions = listify(actionsCat['action'])
                    pRuleTbl = PrettyTable(['rName/rOid', 'act/dir', '2ndSgs', 'applications'])
                    pRuleTbl.align = 'l'
                    for spAction in spActions:  # spAction also known as rule
                        #pprint_od(spAction)
                        spActionName = spAction.get('name', '')
                        spActionObjectId = spAction['objectId']
                        spActionDirection =  spAction['direction']
                        #spActionApps = listify(spAction['applications']['application'])
                        #spActionAgs  = listify(spAction['applications']['applicationGroup'])
                        pApps = 'APP:'+','.join([app['name'] for app in listify(spAction['applications']['application'])]) \
                            if 'applications' in spAction and 'application' in spAction['applications'] else ''
                        pAgs = 'AG:'+','.join([ag['name'] for ag in listify(spAction['applications']['applicationGroup'])]) \
                            if 'applications' in spAction and 'applicationGroup' in spAction['applications'] else ''
                        rApps = filter(lambda x:x, [pApps, pAgs])

                        #pRuleTbl.add_row([spAction['name'], spAction['action'],
                        pRuleTbl.add_row(['%s\n %s'%(spActionName,spActionObjectId),
                            '%s\n %s'%(spAction['action'], spActionDirection),
                            ','.join([sg.get('name','') for sg in listify(spAction.get('secondarySecurityGroup', {}))]),
                            '\n'.join(rApps)])
                    pActionTblTbl.add_row([pRuleTbl])
                elif 'traffic_steering' in actionsCat['category']:
                    spActions = listify(actionsCat['action'])
                    #pActionTblTbl.add_row(['spActions: %s\n' % spActions])
                    pActionTsTbl = PrettyTable(['rName', 'direction', '2ndSgs', 'applications', 'svcProf'])
                    pActionTsTbl.align = 'l'
                    #pprint_od(actionsCat)
                    spActions = listify(actionsCat['action'])
                    for spAction in spActions:
                        spActionName =    spAction.get('name', '')
                        spActionObjectId = spAction['objectId']
                        spActionDirection =  spAction.get('direction', '')
                        spAction2Sgs = ','.join([sg['name'] for sg in listify(spAction['secondarySecurityGroup'])]) \
                            if 'secondarySecurityGroup' in spAction else ''
                        spActionApps = ','.join([app['name'] for app in listify(spAction['applications']['application'])]) \
                            if 'applications' in spAction else ''
                        pActionTsTbl.add_row(['%s\n %s'%(spActionName,spActionObjectId),
                            spActionDirection, spAction2Sgs,
                            spActionApps, spAction['serviceProfile']['name']])

                    pActionTblTbl.add_row([pActionTsTbl])
                elif 'endpoint' in actionsCat['category']:
                    pActionEpTbl = PrettyTable(['name', 'action(Apply)', 'actionType(Block)'])
                    pActionEpTbl.align = 'l'
                    #pprint_od(actionsCat)
                    spActions = listify(actionsCat['action'])
                    for spAction in spActions:
                        # serviceName: "VMware Data Security"
                        # actionType: "FIM" | "ANTI_VIRUS" | "VULNERABILITY_MGMT" | "DATA_SECURITY"
                        spActionName =    spAction.get('name', '')
                        gIntAction =  spAction.get('serviceName', '')
                        gIntActType = spAction.get('actionType', '')
                        pActionEpTbl.add_row([spActionName, gIntAction, gIntActType])
                    pActionTblTbl.add_row([pActionEpTbl])
                elif 'eventcontrol' in actionsCat['category']:
                    spActions = listify(actionsCat['action'])
                    #pActionTblTbl.add_row(['spActions: %s\n' % spActions])
                    pActionTblTbl.add_row(['spActions:'])
                    for spAction in spActions:
                        pActionTblTbl.add_row([spAction['serviceName']])
        else:
            pActionTblTbl = ''

        if sp:
            ptbl.add_row([
                '\n '.join([sp['name'], sp['objectId']]),
                sp['precedence'],
                secGrpBindingNames, pActionTblTbl])

    def list(self, brief=False, fmt=None, nameGlob=None, PCache=''):    # Security_policy
        if brief or fmt=='brief':
            #self.showBrief([nameGlob], PCache=PCache)
            super(Security_policy, self).list(brief=True, fmt='brief', nameGlob=nameGlob, PCache=PCache)
        else:
            super(Security_policy, self).list(brief=False, fmt=fmt, nameGlob=nameGlob, PCache=PCache)

    def showBrief(self, spNames, PCache=''):               # class Security_policy()
        def key(vals):
            vals[0] = int(vals[0])
            return vals

        for spName in spNames:
            sps = self.find_by_name(spName, results=None, matchMethod='glob', PCache=PCache)
            sps = sorted(sps, key=lambda sp: sp['name'])
            ptbl = PrettyTable(['name/id', 'precedence', 'sg', 'action_applications'],
                sortby='precedence', sort_key=key, reversesort=True)
            ptbl.align = 'l'
            for sp in sps:
                self.showSpBrief(sp, ptbl)
            print(ptbl)

    def convertToT(self, name=None, prefix='NSXV_'):
        sps = self.find()
        for sp in listify(sps):
            if name and sp['name'] != name:
                continue
            #print(json.dumps(sp, indent=4))


            # Skip hidden policies
            if sp['extendedAttributes']:
                isHiddenSp=False
                for eAtt in listify(sp['extendedAttributes']):
                    if eAtt['extendedAttribute']['name'] == 'isHidden':
                        if eAtt['extendedAttribute']['value'] == 'true':
                            isHiddenSp = True
                if isHiddenSp==True:
                    #print("Hidden SP %s" %sp['name'])
                    continue
                    
            # the primary security group
            primarySgs = []
            if 'securityGroupBinding' in sp:
                for sg in listify(sp['securityGroupBinding']):
                    primarySgs.append(sg['name'])
            
            if len(primarySgs) == 0:
                # this means primary field is ANY
                #raise ValueError("Need to handle 0 primary SG in policy %s" %sp['name'])
                pass

            namedsection = []
            ipsection = []
            if 'actionsByCategory' in sp:
                for r in listify(sp['actionsByCategory']['action']):
                    if r['category'] != 'firewall':
                        raise ValueError('Policy action of %s not handled %s'
                                         %(r['category'], sp['name']))
                    secondarySgs = []
                    if 'secondarySecurityGroup' in r.keys():
                        for s in listify(r['secondarySecurityGroup']):
                            secondarySgs.append(s['name'])

                    apps = []
                    if 'applications' in r.keys():
                        if 'applicationGroup' in r['applications'].keys():
                            for apg in listify(r['applications']['applicationGroup']):
                                apps.append(apg['name'])
                        if 'application' in r['applications'].keys():
                            for app in listify(r['applications']['application']):
                                apps.append(app['name'])
                
                    rule = '--name \"%s\" --protocol IPV4_IPV6 --insert insert_bottom ' %(r['name'])
                    rulei = '--name \"%s\" --protocol IPV4_IPV6 --insert insert_bottom ' %(r['name'])
                    if 'description' in r.keys():
                        rule += '--description \"%s\" ' %( r['description'])
                        rulei += '--description \"%s\" ' %( r['description'])
                    if r['direction'] == 'inbound':
                        rule +='--direction IN '
                        rulei +='--direction IN '
                        if len(primarySgs) > 0:
                            rule += '--destinations ' + ' '.join('\"nsgroup:'+ sg +'\"' for sg in primarySgs)
                            rulei += '--destinations ' + ' '.join('\"nsgroup:'+ sg +'_ip\"' for sg in primarySgs)
                        if len(secondarySgs) > 0:
                            rule +=' --sources ' + ' '.join('\"nsgroup:'+ sg +'\"' for sg in secondarySgs)
                            rulei +=' --sources ' + ' '.join('\"nsgroup:'+ sg +'_ip\"' for sg in secondarySgs)
                    
                    elif r['direction'] == 'outbound':
                        rule +='--direction OUT '
                        rulei +='--direction OUT '
                        if len(primarySgs) > 0:
                            rule += '--sources ' + ' '.join('\"nsgroup:'+sg +'\"' for sg in primarySgs) 
                            rulei += '--sources ' + ' '.join('\"nsgroup:'+sg +'_ip\"' for sg in primarySgs) 
                        if len(secondarySgs) > 0:
                            rule +=' --destination ' + ' '.join('\"nsgroup:'+sg +'\"' for sg in secondarySgs) 
                            rulei +=' --destination ' + ' '.join('\"nsgroup:'+sg +'_ip\"' for sg in secondarySgs) 
                    elif r['direction'] == 'intra':
                        rule +='--direction IN_OUT '
                        rulei +='--direction IN_OUT '
                        if len(primarySgs) > 0:
                            rule += '--sources ' + ' '.join('\"nsgroup:'+sg +'\"' for sg in primarySgs) 
                            rulei += '--sources ' + ' '.join('\"nsgroup:'+sg +'_ip\"' for sg in primarySgs) 
                        if len(secondarySgs) > 0:
                            rule +=' --destination ' + ' '.join('\"nsgroup:'+sg +'\"' for sg in secondarySgs) 
                            rulei +=' --destination ' + ' '.join('\"nsgroup:'+sg +'_ip\"' for sg in secondarySgs) 
                    else:
                        raise ValueError("Firewall rule direction %s not handled %s"
                                         %(r['direction'], sp['name']))
                    if len(apps) > 0:
                        rule +=' --services ' + ' '.join('\"' + prefix+a+'\"' for a in apps)
                        rulei +=' --services ' + ' '.join('\"' + prefix+a+'\"' for a in apps)

                    if r['action'] == 'block':
                        rule+=' --action DROP'
                        rulei+=' --action DROP'
                    elif r['action'] == 'allow':
                        rule+=' --action ALLOW'
                        rulei+=' --action ALLOW'
                    elif r['action'] == 'REJECT':
                        rule+=' --action REJECT'
                        rulei+=' --action REJECT'
                    else:
                        raise ValueError("Firewall rule action %s not handled %s"
                                         %(r['action'], sp['name']))

                    rulename="firewall section rule add --section %s %s" %(sp['name'], rule)
                    namedsection.append(rulename)
                    ruleip="firewall section rule add --section %s_ipbased %s" %(sp['name'], rulei)
                    ipsection.append(ruleip)
            nameSect = "firewall section add --name \"%s\" --op insert_bottom" %(sp['name'])
            ipSect = "firewall section add --name \"%s_ipbased\" --op insert_bottom" %(sp['name'])
            if sp['description']:
                nameSect+=" --desc \"%s\"" %sp['description']
                ipSect+=" --desc \"%s\"" %sp['description']
            

            #print("#### %s %s####") %(sp['name'], sp['precedence'])
            print(nameSect)
            for i in namedsection:
                print(i)
            #print("#### %s_ipbased %s ####") %(sp['name'], sp['precedence'])
            print(ipSect)
            for i in ipsection:
                print(i)
                        

                            


                            
                        
                
    def apply(self, spName, sgNames):               # class Security_policy()
        sgNames = listify(sgNames)

        self.logger.info('Apply Security Policy %s to Security Groups %s' % (spName, sgNames))

        spXml = self.find_by_name(spName, results='raw')
        spOd = xmltodict.parse(spXml)

        spObjectId = self.find_by_name(spName, results='objectId', refresh=True)

        sgd = Security_group(self.mgr)
        spOd['securityPolicy']['securityGroupBinding'] =  []
        for sgName in sgNames:
            sgObjectId = sgd.find_by_name(sgName, refresh=False)
            if not sgObjectId:
                self.logger.warning('Security Group %s not found' % sgName)
                continue

            sgb = OD()
            sgb['objectId'] = sgObjectId; sgb['name'] = sgName
            sgb['scope'] = OD()
            sgb['scope']['id'] = 'globalroot-0'
            spOd['securityPolicy']['securityGroupBinding'].append(sgb)
            self.logger.debug('Binding Security Group %s to Security Policy %s' % (sgName, spName))

        spXml = xmltodict.unparse(spOd)
        r = self.doRestApi('update', objectId=spObjectId, data=spXml)
        self.logger.info('Applied Security Policy %s to Security Groups %s' %
            (spName, sgNames))

    def create0(self, spName, precedence, sgNames, fwAppSpecs=[], fwAgSpecs=[], fwSpecs=[]):
        ''' todo: add args: category, '''

        def populateActionOD(sgd, sg2Names):
            actionOd=OD()
            actionOd['@class'] = 'firewallSecurityAction'
            actionOd['name'] = name or 'fw-%05d' % random.randint(1,99999)
            actionOd['category'] = 'firewall'
            actionOd['isEnabled'] = 'true'
            actionOd['logged'] = 'false'
            actionOd['action'] = actionAction
            actionOd['direction'] = direction
            if sg2Names:
                actionOd['secondarySecurityGroup'] = []
                for sg2Name in sg2Names.split(','):
                    sg2ObjectId = sgd.find_by_name(sg2Name, logError=True)
                    if sg2ObjectId:
                        actionOd['secondarySecurityGroup'].append({'objectId':sg2ObjectId})
            return actionOd

        sgd = Security_group(self.mgr)
        appd = Application(self.mgr)
        agd = Application_group(self.mgr)

        spObjectId = self.find_by_name(spName)
        if spObjectId:
            self.logger.error('Cannot create security policy %s: policy already exist' % spName)
            return None

        sp = OD()
        sp['name'] = spName
        sp['precedence'] = precedence

        ############################################
        ### security grp this policy is bound to ###
        ############################################
        self.logger.info('Configure SP %s SGs: %s' % (spName, sgNames))
        if sgNames:
            sp['securityGroupBinding']=[]
            sgNames = sgNames.split(',')
            for sgName in sgNames:
                sgObjectId = sgd.find_by_name(sgName, logError=True)
                if sgObjectId:
                    sp['securityGroupBinding'].append({'objectId':sgObjectId})

        ############################################
        ### firewall rules config                ###
        ############################################
        sp['actionsByCategory'] = OD()
        sp['actionsByCategory']['category'] = 'firewall'
        sp['actionsByCategory']['action'] = []


        ############################################
        ### adding applications                  ###
        ############################################
        #fwAppSpecs = '<name>:<direction>:<action>:<sgs>:<apps>; ...'
        #fwAppSpecs = ':intra:allow:test:ICMP Echo,ICMP Echo Reply;   :outbound:allow:test,test1:HTTP,HTTPS;   :inbound:block::HTTP,HTTPS'
        fwAppSpecs = [e.strip() for e in fwAppSpecs.split(';')] if fwAppSpecs else []
        if fwAppSpecs:
            self.logger.info('Configure SP %s FW Apps: %s' % (spName, fwAppSpecs))
            for fwAppSpec in fwAppSpecs:
                name, direction, actionAction, sg2Names, appNames = fwAppSpec.split(':')
                actionOd = populateActionOD(sgd, sg2Names)
                actionOd['applications'] = OD({'application':[]})
                for appName in appNames.split(','):
                    appObjectId = appd.find_by_name(appName)
                    actionOd['applications']['application'].append({'objectId':appObjectId})
                sp['actionsByCategory']['action'].append(actionOd)


        ############################################
        ### adding applicationgroups             ###
        ############################################
        #fwAgSpecs = ':intra:allow:test:Microsoft Exchange 2010;   :outbound:block:test:vCenter5.x,Oracle Database'
        fwAgSpecs = [e.strip() for e in fwAgSpecs.split(';')] if fwAgSpecs else []
        if fwAgSpecs:
            self.logger.info('Configure SP %s FW AppGrps: %s' % (spName, fwAgSpecs))
            for fwAgSpec in fwAgSpecs:
                name, direction, actionAction, sg2Names, agNames = fwAgSpec.split(':')
                actionOd = populateActionOD(sgd, sg2Names)
                actionOd['applications'] = OD({'applicationGroup':[]})
                for agName in agNames.split(','):
                    agObjectId = agd.find_by_name(agName)
                    actionOd['applications']['applicationGroup'].append({'objectId':agObjectId})
                sp['actionsByCategory']['action'].append(actionOd)



        ########################################################
        ### adding applications/applicationgroups            ###
        ### if name exist in both ag and app, both are added ###
        ########################################################
        #fwSpecs = ':intra:allow:test:Microsoft Exchange 2010;   :outbound:block:test:vCenter5.x,Oracle Database;
        #    :intra:allow:test:ICMP Echo,ICMP Echo Reply;   :outbound:allow:test,test1:HTTP,HTTPS;   :inbound:block::HTTP,HTTPS'
        fwSpecs = [e.strip() for e in fwSpecs.split(';')] if fwSpecs else []
        if fwSpecs:
            self.logger.info('Configure SP %s FW Apps/AppGrps: %s' % (spName, fwSpecs))
            for fwSpec in fwSpecs:
                name, direction, actionAction, sg2Names, aNames = [
                    e.strip() for e in fwSpec.split(':')]
                actionOd = populateActionOD(sgd, sg2Names)
                actionOd['applications'] = OD({'application':[], 'applicationGroup':[]})
                for aName in aNames.split(','):
                    agObjectId = agd.find_by_name(aName)
                    if agObjectId:
                        actionOd['applications']['applicationGroup'].append({'objectId':agObjectId})
                    appObjectId = appd.find_by_name(aName)
                    if appObjectId:
                        actionOd['applications']['application'].append({'objectId':appObjectId})
                sp['actionsByCategory']['action'].append(actionOd)



        spTopOd = OD({'securityPolicy':sp})
        spsXml = xmltodict.unparse(spTopOd)
        self.logger.info('Posting SP %s creation request to NSX manager' % spName)
        r = self.doRestApi('config', objectId=spObjectId, data=spsXml)

    def _updActionAppDict(self, actionDict, rApps, rAgs, PCache='w'):
        appOids = [self._procGrpObjs0Val('AP|%s'%apName, PCache=PCache) for apName in rApps.split(',') if apName]
        agOids  = [self._procGrpObjs0Val('AG|%s'%agName, PCache=PCache) for agName in rAgs.split(',') if agName]
        if appOids:
            actionDict['applications'].update({'application': [{'objectId':oid} for oid in appOids]})
        if agOids:
            actionDict['applications'].update({'applicationGroup': [{'objectId':oid} for oid in agOids]})
        actionDict['invalidApplications'] = 'false'
        if not actionDict['applications']:
            del actionDict['applications']

    def _mkFwActionDict(self, rName, rAction, rEna, rLog, rDir, r2sg, rApps, rAgs, orgAction=None):
        TFMap = {'T':'true', 'F':'false', 't':'true', 'f':'false'}
        DirMap = {'I':'inbound', 'O':'outbound', 'X':'intra', 'i':'inbound', 'o':'outbound', 'x':'intra'}
        if orgAction:
            print(rName, rAction, rEna, rLog, rDir, rDir, r2sg, rApps, rAgs)
            if rAction: orgAction['action'] = rAction
            if rEna:    orgAction['isEnabled'] = TFMap[rEna[0]]
            if rLog:    orgAction['logged']    = TFMap[rLog[0]]
            if rDir:    orgAction['direction'] = DirMap[rDir] if rDir in DirMap else rDir
            if r2sg:    orgAction['secondarySecurityGroup'] = \
                self._procGrpObjsMod('G', orgAction.get('secondarySecurityGroup',{}), r2sg)
                #self._procGrpObjsMod('G', orgAction['secondarySecurityGroup'], r2sg)
            if rApps:   orgAction['applications'] = \
                self._procGrpObjsMod('AP', orgAction.get('applications',{}), rApps, shim='application')
                #self._procGrpObjsMod('AP', orgAction['applications'], rApps, shim='application')
            #if rAgs:    orgAction['applicationgroups'] =
            #    self._procGrpObjsMod('AG', orgAction['applications'], rApps, shim='application')
            return orgAction
        else:
            actionDict = {
                '@class':    'firewallSecurityAction',
                'category':  'firewall',
                'name':      rName,
                'action':    rAction,
                'isEnabled': TFMap[rEna[0]],
                'logged':    TFMap[rLog[0]],
                'direction': DirMap[rDir] if rDir in DirMap else rDir,
                'secondarySecurityGroup': [
                    {'objectId': self._procGrpObjs0Val('G|%s'%sgName)}
                        for sgName in r2sg.split(',') ] if r2sg else [],
                'applications': {}
            }
            self._updActionAppDict(actionDict, rApps, rAgs, PCache='r')
            return actionDict

    def _mkNiActionDict(self, rName, rEna, rLog, rRedir, rDir, r2sg, rSiProf, rApps, rAgs, orgAction=None):
        TFMap = {'T':'true', 'F':'false', 't':'true', 'f':'false'}
        DirMap = {'I':'inbound', 'O':'outbound', 'X':'intra', 'i':'inbound', 'o':'outbound', 'x':'intra'}
        #if orgAction:
        #    print('_mkNiActionDict() orgAction["applications"] ====>'); pprint_od(orgAction['applications'])
        if orgAction:
            #print(rName, rEna, rLog, rRedir, rDir, r2sg, rSiProf, rApps, rAgs)
            if rEna:    orgAction['isEnabled'] = TFMap[rEna[0]]
            if rLog:    orgAction['logged']    = TFMap[rLog[0]]
            if rRedir:  orgAction['redirect']  = TFMap[rRedir[0]]
            if rDir:    orgAction['direction'] = DirMap[rDir] if rDir in DirMap else rDir
            if rSiProf: orgAction['serviceProfile']  = {'objectId': self._procGrpObjs0Val('SIP|%s'%rSiProf)}
            if r2sg:    orgAction['secondarySecurityGroup'] = \
                self._procGrpObjsMod('G', orgAction['secondarySecurityGroup'], r2sg)
            if rApps:   orgAction['applications'] = \
                self._procGrpObjsMod('AP', orgAction['applications'], rApps, shim='application')
            #if rAgs:    orgAction['applicationgroups'] =
            #    self._procGrpObjsMod('AP', orgAction['applications'], rApps, shim='application')
            return orgAction
        else:
            actionDict = {
                '@class':    'trafficSteeringSecurityAction',
                'category':  'traffic_steering',
                'name':      rName,
                'isEnabled': TFMap[rEna[0]],
                'logged':    TFMap[rLog[0]],
                'redirect':  TFMap[rRedir[0]],
                'direction': DirMap[rDir] if rDir in DirMap else rDir,
                'serviceProfile': {'objectId': self._procGrpObjs0Val('SIP|%s'%rSiProf)},
                'secondarySecurityGroup': [
                    {'objectId': self._procGrpObjs0Val('G|%s'%sgName)} for sgName in r2sg.split(',') ] if r2sg else [],
                'applications': {}
            }
            self._updActionAppDict(actionDict, rApps, rAgs)
            return actionDict

    def _parseCatOpts(self, catsOptsSpec):
        ''' catsOptsSpec examples:
                fw:useSid
                fw:useSid; ni:tcpStrict
                fw: tcpStrict, useSid
        '''
        attrByCat = {}
        TFMap = {True:'true', False:'false'}

        attrByCatDict = { "attributesByCategory": [] }
        #print('catsOptsSpec >>>', catsOptsSpec)
        for catOptsSpec in catsOptsSpec.split(';'):
            if not catOptsSpec: continue
            #print('catOptsSpec >>>', catOptsSpec)
            catSpec, optsSpec = catOptsSpec.split(':')
            #print('catSpec, optsSpec = %s, %s' % ( catSpec, optsSpec ))
            opts = [o.lower() for o in optsSpec.split(',')]
            opts_l = [o.lower() for o in opts]
            stateless = 'stateless' in opts_l
            tcpStrict = 'tcpstrict' in opts_l
            useSid = 'usesid' in opts_l
            attrByCatDict['attributesByCategory'].append( {
                "category": self.rCatMap[catSpec],
                "categoryAttribute": []
            },)
            attrByCats = attrByCatDict['attributesByCategory'][-1]['categoryAttribute']
            if stateless:
                attrByCats.append( {"attributeName":"stateless", "attributeValue":TFMap[stateless]} )
            if tcpStrict:
                attrByCats.append( {"attributeName":"tcpStrict", "attributeValue":TFMap[tcpStrict]} )
            if useSid:
                attrByCats.append( {"attributeName":"useSid", "attributeValue":TFMap[useSid]} )
        # pprint_json( attrByCatDict)
        return attrByCatDict

    def create(self, spSpec, spRulesSpec, spRulesOpts, PCache='w'):             # Security_policy
        ''' '''
        fields = 'spName,spPrec,spSgs'
        comps = unpackCSSpec(spSpec, ':', fields.split(','), self.mgr.logger)
        exec('%s = comps' % fields)
        if not spPrec:
            self.logger.error('SP precedence must be specified')
            self.logger.error('Abort SP "%s" creation' % spName)
            return

        self.logger.info('Creating SP %s %s %s' % (spName, spPrec,spSgs))

        rCatMap = {'fw':'firewall', 'gi':'endpoint', 'ni': 'traffic_steering'}

        catSet = set()
        spDict = {
            'securityPolicy': {
                'name': spName,
                'precedence': spPrec,
                'securityGroupBinding': [{'objectId': self._procGrpObjs0Val('G|%s'%sgName)}
                    for sgName in spSgs.split(',')] if spSgs.strip() else [],
                'actionsByCategory': []
            }
        }
        catOptDict = self._parseCatOpts(spRulesOpts)
        # pprint_json(catOptDict); exit()
        if catOptDict:
            spDict['securityPolicy'].update(catOptDict)
        #pprint_json(spDict); exit()

        for spRuleSpec in spRulesSpec.split(';'):
            spRuleSpec = spRuleSpec.strip()
            if not spRuleSpec: continue
            rCatSpec = spRuleSpec.split(':')[0]
            self.logger.info3('rCatSpec=%s'%rCatSpec)

            if rCatSpec=='ni':
                fields = 'rCatSpec,rName,rRedir,rEna,rLog,rDir,r2sg,rApps,rAgs,rSiProf'
                comps = unpackCSSpec(spRuleSpec, ':', fields.split(','), self.mgr.logger)
                exec('%s = comps' % fields)
                if not rName:
                    rName = 'nir-%s' % sha256(spRuleSpec).hexdigest()[:8]
                self.logger.info4('%s %s %s %s %s %s %s %s %s' % (
                    rName,rRedir,rEna,rLog,rDir,r2sg,rApps,rAgs,rSiProf))
                if rCatSpec not in catSet:
                    catSet.add(rCatSpec)
                    rCat = rCatMap[rCatSpec]
                    niActionsByCategory = {
                        'category': rCat,
                        'action': [],
                    }
                    spDict['securityPolicy']['actionsByCategory'].append(niActionsByCategory)
                    niActions = niActionsByCategory['action']
                niActions.append(self._mkNiActionDict(rName, rEna, rLog, rRedir, rDir, r2sg, rSiProf, rApps, rAgs))
            elif rCatSpec=='fw':
                fields = 'rCatSpec,rName,rAction,rEna,rLog,rDir,r2sg,rApps,rAgs,rTag'
                comps = unpackCSSpec2(spRuleSpec, ':', fields.split(','), self.mgr.logger)
                exec('%s = comps' % fields)
                if not rName:
                    rName = 'fwr-%s' % sha256(spRuleSpec).hexdigest()[:8]
                #print(rCatSpec,rName,rAction,rEna,rLog,rDir,r2sg,rApps,rAgs,rTag); exit()
                if rCatSpec not in catSet:
                    catSet.add(rCatSpec)
                    rCat = rCatMap[rCatSpec]
                    fwActionsByCategory = {
                        'category': rCat,
                        'action': [],
                    }
                    spDict['securityPolicy']['actionsByCategory'].append(fwActionsByCategory)
                    fwActions = fwActionsByCategory['action']
                #print('0>>>>', r2sg.strip('!~ '))
                #print('1>>>>', any([s.strip()[0] in ['!','~'] for s in r2sg.split(',')]))
                #print('2>>>>', [sgName.strip('!~ ') for sgName in r2sg.split(',') if sgName.strip()])
                #print('3>>>>', [
                #    type(
                #    self._procGrpObjs('G|%s'%(sgName.strip('!~')))
                #    )
                #    for sgName in r2sg.split(',') if sgName.strip()])
                #print('4>>>>', [
                #    self._procGrpObjs('G|%s'%(sgName.strip('!~')))[0]
                #    for sgName in r2sg.split(',') if sgName.strip()])
                #print('5>>>>', [
                #    self._procGrpObjs('G|%s'%(sgName.strip('!~')) )[0]['value']
                #    for sgName in r2sg.split(',') if sgName.strip()])
                #print('6>>>>', [
                #    {'objectId': self._procGrpObjs('G|%s'%(sgName.strip('!~ ')) )[0]['value']}
                #    for sgName in r2sg.split(',') if sgName.strip()])
                actionDict = {
                    '@class': 'firewallSecurityAction',
                    'category': rCat,
                    'name': rName,
                    'action': rAction,
                    'isEnabled': rEna,
                    'logged': rLog,
                    'direction': rDir,
                    'tag': rTag,
                    'outsideSecondaryContainer': any([s.strip()[0] in ['!','~'] for s in r2sg.split(',')]),
                    'secondarySecurityGroup': [
                        {'objectId': self._procGrpObjs('G|%s'%(sgName.strip('!~ ')))[0]['value']}
                        for sgName in r2sg.split(',') if sgName.strip()],
                    'applications': {}
                }
                self._updActionAppDict(actionDict, rApps, rAgs, PCache=PCache)
                fwActions.append(actionDict)
            elif rCatSpec=='gi':
                fields = 'rCatSpec,rName,rAction,rEna,rLog,sProf'
                comps = unpackCSSpec(spRuleSpec, ':', fields.split(','), self.mgr.logger)
                exec('%s = comps' % fields)
                print(rCatSpec,rName,rAction,rEna,rLog,sProf)
                if rCatSpec not in catSet:
                    catSet.add(rCatSpec)
                    rCat = rCatMap[rCatSpec]
                    giActionsByCategory = {
                        'category': rCat,
                        'action': [],
                    }
                    spDict['securityPolicy']['actionsByCategory'].append(giActionsByCategory)
                    giActions = giActionsByCategory['action']
                giActions.append({
                    '@class': 'endpointSecurityAction',
                    'name': rName,
                    'isEnabled': rEna,
                    'logged': rLog,
                    'action': rAction,
                    'category': rCat,
                })

        self.logger.info1('done parsing all ruleSpec')
        self.logger.info4('sp od = %s', pformat(spDict))
        xml = xmltodict.unparse(spDict)
        r = self.doRestApi('config', data=xml)
        #pprint_xml(xml)
        self.logger.info('Created  SP %s' % spName)

    def modify(self, spModSpec, spRulesModSpec, refresh=False, PCache=''): # Security_policy
        '''
            # Security_policy.modify(spRulesModSpec)
            EBNF syntax:
                spRulesModSpec ::= spRuleModSpec, {";", spRuleModSpec}
                spRuleModSpec ::= ( spFwRulesModSpec | spNiRulesModSpec | spGiRulesModSpec )

                spNiRulesModSpec ::= spNiRuleModSpec, {";", spNiRuleModSpec}
                spNiRuleModSpec ::= ( addNiRule | delNiRule | modNiRule )
                addNiRule ::= "+", addNiRuleSpec
                delNiRule ::= "-", delNiRuleSpec
                modNiRule ::=      modNiRuleSpec
                delNiRuleSpec ::= [rName], ":", [rOid]
                addNiRuleSpec ::= rName, "::", redirect, ":", enable, ":", log, ":", direction,
                                  ":", secondSgs, ":", apps, ":", ags, ":", profile
                modNiRuleSpec ::= [rName], ":", [rOid,] ":", [redirect], ":", [enable], ":", [log],
                                  ":", [direction], ":", [secondSgsModSpec], ":", [appsModSpec],
                                  ":", [agsModSpec], ":", [profile]

                spFwRulesModSpec ::= spFwRuleModSpec, {";", spFwRuleModSpec}
                spFwRuleModSpec ::= ( addFwRule | delFwRule | modFwRule )
                addFwRule ::= "+", addFwRuleSpec
                delFwRule ::= "-", delFwRuleSpec
                modFwRule ::=      modFwRuleSpec
                delFwRuleApec ::= [rName], ":", [rOid]
                addFwRuleSpec ::= rName, ":", action, ":", enable, ":", log, ":", direction,
                                  ":", secondSgs, ":", apps, ":", ags
                modFwRuleSpec ::= [rName], ":", [rOid], ":", [action], ":", [enable], ":", [log],
                                  ":", [direction], ":", [secondSgsModSpec], ":", [appsModSpec],
                                  ":", [agsModSpec]

                action    ::= "allow" | "block" | "reject"

                spGiRulesModSpec ::= spGiRuleModSpec, {";", spGiRuleModSpec}
                spGiRuleModSpec ::= ( addGiRule | delGiRule | modGiRule )
                addGiRule ::= "+", spGiSpec
                delGiRule ::= "-", rName, ":", rOid
                modGiRule ::= rName, ":", rOid, ":", action, ":", enable, ":", log, ":", serviceProf

                addGiRule ::= "+", addGiRuleSpec
                delGiRule ::= "-", delGiRuleSpec
                modGiRule ::=      modGiRuleSpec
                delGiRuleApec ::= [rName], ":", [rOid]
                addGiRuleSpec ::= [rName], ":", [rOid], ":", [action], ":", [enable], ":", [log], ":", [serviceProf]
                modGiRuleSpec ::= [rName], ":", [rOid], ":", [action], ":", [enable], ":", [log], ":", [serviceProf]

                apps        ::= [app], {app}
                ags         ::= [ag], {ag}
                sgs         ::= [sg], {sg}
                secondSgs   ::= sgs
                direction   ::= "inbound" | "I" | "outbound" | "O" |"intra" | "X"
                enable      ::= trueOrFalse
                log         ::= trueOrFalse
                redirect    ::= trueOrFalse
                trueOrFalse ::= "true" | "T" | "false" |"F"
                pSgsModSpec ::= sgsModSpec
                secondSgsModSpec ::= sgsModSpec
                sgsModSpec  ::= ("+"|"-"), sg, {",", ("+"|"-"), sg}
                agsModSpec  ::= ("+"|"-"), ag, {",", ("+"|"-"), ag}
                appsModSpec ::= ("+"|"-"), app, {",", ("+"|"-"), app}
                name        ::= IDENTIFIER
                ap          ::= IDENTIFIER
                ag          ::= IDENTIFIER
                sg          ::= IDENTIFIER
                profile     ::= IDENTIFIER
                serviceProf ::= IDENTIFIER
            SUMARY:
                <spRulesModSpec> <spRuleModSpec>, {;<spRuleModSpec>}
                <spRuleModSpec> (<spFwRulesModSpec>|<spNiRulesModSpec>|<spGiRulesModSpec>)

                <delNiRuleSpec> [<rName>]:[<rOid>]
                <addNiRuleSpec> <rName>::<redirect>:<nable>:<og>:<irection>:<econdSgs>:<pps>:<gs>:<rofile>
                <modNiRuleSpec> [<rName>]:[<rOid>]:[<redirect>]:[<enable>]:[<log>]:[<direction>]:\
                                [<secondSgsModSpec>]:[<appsModSpec>]:[<agsModSpec>]:[<profile>]
            EXAMPLE:
                ' ni:simon-sp-14159265-001:::::I:-panimod1_sg2,+panimod1_sg3:+DNS,-SSH,-LDAP:+Heartbeat:panzone;
                  ni:simon-sp-14159265-101:::::I:panimod1_sg2:LDAP,SSH::panzone;
                 +ni:simon-sp-14159265-111::T:F:F:I:panimod1_sg3,panimod1_sg2:LDAP,HTTPS:Heartbeat:panzone;
                 -ni:simon-sp-14159265-102:;
                 +fw:simon-sp-40342-001:allow:true:true:inbound:testSG-100:SSH:;
                 +fw:simon-sp-40342-002::allow:true:true:inbound:testSG-100:SSH:'

        '''
        fields = 'spName,spObjId,spPrec,spSgModSpec'
        comps = unpackCSSpec(spModSpec, ':', fields.split(','), self.mgr.logger)
        #print(fields, comps)
        exec('%s = comps' % fields)
        #print(spName,spPrec,spSgModSpec)

        if not spObjId:
            spObjId = self.find_by_name(spName, PCache=PCache)
        self.logger.info('Getting  SP %s' % spName)
        r = self.doRestApi('getone', objectId=spObjId)
        curSpDict = xmltodict.parse(r.text)
        #pprint_od(curSpDict)
        curSp = curSpDict['securityPolicy']
        curSpObjectId = curSp['objectId']
        curSpRevision = curSp['revision']
        self.logger.info('Modifying SP %s' % spName)

        spRulesModSpecs = spRulesModSpec.split(';')
        spFwRulesModSpec = [r.strip() for r in filter(lambda x: 'fw' in x.split(':')[0], spRulesModSpecs)]
        spNiRulesModSpec = [r.strip() for r in filter(lambda x: 'ni' in x.split(':')[0], spRulesModSpecs)]
        spGiRulesModSpec = [r.strip() for r in filter(lambda x: 'gi' in x.split(':')[0], spRulesModSpecs)]

        niActionsByCategory = { 'category': 'traffic_steering', 'action': [], }
        fwActionsByCategory = { 'category': 'firewall',         'action': [], }
        giActionsByCategory = { 'category': 'endpoint',         'action': [], }

        spDictAactionsByCategory= listify(
            copy.deepcopy(curSp['actionsByCategory'])
                if'actionsByCategory' in curSp else [])
        actCats = [ac['category'] for ac in spDictAactionsByCategory]
        for modSpec,actByDict,actCat in zip(
                    [spFwRulesModSpec,    spNiRulesModSpec,    spGiRulesModSpec],
                    [fwActionsByCategory, niActionsByCategory, giActionsByCategory],
                    ['firewall',          'traffic_steering',  'endpoint']):
            if modSpec and actCat not in actCats:
                spDictAactionsByCategory.append(actByDict)

        catSet = set()
        #pprint_od(curSp)
        spDict = {
            'securityPolicy': {
                'name':     spName,
                'objectId': spObjId,
                'revision': curSpRevision,
                'precedence': spPrec if spPrec else curSp['precedence'],
                'securityGroupBinding': self._procGrpObjsMod('G',
                    curSp['securityGroupBinding'] if 'securityGroupBinding' in curSp else None,
                    spSgModSpec, refresh=refresh),
                'actionsByCategory': spDictAactionsByCategory,
            }
        }

        for actByCat in listify(spDict['securityPolicy']['actionsByCategory']):
            if actByCat['category']=='firewall':
                if spFwRulesModSpec:
                    for spFwRuleModSpec in spFwRulesModSpec:
                        if spFwRuleModSpec[0]=='+':
                            #rName, "::", action, ":", enable, ":", log, ":", direction, ":", secondSgs, ":", apps, ":", ags
                            fields = 'rCatSpec,rName,rAction,rEna,rLog,rDir,r2sg,rApps,rAgs'
                            comps = unpackCSSpec(spFwRuleModSpec, ':', fields.split(','), self.mgr.logger)
                            exec('%s = comps' % fields)
                            if not rName:
                                rName = 'fwr-%s' % sha256(spFwRuleModSpec[1:]).hexdigest()[:8]
                            self.logger.info2('ADDING FW rule: %s %s %s %s %s %s %s %s' % (
                                rName,rAction,rEna,rLog,rDir,r2sg,rApps,rAgs))
                            actions = listify(actByCat['action'])
                            actions.append(self._mkFwActionDict(rName, rAction, rEna, rLog, rDir,
                                    r2sg, rApps, rAgs))
                            actByCat['action'] = actions
                        elif spFwRuleModSpec[0] in ['-','!','~']:
                            dummy, rNameRm, rIdRm = spFwRuleModSpec[1:].split(':')
                            actions = listify(actByCat['action'])
                            self.logger.info2('REMOVING FW rule: %s %s' % (rNameRm, rIdRm))
                            actions = [a for a in actions if not (
                                (rNameRm and not rIdRm and isGlobMatched(rNameRm,a['name'])) or
                                (rIdRm and 'objectId' in a and rIdRm==a['objectId'])) ]
                            actByCat['action'] = actions
                        else:   # modify existing rule -- not yet implemented
                            continue
                            fields = 'rCatSpec,rName,rOid,rAction,rEna,rLog,rDir,r2sg,rApps,rAgs'
                            comps = unpackCSSpec(spFwRuleModSpec, ':', fields.split(','), self.mgr.logger)
                            exec('%s = comps' % fields)
                            self.logger.info2('MODIFYING FW rule: %s %s %s %s %s %s %s %s %s' % (
                                rName,rOid,rAction,rEna,rLog,rDir,r2sg,rApps,rAgs))
                            targetAction = {}
                            actions = listify(actByCat['action'])
                            for a in actions:
                                if a['name']==rName or ('objectId' in a and a['objectId']==rOid):
                                    targetAction = a
                                    #pprint_od(a)
                            if targetAction:
                                self.logger.info2('MODIFYING FW rule: %s FOUND' % rName)
                                actionDict = self._mkFwActionDict(rName, rAction, rEna, rLog, rDir,
                                    r2sg, rApps, rAgs, orgAction=targetAction)
                                #pprint_od(actionDict)
                                #pprint_xml(xmltodict.unparse({'action':actionDict}))
                                actByCat['action'] = actions
                            else:
                                self.logger.warning('MODIFYING NI rule: %s NOT FOUND' % rName)

            elif actByCat['category']=='traffic_steering':
                if spNiRulesModSpec:
                    for spNiRuleModSpec in spNiRulesModSpec:
                        if spNiRuleModSpec[0]=='+':
                            fields = 'rCatSpec,rName,rOid,rRedir,rEna,rLog,rDir,r2sg,rApps,rAgs,rSiProf'
                            comps = unpackCSSpec(spNiRuleModSpec, ':', fields.split(','), self.mgr.logger)
                            exec('%s = comps' % fields)
                            if not rName:
                                rName = 'nir-%s' % sha256(spNiRuleModSpec[1:]).hexdigest()[:8]
                            self.logger.info2('ADDING NI rule: %s %s %s %s %s %s %s %s %s %s' % (
                                rName,rOid,rRedir,rEna,rLog,rDir,r2sg,rApps,rAgs,rSiProf))
                            actions = listify(actByCat['action'])
                            actions.append(self._mkNiActionDict(rName, rEna, rLog, rRedir, rDir,
                                    r2sg, rSiProf, rApps, rAgs))
                            actByCat['action'] = actions
                        elif spNiRuleModSpec[0] in ['-','!','~']:
                            dummy, rNameRm, rIdRm = spNiRuleModSpec[1:].split(':')
                            actions = listify(actByCat['action'])
                            self.logger.info2('REMOVING NI rule: %s %s' % (rNameRm, rIdRm))
                            actions = [a for a in actions if not (
                                (rNameRm and not rIdRm and isGlobMatched(rNameRm,a['name'])) or
                                (rIdRm and 'objectId' in a and rIdRm==a['objectId'])) ]
                            actByCat['action'] = actions
                        else:   # modify existing rule
                            fields = 'rCatSpec,rName,rOid,rRedir,rEna,rLog,rDir,r2sg,rApps,rAgs,rSiProf'
                            comps = unpackCSSpec(spNiRuleModSpec, ':', fields.split(','), self.mgr.logger)
                            exec('%s = comps' % fields)
                            self.logger.info2('MODIFYING NI rule: %s %s %s %s %s %s %s %s %s %s' % (
                                rName,rOid,rRedir,rEna,rLog,rDir,r2sg,rApps,rAgs,rSiProf))
                            targetAction = {}
                            actions = listify(actByCat['action'])
                            for a in actions:
                                if a['name']==rName or ('objectId' in a and a['objectId']==rOid):
                                    targetAction = a
                                    #pprint_od(a)
                            if targetAction:
                                self.logger.info2('MODIFYING NI rule: %s FOUND' % rName)
                                actionDict = self._mkNiActionDict(rName, rEna, rLog, rRedir, rDir,
                                    r2sg, rSiProf, rApps, rAgs, orgAction=targetAction)
                                #pprint_od(actionDict)
                                #pprint_xml(xmltodict.unparse({'action':actionDict}))
                                actByCat['action'] = actions
                            else:
                                self.logger.warning('MODIFYING NI rule: %s NOT FOUND' % rName)
            elif actByCat['category']=='endpoint':
                if spGiRulesModSpec:
                    print('gi:', spGiRulesModSpec)


        self.logger.info1('done parsing all ruleSpec')
        #pprint(spDict)
        xml = xmltodict.unparse(spDict)
        r = self.doRestApi('update', objectId=curSpObjectId, data=xml)
        #print('r.status_code = %s' % r.status_code)
        #pprint_xml(xml)
        self.logger.info('Modified SP %s' % spName)


class Distributed_firewall(Network_element):
    rest_api = {
        # get params: ruleType=LAYER3&name=ngcSec001 (full secion w/rules)
        'get':            Api('get',    '"/api/4.0/firewall/globalroot-0/config?%s"%params', ''),
        'delall':         Api('delete',  '/api/4.0/firewall/globalroot-0/config', ''),
        # get_section params: /layer3sections?name=testSec001 (section level info only)
        'get_section':    Api('get',    '"/api/4.0/firewall/globalroot-0/config/%s"%params', ''),
        'get_sectByName': Api('get',    '"/api/4.0/firewall/globalroot-0/config/layer%ssections?name=%s"%(layer,sectName)', ''),
        'create_section': Api('post',   '"/api/4.0/firewall/globalroot-0/config/%s"%params', ''),
        'modify_section': Api('put',    '"/api/4.0/firewall/globalroot-0/config/%s"%params', ''),
        'delete_section': Api('delete', '"/api/4.0/firewall/globalroot-0/config/%s"%params', ''),
    }
    rKeys = ['firewallConfiguration', 'layer3Sections']
    rKeys = ['firewallConfiguration']
    list_brief_keys = [
        'contextId',
        ['layer3RedirectSections','section', '@name'],
        ['layer3Sections','section', '@name', 'section'],
        ['layer2Sections','section', '@name'],
    ]

    def _procApts(self, grpObjsSpec):
        ''' apply_to Sepcification '''
        if not grpObjsSpec or grpObjsSpec.upper()=='DFW':
            return [OD({'type':'DISTRIBUTED_FIREWALL','value':'DISTRIBUTED_FIREWALL'})]
        elif grpObjsSpec.upper()=='ANY':
            return [OD({'type':'ANY','value':'ANY'})]
        elif grpObjsSpec.upper()=='ALL_PROFILE_BINDINGS':
            return [OD({'type':'ALL_PROFILE_BINDINGS','value':'ALL_PROFILE_BINDINGS'})]
        else:
            return self._procGrpObjs(grpObjsSpec)

    def _mkDfwNiRuleOd(self, ruleSpec, PCache='w'):
        '''
        layer3RedirectSections:
        section:
        -   '@generationNumber': '1498015342379'
            '@id': '1013'
            '@managedBy': NSX Service Composer
            '@name': 'sp100 :: NSX Service Composer - Network Introspection'
            '@timestamp': '1498015342379'
            '@type': L3REDIRECT
            description: null
            rule:
                '@disabled': 'true'
                '@id': '1022'
                '@logged': 'false'
                '@managedBy': NSX Service Composer
                action: redirect
                appliedToList:
                    appliedTo:
                        isValid: 'true'
                        name: ALL_PROFILE_BINDINGS
                        type: ALL_PROFILE_BINDINGS
                        value: ALL_PROFILE_BINDINGS
                direction: inout (in, out)
                name: nis1
                packetType: any (ipv4, ipv6)
                tag: simonTag
                sectionId: '1013'
                siProfile:
                    clientHandle: null
                    description: Palo Alto Networks profile
                    isUniversal: 'false'
                    name: skt-zone
                    objectId: serviceprofile-1
                    revision: '0'
                    universalRevision: '0'
                siRuleIdList:
                    siRuleId: '593'
                stateless: 'false'
        '''
        appd = self.mgr.objd(Application, recreate=False)
        agd = self.mgr.objd(Application_group, recreate=False)

        fields = 'rCat,rName,rDir,siProf,rLog,rApts,rSrcs,rDsts,rAppNames,rAgNames'
        ''' rDir: inout, in, out
            rApts: '' (default=ALL), ALL, (ignored, always ALL)
            rSrcs: '' (default=ANY), ANY, GroupContainerSpec
            dSrcs: '' (default=ANY), ANY, GroupContainerSpec
        '''
        comps = unpackCSSpec(ruleSpec, ':', fields.split(','), self.mgr.logger)
        if not comps:
            return OD()
        exec('%s = comps' % fields)

        if rSrcs=='' or rSrcs.upper()=='ANY': rSrcs=''
        if rDsts=='' or rDsts.upper()=='ANY': rDsts=''
        rApts='ALL_PROFILE_BINDINGS'
        if not rName:
            rName = 'ni-%s' % sha256(ruleSpec).hexdigest()[:8]
        ruleDict = {
            '@disabled': 'false',
            '@logged':   'true' if rLog.lower().startswith('t') else 'false',
            '@type':     'L3REDIRECT',
            'action':    'redirect',
            'packetType':'any',
            'name':      rName,
            'direction': rDir,
        }
        ruleDict['services'] = {'service':[]}
        for rAppName in rAppNames.split(','):
            #rAppName = urllib2.unquote(rAppName)
            if not rAppName: continue
            appObjectId = appd.find_by_name(rAppName, PCache=PCache)
            #sgd  = self.mgr.objd(Security_group, recreate=True)
            #print('rAppName,appObjectId = %s, %s' % (rAppName,appObjectId ))
            ruleDict['services']['service'].append(
                {'value':appObjectId})
                #{'type':'Application', 'value':appObjectId})
        for rAgName in rAgNames.split(','):
            if not rAgName: continue
            agObjectId = agd.find_by_name(rAgName, PCache=PCache)
            #print('rAgName,agObjectId = %s, %s' % (rAgName,agObjectId ))
            ruleDict['services']['service'].append(
                {'value':agObjectId})
                #{'type':'ApplicationGroup', 'value':agObjectId})
        ruleDict['appliedToList'] = { 'appliedTo': self._procApts(rApts) }
        if rSrcs:
            excluded = rSrcs[0] in ['!','~']
            tSrcs = rSrcs[1:] if excluded else rSrcs
            ruleDict['sources'] = {
                '@excluded': excluded,
                'source': self._procGrpObjs(tSrcs)
            }
        if rDsts:
            #if rDsts.startswith('!'): rDsts = rDsts[1:]
            excluded = rDsts[0] in ['!','~']
            tDsts = rDsts[1:] if excluded else rDsts
            ruleDict['destinations'] = {
                '@excluded': excluded,
                'destination': self._procGrpObjs(tDsts)
            }
        ruleDict['siProfile'] = {'objectId':self._procGrpObjs0Val('SIP|%s'%siProf)}
        return ruleDict

    def _mkDfwFwRuleOd(self, ruleSpec, setDefault=True):
        '''
            # Distributed_firewall._mkDfwFwRuleOd(rulesSpec)
            <dfwRulesSpec>   ::= <dfwFwRulesSpec> | <dfwNiRulesSpec> | <dfwL2RulesSpec>

            <dfwFwRulesSpec> ::= <dfwFwRuleSpec> { ";" <dfwFwRuleSpec> }
            <dfwFwRuleSpec>  ::= "fw:" <name> ":" <direction> ":" <action> ":" <logFlag> ":" <applyTo> ":" <srcs> ":" <dsts> ":" <apps> ":" <ags>

            <dfwL2RulesSpec> ::= <dfwL2RuleSpec> { ";" <dfwL2RuleSpec> }
            <dfwL2RuleSpec>  ::= "l2:" <name> ":" <direction> ":" <action> ":" <logFlag> ":" <applyTo> ":" <srcs> ":" <dsts> ":" <apps> ":" <ags>

            <dfwNiRulesSpec> ::= <dfwNiRuleSpec> { ";" <dfwNiRuleSpec> }
            <dfwNiRuleSpec>  ::= 'ni:" <name> ":" <direction> ":" <siPro> ":" <logFlag> ":" <applyTo> ":" <srcs> ":" <dsts> ":" <apps> ":" <ags>

                <direction>  ::= "inout" | "in" | "out"
                <action>     ::= "allow" | "block" | "reject"
                <logFlag>    ::= "T" | "F"  | ""
                <applyTo>    ::= <groupsSpec>
                <srcs>       ::= <groupsSpec>
                <dsts>       ::= <groupsSpec>
                <groupsSpec> ::= ["!"|"~"] <groupSpec> { "," ["!"|"~"]<groupSpec> }
                <groupSpec>  ::=
                    "A|"  <vApp Name> |
                    "AP|" <Application Name> |
                    "AG|" <ApplicationGroup Name> |
                    "C|"  <Cluster Name> |
                    "D|"  <Datacenter Name> |
                    "DG|" <DirectoryGroup
                    "E|"  <Edge Name> |
                    "G|"  <SecurityGroup Name> |
                    "H|"  <Host Name> |
                    "I|"  <IPset Name> |
                    "L|"  <LogicalSwitch Name> |
                    "M|"  <MacSet Name> |
                    "N|"  <Nework (PG) Name> |
                    "NO|" <OS Name> |
                    "NV|" <VM Name> |
                    "NC|" <Computer Name> |
                    "NT|" <SecurityTag Name> |
                    "P|"  <dvPg Name> |
                    "SIP|"<SIProfile
                    "T|"  <SecurityTag Name> |
                    "V|"  <VirtualMachine Name> |
                    "VN|" <VNic Name> |
                    "R|"  <ResourcePool Name> |
                    "EN|" <entity Name> |

                <apps>       ::= <appName> { "," <apps> }
                <ags>        ::= <agName> { "," <ags> }

            Summary:
                <dfwFwRuleSpec>  ::= 'fw:<name>:<direction>:<action>:<logFlag>:<applyTo>:<srcs>:<dsts>:<apps>:<ags>; ...'
                <dfwNiRuleSpec>  ::= 'ni:<name>:<direction>:<siPro>:<logFlag>:<applyTo>:<srcs>:<dsts>:<apps>:<ags>; ...'
            Example:
                <dfwRulesSpec> = '<name>:<direction>:<action>:<logFlag>:<applyTo>:<srcs>:<dsts>:<apps>:<ags>; ...'
                'fw:apiSec999-000:in:allow:F:I|IPSET-192.168.0.0/24:C|cluster1,C|mgmt:G|testSG-100:HTTP,HTTPS:testAG-100;
                 fw:apiSec999-001:out:allow:F:C|cluster-test:C|cluster-test:G|testSG-100:HTTP:testAG-100'
                'ni::in:siprof:T:::::;
                 ni:ni-000:in:siprof:T::::LDAP:;
                 ni:ni-001:out:siprof:T::::SNMP:Heartbeat;
                 ni:ni-002:inout:siprof:F:IGNORE:G|SG_WF_0002:G|SG_WF_0003:SNMP:Heartbeat'


        '''
        appd = self.mgr.objd(Application, recreate=False)
        agd = self.mgr.objd(Application_group, recreate=False)

        fields = 'rCat,rName,rDir,rAction,rLog,rApts,rSrcs,rDsts,rAppNames,rAgNames'
        comps = unpackCSSpec(ruleSpec, ':', fields.split(','), self.mgr.logger)
        if not comps:
            return OD()
        exec('%s = comps' % fields)

        if rSrcs=='' or rSrcs.upper()=='ANY': rSrcs=''
        if rDsts=='' or rDsts.upper()=='ANY': rDsts=''
        if not rName:
            rName = 'fw-%s' % sha256(ruleSpec).hexdigest()[:8]
        ruleDict = {
            '@disabled':  'false',
            '@logged':    'true' if rLog.lower().startswith('t') else 'false',
            'name':       rName,
            'direction':  rDir,
            'action':     rAction,
            'packetType': 'any',
        }

        ruleDict['services'] = {'service':[]}
        for rAppName in rAppNames.split(','):
            if not rAppName: continue
            #self.logger.warning(rAppName )

            appObjectId = appd.find_by_name(rAppName)
            #appObjectId = appd.n2oid(rAppName, PCache='rw')

            #sgd  = self.mgr.objd(Security_group, recreate=True)
            #print('rAppName,appObjectId = %s, %s' % (rAppName,appObjectId ))
            ruleDict['services']['service'].append(
                {'value':appObjectId})
                #{'type':'Application', 'value':appObjectId})
        for rAgName in rAgNames.split(','):
            if not rAgName: continue
            #self.logger.warning(rAgName )
            agObjectId = agd.find_by_name(rAgName)
            #print('rAgName,agObjectId = %s, %s' % (rAgName,agObjectId ))
            ruleDict['services']['service'].append(
                {'value':agObjectId})
                #{'type':'ApplicationGroup', 'value':agObjectId})
        ruleDict['appliedToList'] = { 'appliedTo': self._procApts(rApts) }
        if rSrcs:
            #self.logger.warning(rSrcs )
            excluded = rSrcs[0] in ['!','~']
            tSrcs = rSrcs[1:] if excluded else rSrcs
            ruleDict['sources'] = {
                '@excluded': excluded,
                'source': self._procGrpObjs(tSrcs)
            }
        if rDsts:
            #self.logger.warning(rDsts )
            excluded = rDsts[0] in ['!','~']
            tDsts = rDsts[1:] if excluded else rDsts
            ruleDict['destinations'] = {
                '@excluded': excluded,
                'destination': self._procGrpObjs(tDsts)
            }

        if not setDefault:
            ruleDict.pop('@disabled', None)
            if not rLog: ruleDict.pop('@logged', None)
            if not rDir: ruleDict.pop('direction', None)
            if not rAction: ruleDict.pop('action', None)
            if not rDir: ruleDict.pop('direction', None)
            ruleDict.pop('packetType', None)
            if not rAppNames and not rAgNames: ruleDict.pop('services', None)
            if not rApts: ruleDict.pop('appliedToList', None)
            if not rSrcs: ruleDict.pop('sources', None)
            if not rDsts: ruleDict.pop('destinations', None)
        return ruleDict

    def _expandDfwSectNameGlob(self, names, layer, sectionCat):
        etag, dfwCfgOd, sectCats = self._getSectDict(layer)
        #pprint_od(dfwOd)
        resultDfwSectNames = []
        for name in names:
            if not re.search('[\*\[\?]', name):
                resultDfwSectNames.append(name)
                continue
            #if 'firewallConfiguration' in dfwCfgOd:         dfwCfgOd = dfwOd['firewallConfiguration']
            #if 'filteredfirewallConfiguration' in dfwCfgOd: dfwCfgOd = dfwOd['filteredfirewallConfiguration']
            for sectCat in sectCats:
                #print('for sectCat:', sectCat, sectCat in dfwCfgOd, name)
                if sectCat not in dfwCfgOd: continue
                Distributed_firewall._prSection(dfwCfgOd, sectCat, name, self.logger, False)
                resultDfwSectNames.append(name)
        return resultDfwSectNames

    def _expandDfwSectNameGlobGen(self, names, dfwCfgOd, sectCats):
        for name in names:
            #if 'firewallConfiguration' in dfwCfgOd:         dfwCfgOd = dfwOd['firewallConfiguration']
            #if 'filteredfirewallConfiguration' in dfwCfgOd: dfwCfgOd = dfwOd['filteredfirewallConfiguration']
            for sectCat in sectCats:
                if dfwCfgOd.get('sectCat', None): continue
                for section in listify(dfwCfgOd[sectCat]['section']):
                    if isGlobMatched(name, section['@name']):
                        yield section['@name'], sectCat, section


    def dfwSectCreate(self, names, rulesSpec, layer):
        for name in names:
            self.logger.info('Creating DFW section %s' % name)
            dfwSectOd = {
                'section': {
                    '@name': name,
                    'rule': [],
                }
            }

            rulesSpec = [e.strip() for e in rulesSpec.split(';')] if rulesSpec else []
            params = 'layer%ssections' % layer
            self.logger.info1('rulesSpec: %s' % rulesSpec)
            for ruleSpec in rulesSpec:
                self.logger.info1('ruleSpec: %s' % ruleSpec)
                if len(ruleSpec.strip())==0: continue

                if ruleSpec.split(':')[0] not in ['ni', 'fw', 'gi', 'l2']:
                    ruleSpec = 'fw:' + ruleSpec
                rCatSpec = ruleSpec.split(':')[0]
                #self.logger.warning('rCatSpec = %s' % rCatSpec)


                if rCatSpec=='ni':
                    # fields = 'rCat,rName,rDir,siProf,rLog,rApts,rSrcs,rDsts,rAppNames,rAgNames'
                    params = 'layer3redirectsections'
                    dfwSectOd['section']['rule'].append(self._mkDfwNiRuleOd(ruleSpec, PCache='r'))
                elif rCatSpec=='fw':
                    #rulesSpec = '<name>:<direction>:<action>:<log>:<applyTo>:<srcs>:<dsts>:<apps>:<ags>; ...'
                    params = 'layer3sections'
                    dfwSectOd['section']['rule'].append(self._mkDfwFwRuleOd(ruleSpec))
                elif rCatSpec=='l2':
                    #rulesSpec = '<name>:<direction>:<action>:<log>:<applyTo>:<srcs>:<dsts>:<apps>:<ags>; ...'
                    params = 'layer2sections'
                    dfwSectOd['section']['rule'].append(self._mkDfwFwRuleOd(ruleSpec))
                elif rCatSpec=='gi':
                    self.logger.error('gi rules type has not been implemented yet')
                else:
                    self.logger.error('Unknow rule type: %s' % rCatSpec)


            xml = xmltodict.unparse(dfwSectOd)
            r = self.doRestApi('create_section', params=params, data=xml)
            self.logger.info('Created  DFW section %s' % name)
            #etag = r.headers['ETag']
            return r

    def dfwSectOp(self, op=None, argsNs=None, dfwSectDict={}, noLogMsg=False, names=[], layer=3, format='yaml'):
        '''
            # dfwRuleModSpecsHelp
            semi-colon separated list of dfwModRuleSpec
                <dfwModRulesSpec> ::= "+" <dfwRuleSpec> |
                                      "=" <dfwRuleModSpec> |
                                      ">" <dfwRuleModSpec> |
                                      ("-" | "!" | "~") <dfwDelRuleSpec>
                <dfwRuleSpec> : SEE dfwRuleSpecsHelp for details
                <dfwRuleModSpec> ::=
                    "fw:" <name> ":" <id> ":" <direction> ":" <action> ":" <logFlag> ":" <applyTo> ":" <srcs> ":" <dsts> ":" <apps> ":" <ags> |
                    "ni:" <name> ":" <id> ":" <direction> ":" <siPro> ":" <logFlag> ":" <applyTo> ":" <srcs> ":" <dsts> ":" <apps> ":" <ags>
                <dfwDelRuleSpec> ::= "N|" <dfwRuleName> | "I|" <dfwRuleId> (* deprecated *)
                <dfwDelRuleSpec> ::= rNames ":" rIds
            Summary:
                <dfwModRulesSpec> = '+<rCat>:<rName>:<direction>:<action>:<logFlag>:<applyTo>:<srcs>:<dsts>:<apps>:<ags>;
                                    '=<rCat>:<rName>:<rId>:<direction>:<action>:<logFlag>:<applyTo>:<srcs>:<dsts>:<apps>:<ags>;
                                    '><rCat>:<rName>:<rId>:<direction>:<action>:<logFlag>:<applyTo>:<srcs>:<dsts>:<apps>:<ags>;
                <dfwDelRuleSpec>  = ~<ruleName>,<ruleName>:;
                                    ~:<ruleId>,<ruleId>;'
            Example:
                '+fw:apiSec999-000:in:allow:F:I|IPSET-192.168.0.0/24:C|cluster1,C|mgmt:G|testSG-100:HTTP,HTTPS:testAG-100;
                 +fw:apiSec999-001:out:allow:F:C|cluster-test:C|cluster-test:G|testSG-100:HTTP:testAG-100;
                 =fw:apiSec999-002::out:allow:F:C|cluster-test:C|cluster-test:G|testSG-100:HTTP:testAG-100;
                 >fw:apiSec999-003:::deny:::::SNMP:;
                 -ruleNo1; -:1234,1235;'

        '''
        ''' if dfwSectDict is specified, none of the other parameter should be specified '''
        #print('>>', layer)
        ''' op: get_section, modify
        get_section /layer3sections/<rId> /layer3sections?k=v /layer2sections
        show_section
        create_section /layer3sections /layer2sections
        modify_section /layer3sections/<sId>|<sName> /layer2sections
        delete_section /layer3sections/<sId>         /layer2sections
        '''

        if not dfwSectDict:
            dfwSectDict = vars(argsNs)
        exec('\n'.join('%s=dfwSectDict["%s"]' % (k, k) for k in dfwSectDict.keys()))
        names = listify(names)

        sectionType = 'layer%ssections' % layer
        sectionCat =  'layer%sSections' % layer
        ruleType    = 'LAYER%s' % layer

        etag, dfwOd, sectCats = self._getSectDict(layer)
        if op == 'show_section':
            for name,sectCat,sectDict in self._expandDfwSectNameGlobGen(names, dfwOd, sectCats):
                if format=='brief':
                    Distributed_firewall._prSection0(sectDict, sectCat, self.logger, True)
                else:
                    #self.prRespText(dfwSecRespText, format)
                    pprint_od(sectDict)
            return
        elif op == 'delete_section':
            self.logger.info('Delete DFW section %s' % names)
            for name,sectCat,sectDict in self._expandDfwSectNameGlobGen(names, dfwOd, sectCats):
                sectType = sectCat.lower()
                self.logger.info('Deleting DFW %s "%s" (id=%s)' % (sectType, sectDict['@name'], sectDict['@id']))
                params = '%s/%s' % (sectType, sectDict['@id'])
                r = self.doRestApi('delete_section', params=params)
                self.logger.info('Deleted  DFW %s "%s" (id=%s)' % (sectType, sectDict['@name'], sectDict['@id']))
            return
        elif op == 'create_section':
            r = self.dfwSectCreate(names, rulesSpec, layer)
            #for name in names:
            #    self.logger.info('Creating DFW section %s' % name)
            #    dfwSectOd = {
            #        'section': {
            #            '@name': name,
            #            'rule': [],
            #        }
            #    }

            #    rulesSpec = [e.strip() for e in rulesSpec.split(';')] if rulesSpec else []
            #    params = 'layer%ssections' % layer
            #    self.logger.info1('rulesSpec: %s' % rulesSpec)
            #    for ruleSpec in rulesSpec:
            #        self.logger.info1('ruleSpec: %s' % ruleSpec)
            #        if len(ruleSpec.strip())==0: continue

            #        if ruleSpec.split(':')[0] not in ['ni', 'fw', 'gi', 'l2']:
            #            ruleSpec = 'fw:' + ruleSpec
            #        rCatSpec = ruleSpec.split(':')[0]
            #        #self.logger.warning('rCatSpec = %s' % rCatSpec)


            #        if rCatSpec=='ni':
            #            # fields = 'rCat,rName,rDir,siProf,rLog,rApts,rSrcs,rDsts,rAppNames,rAgNames'
            #            params = 'layer3redirectsections'
            #            dfwSectOd['section']['rule'].append(self._mkDfwNiRuleOd(ruleSpec, PCache='r'))
            #        elif rCatSpec=='fw':
            #            #rulesSpec = '<name>:<direction>:<action>:<log>:<applyTo>:<srcs>:<dsts>:<apps>:<ags>; ...'
            #            params = 'layer3sections'
            #            dfwSectOd['section']['rule'].append(self._mkDfwFwRuleOd(ruleSpec))
            #        elif rCatSpec=='l2':
            #            #rulesSpec = '<name>:<direction>:<action>:<log>:<applyTo>:<srcs>:<dsts>:<apps>:<ags>; ...'
            #            params = 'layer2sections'
            #            dfwSectOd['section']['rule'].append(self._mkDfwFwRuleOd(ruleSpec))
            #        elif rCatSpec=='gi':
            #            self.logger.error('gi rules type has not been implemented yet')
            #        else:
            #            self.logger.error('Unknow rule type: %s' % rCatSpec)


            #    xml = xmltodict.unparse(dfwSectOd)
            #    r = self.doRestApi('create_section', params=params, data=xml)
            #    self.logger.info('Created  DFW section %s' % name)
            #    #etag = r.headers['ETag']
            return
        elif op == 'modify_section':
            # '+:in:allow:F:::::'
            # '+fw:rName:rId:in:allow:F:::::'
            #print(argsNs)
            self.logger.info('Modify DFW section %s' % names)

            appd = self.mgr.objd(Application, recreate=False)
            agd = self.mgr.objd(Application_group, recreate=False)
            #for name in names:
            for name,sectCat,sectDict in self._expandDfwSectNameGlobGen(names, dfwOd, sectCats):
                varList = [ '%s=%s' % ('name', name) ]
                self.logger.debug('varList: %s' % varList)

                params = '%s?%s' % (sectionType, '&'.join(varList))
                self.logger.debug('params: %s' % params)
                r = self.doRestApi('get_section', params=params)
                #print('params=%s'%params)
                #pprint_od(xmltodict.parse(r.text))
                dfwCfgOd = xmltodict.parse(r.text)
                #pprint_od(dfwCfgOd); exit()
                if not isinstance(dfwCfgOd['sections']['section'], list):
                    etag = r.headers['ETag']
                else:
                    self.logger.error('Multiple (%s) DFW Section "%s" exist, please remove and recreate' %
                        (len(dfwCfgOd['sections']['section']), name))
                    exit(171)

                dfwCfgL3SectOd = dfwCfgOd['sections']['section']
                dfwCfgL3SectTimestamp = dfwCfgL3SectOd['@timestamp']
                curRules = listify(dfwCfgL3SectOd['rule']) if 'rule' in dfwCfgL3SectOd else []
                self.logger.info('Got DFW section %s (last updated %s %s)' % (name,
                    time.strftime('%Y-%m-%d %H:%M:%S',
                        time.localtime(float(dfwCfgL3SectTimestamp)/1000)),
                    dfwCfgL3SectTimestamp))

                rulesModSpec = [e.strip() for e in rulesModSpec.split(';')] if rulesModSpec else []
                self.logger.info1('rulesModSpec: %s' % rulesModSpec)
                for ruleModSpec in rulesModSpec[::-1]:
                    ruleModSpec = ruleModSpec.strip()
                    self.logger.info1('ruleModSpec: %s' % ruleModSpec)
                    if len(ruleModSpec.strip())==0: continue

                    # take care of old syntax where rCat is not specified
                    #print('>>>>>', ruleModSpec)
                    if ruleModSpec.split(':')[0][1:] not in ['ni', 'fw', 'gi'] and \
                            ruleModSpec.split(':')[0][0] not in ['+', '-','~',  '!']:
                        ruleModSpec = '%sfw:'%ruleModSpec.split(':')[0][0] + ruleModSpec
                    # rCatSpec is not valid for delete
                    rCatSpec = ruleModSpec.split(':')[0].strip('+-!~')
                    #print('>>>>>', ruleModSpec,rCatSpec )

                    ruleModOp = ruleModSpec[0]
                    if ruleModOp == '+':                     # add a rule
                        ruleSpec = ruleModSpec[1:]
                        #if rCatSpec=='fw':
                        if layer=='3':
                            ruleOd = self._mkDfwFwRuleOd(ruleSpec)
                            curRules.insert(0, ruleOd)
                        elif layer.startswith('3r'):
                            ruleOd = self._mkDfwNiRuleOd(ruleSpec)
                            curRules.insert(0, ruleOd)
                    elif ruleModOp == '=':                   # replace a rule
                        # "=fw:apiSec999-003:14983:out:deny:F::::SNMP:"
                        # "=fw:apiSec999-003::out:deny:F::::SNMP:"
                        # "=fw::14983:out:deny:F::::SNMP:"
                        modRuleName, modRuleId = ruleModSpec.split(':')[1:3]   # =fw:rName:rId...
                        print('ruleModSpec, mr: "%s", "%s", "%s"' % (ruleModSpec, modRuleName, modRuleId))
                        for curRule in curRules:
                            curRuleName, curRuleId = curRule.get('name',''), curRule['@id']
                            #print('ruleModSpec, mr: "%s", "%s", "%s" <--C' % (ruleModSpec, curRuleName, curRuleId))
                            if modRuleId==curRuleId or (modRuleName==curRuleName and modRuleId==''):
                                # NOTE: modRuleD match override modRuleName misMatch
                                print('ruleModSpec, mr: "%s", "%s", "%s" <==C' % (ruleModSpec, curRuleName, curRuleId))
                                rComps = ruleModSpec[1:].split(':')
                                ruleSpec = ':'.join(rComps[:2] + rComps[3:])
                                ruleOd = self._mkDfwFwRuleOd(ruleSpec)
                                curRule.update(ruleOd)
                    elif ruleModOp == '>':                   # replace fields in a rule
                        # "=fw:apiSec999-003:14983::allow::::::"
                        # "=fw:apiSec999-003:::allow::::::"
                        # "=fw::14983::allow::::::"
                        modRuleName, modRuleId = ruleModSpec.split(':')[1:3]   # =fw:rName:rId...
                        print('ruleModSpec, mr: "%s", "%s", "%s"' % (ruleModSpec, modRuleName, modRuleId))
                        for curRule in curRules:
                            curRuleName, curRuleId = curRule.get('name',''), curRule['@id']
                            #print('ruleModSpec, mr: "%s", "%s", "%s" <--C' % (ruleModSpec, curRuleName, curRuleId))
                            if modRuleId==curRuleId or (modRuleName==curRuleName and modRuleId==''):
                                # NOTE: modRuleD match override modRuleName misMatch
                                print('ruleModSpec, mr: "%s", "%s", "%s" <==C' % (ruleModSpec, curRuleName, curRuleId))
                                rComps = ruleModSpec[1:].split(':')
                                ruleSpec = ':'.join(rComps[:2] + rComps[3:])
                                ruleOd = self._mkDfwFwRuleOd(ruleSpec, setDefault=False)
                                pprint_od(ruleOd)
                                curRule.update(ruleOd)
                                pprint_od(curRule)
                    elif ruleModOp in ['!', '-', '~']:     # remove a rule
                        if ruleModSpec[2] != '|':
                            ''' ~rName1,rName2:rId1,rId2; ~rName1,rName2; ~:rId1,rId2; ~rName1:rId2 '''
                            #print('ruleModSpec=',ruleModSpec)
                            rulesModSpec = ruleModSpec[1:].split(':')
                            #print('rulesModSpec=',rulesModSpec)
                            curRuleNameSet = set([d['name'] for d in curRules if d['name']])
                            curRuleIdSet = set([d['@id'] for d in curRules if d['@id']])
                            if len(rulesModSpec)>0:
                                rmRuleNames = [e for e in rulesModSpec[0].split(',') if e]
                                #print('rmRuleNames=',rmRuleNames)
                                rmRuleNameSet = set(rmRuleNames)
                                if rmRuleNames and not rmRuleNameSet<=curRuleNameSet:
                                    self.logger.warning('rule "%s" does not exist in current rule set' %
                                        ','.join((rmRuleNameSet-curRuleNameSet)))
                                curRules = [d for d in curRules if d['name'] not in rmRuleNames]
                            if len(rulesModSpec)>1:
                                rmRuleIds = [e for e in rulesModSpec[1].split(',') if e]
                                #print('rmRuleIds=',rmRuleIds)
                                rmRuleIdSet = set(rmRuleIds)
                                if rmRuleIds and not rmRuleIdSet<=curRuleIdSet:
                                    self.logger.warning('rule id "%s" does not exist in current rule set' %
                                        ','.join((rmRuleIdSet-curRuleIdSet)))
                                curRules = [d for d in curRules if d['@id'] not in rmRuleIds]
                            #pprint_od(curRules)
                        else:
                            #rmRuleNames, rmRuleIds = ruleModSpec.split(':')[1:3]   # -N|n1,n2,n3
                            #print('ruleModSpec=%s' % ruleModSpec)
                            rmRuleNames = ruleModSpec[3:].split(',') if ruleModSpec[1:3].upper()=='N|' else []
                            rmRuleIds   = ruleModSpec[3:].split(',') if ruleModSpec[1:3].upper()=='I|' else []
                            curRules = [d for d in curRules if d.get('name','') not in rmRuleNames]
                            curRules = [d for d in curRules if d['@id'] not in rmRuleIds]
                            #print(rmRuleNames, rmRuleIds); exit()

                            #if ruleModSpec[1:3].upper()=='N|':
                            #    ''' -N|rName1,rName2 '''
                            #    rmRuleNames = ruleModSpec[3:].split(',')
                            #    curRules = [d for d in curRules if d.get('name','') not in rmRuleNames]
                            #elif ruleModSpec[1:3].upper()=='I|':
                            #    ''' -I|rid1,rid1 '''
                            #    rmRuleIds = ruleModSpec[3:].split(',')
                            #    curRules = [d for d in curRules if d['@id'] not in rmRuleIds]
                    else:
                        self.logger.warning('Invalid DFW section rule modification specification: %s' % ruleModSpec)

                dfwCfgL3SectOd['rule'] = curRules
                sectXml = xmltodict.unparse(dfwCfgOd['sections'], full_document=False)

                secId = dfwCfgL3SectOd['@id']
                params = '%s/%s' % (sectionType, secId)
                r = self.doRestApi('modify_section', params=params, data=sectXml,
                    headers={'if-match':etag})
                self.logger.info('DFW section %s updated' % name)
            return







        #print('>>', layer, names)
        for name in names:
            varList = [ '%s=%s' % ('name', name) ]
            self.logger.debug('varList: %s' % varList)

            #params = 'layer3sections/1003'
            #params = 'layer3sections?name=LSG_PRD_AAA_00001_EUFRPARIS2'
            #params = 'layer3sections?name=Default Section Layer3'

            #print('>>', layer, names, op)
            if op == 'get_section':
                #etag, dfwCfgOd, sectCats = self._getSectDict(layer)

                if not noLogMsg:
                    self.logger.info('Get DFW section %s' % name)
                params = '%s?%s' % (sectionType, '&'.join(varList))
                #print('params = %s' % params)
                r = self.doRestApi('get_section', params=params)
                etag = ''
                if r.ok:
                    if 'ETag' in r.headers:
                        etag = r.headers['ETag']
                    #self.prRespText(r.text, 'yaml')
                    dfwCfgOd = xmltodict.parse(r.text)
                    #Distributed_firewall._prSection(dfwCfgOd, 'sections', self.mgr.logger)
                    secIds = [s['@id'] for s in listify(dfwCfgOd['sections']['section'])]
                    #print('secIds: %s' % secIds)
                else:
                    dfwCfgOd = {}
                    self.logger.error('DFW section %s not found' % name)
                return etag, r.text
            else:
                self.logger.error('Unknown DFW operation: %s' % op)

    def _getSectDict(self, layer):
        ''' sectCats: should be used to filter rText sectionCategories '''
        ''' section filter result does not include section w/rules, bug? limitaion? '''
        sectDict = {'2':'layer2Sections', '3':'layer3Sections', '3redirect':'layer3RedirectSections'}
        #if layer:
        #    params = 'ruleType=%s' % {'2':'LAYER2', '3':'LAYER3', '3redirect':'L3REDIRECT'}[layer]
        #    sectCats = [sectDict[layer]]
        #else:
        #    params = ''
        #    sectCats = sorted(sectDict.values())

        params = ''
        sectCats = sorted(sectDict.values())

        r = self.doRestApi('get', params=params)
        dfwSectCfgOd = xmltodict.parse(r.text)
        #pprint_od(dfwSectCfgOd)
        if layer:
            sectCats = [sectDict[layer]]
            sectType = {'2':'layer2Sections', '3':'layer3Sections', '3redirect':'layer3RedirectSections'}[layer]
            for k,v in dfwSectCfgOd['firewallConfiguration'].items():
                #print('>>', k)
                if k.startswith('layer') and k.endswith('Sections') and k!=sectType:
                    #print('del >>', k)
                    del dfwSectCfgOd['firewallConfiguration'][k]
        dfwSectCfgOd = dfwSectCfgOd['firewallConfiguration']        # peel off 'firewallConfiguration' level
        #print('RET >>', r.headers['ETag'], dfwSectCfgOd, sectCats)
        return r.headers['ETag'], dfwSectCfgOd, sectCats

    def list(self, brief=False, fmt=None, prRule=True, layer='', name=''):  # dfw section
        etag, dfwCfgOd, sectCats = self._getSectDict(layer)

        if not fmt or fmt=='brief' or brief:
            #dfwOd = xmltodict.parse(rText)
            #if 'firewallConfiguration' in dfwCfgOd:         dfwCfgOd = dfwOd['firewallConfiguration']
            #if 'filteredfirewallConfiguration' in dfwCfgOd: dfwCfgOd = dfwOd['filteredfirewallConfiguration']
            for sectCat in sectCats:
                if sectCat not in dfwCfgOd: continue
                Distributed_firewall._prSection(dfwCfgOd, sectCat, name, self.logger, prRule)
        else:
            #self.prRespText(rText, fmt)
            pprint_yaml(byteify(dfwCfgOd))

    @staticmethod
    def _fmtRuleElems(rule, outerTag, innerTag, default=''):
        global grpObjMap, grpObjMap_r

        default = listify(default)
        r1, excluded = [], False

        if outerTag in rule:
            excluded = '@excluded' in rule[outerTag] and rule[outerTag]['@excluded']=='true'
            if innerTag:
                for elem in sorted(listify(rule[outerTag][innerTag]), key=cptutil.alnum_keys):
                    elemType = grpObjMap_r.get(elem['type'], None) or elem['type']
                    elemName = elem['name'] if 'name' in elem else elem['value']
                    r1.append('%s|%s' % (elemType, elemName))
            else:
                r1.append('%s|%s' % (grpObjMap_r, rule[outerTag]['name']))
        else:
            r1 = default
        if excluded:
            r = '%s%s' % ('~ ', '\n  '.join(r1))
        else:
            r =  '\n'.join(r1)
        return r

    @staticmethod
    def _prSection(dfwCfgOd, sectCat, sectionName, logger, prRule=True):
        if sectCat not in dfwCfgOd:
            logger.warning('No such secion %s' % sectCat)
            return
        if dfwCfgOd[sectCat]:
            ptblSect = PrettyTable(['sectionName', 'id', 'nRules', 'type', 'timestamp'], sortby='sectionName')
            ptblSect.align = 'l'

            sections = listify(dfwCfgOd[sectCat]['section'])
            sections = sorted(sections, key=lambda s: s['@name'])
            #print(sectCat, sectionName, [s['@name'] for s in sections])
            for section in sections:
                #print('sectionName: %s %s %s' % (sectionName, section['@name'],
                #    isGlobMatched(sectionName, section['@name'])))
                #if sectionName and section['@name']!=sectionName: continue
                if sectionName and not isGlobMatched(sectionName, section['@name']): continue
                if prRule:
                    print('%-30s (id=%s, type=%s, %s)' % (
                        section['@name'], section['@id'], section['@type'],
                        time.strftime('%Y-%m-%d %H:%M:%S',
                            time.localtime(float(section['@timestamp'])/1000))))
                else:
                    ptblSect.add_row([section['@name'], section['@id'],
                        len(section['rule']) if 'rule' in section else 0, section['@type'],
                        time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(float(section['@timestamp'])/1000))])
                if prRule and 'rule' in section:
                    ptbl = PrettyTable(['rule name/id', 'act/dir/log', 'Srcs', 'Dsts', 'Apps', 'applyTo'])
                    ptbl.align = 'l'
                    for rule in listify(section['rule']):
                        ruleName = rule['name'] if 'name' in rule else ''
                        applyToValue = Distributed_firewall._fmtRuleElems(rule, 'siProfile', None) \
                            if 'siProfile' in rule else \
                                Distributed_firewall._fmtRuleElems(rule, 'appliedToList', 'appliedTo'),
                        ptbl.add_row([
                            '%s/%s' % (ruleName or '-', rule['@id']),
                            '/'.join(['%-5s'%rule['action'], '%-5s'%rule['direction'], '%-5s'%rule['@logged']]),
                            Distributed_firewall._fmtRuleElems(rule, 'sources', 'source', 'ANY'),
                            Distributed_firewall._fmtRuleElems(rule, 'destinations', 'destination', 'ANY'),
                            Distributed_firewall._fmtRuleElems(rule, 'services', 'service'),
                            #Distributed_firewall._fmtRuleElems(rule, 'appliedToList', 'appliedTo'),
                            #Distributed_firewall._fmtRuleElems(rule, 'siProfile', None),
                            Distributed_firewall._fmtRuleElems(rule, 'siProfile', None) \
                                if 'siProfile' in rule else \
                                Distributed_firewall._fmtRuleElems(rule, 'appliedToList', 'appliedTo'),
                            ])
                    if ptbl._rows:
                        print(ptbl)
                        print('Count: %d' % ptbl.rowcount)
            if not prRule:
                print('%s:' % sectCat)
                print(ptblSect)
                print('Count: %d' % ptblSect.rowcount)
        else:
            logger.info('Empty %s' % sectCat)

    @staticmethod
    def _prSection0(section, sectCat, logger, prRule=True):
            ptblSect = PrettyTable(['sectionName', 'id', 'nRules', 'type', 'timestamp'], sortby='sectionName')
            ptblSect.align = 'l'

            if prRule:
                print('%-30s (id=%s, type=%s, %s)' % (
                    section['@name'], section['@id'], section['@type'],
                    time.strftime('%Y-%m-%d %H:%M:%S',
                        time.localtime(float(section['@timestamp'])/1000))))
                ptbl = PrettyTable(['rule name/id', 'act/dir/log', 'Srcs', 'Dsts', 'Apps', 'applyTo'])
                ptbl.align = 'l'
                if 'rule' in section:
                    for rule in listify(section['rule']):
                        ruleName = rule['name'] if 'name' in rule else ''
                        applyToValue = Distributed_firewall._fmtRuleElems(rule, 'siProfile', None) \
                            if 'siProfile' in rule else \
                                Distributed_firewall._fmtRuleElems(rule, 'appliedToList', 'appliedTo'),
                        ptbl.add_row([
                            '%s\n %s' % (ruleName, rule['@id']),
                            '\n'.join([rule['action'], rule['direction'], rule['@logged']]),
                            Distributed_firewall._fmtRuleElems(rule, 'sources', 'source', 'ANY'),
                            Distributed_firewall._fmtRuleElems(rule, 'destinations', 'destination', 'ANY'),
                            Distributed_firewall._fmtRuleElems(rule, 'services', 'service'),
                            #Distributed_firewall._fmtRuleElems(rule, 'appliedToList', 'appliedTo'),
                            #Distributed_firewall._fmtRuleElems(rule, 'siProfile', None),
                            Distributed_firewall._fmtRuleElems(rule, 'siProfile', None) \
                                if 'siProfile' in rule else \
                                Distributed_firewall._fmtRuleElems(rule, 'appliedToList', 'appliedTo'),
                            ])
                print(ptbl)
                print('Count: %d' % ptbl.rowcount)
            else:
                ptblSect.add_row([section['@name'], section['@id'],
                    len(section['rule']) if 'rule' in section else 0, section['@type'],
                    time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(float(section['@timestamp'])/1000))])
                print('%s:' % sectCat)
                print(ptblSect)
                print('Count: %d' % ptblSect.rowcount)

class ExcludeVM(Network_element):
    rest_api = {
        'get': Api('get',     '/api/2.1/app/excludelist', ''),
        'add': Api('put',    '"/api/2.1/app/excludelist/%s"%objectId', ''),
        'rm':  Api('delete', '"/api/2.1/app/excludelist/%s"%objectId', ''),
    }
    rKeys = ['VshieldAppConfiguration', 'excludeListConfiguration']
    ptblFmts = {
        'get': PtblFmt(rest_api['get'].url, '''
            def listify:if type=="array" then .[] else select(.) end;
            .VshieldAppConfiguration.excludeListConfiguration.excludeMember |listify |.member |{
                "name":           .name,
                "id":             .objectId,
                "scope":          (.scope|.objectTypeName+":"+.name),
            }'''),
    }

    def excludeVMOp(self, op, nameGlob, fmt='brief'):
        # choices=['raw','xml','yaml','json','brief','pipe'],
        if op=='list':
            if fmt=='brief':
                rows, ptbl = self.jqTable(apiKey='get', nameGlob=nameGlob)
            else:
                self.list(fmt=fmt, nameGlob=nameGlob)
        else:
            for vmMo in self.mgr.vslibVc.getByNamesGlob(vim.VirtualMachine, nameGlob):
                if op=='add':
                    self.logger.info('Adding VM "%s" to exclude VM list' % vmMo.name)
                    r = self.doRestApi('add', objectId=vmMo._moId)
                elif op=='remove':
                    self.logger.info('Removing VM "%s" from exclude VM list' % vmMo.name)
                    r = self.doRestApi('rm', objectId=vmMo._moId)

class Ipfix(Network_service, Network_element):
    rest_api = {
        'get' : Api('get', '/api/4.0/firewall/globalroot-0/config/ipfix', ''),
        'cfg' : Api('put', '/api/4.0/firewall/globalroot-0/config/ipfix', ''),
    }
    rKeys = ['ipfixConfiguration']
    #jqTableSpec = JqTableSpec( '[.contextId, .ipfixEnabled, .observationDomainId, .flowTimeout]', [])
    jqTblSpec = JqTblSpec('''{
        ".contextId":           .contextId,
        "ipfixEnabled":         .ipfixEnabled,
        "observationDomainId":  .observationDomainId,
        "flowTimeout":          .flowTimeout,
    }''', '')

    s_rest_api = {
        'get' : Api('get', '/api/4.0/firewall/globalroot-0/config/ipfix', ''),
        'cfg' : Api('put', '/api/4.0/firewall/globalroot-0/config/ipfix', ''),
    }
    sKeys = ['ipfixConfiguration', 'ipfixEnabled']
    svcKeys = {
        'enable': ['ipfixConfiguration', 'ipfixEnabled'],
        'rmList': [['observationDomainId']]
    }


class Health(Network_element):
    '''
    Retrieve and display the communication health of one or more clusters
    '''
    rest_api = {
        'show': Api('get',
            '"/api/2.0/vdn/inventory/hosts/connection/status?%s"%hostIds', ''),
    }


    def show_health(self, cluster, outjson= True):
        hostIds = None
        for h in cluster.host:
            if not hostIds:
                hostIds = 'hostId=' + h._moId
            else:
                hostIds = hostIds + '&hostId=' + h._moId
        if not hostIds:
            self.logger.info('Health check: no host found in cluster: '
                    + cluster.name)
            return

        for hostMoid in [str(h._moId) for h in cluster.host]:
            hostMo = vim.HostSystem(hostMoid)
            hostMo._stub = self.mgr.vcSi._stub
            print('%s\t%s\t%s' % (hostMo, hostMo.name, hostMo._moId))

        r = self.doRestApi('show', hostIds=hostIds, headers={'Accept': 'application/json'})

        if outjson:
            output = {}
            output[cluster.name] = json.loads(r.text)
            print(json.dumps(output, indent=4))
        else:
            print(r.text)


    def show(self, clusters, args = None):          # class Health():
        for c in clusters:
            cObject = clusterNameToMo(c, self.mgr.vslibVc)
            self.logger.info('Getting communication health for cluster: %s' %c)
            self.show_health(cObject)

class Detection(Network_element):
    '''
    Configure or show IP Detection.
    Configuration requires YAML configuration.
      Sample YAML:
        ipRepositoryConfig:
            -
                dhcpSnoopEnabled: 'true'
                arpSnoopEnabled: 'true'
                HINT_CLUSTER_scopeId: Cluster01
            -
                dhcpSnoopEnabled: 'true'
                arpSnoopEnabled: 'true'
                HINT_CLUSTER_scopeId: Cluster02
            -
                dhcpSnoopEnabled: 'true'
                arpSnoopEnabled: 'false'
                HINT_CLUSTER_scopeId: Cluster03

    Show requires cluster name.
    '''
    rest_api = {
        'cfg' : Api('put',
             '"/api/2.0/services/iprepository/config/scope/%s"%scopeId',''),
        'show' : Api('get',
             '"/api/2.0/services/iprepository/config/scope/%s"%scopeId',''),
    }

    def config(self, data, args = None):
        restUrl = self.rest_api['cfg'].url
        cluster = data['yaml']['ipRepositoryConfig'][0]['HINT_CLUSTER_scopeId']
        swapXmlTag(self,data['yaml']['ipRepositoryConfig'][0])
        newdata,begin,end = yaml_to_xml(yml=data['yaml'], top = True)
        scopeId = newdata[0]['yaml']['ipRepositoryConfig'][0]['scopeId']
        restUrl = eval(restUrl)
        self.logger.info("Configuring IP detection for cluster: %s" %cluster)
        r = getattr(self.mgr,
                self.rest_api['cfg'].method)(restUrl, data=newdata[0]['xml'])

    def show(self, clusters, args = None):          # class Detection()
        for c in clusters:
            scopeId = clusterNameToMoid(c, self.mgr.vslibVc)
            r = self.doRestApi('show', scopeId=scopeId)
            output = xmltodict.parse(r.text)
            print("%s:" %c)
            print("   dhcpSnoopEnabled: %s" %
                output['ipRepositoryConfig']['dhcpSnoopEnabled'])
            print("   arpSnopEnabled: %s" %
                output['ipRepositoryConfig']['arpSnoopEnabled'])

class Bfd(Network_element):
    rest_api = {
        'cfgGet':       Api('get', '/api/2.0/vdn/bfd/configuration/global', ''),
        'cfgSet':       Api('put', '/api/2.0/vdn/bfd/configuration/global', ''),
        'pnic_cfgGet':  Api('get', '/api/2.0/vdn/pnic-check/configuration/global', ''),
        'pnic_cfgSet':  Api('put', '/api/2.0/vdn/pnic-check/configuration/global', ''),

        'host_rStatus': Api('get', '"/api/2.0/vdn/host/%s/remote-host-status"%hostId', ''),
        'host_status':  Api('get', '"/api/2.0/vdn/host/%s/status"%hostId', ''),
        'host_tStatus': Api('get', '"/api/2.0/vdn/host/%s/tunnel"%hostId', ''),
        'hosts_status': Api('get',  '/api/2.0/vdn/host/status', ''),
    }
    def globalConfig(self, op, gType, **kwargs):
        ''' op: 'get', 'set'
            gType: 'pnic', ''
            kwargs for gType != 'pnic':
                pollIntevalSec: host Polling Interval in seconds
                bfdIntevalMsec: host BFD Interval in milli-seconds
                enabled: '  enable', 'disable'
            kwargs for gType='pnic':
                pollIntevalSec: host Polling Interval in seconds
                enableCheckGlobalConfig: 'enable', 'disable'
        '''
        exec('\n'.join('%s=kwargs["%s"]' % (k, k) for k in kwargs.keys()))
        if op=='get':
            if gType=='config':
                r = self.doRestApi('cfgGet')
            elif gType=='pnic':
                r = self.doRestApi('pnic_cfgGet')
            rOd = xmltodict.parse(r.text)
        elif op=='set':
            if gType=='config':
                bodyOd = { 'bfdGlobalConfiguration': { 'enabled': enabled } }
                if pollIntevalSec != None:
                    bodyOd['bfdGlobalConfiguration']['pollingIntervalSecondsForHost'] = pollIntevalSec
                if bfdIntevalMsec != None:
                    bodyOd['bfdGlobalConfiguration']['bfdIntervalMillSecondsForHost'] = bfdIntevalMsec
                bodyXml = xmltodict.unparse(bodyOd)
                print(bodyXml)
                r = self.doRestApi('cfgSet')
            elif gType=='pnic':
                r = self.doRestApi('pnic_cfgSet', data=bodyXml)

    def hostStatus(self, statusType, hostNamesGlob):
        ''' statusType: 'host', 'remote', 'tunnel' '''
        print('hostNamesGlob:', hostNamesGlob)
        hostNamesGlob = listify(hostNamesGlob)
        hostMoref = flatten([hostNameGlobToMoids(hostName, self.mgr.vslibVc, shortMoid=False)
            for hostName in hostNamesGlob])
        print('hostMoref:', hostMoref)
        print('hostTuple:', [(h.name, h._moId) for h in hostMoref])

class Vxlan(Network_element):
    rest_api = {
        #'get':      Api('get' ,   '/api/2.0/vdn/map/cluster', ''),
        'get':      Api('get' ,   '/api/2.0/vdn/inventory/ui/cluster', ''),
        'getone':   Api('get' ,  '"/api/2.0/vdn/map/cluster/%s"%objectId', ''),
        'gethosts': Api('get' ,  '"/api/2.0/vdn/inventory/ui/cluster/host/%s"%objectId', ''),
        'cfg':      Api('post',   '/api/2.0/nwfabric/configure', ''),
        'del':      Api('delete', '/api/2.0/nwfabric/configure', ''),
        'getport':  Api('get',    '/api/2.0/vdn/config/vxlan/udp/port', ''),
        'setport':  Api('put',   '"/api/2.0/vdn/config/vxlan/udp/port/%d"%vxlanPort', ''),
    }
    rKeys = ['list', 'com.vmware.vshield.vsm.vdn.dto.ui.UiClusterDto']
    """
    jqTblSpec = JqTblSpec('''{
        "cluster":  .cluster.name,
        "switch":   .selectedSwitches."com.vmware.vshield.vsm.vdn.dto.ui.UiSwitchDto".switch.name,
        "teaming":  .selectedSwitches."com.vmware.vshield.vsm.vdn.dto.ui.UiSwitchDto".teaming,
        "mtu":      .selectedSwitches."com.vmware.vshield.vsm.vdn.dto.ui.UiSwitchDto".mtu,
        "ipPool":   .ipPool.name,
        "vlanId":   .vlanId,
        "nVmk":     .vmknicCount,
    }''', '')
    """

    rKeys2 = ['list', 'vdnHost']
    jqTableSpec2 = JqTableSpec(
        '[.host.name, [.vmknics.vdnVmknic[]|[.deviceId,.ipAddress,.dhcp]]]',
        ['host', 'vnk-id,ip,dhcp'])

    delXml = '"<nwFabricFeatureConfig>'+\
        '<featureId>com.vmware.vshield.vsm.vxlan</featureId>'+\
        '<resourceConfig><resourceId>%s</resourceId></resourceConfig>'+\
        '</nwFabricFeatureConfig>"%objectId'
    delVxlanVdsXml = ''''<nwFabricFeatureConfig> <featureId>com.vmware.vshield.vsm.vxlan</featureId> <resourceConfig> <resourceId>%s</resourceId> <configSpec class="map"> <entry> <key class="java.lang.String">vxlan</key> <value class="java.lang.String">cascadeDeleteVdsContext</value> </entry> </configSpec> </resourceConfig> </nwFabricFeatureConfig>'%objectId'''

    def portOp(self, action, vxlanPort=None):
        if action in ['getport', 'setport']:
            restUrl = self.rest_api[action].url
            restMethod = self.rest_api[action].method
            if action == 'getport':
                r = getattr(self.mgr, restMethod)(restUrl)
                vxlanPort = int(re.search('.*<int>(\d+)</int>', r.text).group(1))
                print(vxlanPort, {4789:'rfc', 8472:'vmware'}[vxlanPort])
            if action == 'setport':
                restUrl = eval(restUrl)
                r = getattr(self.mgr, restMethod)(restUrl)
                print(r.text)

    def config(self, data):
        '''
        Configure VXLAN for cluster
        '''
        yml = data['yaml']['nwFabricFeatureConfig'][0]

        swapXmlTag(self, yml)


        datacopy = copy.deepcopy(data['yaml'])
        self.logger.info('Vxlan.config() Recreating XML for API post with new values from VC')
        newdata, begin,end  = yaml_to_xml(yml = datacopy, top = True)
        #print(json.dumps(newdata[0]['yaml'], indent=4))
        #print(newdata[0]['xml'])
        self.logger.info('Vxlan.config() Posting VXLAN config to NSX Manager')

        restUrl = self.rest_api['cfg'].url
        restMethod = self.rest_api['cfg'].method
        self.logger.debug('%s: REST CALL %s %s' % (type(self), restMethod, restUrl))

        self.logger.debug('%s: REST BODY xml=%s' % (type(self), data['xml']))
        r = getattr(self.mgr, restMethod)(restUrl, data=newdata[0]['xml'])

        if r.status_code >= 400:
            self.mgr.responseError(r)
        return r.text

    def listHost(self, brief=False, fmt=None, nameGlob=None, PCache=''):
        print(self.rest_api['get'].url)
        print(self.rest_api['gethosts'].url)
        print('xxx')
        temp_rKeys, temp_jqTableSpec = self.rKeys, self.jqTableSpec
        temp_get, temp_gethosts = self.rest_api['get'], self.rest_api['gethosts']
        print(temp_gethosts.url)

        objectId = 'domain-c7'
        self.rKeys, self.jqTableSpec = self.rKeys2, self.jqTableSpec2
        self.rest_api['get'] = Api('get' , eval(temp_gethosts.url), '')
        print(self.rest_api['get'].url)
        self.list(brief, nameGlob=nameGlob)
        #self.list(brief)

        self.rKeys, self.jqTableSpec, rest_api['get'] = temp_rKeys, temp_jqTableSpec, temp_get

    def delete(self, clusterNames):                     # Vxlan
        ''' Remove VXLAN on ESXi hosts for given cluster
        '''
        for clusterName in clusterNames:
            self.logger.info('Unconfigure VXLAN for hosts in %s' % clusterName)
            objectId = clusterNameToMoid(clusterName, self.mgr.vslibVc)
            restUrl = self.rest_api['del'].url
            if restUrl.count('%') >= 2: restUrl = eval(restUrl)
            restMethod = self.rest_api['del'].method
            self.logger.debug('%s: REST CALL %s %s' % (type(self), restMethod, restUrl))

            xml = eval(self.delXml)
            #xml = eval(self.delVxlanVdsXml)
            self.logger.debug('%s: REST BODY xml=%s' % (type(self), xml))
            r = getattr(self.mgr, restMethod)(restUrl, data=xml)

            if r.status_code >= 400:
                self.mgr.responseError(r)

            # host prep does not return jobID
            #jobId = r.text
            #print('jobId=', jobId)
            #jobd = Job(self.mgr)
            #jobd.jobStatus(jobId)

class Network_virtualization_components(Network_element):
    rest_api = {
        'prep':        Api('post',   '/api/2.0/nwfabric/configure', ''),
        'upgrade':     Api('put',    '/api/2.0/nwfabric/configure', ''),
        'unprep':      Api('delete', '/api/2.0/nwfabric/configure', ''),
        'status':      Api('get',   '"/api/2.0/nwfabric/status?resource=%s"%objectId', ''),
        'childstatus': Api('get',   '"/api/2.0/nwfabric/status/child/%s"%objectId', ''),
    }
    cfgXml = '"<nwFabricFeatureConfig><resourceConfig>'+\
        '<resourceId>%s</resourceId>'+\
        '</resourceConfig></nwFabricFeatureConfig>"%objectId'

    def printHostPrepStatus(self, xml):
        od = xmltodict.parse(xml)
        for rRoot in listify(od['resourceStatuses']['resourceStatus']):
            resource = rRoot['resource']
            hRebootRequired = rRoot['hostRebootRequired'] == 'true'
            print('%s(%s): REBOOT %sREQUIRED' % (
                self.mgr.vslibVc.moid2mo(resource['objectId']).name, resource['objectId'],
                '' if hRebootRequired else 'NOT '))
            ptbl = PrettyTable(['featureId', 'installed', 'version', 'updateAvail', 'enabled'], sortby='featureId')
            ptbl.align = 'l'
            for fea in rRoot['nwFabricFeatureStatus']:
                ptbl.add_row([fea['featureId'], fea['installed'],
                    fea.get('featureVersion', ''), fea.get('updateAvailable', ''), fea['enabled']])
            if ptbl._rows:
                print(ptbl)
                print('Count: %d' % ptbl.rowcount)
            del ptbl

    def prep(self, objNamesGlob, action='prep', objType='cluster'):
        ''' Install/Remove NSX VIBs into ESXi for given cluster
            action 'prep':    install
            action 'upgrade': upgrade
            action 'unprep':  uninstall
            action 'status':  show feature status
        '''
        if objType=='cluster':
            objMoids = flatten([clusterNameGlobToMoids(objName, self.mgr.vslibVc, shortMoid=False)
                for objName in objNamesGlob])
        elif objType=='host':
            objMoids = flatten([hostNameGlobToMoids(objName, self.mgr.vslibVc, shortMoid=False)
                for objName in objNamesGlob])


        objNames = [moid.name for moid in objMoids]
        #for objName in objNames:
        for objName,objMoid in zip(objNames,objMoids):
            self.logger.info('Host %s for %s %s' % (action, objType, objName))

            objectId = vslib.shortMoid(objMoid)
            #fn = hostNameToMoid if objType=='host' else clusterNameToMoid
            #objectId = fn(objName, self.mgr.vslibVc)
            if not objectId:
                self.logger.error('%s %s Cannot be found' % (objType, objName))
                continue

            xml = eval(self.cfgXml)

            r = self.doRestApi(action, objectId=objectId, data=xml)
            #self.mgr.dumpResquestsResponse(r)
            #print(">>> r.status_code=%s r.ok=%s, r.text=%s" % (r.status_code, r.ok, r.text))

            if r.ok:
                if action=='status' and r.ok:
                    self.printHostPrepStatus(r.text)
                elif action in ['prep', 'upgrade', 'unprep']:
                    rText = r.text.strip()
                    if rText.startswith('jobdata-'):
                        Job(self.mgr).jobStatus(rText)
                    else:
                        self.logger.info(
                            '%s %s: %s' % (action, objName, r.text) if r.text
                            else '%s already %s' % (objName, action))

class System(Network_element):
    rest_api = {
        'info':        Api('get',  '/api/1.0/appliance-management/global/info', ''),
        'restart':     Api('post', '/api/1.0/appliance-management/system/restart', ''),
        'uptime':      Api('get',  '/api/1.0/appliance-management/system/uptime', ''),
        'cpuinfo':     Api('get',  '/api/1.0/appliance-management/system/cpuinfo', ''),
        'meminfo':     Api('get',  '/api/1.0/appliance-management/system/meminfo', ''),
        'storageinfo': Api('get',  '/api/1.0/appliance-management/system/storageinfo', ''),
        'network':     Api('get',  '/api/1.0/appliance-management/system/network', ''),
        'locale':      Api('get',  '/api/1.0/appliance-management/system/locale', ''),
        'syslogserver':Api('get', '/api/1.0/appliance-management/system/syslogserver', ''),
        'timesettings':Api('get', '/api/1.0/appliance-management/system/timesettings', ''),

        'dns':         Api('put', '/api/1.0/appliance-management/system/network/dns', ''),
        'ntp':         Api('put', '/api/1.0/appliance-management/system/network/ntp', ''),
    }

    def restart(self):
        sys.stdout.write('Restart NSX Manager Appliance, are you sure (yes/no)? ')
        choice = raw_input().lower()
        msg = 'Restarting NSX Manager Appliance...\n\n' if choice == 'yes' else \
            'Restart NSX Manager operation aborted, NSX manager is not restarting'
        self.logger.info(msg)
        if choice != 'yes': return

        self.doRestApi('restart')

    def systemGetInfo(self, ns):
        retryParams = { 'method': 'get', 'maxTry': 10, 'interval': 5,
            'statusCodes': [200], 'rTextPat': ' 23:', }
        if ns=='INFO':
            resultStr = ''
            for ns in [
                    'info', 'uptime', 'cpuinfo', 'meminfo', 'storageinfo',
                    'network', 'locale', 'syslogserver', 'timesettings', ]:
                r = self.doRestApi(ns, retryParams=None)
                if r.text.startswith('<?xml '):
                    resultStr += pformat_xmlInYaml(r.text)
                else:
                    resultStr += '%s:\n    %s\n' % (ns,r.text)
            vcInfo = Vcenter2(self.mgr).show(display=False)
            if vcInfo:
                del vcInfo['certificateThumbprint']
                resultStr += pformat_yaml({'vcenter': vcInfo})
            else:
                resultStr += 'vcenter:\n    None'

            return resultStr

        else:
            r = self.doRestApi(ns)
            print('rText='+r.text)
            return r.text


class Component(Network_element):
    rest_api = {
        'components': Api('get', '/api/1.0/appliance-management/components', ''),
        'component': Api('get', '"/api/1.0/appliance-management/components/component/%s"%objectId', ''),
        'componentdependencies': Api('get', '"/api/1.0/appliance-management/components/%s/dependencies"%objectId', ''),
        'componentdependents': Api('get', '"/api/1.0/appliance-management/components/%s/dependents"%objectId', ''),
        'componentstatus': Api('get', '"/api/1.0/appliance-management/components/%s/status"%objectId', ''),
    }


class Log(Network_element):
    rest_api = {
        'get_sysEvent':       Api('get',   '/api/2.0/systemevent', ''),
        'get_audit':          Api('get',   '/api/2.0/auditlog', ''),
        'get_level':          Api('get',   '/api/1.0/services/debug/loglevel/com.vmware.vshield.vsm.security', ''),
        'set_level':          Api('post', "'/api/1.0/services/debug/loglevel/com.vmware.vshield.vsm.security?level=%s'%logLevel", ''),
        'create_techSupport': Api('post',  '/api/1.0/appliance-management/techsupportlogs/NSX', ''),
        'get_techSupport0':   Api('get',  '"/api/1.0/appliance-management/techsupportlogs/%s"%fname', ''),
        'get_techSupport':    Api('getStream',  '"%s"%locationUrl', ''),
    }

    def logOp(self, op, **kwargs):
        ''' extract kwargs to local namesapce '''
        exec('\n'.join('%s=kwargs["%s"]' % (k, k) for k in kwargs.keys()))

        if op in ['get_audit', 'get_sysEvent']:
            self.logger.info(op)
            r = self.doRestApi(op)
            self.prRespText(r.text, 'yaml')
        elif op in ['get_techSupport']:
            self.logger.info('Creating Tech Support Log Bundle')
            r = self.doRestApi('create_techSupport')
            locationUrl = r.headers['location']
            self.logger.info('Tech Support Log Bundle creaeted: %s', locationUrl)
            fname = locationUrl.split('/')[-1]
            self.logger.info('Downloading Tech Support Log Bundle %s' % fname)
            self.mgr.tmpDir = '/tmp'
            r = self.doRestApi('get_techSupport', locationUrl=locationUrl)
            self.logger.info('Downloading Tech Support Log Bundle to directory %s' % self.mgr.tmpDir)
            header={'stream':True}
            # normDiskSize
        elif op in ['get_level']:
            self.logger.info(op)
            r = self.doRestApi(op)
            print(r.text)
        elif op in ['set_level']:
            self.logger.info('%s to %s' % (op, logLevel))
            r = self.doRestApi(op, logLevel=logLevel)
            self.logger.info(r.text)


class Backup_restore(Network_element):
    rest_api = {
        'getconfig':  Api('get',    '/api/1.0/appliance-management/backuprestore/backupsettings', ''),
        'config':     Api('put',    '/api/1.0/appliance-management/backuprestore/backupsettings', ''),
        'delconfig':  Api('delete', '/api/1.0/appliance-management/backuprestore/backupsettings', ''),
        'available':  Api('get',    '/api/1.0/appliance-management/backuprestore/backups', ''),
        'backup':     Api('post',   '/api/1.0/appliance-management/backuprestore/backup', ''),
        'restore':    Api('post',   '"/api/1.0/appliance-management/backuprestore/backup?restoreFile=%s"%restoreFile', ''),
    }

    def backupOp(self, op, **kwargs):
        restMethod = self.rest_api[op].method
        restUrl = self.rest_api[op].url

        if op=='config':
            xml = kwargs['data']['xml']
            r = self.doRestApi(op, data=xml)
            self.logger.info('Backup settings configured')
        elif op=='restore':
            r = self.doRestApi(op, restoreFile=kwargs['restoreFile'])
            #self.mgr.dumpResquestsResponse(r)
            self.logger.info('Database restored')
        elif op in ['getconfig', 'available']:
            r = self.doRestApi(op)
            return r.text
        elif op in ['backup', 'delconfig']:
            r = self.doRestApi(op)
            self.logger.info('%s done' % op)
            return

class Upgrade(Network_element):
    '''
        http://www.geordy.nl/upgrading-nsx-from-the-command-line/
        wget http://build-squid.eng.vmware.com/build/mts/release/bora-3979471/publish/VMware-NSX-Manager-upgrade-bundle-6.2.3-3979471.tar.gz
        curl -i -v -k -u 'admin:Vmware123!' -H 'Accept:application/xml' -F file=@/nsx_nfs1/iso/6.2.3/RTQA12/VMware-NSX-Manager-upgrade-bundle-6.2.3-3979471.tar.gz -X POST https://nsxmgr3b/api/1.0/appliance-management/upgrade/uploadbundle/NSX -o upload.out

        curl -k -u 'admin:Vmware123!' -H "Accept:application/xml" -X GET https://nsxmgr3b/api/1.0/appliance-management/upgrade/information/NSX
    '''
    rest_api = {
        'upload': Api('post', '"/api/1.0/appliance-management/upgrade/uploadbundle/%s"%objectId', ''),
        'info':   Api('get',  '"/api/1.0/appliance-management/upgrade/information/%s"%objectId', ''),
        'start':  Api('post', '"/api/1.0/appliance-management/upgrade/start/%s"%objectId', ''),
        'status': Api('get',  '"/api/1.0/appliance-management/upgrade/status/%s"%objectId', ''),
    }

    def upgradeOp(self, op, **kwargs):
        ''' extract kwargs to local namesapce '''
        exec('\n'.join('%s=kwargs["%s"]' % (k, k) for k in kwargs.keys()))

        objectId = 'NSX'
        if op in ['info', 'status']:
            r = self.doRestApi(op, objectId='NSX')
            print(cptutil.StringData(r.text))
        elif op == 'upload':
            if not (os.path.isfile(upgradeBundleFile) and os.access(upgradeBundleFile, os.R_OK)):
                self.logger.error('Cannot read upgradeBundleFile "%s"' % upgradeBundleFile)
                return
            fileSize = os.stat(upgradeBundleFile).st_size
            self.logger.info('Uploading upgradeBundleFile "%s" (%s)' %
                (upgradeBundleFile, cptutil.normDiskSize(fileSize)))

            rest_url = eval(self.rest_api['upload'].url)
            self.mgr.postMultipartFile(rest_url, upgradeBundleFile)

        elif op == 'start':
            self.logger.info('Start NSX manager upgrade')
            xml = xw(
                xw('preUpgradeChecks1:Q1', ['questionId'])+
                xw('Do you want to enable SSH?', ['question'])+
                xw('YESNO', ['questionAnserType'])+
                xw('YES', ['answer']),
                ['preUpgradeQuestionAnswer', 'preUpgradeQuestionsAnswers'])
            r = self.doRestApi(op, objectId='NSX', data=xml)
            print(cptutil.StringData(r.text))


class Techsupportlogs(Network_element):
    rest_api = {
        'gen': Api('post', '"/api/1.0/appliance-management/techsupportlogs/%s"%objectId', ''),
        'get': Api('post', '"/api/1.0/appliance-management/techsupportlogs/%s"%filename', ''),
    }


class Vcenter2(Network_element):
    yamlObjNamePath = ['yaml', 'vcInfo', 0, 'ipAddress']
    rest_api = {
        'get': Api('get', '/api/2.0/services/vcconfig', ''),
        'cfg': Api('put', '/api/2.0/services/vcconfig', ''),
    }
    rKeys = ['vcInfo']
    #jqTableSpec = JqTableSpec( '[.ipAddress, .userName]', [])
    jqTblSpec = JqTblSpec('''{
        "ipAddress":    .ipAddress,
        "userName":     .userName,
        "invUpdate":    ((.vcInventoryLastUpdateTime|tonumber)/1000|todate),
    }''', '')


    def show(self, display=True):                   # class Vcenter2()
        vcs = self.find()
        if vcs:
            vc = vcs[0]
            if 'ipAddress' in vc and vc['ipAddress']:
                vc['vcInventoryLastUpdateTime'] = '%ss (%s)' % (
                    vc['vcInventoryLastUpdateTime'],
                    time.strftime('%D %T',
                        time.localtime(int(vc['vcInventoryLastUpdateTime'])/1000)))
                if display:
                    pprint_yaml(vc)
                return vc
        self.logger.warning('vCenter information not configured/avaliable')
        return {}

    def config(self, data, idBy='objectId', checkExist=True, confirmCert=False, **kwargs):
        xml = data['xml']
        restApiKey = 'cfgUniversal' if checkIsUniversal(data['yaml']) else 'cfg'
        r = self.doRestApi(restApiKey, data=xml, suppressRestErrMsg=True)

        if confirmCert and r.status_code == 403:
            m = re.search('<details>([0-9a-fA-F:]+)</details>', r.text)
            if m:
                thumbprint = m.group(1)
                xml = re.sub('<certificateThumbprint>.*</certificateThumbprint>',
                        '<certificateThumbprint>%s</certificateThumbprint>' % thumbprint,
                        xml)
                self.logger.info('Confirm server thumbprint %s...' % thumbprint[:12])
                r = self.doRestApi(restApiKey, data=xml)
            return True
        elif r.status_code >= 400:
            self.mgr.responseError(r)
            return False
        return True

    def register(self, vcIp, username, password, confirmCert):
        jDict = {
            'vcInfo': {
                'ipAddress': vcIp,
                'userName': username,
                'password': password,
            }
        }
        restApiKey = 'cfg'
        xml = xmltodict.unparse(jDict)
        r = self.doRestApi(restApiKey, data=xml, suppressRestErrMsg=True)
        if confirmCert and r.status_code >= 400:
            errDict = xmltodict.parse(r.text)
            if 'error' in errDict and 'details' in errDict['error']:
                thumbprint = errDict['error']['details']
                jDict['vcInfo']['certificateThumbprint'] = thumbprint
                xml = xmltodict.unparse(jDict)
                self.logger.info('Confirm server thumbprint %s...' % thumbprint[:12])
                r = self.doRestApi(restApiKey, data=xml)

        self.changeUserRole(username)

    def changeUserRole(self, username):
        userd = User(self.mgr)
        newRole = 'enterprise_admin'
        curRole = userd.roleMgmt('getrole', username)
        self.logger.info('Current role for user "%s": %s' % (username, curRole))
        if curRole and curRole!=newRole:
            self.logger.info('Remove existing role %s for user "%s"' % (curRole, username))
            userRold = userd.roleMgmt('delrole', username)
        if not curRole or curRole!=newRole:
            self.logger.info('Add role %s for user %s' % (newRole, username))
            userd.roleMgmt('addrole', username, newRole)
        self.logger.info('User "%s" now has role "%s"' % (username, newRole))

class User(Network_element):
    rest_api = {
        'get':        Api('get',     '/api/2.0/services/usermgmt/users/vsm', {'content-type':'application/xml', 'accept':'application/xml'}),
        'info':       Api('get',    '"/api/2.0/services/usermgmt/user/%s"%objectId', ''),
        'getrole':    Api('get',    '"/api/2.0/services/usermgmt/role/%s"%objectId', ''),
        'addrole':    Api('post',   '"/api/2.0/services/usermgmt/role/%s?isGroup=false"%objectId', ''),
        'delrole':    Api('delete', '"/api/2.0/services/usermgmt/role/%s?isGroup=false"%objectId', ''),
        'listroles':  Api('get',     '/api/2.0/services/usermgmt/roles', ''),
        'changerole': Api('put',    '"/api/2.0/services/usermgmt/role/%s?isGroup=false"%objectId', ''),
        'listscopingobjects': Api('get', '/api/2.0/services/usermgmt/scopingobjects', ''),
    }
    rKeys = ['users', 'userInfo']
    jqTableSpec = JqTableSpec('[.userId, .isEnabled, .isCli, .accessControlEntry.role]', [])
    jqTblSpec = JqTblSpec('''{
        "userId":    .userId,
        "isEnabled": .isEnabled,
        "isCli":     .isCli,
        "isEnabled": .isEnabled,
        "role":     .accessControlEntry.role,
    }''', '')

    def roleMgmt(self, op, userId=None, role=None, fmt='xml'):
        ''' op: getrole, addrole, delrole, listroles, changerole, listscopingobjects '''

        objectId = userId
        xml = '<accessControlEntry><role>%s</role></accessControlEntry>' % role

        restMethod = self.rest_api[op].method
        restUrl = self.rest_api[op].url
        restHeaders = self.rest_api[op].headers
        if restUrl.count('%') >= 2: restUrl = eval(restUrl)
        self.logger.debug('%s: REST CALL %s %s' % (type(self), restMethod, restUrl))
        if restMethod in ['post', 'put']:
            r = getattr(self.mgr, restMethod)(restUrl, xml,
                headers={'Accept': 'application/xml'})
        else:
            r = getattr(self.mgr, restMethod)(restUrl,
                headers={'Accept': 'application/xml'})

        if (200 <= r.status_code <= 204):
            if op.startswith('list'):
                #pprint(byteify(json.loads(r.text)))
                pprint_xml(r.text)
                #self.list(True)
                return r.text
            elif op == 'delrole':
                return True
            elif op == 'getrole':
                od = xmltodict.parse(r.text)
                return od['accessControlEntry']['role']
            elif op == 'info':
                self.prRespText(r.text, fmt=fmt)
        else:
            if op == 'getrole':
                return None
            else:
                self.logger.error("HTTP return code is not 20x: %d" % r.status_code)
                self.mgr.responseError(r)


class Sso(Network_element):
    yamlObjNamePath = ['yaml', 'ssoConfig', 0, 'ssoLookupServiceUrl']
    rest_api = {
        'get': Api('get', '/api/2.0/services/ssoconfig', ''),
        'status': Api('get', '/api/2.0/services/ssoconfig/status', ''),
        'cfg': Api('post', '/api/2.0/services/ssoconfig', ''),
        'del': Api('delete', '/api/2.0/services/ssoconfig', ''),
    }
    rKeys = ['ssoConfig']


class SIProfile(Network_element):
    rest_api = {
        'get':              Api('get',   '/api/4.0/firewall/layer3redirect/profiles', ''),
        'apply_binding':    Api('put',  '"/api/2.0/si/serviceprofile/%s/binding"%objectId', ''),
        'add_binding':      Api('post', '"/api/2.0/si/serviceprofile/%s/binding"%objectId', ''),
        'delete_binding':   Api('post', '"/api/2.0/si/serviceprofile/%s/binding"%objectId', ''),
        'deleteall_binding':Api('put',  '"/api/2.0/si/serviceprofile/%s/binding"%objectId', '')
    }
    rKeys = ['serviceProfiles', 'serviceProfile']
    jqTblSpec = JqTblSpec('''{
        "name":          .name,
        "objectId":      .objectId,
        "status":        .status,
    }''', '')

    def show(self, sipNameGlob, fmt='brief'):  # SIProfile
        def _fmtBindings(bindingHandle, binding):
            return '\n'.join([(bindingHandle.oid2n(oid) if bindingHandle else oid)
                for oid in listify(binding['string'])]
                if binding else '')

        sgd = self.mgr.objd(Security_group)
        lsd = self.mgr.objd(Logical_switch)
        sips = [sip for sip in self.find() if isGlobMatched(sipNameGlob, sip['name'])]
        ptbl = PrettyTable(['name/oId', 'desc', 'service', 'bindings'])
        ptbl.align = 'l'
        for sip in sips:
            sProfBindings = sip['serviceProfileBinding']

            ### only SG has been tested, ls, vs, dvpg are not tested
            sgs = _fmtBindings(sgd, sProfBindings['securityGroups'])
            lss = _fmtBindings(lsd, sProfBindings['virtualWires'])
            vss = _fmtBindings(None, sProfBindings['virtualServers'])
            dvpgs = _fmtBindings(None, sProfBindings['distributedVirtualPortGroups'])

            sProfSGBlindings =   'SG:\n'+     sgs   if sgs   else ''
            sProfLSBlindings =   'LS:\n'+     lss   if lss   else ''
            sProfDVPGBlindings = 'DVPG:\n'+   dvpgs if dvpgs else ''
            sProfVSSBlindings =  'vServer:\n'+vss   if vss   else ''
            ptbl.add_row([
                '%s\n %s'%(sip['name'], sip['objectId']),
                sip['description'],
                sip['service']['name'],
                '\n'.join([sProfSGBlindings, sProfDVPGBlindings, sProfLSBlindings, sProfVSSBlindings]).strip()
                ])
        if ptbl._rows:
            print(ptbl)
        print('Count: %d' % ptbl.rowcount)

    def sipOp(self, op, opDict={}):
        sipName = opDict['sipName']
        sipOid = self.n2oid(sipName)
        if op in ['apply_binding', 'add_binding']:
            sipBindingSpec = opDict['sipBindingSpec']
            self.logger.info('%s to SI Profile "%s"' % (op, sipName))
            sipBindings = (self._procGrpObjs(sipBindingSpec, refresh=True, PCache='w'))
            sipSgBindings = [e['value'] for e in sipBindings if e['type']=='SecurityGroup']
            sipLsBindings = [e['value'] for e in sipBindings if e['type']=='VirtualWire']
            sipDvpgBindings = [e['value'] for e in sipBindings if e['type']=='DistributedVirtualPortgroup']
            sipBindingDict = { 'serviceProfileBinding': {} }
            spb = sipBindingDict['serviceProfileBinding']
            if sipSgBindings: spb.update({'securityGroups': {'string': sipSgBindings}})
            if sipLsBindings: spb.update({'virtualWires': {'string': sipLsBindings}})
            if sipDvpgBindings: spb.update({'distributedVirtualPortGroups': {'string': sipDvpgBindings}})
            xml = xmltodict.unparse(sipBindingDict)
            r = self.doRestApi(op, objectId=sipOid, data=xml)
            self.logger.info('%s to SI Profile "%s" - DONE' % (op, sipName))
        elif op == 'delete_binding':

            sipDelBindings = self._procGrpObjs(opDict['sipBindingSpec'], refresh=True, PCache='w')
            sipDelBindingOids = [e['value'] for e in sipDelBindings]

            self.logger.info('Delete bindings from SI Profile "%s' % sipName)
            r = self.doRestApi('get', objectId=sipOid)
            sipBindingDict = xmltodict.parse(r.text)['serviceProfiles']['serviceProfile']['serviceProfileBinding']

            for k in sipBindingDict:
                if sipBindingDict[k]:
                    sipBindingDict[k]['string'] = list(
                        set(sipBindingDict[k]['string'])-set(sipDelBindingOids))

            xml = xmltodict.unparse({'serviceProfileBinding':sipBindingDict})
            r = self.doRestApi('apply_binding', objectId=sipOid, data=xml)
            self.logger.info('Deleted bindings from SI Profile "%s"' % sipName)
        elif op=='deleteall_binding':
            self.logger.info('Delete all bindings from SI Profile "%s"' % sipName)
            xml = xmltodict.unparse({'serviceProfileBinding': {}})
            r = self.doRestApi(op, objectId=sipOid, data=xml)
            self.logger.info('Deleted all bindings from SI Profile "%s"' % sipName)


class Certificate(Network_element):
    rest_api = {
        'getnsx': Api('get',    '/api/1.0/appliance-management/certificatemanager/certificates/nsx', ''),
        'getone': Api('get',   '"/api/2.0/services/truststore/certificate/%s"%objectId', ''),
        'get':    Api('get',   '"/api/2.0/services/truststore/certificate/scope/%s"%objectId', ''),
        'create': Api('post',  '"/api/2.0/services/truststore/certificate/%s"%objectId', ''),
        'del':    Api('delete','"/api/2.0/services/truststore/certificate/%s"%objectId', ''),
    }
    rKeys = ['certificates', 'certificate']

    def _mapScope(self, scope):
        return 'globalroot-0' if scope in ['globalroot-0', 'global'] else \
            Edge(self.mgr).find_by_name(scope)

    def list(self, scope):                                              # Certificate
        ptbl = PrettyTable(['objectId', 'name'])
        ptbl.align = 'l'
        objectId = self._mapScope(scope)
        certs = self.find(objectId=objectId, refresh=True)
        for cert in certs:
            certName = cert['name'] if 'name' in cert else ''
            if isinstance(cert['x509Certificate'], list):
                certSubjectName = cert['x509Certificate'][0]['subject']
                certSubjectName = '\n'.join([c['subject'] for c in cert['x509Certificate']])
            else:
                certSubjectName = cert['x509Certificate']['subject']
            ptbl.add_row([cert['objectId'], certName])
        print('%s:' % self.className)
        if ptbl._rows:
            print(ptbl)
        print('Count: %d' % ptbl.rowcount)

    def create(self, scope, pem, privKey, scopeId=None):  # Certificate
        if not scopeId:
            scopeId = self._mapScope(scope)
        print pem
        with open(pem, 'r') as certfile:
            certContent=certfile.read()
            cert = OpenSSL.crypto.load_certificate(OpenSSL.crypto.FILETYPE_PEM, certContent)
        certCN = cert.get_subject().commonName
        withPrivKeyStr = ' with private key' if privKey else ''
        if privKey:
            with open(privKey, 'r') as keyfile:
                keyContent = keyfile.read()
        privKeyXml = xw(keyContent, ['privateKey']) if privKey else ''
        pemXml = xw(certContent, ['pemEncoding'])
        xml = xw(pemXml+privKeyXml, ['trustObject'])
        
        self.logger.info('Creating certificate "%s"%s in %s' % (certCN, withPrivKeyStr, (scope or scopeId)))
        r = self.doRestApi('create', objectId=scopeId, data=xml)
        if r.status_code == requests.codes.ok:
            certOd = xmltodict.parse(r.text)
            certId = certOd['certificates']['certificate']['objectId']
            self.logger.info('Created  certificate "%s"%s in %s (%s)' % (
                certCN, withPrivKeyStr, (scope or scopeId), certId))
            return certId
        return None

    def delete(self, scope, certName):                              # Certificate
        scopeId = self._mapScope(scope)
        self.find(objectId=scopeId, refresh=True)
        certs = certs = self.find_by_name(certName, results=['objectId', 'name'], matchMethod='glob') \
            if self.cachedObjs else None
        if not certs:
            self.logger.warning('No %s certificate "%s" found' % (scope, certName))
            return
        for certId,certName in certs:
            self.logger.info('Deleting %s certificate "%s" (%s)' % (scope, certName, certId))
            r = self.doRestApi('del', objectId=certId)
            if r.status_code/200 == 1:
                self.logger.info('Deleted  %s certificate "%s" (%s)' % (scope, certName, certId))

class Cli(Network_element):
    rest_api = {
        'exec': Api('post', '/api/1.0/nsx/cli?action=execute', ''),
    }

    def execCmds(self, cmds):
        ''' Example: cli exec 'show ip route' '''
        for cmd in cmds:
            xml = xw('%s'%cmd, ['command','nsxcli'])
            r = self.doRestApi('exec', data=xml)
            print(r.text)

class SpoofGuard(Network_element):
    rest_api = {
        'getone':      Api('get',   '"/api/4.0/services/spoofguard/policies/%s"%objectId', ''),
        'del':         Api('delete','"/api/4.0/services/spoofguard/policies/%s"%objectId', ''),
        'get':         Api('get',    '/api/4.0/services/spoofguard/policies/', ''),
        'create':      Api('post',   '/api/4.0/services/spoofguard/policies/', ''),
        'listByState': Api('get',   '"/api/4.0/services/spoofguard/%s?list=%s"%(sgpId,state)', ''),
        'update':      Api('post',  '"/api/4.0/services/spoofguard/%s?action=%s"%(sgpId,ipAction)', ''),
    }
    rKeys = ['spoofguardList', 'spoofguard']
    rKeys = ['spoofguardPolicies', 'spoofguardPolicy']
    oidParentDepth = 2
    #jqTblSpec = JqTblSpec('''{
    #    "nicName":       .nicName,
    #    "approvedIp":   .approvedIpAddress.ipAddress,
    #    "publishedIp":  .publishedIpAddress.ipAddress,
    #    "detectedIp":   .detectedIpAddress.ipAddress|join(","),
    #    "detectedMac":  .publishedMacAddress,
    #}''', '')
    ptblFmts = {
        'get': PtblFmt(rest_api['get'].url, '''.[] |{
            "name":           .name,
            "id":             .policyId,
            "mode":           .operationMode,
            "publishedOn":    .publishedOn,
            "allowLocalIPs":  .allowLocalIPs,
            "publishPending": .publishPending,
            "defaultPolicy":  .defaultPolicy,
        }'''),
        'listByState': PtblFmt(rest_api['listByState'].url, '''
            def shortUuid:.[0:4]+".."+.[32:];
            def listify:if type=="array" then .[] else select(.) end;
            .[]|{
                "nicName":      .nicName,
                "nicUuid":      .vnicUuid,
                "detechedMac":  .detectedMacAddress,
                "approvedMac":  .approvedMacAddress,
                "publishedMac": .publishedMacAddress,
                "detectedIp":   [.detectedIpAddress.ipAddress|listify]|sort|join("\n") ,
                "approvedIp":   [.approvedIpAddress.ipAddress|listify]|sort|join("\n"),
                "publishedIp":  [.publishedIpAddress.ipAddress|listify]|sort|join("\n"),
            }
        '''),
    }


    def spgOp(self, policyNameGlob, op, nicNameGlob='*', state=None, defPolicy=None,
            allowLocalIPs=None, opMode=None, enforcementPointsSpec=''):
        ''' op: show, create, publish, unpublish '''
        if op == 'create':
            self.logger.info('Create Spoof Guard Policy "%s" (default=%s, allowLocalIPs=%s, opMode=%s)' % (
                policyNameGlob, defPolicy, allowLocalIPs, opMode))
            postDict = {
                'spoofguardPolicy': {
                    'name': policyNameGlob,
                    'operationMode': opMode,
                    'allowLocalIPs': allowLocalIPs
                }
            }
            if enforcementPointsSpec:
                eps = postDict['spoofguardPolicy']['enforcementPoint'] = []
                for epSpec in enforcementPointsSpec.split(','):
                    epId = self._procGrpObjsOids(epSpec, refresh=False)
                    epType, epName = epSpec.split('|')
                    #print('>>', epType, epName, epId)
                    epType, epName = epSpec.split('|')
                    eps.append( {'id': epId} )
            xml = xmltodict.unparse(postDict)
            #pprint_xml(xml)
            r = self.doRestApi('create', data=xml)
        elif op in ['list', 'show', 'publish', 'unpublish']:
            r = self.doRestApi('get')
            jsonData = xmltodict.parse(r.text)
            jsonData = listify(jsonData['spoofguardPolicies']['spoofguardPolicy']) \
                if jsonData['spoofguardPolicies'] else []
            sgps = [d for d in jsonData if isGlobMatched(policyNameGlob, d['name'])]
            #pprint_json(sgps)
            display = (op in ['list', 'show'])
            print('Spoof Guard Policy list:')
            self.jqTable(sgps, jqFilter=self.ptblFmts['get'].jqFilter)
            if op in ['show', 'publish', 'unpublish']:
                for sgp in sgps:
                    sgpId,sgpName = sgp['policyId'],sgp['name']
                    enfPoints = sgp['enforcementPoint'] if 'enforcementPoint' in sgp else []
                    #pprint_od(sgp)
                    #pprint_od(sgp['enforcementPoint'])
                    print('\nSpoof Guard Policy "%s" entries w/state=%s%s:' % (
                        sgpName, state, ' (Default policy)' if sgp['defaultPolicy']=='true' else ''))
                    print('    EnforcementPoints: %s' % ', '.join([e['name'] for e in enfPoints]))
                    r = self.doRestApi('listByState', sgpId=sgpId, state=state.upper())
                    jsonDict = xmltodict.parse(r.text)
                    jsonDict = jsonDict['spoofguardList']['spoofguard'] if jsonDict['spoofguardList'] else []
                    rows, ptbl = self.jqTable(json.dumps(jsonDict), jqFilter=self.ptblFmts['listByState'].jqFilter,
                        nameGlob=nicNameGlob, nameTag='nicName', display=display)
                    if op in ['publish', 'unpublish']:
                        for nicEntry in rows:
                            #pprint_json(nicEntry)
                            detectedIps = nicEntry['detectedIp'].split('\n')
                            candidateIps = []
                            jsonPost = {'spoofguardList': {'spoofguard': {
                                'id': nicEntry['nicUuid'],
                                'vnicUuid': nicEntry['nicUuid'],
                                'approvedMacAddress':  nicEntry['detechedMac'],
                                'approvedIpAddress':  {'ipAddress': detectedIps} if op=='publish' else {}
                            } } }
                            #pprint_json(jsonPost)
                            xml = xmltodict.unparse(jsonPost)
                            #pprint_xml(xml)
                            r = self.doRestApi('update', data=xml, sgpId=sgpId, ipAction='approve')
                            #print(r.text) 
                            r = self.doRestApi('update', sgpId=sgpId, ipAction='publish')
                            #print(r.text)


class Internal(object):
    def internalOp(self, op, args):
        if op == 'listClass':
            classes = []
            for name, obj in inspect.getmembers(sys.modules[__name__]):
                if inspect.isclass(obj):
                    print(' => '.join(['%-15s'%c.__name__ for c in inspect.getmro(obj)]))
        elif op == 'class':
            for c in [ Network_object, Security_group, Health, Detection, Vcenter2, Cli ]:
                print('%-15s %s' % (c.__name__, cptutil.getClassByMethod(c.show).__name__))
            c=eval(args[0])
            print(' >> '.join([c.__name__ for c in inspect.getmro(c)]))
        elif op == 'method':
            if len(args)==2:
                c, m = args; C=eval(c); method=eval('%s.%s' % (c,m))
                print('%s.%s() from %s' % (C.__name__, m, cptutil.getClassByMethod(method).__name__))
            elif len(args)==1:
                m = args[0];
                for name, obj in inspect.getmembers(sys.modules[__name__]):
                    if inspect.isclass(obj) and hasattr(obj, m):
                        method = eval('%s.%s' % (obj.__name__, m))
                        print('%-30s from %s' % ('%s.%s()'%(obj.__name__, m), cptutil.getClassByMethod(method).__name__))

def subClasses(c):
    return c.__subclasses__()
def subClassNames(c):
    return [c(None,logger=None).className for c in c.__subclasses__()]

grpObjMap = {
#   <key> | <apiType>                    <nsxvlibType>            GroupingObj       DFW      SG-member
#                                                                                           static  dyn
    'A':  ('VirtualApp',                 vim.ResourcePool),     # vApp              S/D     M/E      E
    'AP': ('Application',                Application),          # Application
    'AG': ('Applicationgroup',           Application_group),    # ApplicationGroup
    'C':  ('ClusterComputeResource',     vim.ClusterComputeResource),   # Cluster   S/D/A   M/E      E
    'D':  ('Datacenter',                 vim.Datacenter),       # Datacenter        S/D/A   M/E      E
    'DG': ('DirectoryGroup',             DirectoryGroup),       # DirectoryGroup
    'E':  ('',                           None),                 # Edge                  A
    'G':  ('SecurityGroup',              Security_group),       # SecurityGroup     S/D/A   M/E      E
    'H':  ('',                           None),                 # Host                  A
    'I':  ('IPSet',                      Ipset),                # IPset             S/D     M/E      E
    'L':  ('VirtualWire',                Logical_switch),       # LogicalSwitch     S/D/A   M/E      E
    'M':  ('MACSet',                     Macset),               # MacSet                             E
    'N':  ('Network',                    vim.Network),          # Nework (PG)       S/D/A   M/E      E
    'NO': ('VM.GUEST_OS_FULL_NAME',      None),                 # OS Name                           D
    'NV': ('VM.NAME',                    None),                 # VM Name                           D
    'NC': ('VM.GUEST_HOST_NAME',         None),                 # Computer Name                     D
    'NT': ('VM.SECURITY_TAG',            Security_tag),         # SecurityTag                       D
    'P':  ('DistributedVirtualPortgroup',vim.dvs.DistributedVirtualPortgroup),# dPG S/D/A   M/E      E
    'SIP':('SIProfile',                  SIProfile),            # SIProfile
    'T':  ('',                           Security_tag),         # SecurityTag                        E
    'V':  ('VirtualMachine',             vim.VirtualMachine),   # VirtualMachine    S/D/A   M/E      E
    'VN': ('Vnic',                       vim.VirtualMachine),   # VNic              S/D/A   M/E      E
    'R':  ('',                           None),                 # ResourcePool      S/D     M/E      E
    'EN': ('',                           None),                 # entity                            D
    'i4': ('',                           None),                 # Ipv4Address       S/D     M/E      E
    'i6': ('',                           None),                 # Ipv6Address       S/D     M/E      E
}
grpObjMap_r = {}
for k,v in grpObjMap.items():
    grpObjMap_r[v[0]]=k

def main():
    import requests
    requests.packages.urllib3.disable_warnings()
    nsxmgr, nuser, npass  = 'nsxmgr3b', 'admin', 'Vmware123!'

    #mgr = restlib.RestConnect('https://%s' % nsxmgr, user=nuser, password=npass, verify=False)
    mgr = Manager(nsxmgr, user=nuser, password=npass, verify=False)

    dfw = Distributed_firewall(mgr)

    for c in Network_element.__subclasses__():
        print(c(None,logger=None).className)
    print(subClassNames(Network_element))
    pprint(mgr.pCache)

if __name__ == '__main__':
    main()

'''
# Query Certificates
api get /api/1.0/appliance-management/certificatemanager/certificates/nsx
# Query ALL Certificates
api get  /api/2.0/services/truststore/certificate/scope/globalroot-0
api post /api/2.0/services/truststore/certificate/edge-30 '<trustObject><pemEncoding>
-----BEGIN CERTIFICATE-----
MIIF7jCCA9agAwIBAgIJAORqHRy4v8T1MA0GCSqGSIb3DQEBCwUAMIGGMQswCQYD
VQQGEwJVUzETMBEGA1UECAwKQ2FsaWZvcm5pYTESMBAGA1UEBwwJUGFsbyBBbHRv
MQ8wDQYDVQQKDAZWTXdhcmUxDTALBgNVBAsMBE5TQlUxDzANBgNVBAMMBkNQVCBD
QTEdMBsGCSqGSIb3DQEJARYObHlkQHZtd2FyZS5jb20wHhcNMTUwMTIzMjEzODEx
WhcNNDIwNjA5MjEzODExWjCBhjELMAkGA1UEBhMCVVMxEzARBgNVBAgMCkNhbGlm
b3JuaWExEjAQBgNVBAcMCVBhbG8gQWx0bzEPMA0GA1UECgwGVk13YXJlMQ0wCwYD
VQQLDAROU0JVMQ8wDQYDVQQDDAZDUFQgQ0ExHTAbBgkqhkiG9w0BCQEWDmx5ZEB2
bXdhcmUuY29tMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEApuYOjoL/
rHhRsbkxZCa4J1eawdeRpZKMbq+s7R124eL8dUg084IPtu2Q5hCO3aJn3v9wak8i
HR3wOBf7P7FsUSyspEK8a15R7ApjxDQSTbBdBHeOB6b27Mo+ZcjH5eu5HulOlPfu
f3uTwqUakSaDcZDa9sbyIu5yeQu1RbvWmXR5cmLhHevx1GdKlXLFD6PDF0dz/8Hy
GLIJuU6i2J5+HCLlrjTd5EK1+G487d83f8hQw/loqUHVvlao8yT6owv2WCNJSzqA
Sy1l2Vvxvv83QDhQkhvWLBfQHpapb0q1zvvISsONpqos05g30Fw+BUc+FM93SBHO
WqTt/XVFvYWqHliV/t7j6qLXS73GMZZEKrmfaIgofSwSFMneN/9cr2Xv1t+FYc6R
K1K5ZX0bcckM4LiLLNDFLkK0ySp2Z9f5tfPWgwU61ywzvf8fTfuRZh5OAPPnOhto
ypwm94tBjqS223ip3yLWNMm3MEll6ozR9vq9dO7NLPyPgMf0VpjN03fsJPUVRay3
PL7XdyUgujoKNPntH1xIpx0eRXKj2ABHR2b51foScBtMAbZ/3pAogm9qegOurnFj
WfV+7s/GCmF4vXvBRG3RyesHOCFEGFbRb8qzxoPWRixB9UT3r2Kd/qtb91JeOQqb
VM/mRQR6cwt77oC35nigEreMAKkF0MpIqIkCAwEAAaNdMFswHQYDVR0OBBYEFBEA
MHZvSH3Dqz/zZ4BW6RuJQ7oEMB8GA1UdIwQYMBaAFBEAMHZvSH3Dqz/zZ4BW6RuJ
Q7oEMAwGA1UdEwQFMAMBAf8wCwYDVR0PBAQDAgEGMA0GCSqGSIb3DQEBCwUAA4IC
AQCN7sNhbXOzVi8LEmBmYLoHe3IazGNcfGQmo2Rd2EJCeGxIuNyaOwQRmUW6I//0
vgnOfqtWyAIwFcRSqeuZv73bnjX5GChPKSZel9wIzGPgM+73o67Lym6w/TO5QjVJ
jE69MZ35k4sg62xB3qgTpTDmeSj3Gio8z0MiOQgqq2y4A8mfo1aFxWrAzalftnWu
rYD0zr9nfuEhR9EY/itg0ZOftG5zxIh3DqNbmnpGykU/HN/2MpO619NHj3sR87eJ
cfE7fYD3mrI5Qcp7iHlL2NXVIrdGhpPznimNA8D5h9+TqRU8B/YZBrlkXhaawgHc
jeeOGg4lRy7+x9qLQ1VcFvxrKw8UxteIWuzfZc0aKyw0143ulZzWw+MuTXYP6chN
oj9AOp3oVSh1J71lYf6MJUfbRT/BstPWYYlUp9xLoD3QQG13dtQnUMDvzjNwbGgX
Rt51XfDgod0rBEjxp6VDLZQ4MmR/JFR91O/yDzWjhwLi127NRlN6JP9NUgp0epP1
PJNRk3cUqzMbRLq+HtU0yODm77Xn2+zbvF4X1+1W2Twy5LUTrg5+8V2YrbjaARyd
dwzaAc4ag+c6z/qXGfz4Fo8hPXlo1SMg31LOwx+Muc2HQJeELdZbS2SxBatL/ptW
iBhiYfH3ZczFb7+/7F93TL8BtpjDOGPhTsXoyd9s82IWyg==
</pemEncoding></trustObject>'


# Query Global Appliance Manager Information
api get /api/1.0/appliance-management/global/info

/api/4.0/firewall/globalroot-0/config?layer=3
/api/4.0/firewall/globalroot-0/config/?ruleType=LAYER3

[
    {
        "id": "virtualwire-10",
        "name": "LS6",
        "type": "VirtualWire"
    },
    {
        "id": "virtualwire-5",
        "name": "LS1",
        "type": "VirtualWire"
    },
    {
        "id": "virtualwire-6",
        "name": "LS2",
        "type": "VirtualWire"
    },
    {
        "id": "virtualwire-7",
        "name": "LS3",
        "type": "VirtualWire"
    },
    {
        "id": "virtualwire-8",
        "name": "LS4",
        "type": "VirtualWire"
    },
    {
        "id": "virtualwire-9",
        "name": "LS5",
        "type": "VirtualWire"
    }
]

'''
