#!/usr/bin/env python
#from __future__ import print_function
import pinit
import cptdecor
import threading
import time
import sys
import logging
import types
#import commands
import subprocess
import traceback

class Toaster(object):
    '''
    load(workloadName, workload, **kwargs)
        workloadName: name of this instance of workload
        workload: python function or shell command (string)
        **kwargs: keyword argument consumed by python function
    '''
    def __init__(self, nSlot, logLevel=logging.WARNING, logger=None):
        #super(Toaster, self).__init__()
        super(self.__class__, self).__init__()
        self.lock = threading.Lock()
        self.semaphore = threading.Semaphore(nSlot)

        if logger:
            self.logger = logger
        else:
            logging.basicConfig(
                datefmt='%T',
                format='%(asctime)s (%(threadName)-9s) %(message)s')

            self.logger = logging.getLogger('Toaster')
            self.logger.setLevel(logLevel)

    def load(self, threadName, workload, *args, **kwargs):
        #t = threading.Thread(target=self.toast, name=threadName,
        #    args=(workload,), **kwargs)
        t = threading.Thread(group=None, target=self.toast, name=threadName,
            args=(workload,), *args, **kwargs)

        self.logger.debug('loading: %s', threadName)
        t.start()
        return t

    def push(self, name):
        with self.lock:
            self.logger.debug('START %s', name)
            self.logger.debug('Running: %s',
                [t.getName() for t in threading.enumerate()])

    def pop(self, name):
        with self.lock:
            self.logger.debug('DONE %s', name)
            self.logger.debug('Running: %s',
                [t.getName() for t in threading.enumerate()])

    def toast(self, work, *args, **kwargs):
        self.logger.debug('Waiting to join the pool')
        with self.semaphore:
            name = threading.currentThread().getName()
            self.push(name)
            try:
                if isinstance(work,types.FunctionType):
                    work(*args, **kwargs)
                elif isinstance(work,types.StringType):
                    #print(commands.getoutput(work))
                    print(subprocess.check_output(workload.split(' ')))
                elif isinstance(work,types.MethodType):
                    work(*args, **kwargs)
                else:
                    self.logger.error('Unsupporte workload type: %s' % type(work))
            except Exception as e:
                self.logger.error('Exception in thread %s: %s' % (name, e))
                self.logger.error(traceback.print_exc())
            self.pop(name)

    def wait(self):
        nActive = threading.activeCount()
        while nActive>1:
            self.logger.debug('%d active thread(s): %s' % (
                threading.activeCount(),
                [t.getName() for t in threading.enumerate()]))
            #time.sleep(max(1, nActive))
            nActive = threading.activeCount()
            if nActive > 1:
                #time.sleep(nActive)
                time.sleep(1)

def toastlib_workload(**kwargs):
    msg = kwargs['msg']
    delay = random.randint(1,10)/10.0
    print('%s, delay=%s' % (msg,str(delay)))
    time.sleep(delay)

class Toastlib_workload(object):
    def prMsg(self, msg):
        delay = random.randint(1,10)/10.0
        print('%s, delay=%s' % (msg,str(delay)))
        time.sleep(delay)

if __name__ == '__main__':
    import random

    nSemaphore = 3
    nJob = 10

    hostList = ['192.168.0.%d'%i for i in xrange(1,nJob+1)]

    twork = Toastlib_workload()

    toaster = Toaster(nSemaphore, logging.DEBUG)
    for hostIp in hostList:
        msg = '\ttime=%s' % time.strftime('%T')
        jobName = 'Job-'+hostIp
        #toaster.load(jobName, toastlib_workload, kwargs={'msg':msg})
        #toaster.load(jobName, 'sleep $(expr $RANDOM % 3); date', kwargs={'msg':msg})
        toaster.load(jobName, twork.prMsg, kwargs={'msg':msg})
        #toaster.load(jobName, twork.prMsg , msg)
    #toaster.wait()

