#!/usr/bin/env python
from __future__ import print_function
import pinit
import sys, os
import traceback
import itertools
import re
import json
#import yaml
#import urllib2
import restlib
from requests.structures import CaseInsensitiveDict
import argparse
import logging
from pprint import pprint, pformat
import collections
import socket
#import xmltodict
import abc
import copy
import cptutil
from cptutil import pprint_od, toUtf8Dict, listify, isGlobMatched, pprint_json
from pyVim import connect
from pyVmomi import vim
from pyVmomi import vmodl
from collections import OrderedDict as OD, namedtuple
from random import shuffle
import time, datetime
import math
import operator
import pdb
import paramiko
from pyVim.connect import SmartConnect
from pyVmomi import vim
from prettytable import PrettyTable
from enum import Enum
import nsxtlib
import pyjq
import uuid
import ssl
import OpenSSL

Api      = namedtuple('Api',     ('method', 'url'))
PtblFmt  = namedtuple('PtblFmt', ('url', 'jqFilter'))
ResTypeMap = namedtuple('ResTypeMap', ('apiResType', 'nsxvClass'))

#------------------------------------------------------------------------------
# https://wiki.python.org/moin/PythonDecoratorLibrary#Memoize
import collections
import functools

class memoized(object):
   '''Decorator. Caches a function's return value each time it is called.
   If called later with the same arguments, the cached value is returned
   (not reevaluated).
   '''
   def __init__(self, func):
      self.func = func
      self.cache = {}
   def __call__(self, *args):
      if not isinstance(args, collections.Hashable):
         # uncacheable. a list, for instance.
         # better to not cache than blow up.
         return self.func(*args)
      if args in self.cache:
         return self.cache[args]
      else:
         value = self.func(*args)
         self.cache[args] = value
         return value
   def __repr__(self):
      '''Return the function's docstring.'''
      return self.func.__doc__
   def __get__(self, obj, objtype):
      '''Support instance methods.'''
      return functools.partial(self.__call__, obj)
#------------------------------------------------------------------------------
def memoize(obj):
    cache = obj.cache = {}

    @functools.wraps(obj)
    def memoizer(*args, **kwargs):
        if args not in cache:
            cache[args] = obj(*args, **kwargs)
        return cache[args]
    return memoizer
#------------------------------------------------------------------------------

#---- HELP MSG BEGIN ----------------------------------------------------------
notSupportedMsg = 'FEATURE NOT YET SUPPORTED BY PM'
pmPolicyRulesSpecHelp='''
    policy communication map entries specification (rules Spec):
        ( rName : rSrcs : rDsts : rScope : rAction : rServices [;] )...
    Examples:

'''
pmPolicyApplicationSpecHelp = notSupportedMsg
pmPolicyEmergencySpecHelp = pmPolicyRulesSpecHelp
pmPolicyEnvironmentalSpecHelp = notSupportedMsg
pmPolicyInfrastructureSpecHelp = notSupportedMsg

#---- HELP MSG END ------------------------------------------------------------


class Policy_object(nsxtlib.Network_object):
    __metaclass__  = abc.ABCMeta

    def __checkReturnCode(self, value, codes):
        if codes:
            if value not in codes:
                print("Return code '%d' not in list of expected codes: %s"
                      %(value, codes))
        
    def get(self, api, convert=True,display=False,
            codes=None,mgr=None):
        r = self.rest_api(api=api, method='GET', convert=convert,display=display,mgr=mgr)
        self.__checkReturnCode(r.status_code, codes)
        return r
    def put(self, api, data=None,convert=True,
            codes=None,display=False,mgr=None):
        
        r = self.rest_api(api=api, method='PUT', data=data,
                             convert=convert,display=display,mgr=mgr)
        self.__checkReturnCode(r.status_code, codes)
        return r
                      
    def patch(self, api, data=None,convert=True,codes=None,
              display=False,mgr=None):
        r = self.rest_api(api=api, method='PATCH', data=data,
                             convert=convert,display=display,mgr=mgr)
        self.__checkReturnCode(r.status_code, codes)
        return r
    def post(self, api, data=None,convert=True,display=False,mgr=None, codes=None):
        r = self.rest_api(api=api, method='POST', data=data, 
                             convert=convert,display=display,mgr=mgr)
        self.__checkReturnCode(r.status_code, codes)
        return r
    def delete(self, api, data=None,convert=True,codes=None, display=False,mgr=None):
        r = self.rest_api(api=api, method='DELETE', data=data,
                             convert=convert,display=display,mgr=mgr)
        self.__checkReturnCode(r.status_code, codes)
        return r
        

    def getPathByName(self, name, api=None, data=None, display=True):
        if not api:
            api=self.listUrl

        obj = self.findByName(restUrl=api,name=name, data=data, display=False)
        if obj:
            if display:
                print(obj['path'])
            return obj['path']
        return None
    def getPathById(self, id, api=None, data=None, display=True):
        if not api:
            api=self.listUrl

        obj = self.findById(restUrl=api,id=id,data=data, display=False)
        if obj:
            if display:
                print(obj['path'])
            return obj['path']
        return None

    def getRealizationEntities(self, name=None,path=None,display=True):
        if not path and not name:
            print("Must either supply entity path or name to get realization status")
            return None


        if not path and name:
            path=self.getPathByName(name=name,display=False)
            if not path:
                print("Entity with name %s not found to retrieve realization" %name)
                return None

        api="/policy/api/v1/infra/realized-state/realized-entities?intent_path=%s"%path
        r = self.get(api=api, display=True)
        if display:
            self.json_print(json.loads(r.text), convert=False)
        return json.loads(r.text)

    def getRealizationStatus(self, name=None, path=None,display=True):
        if not path and not name:
            print("Must either supply entity path or name to get realization status")
            return None


        if not path and name:
            path=self.getPathByName(name=name,display=False)
            if not path:
                print("Entity with name %s not found to retrieve realization" %name)
                return None

        api="/policy/api/v1/infra/realized-state/status?intent_path=%s"%path
        r = self.get(api=api, display=True)
        if display:
            self.json_print(json.loads(r.text), convert=False)
        return json.loads(r.text)

    def getPathByTypeAndName(self, name, types, display=True):
        '''
        name = name of the object
        types = list of types to search through
        '''

        for t in types:
            obj=t(mp=self.mp)
            p = obj.getPathByName(name=name, display=display)
            if p:
                return p
        
        return None
        
class PolicyNode(nsxtlib.ManagerNode):
    def __init__(self, host,
                 thumbprint=False,
                 rootpassword='CptWare12345!',
                 adminuser='admin',
                 adminpassword='Vmware12345!',
                 verify=False,
                 content_type="application/json",
                 accept='application/json',
                 loglevel="INFO",
                 nsxtAuth=True,
                 mgr=None,
                 pm=None,
                 site='default',
                 enforce='default',
                 certFile=None,
                 sessCookieFile=None,
                 timeout=None,
                 safe=False):

        super(self.__class__, self).__init__(host=host,
                                             thumbprint=thumbprint,
                                             rootpassword=rootpassword,
                                             adminuser=adminuser,
                                             adminpassword=adminpassword,
                                             verify=verify,
                                             content_type=content_type,
                                             accept=accept,
                                             loglevel=loglevel,
                                             nsxtAuth=nsxtAuth,
                                             mgr=mgr,
                                             pm=pm,
                                             timeout=timeout,
                                             certFile=certFile,
                                             sessCookieFile=sessCookieFile,
                                             safe=safe)
        self.site=site
        self.enforce=enforce
        self.logger=self.mgr.logger

                                           

def _mkTagQuery(tags, op='OR'):
    tagQuery = '(%s)' % (
        ' %s '%op).join(
            ['(tags.scope:%s AND tags.tag:%s)' %
                tuple([v or '*' for v in tag.split(':')]) \
            for tag in tags]
        ) if tags else ''
    tagQuery = re.sub(r'tags.scope:\* AND ', '', tagQuery)
    tagQuery = re.sub(r' AND tags.tag:\*', '', tagQuery)
    return tagQuery

def _mkSearchQuery(key, vals, op='OR'):
    conds = ['%s:%s'%(key,val) for val in listify(vals)]
    qStr = ' %s '.join(conds) if vals else ''
    return '(%s)'%qStr if len(conds)>1 else qStr

def _jqResOrCrit(resType, key, vals, reMagic=False):
    if not reMagic:
        vals = [v.replace('/', '\/') for v in vals]
    keyCond = _mkSearchQuery(key, vals, op='OR')
    resCond = _mkSearchQuery('resource_type', resType)
    combCond = [resCond, keyCond]
    combCond = [c for c in combCond if c]
    return ' AND '.join(combCond)

def _jqResOrCrit0(resType, key, vals):
    orCond = ' AND (%s)'%' OR '.join(['%s:%s'%(key,val) for val in vals]) if vals else ''
    return 'resource_type:%s%s' % (resType, orCond)


class Cluster(Policy_object):
    '''
    This overwrites the same cluster class in nsxtlib.py
    '''
    
    def __init__(self, mp):
        super(self.__class__, self).__init__(mp=mp)
        self.listUrl = '/api/v1/cluster/nodes'
        self.clusterid = self.info(display=False)['cluster_id']
        self.mgr=mp.getMgr()


    def info(self, display=True):
        restUrl = '/api/v1/cluster'
        r = self.mgr.get(restUrl,
                headers={'Accept': 'application/json'})
        if r.status_code >= 400:
            print (r.text)
            self.mgr.responseError(r)
            return None

        if display:
            self.json_print(json.loads(r.text),indent=4)
        return json.loads(r.text)


    def createCluster(self,primary,secondaries):
        primary.getThumbprint(refresh=True)
        primary.getClusterInfo()
        for s in secondaries:
            s.getClusterInfo()
            data={}
            data['certficate_sha256_thumbprint'] = primary.getThumbprint()
            data['cluster_id']=primary.getClusterId()
            data['ip_address'] = primary.getIpAddress()
            #data['port'] = 443
            data['username'] = primary.getAdminUser()
            data['password'] = primary.getAdminPassword()

            restUrl='/api/v1/cluster?action=join_cluster'
            r = s.rest_api(api=restUrl,method='POST', data=data, display=True)
            if r.status_code != 200:
                print("Error in joining cluster.  primary: %s, secondary: %s"
                      % (primary.getIpAddress(), s.getIpAddress()))
                raise ValueError("Failure to join cluster: %d'" %r.status_code)

    def nodes(self):
        restUrl = '/api/v1/cluster/nodes'
        r=self.mgr.get(restUrl,
                headers={'Accept': 'application/json'})
        if r.status_code >= 400:
            print (r.text)
            self.mgr.responseError(r)
            return None

        cluster = json.loads(r.text)

        for i in cluster['results']:
            self.walk_and_replace_dict_keyval(d=i,
                    name='certificate', val='_snipped_')
            self.json_print(i,indent=4)

    def health(self):
        r = self.get(api='/api/v1/reverse-proxy/node/health',display=True,codes=[200])
        
    def status(self):
        restUrl = '/api/v1/cluster/status'
        r = self.rest_api(api=restUrl)
        self.json_print(json.loads(r.text), indent=4)

    def getClusterIp(self):
        restUrl='/api/v1/cluster/api-virtual-ip'
        r=self.get(api=restUrl)
        self.json_print(data=r.text, convert=True)

    def clearClusterIp(self):
        restUrl='/api/v1/cluster/api-virtual-ip?action=clear_virtual_ip'
        r = self.post(api=restUrl)
        self.json_print(data=r.text, convert=True)

    def setClusterIp(self,addr):
        restUrl='/api/v1/cluster/api-virtual-ip?action=set_virtual_ip&ip_address=%s' %addr
        r = self.post(api=restUrl)
        self.json_print(data=r.text, convert=True)


    def setCertificate(self, certName):
        certObj = nsxtlib.Certificate(mp=self.mp)
        cert = certObj.find(name=certName,
                            types=['certificate_signed', 'certificate_self_signed'],
                            display=False)   
        #cert = self.findByName(restUrl='/api/v1/trust-management/certificates',
        #                       name=certName, display=False)
        if not cert:
            print("Certificate %s not found" %certName)
        else:
            restUrl='/api/v1/cluster/api-certificate?action=set_cluster_certificate&certificate_id=%s' %cert['id']
            r = self.post(api=restUrl,display=True)
            print(r.status_code)


    def getCertificate(self):
        r = self.get(api='/api/v1/cluster/api-certificate', display=True)

    def clearCertificate(self, certName):
        cert = self.findByName(restUrl='/api/v1/trust-management/certificates',
                               name=certName, display=False)
        if not cert:
            print("Certificate %s not found" %certName)
        else:
            restUrl='/api/v1/cluster/api-certificate?action=clear_cluster_certificate&certificateId=%s' %cert['id']
            r = self.post(api=restUrl,display=True)
            print(r.status_code)
        


class GlobalConfigs(Policy_object):
    def __init__(self,mp):
        super(self.__class__, self).__init__(mp=mp)
        self.listUrl='/api/v1/global-configs'

    def updateSwitchingConfig(self, name=None,desc=None,mtu=None,replication=None):
        self.listUrl ='/api/v1/global-configs/SwitchingGlobalConfig'
        data=self.list(display=False)


        changed = False
        if name:
            data['display_name'] = name
            changed = True
        if desc:
            data['description'] = desc
            changed = True
        if mtu:
            data['physical_uplink_mtu'] = mtu
            changed = True
        if replication != None and replication != data['global_replication_mode_enabled']:
            data['global_replication_mode_enabled'] = replication
            changed = True


        if changed:
            r = self.put(api=self.listUrl, data=data, display=True)
        else:
            print("No change submitted, no-op")
            
    def updateRoutingConfig(self, name=None, desc=None, mtu=None, l3mode=None):
        self.listUrl ='/api/v1/global-configs/RoutingGlobalConfig'
        data=self.list(display=False)


        changed = False
        if name:
            data['display_name'] = name
            changed = True
        if desc:
            data['description'] = desc
            changed = True
        if mtu:
            data['logical_uplink_mtu'] = mtu
            changed = True
        if l3mode:
            data['l3_forwarding_mode'] = l3mode
            changed = True


        if changed:
            r = self.put(api=self.listUrl, data=data, display=True)
        else:
            print("No change submitted, no-op")
        
    


class EnforcementPoints(Policy_object):    
    def __init__(self,mp, site='default'):
        super(self.__class__, self).__init__(mp=mp)
        self.listUrl='/policy/api/v1/infra/sites/%s/enforcement-points' %site

class EdgeCluster(Policy_object):
    def __init__(self,mp, site='default', enforcementPoint='default'):
        super(self.__class__, self).__init__(mp=mp)
        self.listUrl=('/policy/api/v1/infra/sites/%s/enforcement-points/%s/edge-clusters'
                      % (site, enforcementPoint))
    
class Edge(Policy_object):
    def __init__(self, mp, site='default', enforcementPoint='default', ec=None):
        super(self.__class__, self).__init__(mp=mp)

    def list(self, ec=None, display=True):
        if ec:
            api=('/policy/api/v1/infra/sites/%s/enforcement-points/%s/edge-clusters/%s/edge-nodes'
                 % (self.mp.site, self.mp.enforce, ec))
            return super(self.__class__, self).list(restUrl=api,display=display)
        else:
            edges={}
            edges['results'] = []
            edges['result_count'] = 0
            ec = EdgeCluster(mp=self.mp, site=self.mp.site, enforcementPoint=self.mp.enforce)
            ecList = ec.list(display=False)
            for e in ecList['results']:
                r = self.list(ec=e['id'],display=False)
                if r['result_count'] > 0:
                    edges['result_count']+=r['result_count']
                    edges['results']+=r['results']
            if display:
                self.json_print(edges,convert=False)
            return edges
            
        
class Tier0(Policy_object):
    def __init__(self, mp, site='default'):
        super(self.__class__, self).__init__(mp=mp)
        self.listUrl='/policy/api/v1/infra/tier-0s'

    def setEdgeCluster(self, name=None, cluster=None, clusterid=None,
                       clusterpath=None, locale='default'):
        ec = EdgeCluster(mp=self.mp)
        cluster = None
        if not clusterpath:
            if not clusterid:
                if not clustername:
                    path = ec.getPathByName(name=clustername,display=False)
                else:
                    print("EdgeCluster path, id, or name must be provided")
                    return None
            else:
                path = ec.getPathById(id=clusterid, display=False)
        if not path:
            print("EdgeCluster path, id, or name must be provided")
            return None
        
        t0 = self.getPathByName(name=name, display=False)
        if not t0:
            print("Can't find Tier0 %s" %name)
            return False
        api='/policy/api/v1/'+t0+'/locale-services/' + locale
        data={}
        data['edge_cluster_path'] = path
        self.patch(api=api, data=data, codes=[200], display=True)

    def setRouteDistribution(self, name, redist=None, locale='default'):

        t0 = self.getPathByName(name=name, display=False)
        if not t0:
            print("Can't find Tier0 %s" %name)
            return False

        api='/policy/api/v1'+ t0 + '/locale-services/' + locale
        data={}
        print(redist)
        data['route_redistribution_types'] = redist
        self.patch(api=api, data=data, codes=[200], display=True)

    def setPreferredEdges(self, name, cluster=None, edges=None, locale='default'):
        t0 = self.getPathByName(name=name, display=False)
        if not t0:
            print("Can't find Tier0 %s" %name)
            return False

        api='/policy/api/v1/'+ t0 + '/locale-services/' + locale

        if not edges:
            print("No edges specified, nothing changed")
            return False
        ec = None
        if cluster:
            c = EdgeCluster(mp=self.mp)
            ec = c.getPathByName(name=cluster, display=False)
            
        edge=Edge(mp=self.mp)
        edgeList = edge.list(display=False)
        preferred=[]
        for e in edges:
            t = edge.findByNam(name=e, data=edgeList, display=False)
            if not t:
                print("Edge %s not found" % e)
                return False
            if ec:
                if t['parent_path'] != ec:
                    print("EdgeCluster path %s not same as edge's parent: %s"
                          %ec, t['parent_path'])
                    return False
            preferred.append(t['path'])
        if len(preferred) == 0:
            print("No valid edges specified")
            return None

        data={}
        data['preferred_edge_paths'] = preferred
                
        self.path(api=api, data=data, codes=[200], display=True)
            

    def getInterfaces(self, name, locale='default', interface=None, display=True):

        t0=self.getPathByName(name=name, display=False)
        if not t0:
            print("Tier0 with name %s not found" %name)
            return None
            
        api='/policy/api/v1' + t0 + '/locale-services/' + locale + '/interfaces'
        if interface:
            api=api + '/' + interface

        r = self.get(api=api, display=display, codes=[200])
        return json.loads(r.text)

    def createInterface(self, name, interface, 
                        segment, cidr, mtu=1500, intType='EXTERNAL',
                        edge=None, desc=None, locale='default'):
        
        t0=self.getPathByName(name=name, display=False)
        if not t0:
            print("Tier0 with name %s not found" %name)
            return None

        api='/policy/api/v1' + t0 + '/locale-services/' \
            + locale + '/interfaces/' + interface
        s = Segments(mp=self.mp)
        ls = s.getPathByName(name=segment,display=False)
        if not ls:
            print("Segment %s not found" %segment)
            return None
        e=Edge(mp=self.mp)
        eList=e.list(display=False)
        edgePath = e.getPathByName(name=edge, data=eList,display=False)
        if intType=="EXTERNAL" and not edgePath:
            print("Edge %s not found" %edge)
            return False

        subnets=[]
        for n in cidr:
            if '/' not in n:
                print("IP address must be in CIDR format")
                return None
            p,m = n.split('/')
            subnet={}
            subnet['ip_addresses'] = [p]
            subnet['prefix_len'] = m
            subnets.append(subnet)

        if len(subnets) == 0:
            print("Must provide atleast one CIDR for interface address")
            return None
        
        data={}
        data['display_name'] = interface
        data['mtu'] = mtu
        if edgePath:
            data['edge_path'] = edgePath
        data['segment_path'] = ls
        data['type'] = intType
        data['description'] = desc
        data['subnets'] = subnets
        data['resource_type'] = 'Tier0Interface'

        self.patch(api=api, data=data, codes=[200], display=True)
        
    def deleteInterface(self, name, interface, locale='default', display=True):
        t0=self.getPathByName(name=name, display=False)
        if not t0:
            print("Tier0 with name %s not found" %name)
            return None

        api='/policy/api/v1' + t0 + '/locale-services/' \
            + locale + '/interfaces/' + interface
        self.delete(api=api,display=display,codes=[200])


    def config(self, name, failover=None, ha=None,
               transit=None, dhcprelay=None, desc=None):
        data={}
        data['display_name'] = name

        if failover:
            data['failover_mode'] = failover
        if ha:
            data['ha_mode'] = ha
        if transit:
            data['transit_subnets'] = [transit]
        if desc:
            data['description'] = desc
        if dhcprelay:
            ds=DhcpRelay(mp=self.mp)
            dhcp=ds.getPathByName(name=dhcprelay, display=False)
            if not dhcp:
                print("DHCP relay service %s not found." %dhcprelay)
                return False
            data['dhcp_config_paths'] = [dhcp]

        api='/policy/api/v1/infra/tier-0s/%s' % name
        self.patch(api=api,data=data,display=True,codes=[200])

    def getLocale(self,name,display=True):
        url=self.listUrl + "/" + name + "/locale-services"
        self.list(restUrl=url,display=display)
        

    def setDhcpRelayService(self, name, relay, display=True):
        t0=self.getPathByName(name=name, display=False)
        if not t0:
            print("Tier0 with name %s not found" %name)
            return None

        api='/policy/api/v1' + t0
        ds=DhcpRelay(mp=self.mp)
        dhcp = ds.getPathByName(name=relay)
        if not dhcp:
            print("DHCP Relay service %s not found" %relay)
            return None
        data={}
        data['dhcp_config_paths'] = [dhcp]
        self.patch(api=api, data=data, display=display, codes=[200])

    def getBgpConfig(self, name, locale='default', display=True):
        t0=self.getPathByName(name=name, display=False)
        if not t0:
            print("Tier0 with name %s not found" %name)
            return None
        
        api='/policy/api/v1' + t0 + '/locale-services/' + locale + '/bgp'
        self.get(api=api,display=display,codes=[200])

    def configBgp(self, name,
                  localas,
                  routeagg=None,
                  enable_multipathrelax=False,
                  disable_multipathrelax=False,
                  enable_intersr=False,
                  disable_intersr=False,
                  enable_ecmp=False,
                  disable_ecmp=False,
                  desc=None,
                  locale='default',
                  display=True):

        '''
        Have to let each config flag to be specified individually because
        patch will toggle previous config.  If user specifies a flag, it
        means we want a config change.  
        '''
        
        t0=self.getPathByName(name=name, display=False)
        if not t0:
            print("Tier0 with name %s not found" %name)
            return None
        
        api='/policy/api/v1' + t0 + '/locale-services/' + locale + '/bgp'

        data={}
        data['local_as_num'] = localas
        if enable_multipathrelax:
            data['multipath_relax'] = enable_multipathrelax
        if disable_multipathrelax:
            data['multipath_relax'] = disable_multipathrelax
        if enable_intersr:
            data['intersr'] = enable_intersr
        if disable_intersr:
            data['intersr'] = disable_intersr
        if enable_ecmp:
            data['ecmp'] = enable_ecmp
        if disable_ecmp:
            data['ecmp'] = disable_ecmp
        if desc:
            data['description'] = desc
        if routeagg:
            for r in routeagg:
                route={}
                if ':' in r:
                    prefix,summary=r.split(':')
                    summary=summary.lower()
                    if summary not in ['true', 'false']:
                        print("Route summary must be true or false for prefix %s but is (%s)"
                              %(prefix, summary))
                        return False
                    if summary == 'true':
                        route['summary_only'] = True
                    else:
                        route['summary_only'] = False
                            
                else:
                    prefix=r
                if '/' not in prefix:
                    print("Prefix must be in CIDR format, missing /: %s" %prefix)
                    return False
                route['prefix'] = prefix
                if 'route_aggregations' in data.keys():
                    data['route_aggregations'].append(route)
                else:
                    data['route_aggregations'] = [route]
        data['resource_type'] = 'BgpRoutingConfig'
        self.patch(api=api, data=data, display=display, codes=[200])
        

    def getBgpNeighbors(self, name, locale='default', display=True):
        
        t0=self.getPathByName(name=name, display=False)
        if not t0:
            print("Tier0 with name %s not found" %name)
            return None
        
        api='/policy/api/v1' + t0 + '/locale-services/' + locale + '/bgp/neighbors'
        self.get(api=api,display=True,codes=[200])
    
                

    def configBgpNeighbor(self, name,
                          neighborAddr,
                          remoteAs,
                          neighborName,
                          neighborDesc=None,
                          holdtime=None,
                          keepalive=None,
                          password=None,
                          enablebfd=False,
                          disablebfd=False,
                          bfdInterval=None,
                          bfdMultiple=None,
                          locale='default', display=True):

        t0=self.getPathByName(name=name, display=False)
        if not t0:
            print("Tier0 with name %s not found" %name)
            return None
        
        api='/policy/api/v1' + t0 + '/locale-services/' + locale + '/bgp/neighbors/'+neighborName

        data={}
        data['display_name'] = neighborName
        data['neighbor_address'] = neighborAddr
        data['remote_as_num'] = remoteAs
        if neighborDesc:
            data['description'] = neighborDesc
        if holdtime:
            data['hold_down_time'] = holdtime
        if keepalive:
            data['keep_alive_time'] = keepalive
        if password:
            data['password'] = password

        if enablebfd or disablebfd or bfdInterval or bfdMultiple:
            bfdData={}
            if enablebfd:
                bfdData['enabled'] = enablebfd
            if disablebfd:
                bfdData['enabled'] = disablebfd
            if bfdInterval:
                bfdData['interval'] = bfdInterval
            if bfdMultiple:
                bfdData['multiple'] = bfdMultiple
            data['bfd'] = bfdData
            
        data['resource_type'] = 'BgpNeighborConfig'
        
        self.patch(api=api,data=data,display=True, codes=[200])
        


    def deleteBgpNeighbor(self, name, neighborName, locale='default', display=True):
        t0=self.getPathByName(name=name, display=False)
        if not t0:
            print("Tier0 with name %s not found" %name)
            return None
        
        api='/policy/api/v1' + t0 + '/locale-services/' + locale + '/bgp/neighbors/'+neighborName

        self.delete(api=api, display=display)

class PrefixList(Policy_object):
    def __init__(self, mp, tier0):
        super(self.__class__, self).__init__(mp=mp)
        self.listUrl='/policy/api/v1/infra/tier-0s/' + tier0 + '/prefix-lists'

    def config(self, t0, name, prefix, desc=None,display=True):
        api='/policy/api/v1/infra/tier-0s/' + t0 + '/prefix-lists/' + name

        data={}
        data['display_name'] = name
        if desc:
            data['description'] = desc

        data['prefixes'] = []
        
        for p in prefix:
            '''
            format CIDR:GE bits:LE bits:action
            action can be PERMIT, DENY
            GE and LE can be blank
            the CIDR could also be "ANY"
            '''
            prefix = p.split(':')
            pdata={}
            if len(prefix) != 4:
                print("Prefix format: CIDR:GE:LE:<PERMIT,DENY>")
                return None

            subnet = prefix[0].strip()
            if not '/' in subnet and subnet.upper()!='ANY':
                print("Prefix %s not in CIDR format" %subnet)
                return None
            else:
                pdata['network'] = subnet.upper()
                
            ge = prefix[1].strip()
            if ge == '':
                ge = None
            else:
                pdata['ge'] = ge
                
            le = prefix[2].strip()
            if le == '':
                le = None
            else:
                pdata['le'] = le
                
            action = prefix[3].strip().upper()
            if action not in ["DENY", "PERMIT"]:
                print("action must be DENY or PERMIT")
                return None
            else:
                pdata['action'] = action

            data['prefixes'].append(pdata)

        if len(data['prefixes']) ==  0:
            print("No prefix specified.")
            return None

        self.patch(api=api, data=data, codes=[200], display=True)
                  
    def deletePrefixList(self, t0, name, display=True):
        api='/policy/api/v1/infra/tier-0s/' + t0 + '/prefix-lists/' + name
        self.delete(api=api,display=display,codes=[200])

class BgpCommunity(Policy_object):
    def __init__(self, mp, tier0):
        super(self.__class__, self).__init__(mp=mp)
        self.listUrl='/policy/api/v1/infra/tier-0s/' + tier0 + '/community-lists'

    def config(self, t0, name, communities, desc=None,display=True):
        api='/policy/api/v1/infra/tier-0s/' + t0 + '/community-lists/' + name

        data={}
        data['display_name'] = name
        if desc:
            data['description'] = desc

        data['communities'] = []
        
        for p in communities:
            '''
            value types: NO_EXPORT, NO_ADVERTISE, NO_EXPORT_SUBCONFED, <x:y>
            '''
         
            if p.upper() in ["NO_EXPORT", "NO_ADVERTISE", "NO_EXPORT_SUBCONFED"]:
                data['communities'].append(p.upper())
            elif ':' in p:
                data['communities'].append(p)
            else:
                print("Community %s not valid")
                return None
                
        if len(data['communities']) ==  0:
            print("No communities specified.")
            return None

        self.patch(api=api, data=data, codes=[200], display=True)
                  
    def deleteBgpCommunity(self, t0, name, display=True):
        api='/policy/api/v1/infra/tier-0s/' + t0 + '/community-liss/' + name
        self.delete(api=api,display=display,codes=[200])
            
class RouteMap(Policy_object):
    def __init__(self, mp, tier0):
        super(self.__class__, self).__init__(mp=mp)
        self.listUrl='/policy/api/v1/infra/tier-0s/' + tier0 + '/route-maps'

    def config(self, t0, name, community, prefix, desc=None,display=True):
        api='/policy/api/v1/infra/tier-0s/' + t0 + '/route-maps/' + name

        data={}
        data['display_name'] = name
        if desc:
            data['description'] = desc

        data['entries'] = []
        
        for p in prefix:
            '''
            format CIDR:GE bits:LE bits:action
            action can be PERMIT, DENY
            GE and LE can be blank
            the CIDR could also be "ANY"
            '''
            prefix = p.split(':')
            pdata={}
            if len(prefix) != 4:
                print("Prefix format: CIDR:GE:LE:<PERMIT,DENY>")
                return None

            subnet = prefix[0].strip()
            if not '/' in subnet and subnet.upper()!='ANY':
                print("Prefix %s not in CIDR format" %subnet)
                return None
            else:
                pdata['network'] = subnet.upper()
                
            ge = prefix[1].strip()
            if ge == '':
                ge = None
            else:
                pdata['ge'] = ge
                
            le = prefix[2].strip()
            if le == '':
                le = None
            else:
                pdata['le'] = le
                
            action = prefix[3].strip().upper()
            if action not in ["DENY", "PERMIT"]:
                print("action must be DENY or PERMIT")
                return None
            else:
                pdata['action'] = action

            data['prefixes'].append(pdata)

        if len(data['prefixes']) ==  0:
            print("No prefix specified.")
            return None

        self.patch(api=api, data=data, codes=[200], display=True)
                  
    def deletePrefixList(self, t0, name, display=True):
        api='/policy/api/v1/infra/tier-0s/' + t0 + '/route-maps/' + name
        self.delete(api=api,display=display,codes=[200])
            
        
class Tier1(Policy_object):
    def __init__(self, mp, site='default'):
        super(self.__class__, self).__init__(mp=mp)
        self.listUrl='/policy/api/v1/infra/tier-1s'

class Segments(Policy_object):
    def __init__(self,mp):
        super(self.__class__, self).__init__(mp=mp)
        self.listUrl='/policy/api/v1/infra/segments'

    def config(self, name, tz, connectPath=None, gw=None, dhcp=None, vlans=None, desc=None):
        '''
        name - name of the segment, will be used as ID for path
        tz = name of the transportzone
        connectPath = name of the logical router if connecting upstream
        gw = Gateway IP address in CIDR
        dhcp = dhcp range
        '''

        api='/policy/api/v1/infra/segments/%s' %name

        data={}
        data['display_name'] = name
        t = TransportZone(mp=self.mp)
        myTz = t.getPathByName(name=tz, display=False)
        if not myTz:
            print("TZ %s not found" %tz)
            return None
        else:
            data['transport_zone_path'] = myTz

        if vlans:
            data['vlan_ids'] = vlans
        
        if gw or dhcp:
            subnet={}
            if dhcp:
                subnet['dhcp_ranges'] = dhcp
            if gw:
                subnet['gateway_address'] = gw

            data['subnets'] = [subnet]

        if connectPath:
            p=self.getPathByTypeAndName(name=connectPath, types=[Tier0, Tier1])
            if not p:
                print("LogicalRouter %s not found for connect Path" %connectPath)
                return None
            else:
                data['connectivity_path'] = p

        r = self.patch(api=api, data=data,display=True)
        if r.status_code != 200:
            print("Logical segment creation did not return 200: %d" %r.status_code)
            return None
        else:
            return True
        

class Sites(Policy_object):    
    def __init__(self,mp):
        super(self.__class__, self).__init__(mp=mp)
        self.listUrl='/policy/api/v1/infra/sites'
    


class TransportZone(Policy_object):
    def __init__(self,mp):
        super(self.__class__, self).__init__(mp=mp)
        self.listUrl=('/policy/api/v1/infra/sites/%s/enforcement-points/%s/transport-zones'
                      %(mp.site, mp.enforce)) 

class IpPool(Policy_object):
    def __init__(self,mp):
        super(self.__class__, self).__init__(mp=mp)
        self.listUrl='/policy/api/v1/infra/ip-pools'

    

class TNProfile(Policy_object):

    #from nsxtlib import Uplinkprofile, Pools, Switch
    
    def __init__(self,mp):
        super(self.__class__, self).__init__(mp=mp)
        self.listUrl='/api/v1/transport-node-profiles'
    def __validateUplinks(self, names, nameList):

        for n in names:
            if n not in nameList:
                return False
        return True
        

    def config(self, name,
               uplinkprofile, pnics, uplinknames,
               hswname,
               tz,
               lldp,
               vmks=None, vmknets=None,
               vmkuninstall=None, vmkuninstnets=None,
               pnicuninstalls=True,
               ippool = None,
               desc = None):

        '''
        name = name of this TNProfile
        desc = Description of the uplink profile
        uplinkprofile - name of the uplink profile to be used
        uplinks - list of pNICs
        uplinknames - list of uplinks for mapping in order of "uplinks", must match
                      names in uplinkprofile
        vmks - list of vmkernel interfaces to migrate to NSX VLAN logical switches
        vmknets - list of NSX VLAN logical switches, order must match vmks order
        vmkuninstall - list of vmkernel interfaces to migrate out of NVDS at uninstall
        vmkuninstnets - list of DVS portgroups to use when migrating vmks out of NVDS to DVS
        pnicuninstalls - list of pNICs to uninstall
        hswname - name of the NVDS host switch
        tz - list of transport zone names
        lldp - Name of LLDP profile
        ippool - Name of IpPool to use, DHCP if this is None
        '''

        data = {}
            
        data['display_name'] = name
        data['resource_type'] = 'TransportNodeProfile'
        if desc:
            data['description'] = desc

        T = nsxtlib.Transportzone(mgr=self.mp.mgr)
        data['transport_zone_endpoints'] = []
        foundSwitch = False
        for n in tz:
            t = T.findByName(name=n, display=False)
            if not t:
                print("TransportZone %s not found" %n)
                return None
            else:
                data['transport_zone_endpoints'].append({'transport_zone_id':t['id']})
                if hswname==t['host_switch_name']:
                    foundSwitch = True
        if not foundSwitch:
            print("Host switch name %s not found in any of listed TZs" %hswname)
            return None

        swdata={}
        switchSpec=self.__configSwitchSpec(data=swdata,hswname=hswname,
                                           uplinkprofile=uplinkprofile,
                                           pnics=pnics,
                                           uplinknames=uplinknames,
                                           vmks=vmks,
                                           lldp=lldp,
                                           vmknets=vmknets,
                                           vmkuninstall=vmkuninstall,
                                           vmkuninstnets=vmkuninstnets,
                                           pnicuninstalls=pnicuninstalls,
                                           ippool=ippool)

        if not switchSpec:
            print("Host switch not created properly")
            return None
        data['host_switch_spec'] = {}
        data['host_switch_spec']['resource_type'] = 'StandardHostSwitchSpec'
        data['host_switch_spec']['host_switches'] = [switchSpec]

        api='/api/v1/transport-node-profiles'
        r = self.post(api=api,data=data,display=True)

    def __configSwitchSpec(self, data, hswname,
                           uplinkprofile, pnics, uplinknames, lldp=None,
                           vmks=None, vmknets=None,
                           vmkuninstall=None, vmkuninstnets=None,
                           pnicuninstalls=True,
                           ippool = None, update=False):
        
        '''
        name = name of this TNProfile
        desc = Description of the uplink profile
        uplinkprofile - name of the uplink profile to be used
        uplinks - list of pNICs
        uplinknames - list of uplinks for mapping in order of "uplinks", must match
                      names in uplinkprofile
        vmks - list of vmkernel interfaces to migrate to NSX VLAN logical switches
        vmknets - list of NSX VLAN logical switches, order must match vmks order
        vmkuninstall - list of vmkernel interfaces to migrate out of NVDS at uninstall
        vmkuninstnets - list of DVS portgroups to use when migrating vmks out of NVDS to DVS
        pnicuninstalls - list of pNICs to uninstall
        hswname - name of the NVDS host switch
        tz - list of transport zone names
        ippool - Name of IpPool to use, DHCP if this is None
        '''

        if not ippool:
            if 'ip_assigment_spec' not in data.keys():
                data['ip_assignment_spec'] = {'resource_type': 'AssignedByDhcp'}
        else:
            P = nsxtlib.Pools(mgr=self.mp.mgr)
            pool = P.findByName(name=ippool, display=False)
            if not pool:
                print("IP Pool %s not found" %ippool)
                return None
            else:
                ip = {}
                ip['ip_pool_id'] = pool['id']
                ip['resource_type'] = 'StaticIpPoolSpec'
                data['ip_assignment_spec'] = ip
                
        if lldp:
            U = nsxtlib.Uplinkprofile(mgr=self.mp.mgr)
            u = U.findByName(name=lldp,display=False)
            self.json_print(u)
            if not u:
                print("LLDP UplinkProfile %s not found" %lldp)
                return None
            if 'host_switch_profile_ids' not in data.keys():
                data['host_switch_profile_ids'] = [{'key':u['resource_type'], 'value': u['id']}]
            else:
                found=False
                for p in data['host_switch_profile_ids']:
                    if p['value'] == u['id']:
                        found = True
                        break
                    else:
                        tu = U.findById(id=p['value'], display=False)
                        if tu and tu['resource_type'] == u['resource_type']:
                            p['value'] = u['id']
                            found=True
                            break
                            
                if not found:
                    data['host_switch_profile_ids'].append({'key':u['resource_type'],
                                                            'value':u['id']})

        if uplinkprofile:
            U = nsxtlib.Uplinkprofile(mgr=self.mp.mgr)
            u = U.findByName(name=uplinkprofile,display=False)
            if not u:
                print("UplinkProfile %s not found" %uplinkprofile)
                return None
            if 'host_switch_profile_ids' not in data.keys():
                data['host_switch_profile_ids'] = [{'key':u['resource_type'], 'value': u['id']}]
            else:
                found=False
                for p in data['host_switch_profile_ids']:
                    if p['value'] == u['id']:
                        found = True
                        break
                    else:
                        tu = U.findById(id=p['value'], display=False)
                        if tu and tu['resource_type'] == u['resource_type']:
                            p['value'] = u['id']
                            found=True
                            break
                            
                if not found:
                    data['host_switch_profile_ids'].append({'key':u['resource_type'],
                                                            'value':u['id']})
                


        if hswname:
            data['host_switch_name'] = hswname
        
        l = U.uplinkList(name=None,obj=u,display=False)
        if not self.__validateUplinks(names=uplinknames, nameList=l):
            print("Uplink names do not match names list in uplink profile")
            print(" Provided uplinks: %s "%uplinknames)
            print(" Uplink profile link names: %s" %l)
            return None

        
        if not (len(pnics)  <= len(uplinknames)):
            print("The number of PNICs must be equal to or less than the number of profile uplinks")
            return None
            

        _pnics = [ ]
        for i in range(len(pnics)):
            _pnics.append({'device_name':pnics[i], 'uplink_name':uplinknames[i]})
        data['pnics'] = _pnics
        if pnicuninstalls:
            data['pnics_uninstall_migration'] = _pnics
        
        
        

        if vmks:
            if len(vmks) != len(vmknets):
                print("The number of vmknets must be equal the number of vmks to be migrated")
                return None
            S=nsxtlib.Switch(mgr=self.mp.mgr)
            vmk_install_migration = []
            for v in range(len(vmknets)):
                sw = S.findByName(name=vmknets[v],display=False)
                if not sw:
                    print("VMK migration destination network %s does not exist" %vmknets[v])
                    return None
                else:
                    vmk_install_migration.append({'device_name': vmks[v],
                                                  'destination_network': sw['id']})
            data['vmk_install_migration'] = vmk_install_migration

        
        if vmkuninstall:
            if len(vmkuninstall) != len(vmkuninstnets):
                print("The number of vmkuninstnet must equal vmkuninstall")
                return None
            S=nsxtlib.Switch(mgr=self.mp)
            vmk_uninstall_migration = []
            for v in range(len(vmkuninstnets)):
                vmk_uninstall_migration.append({'device_name': vmkuninstall[v],
                                                'destination_network': vmkuninstnets[v]})
            data['vmk_uninstall_migration'] = vmk_uninstall_migration

        return data
        

class ComputeCollections (Policy_object):
    def __init__(self,mp):
        super(self.__class__, self).__init__(mp=mp)
        self.listUrl='/api/v1/fabric/compute-collections'

class TNCollections (Policy_object):
        def __init__(self,mp):
            super(self.__class__, self).__init__(mp=mp)
            self.listUrl='/api/v1/transport-node-collections'

        def config(self, computecollection, tnprofile, name=None, desc=None):
            '''
            name = name of this TNCollection
            desc = Description of TNCollection
            compute-collection =  name of vc-cluster to configure
            transport-node-profile = name of TN-Profile to configure compute-collection
            '''
            data = {}
            data['display_name'] = name
            data['resource_type'] = 'TransportNodeCollection'
            if desc:
                data['description'] = desc

            if computecollection:
                C = ComputeCollections(mp=self.mp)
                c = C.findByName(name=computecollection, display=False)
                print (c)
                data['compute_collection_id'] = c['external_id']

                if not c:
                    print("Compute-Collection %s not found" %computecollection)
                    return None
                                            
            if tnprofile:
                T = TNProfile(mp=self.mp)
                t = T.findByName(name=tnprofile, display=False)
                data['transport_node_profile_id'] = t['id']
                
                if not t:
                    print("TN Profile %s not found" %tnprofile)
                    return None
            api='/api/v1/transport-node-collections'
            r = self.post(api=api,data=data,display=True)


class Certificate(Policy_object):
    def __init__(self,mp):
        super(self.__class__, self).__init__(mp=mp)
        self.listUrl='/policy/api/v1/infra/certificates'


    def readCert(self,filename):
        fp=open(filename,'r')
        return fp.read()
        
    def importCertificate(self, name, cert, key=None,passphrase=None, description=None):
        data={}
        data['display_name'] = name
        if description:
            data['description']= description
        if passphrase:
            data['passphrase'] = passphrase
        if key:
            data['private_key'] = self.readCert(filename=key)
        data['pem_encoded'] = self.readCert(filename=cert)

        api='/policy/api/v1/infra/certificates/%s'%name

        r = self.patch(api=api,data=data,display=True)
        if r.status_code != 200:
            print("Error in importing certificate: %d"%r.status_code)
            return None
        else:
            print(r.status_code)
            return True


class Realization(Policy_object):
    '''
    Realization currently will only support global alarms list retrieval
    Do not add individual entity alarms here, as those should be done in the
    class of the entity
    '''
    def __init__(self,mp):
        super(self.__class__, self).__init__(mp=mp)
        self.listUrl='/policy/api/v1/infra/realized-state/alarms'
        
    def cleanup(self, path):
        data={}
        data['paths'] = [path]
        api='/policy/api/v1/troubleshooting/infra/tree/realization?action=cleanup'
        r = self.post(api=api, data=data, display=True)
        
    def systemList(self):
        api='/policy/api/v1/search?query=(_exists_:status and !status.consolidated_status.consolidated_status:SUCCESS)'
        r = self.get(api=api,display=True)
        
        
    

class Roles(Policy_object):
    def __init__(self,mp):
        super(self.__class__, self).__init__(mp=mp)
        self.listUrl='/policy/api/v1/aaa/roles'

    def findByName(self, name, display=False):
        r = self.list(display=False)
        for i in r['results']:
            if i['role'] == name:
                return True

        return False
            
    def bind(self, name, roles, utype='remote_user', display=False):
        data={}
        data['name'] = name
        data['display_name'] = name
        data['type'] = utype
        data['resource_type'] = 'RoleBinding'
        data['roles'] = []
        for i in roles:
            role={}
            role['role'] = i
            data['roles'].append(role)
            
        self.post(api='/policy/api/v1/aaa/role-bindings', data=data,
                  codes=[200], display=True)


class Vidm(Policy_object):
    def __init__(self,mp):
        super(self.__class__, self).__init__(mp=mp)
        self.listUrl='/api/v1/node/aaa/providers/vidm'


    def __getCertificate(self, node, port=443):
        c = ssl.get_server_certificate(addr={node, port})
        return c

    def getFingerprint(self, node, port=443, digest='sha256'):
        '''
        digest options are sha1 and sha256
        '''
        c =  self.__getCertificate(node=node, port=port)
        x509 = OpenSSL.crypto.load_certificate(OpenSSL.crypto.FILETYPE_PEM, c)
        return x509.digest(digest)
        
        
        
    def config(self, vidmhost, client, secret,
               nodename, enable=False, lb=False):
        data={}
        data['host_name'] = vidmhost
        data['client_id'] = client
        data['client_secret'] = secret
        data['vidm_enable'] = enable
        data['lb_enable'] = lb
        data['node_host_name'] = nodename
        data['thumbprint'] = self.getFingerprint(node=vidmhost, port=443)
        r=self.put(api='/api/v1/node/aaa/providers/vidm', data=data, display=True)
        if r.status_code != 202:
            print("Error in configuring VIDM, code: %d" %r.status_code)

    def getStatus(self):
        self.get(api='/api/v1/node/aaa/providers/vidm/status', display=True)

    def getState(self):
        d=self.list(restUrl='/api/v1/node/aaa/providers/vidm/status', display=False)
        if d['runtime_state'] == 'ALL_OK' and d['vidm_enable'] == True:
            return True
        else:
            return False
        
        
        
    
    
                
class PrincipalIdentity(Policy_object):
    '''
    Not a policy object...
    '''

    def __init__(self,mp):
        super(self.__class__, self).__init__(mp=mp)
        self.listUrl='/api/v1/trust-management/principal-identities'
    

    def create(self, name, nodeid, role=None, desc=None,cert=None,isprotected=False):
        data={}
        data['name'] = name
        data['display_name'] = name
        data['node_id'] = nodeid
        if desc:
            data['description'] = desc
        if cert:
            C = Certificate(mp=self.mp)
            crt = C.readCert(filename=cert)
            if not crt:
                print("Certificate with name %s read error" %cert)
                return None
            else:
                data['certificate_pem'] = crt
        if role:
            data['role'] = role
        if isprotected:
            data['is_protected'] = True
        else:
            data['is_protected'] = False
        
        R = Roles(mp=self.mp)
        if R.findByName(name=role, display=False):
            data['role'] = role
        else:
            print("Invalid role name %s specified" %role)
            return None

        data['resource_type'] = 'PrincipalIdentifyWithCertificate'
         
            
        api='/api/v1/trust-management/principal-identities/with-certificate'
        r = self.post(api=api, data=data,display=False, codes=[201])
        return json.loads(r.text)
            
            
        
    def deletePi(self, name, display=True):
        pi=self.findByName(name=name,display=False)
        if not pi:
            print("Principal identity %s not found" %name)
            return False


        api='/api/v1/trust-management/principal-identities/%s' % pi['id']
        r = self.delete(api=api,display=display)
        
        
class DhcpRelay(Policy_object):
    def __init__(self,mp):
        super(self.__class__, self).__init__(mp=mp)
        self.listUrl='/policy/api/v1/infra/dhcp-relay-configs'

        

    
