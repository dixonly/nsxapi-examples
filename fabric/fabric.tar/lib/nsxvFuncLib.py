import pinit
import os, sys
import time, datetime
import pdb, traceback, inspect
import json, yaml
import xmltodict
import logging
import copy
import math
import OpenSSL
import cptutil
import itertools
import vs
import nsxv
import vslib
import nsxvlib 

from pprint import pprint
from collections import OrderedDict as OD
from random import shuffle
from yamlxml import yaml_to_xml
from toasterlib import Toaster
from prettytable import PrettyTable
from cptutil import pprint_od, listify
from pyVmomi import vim
from pprint import pprint

def chunks_list(l, n):
    """ Yield successive n-sized chunks from l.
    """
    t =[]
    for i in range(0, len(l), n):
        t.append(l[i:i+n])
    return t

def expand_list(l,e):
    ''' expand the list to e factor and shuffle'''
    if e < len(l):
        raise ValueError('count requested is less than current list size')
    factor = int(math.ceil(float(e) / len(l)))
    l = l * factor
    shuffle(l)
    return l

def push_securitypolicy(**kwargs):

    data = OD()
    sp_name = kwargs['kwargs']['sp_name']
    prcd = kwargs['kwargs']['prcd']
    sg_list = kwargs['kwargs']['sg_list']
    direction = kwargs['kwargs']['direction']
    fw_sp = kwargs['kwargs']['fw_sp']
    sg_sp = kwargs['kwargs']['sg_sp']
    action = kwargs['kwargs']['action']
    mgr = kwargs['kwargs']['mgr']
    appL = kwargs['kwargs']['appL']
    appPerFw = kwargs['kwargs']['appPerFw']
    deny_rule = kwargs['kwargs']['deny_rule']
    appC = chunks_list(appL,appPerFw)

    fw_sg_list = kwargs['kwargs']['fw_sg_list']
    apl_sg = kwargs['kwargs']['apl_sg']
    ''' shuffle the sg list to random order '''
   # print(sp_name,prcd, len(sg_list), direction, fw_sp, sg_sp, mgr)
    if not sg_list:
        print("Oubound SP with SRC SG and DST DG ")
        shuffle(fw_sg_list)
        '''configure based on src and dst SG for JPMC , This has been testbed only for outbound SP with 1 SG as SRC and multiple SG as destination'''

        if len(fw_sg_list) < fw_sp:
                raise ValueError('length of fw_sg_list (%s) is less than fw per SP or SG per SP' % len(fw_sg_list))

        '''security group outer policy definition'''
        data['securityPolicy'] = OD({'name':sp_name})
        data['securityPolicy'].update({'precedence':prcd})

        ''' security grp this policy is bound to'''
        data['securityPolicy']['securityGroupBinding']=[]
        data['securityPolicy']['securityGroupBinding'].append({'objectId':apl_sg})

        ''' firewall rules config'''
        data['securityPolicy']['actionsByCategory'] = OD()
        data['securityPolicy']['actionsByCategory'].update({'category':'firewall'})


        data['securityPolicy']['actionsByCategory']['action']=[]

        if filter(lambda x: 'applicationgroup' in x, appL):
                print("Apllication Groups used")
                for i in range(0,fw_sp):
                    fw_name = "fw_rule-" + str(i+1)
                    temp_dict=OD()
                    temp_dict.update({'@class':'firewallSecurityAction'})
                    temp_dict.update({'name':fw_name})
                    temp_dict.update({'category':'firewall'})
                    temp_dict.update({'isEnabled':'true'})
                    temp_dict['applications'] = {}
                    temp_dict['applications']['applicationGroup'] = []
                    for app in appC[i]:
                        temp_dict['applications']['applicationGroup'].append({'objectId':app})
                    if not direction.startswith('intra'):
                        temp_dict.update({'secondarySecurityGroup':{'objectId':fw_sg_list[i]}})
                    temp_dict.update({'logged':'false'})
                    temp_dict.update({'action':action})
                    temp_dict.update({'direction':direction})
                    data['securityPolicy']['actionsByCategory']['action'].append(temp_dict)
        else:

                for i in range(0,fw_sp):
                    fw_name = "fw_rule-" + str(i+1)
                    temp_dict=OD()
                    temp_dict.update({'@class':'firewallSecurityAction'})
                    temp_dict.update({'name':fw_name})
                    temp_dict.update({'category':'firewall'})
                    temp_dict.update({'isEnabled':'true'})
                    temp_dict['applications'] = {}
                    temp_dict['applications']['application'] = []
                    for app in appC[i]:
                        temp_dict['applications']['application'].append({'objectId':app,'type':{'typeName':'Application'}})
                    if not direction.startswith('intra'):
                        temp_dict.update({'secondarySecurityGroup':{'objectId':fw_sg_list[i]}})
                    temp_dict.update({'logged':'false'})
                    temp_dict.update({'action':action})
                    temp_dict.update({'direction':direction})
                    data['securityPolicy']['actionsByCategory']['action'].append(temp_dict)
        print("deny_rule:",deny_rule)
        if deny_rule:
                    fw_name = "DENY ALL OTHERS"
                    temp_dict=OD()
                    temp_dict.update({'@class':'firewallSecurityAction'})
                    temp_dict.update({'name':fw_name})
                    temp_dict.update({'category':'firewall'})
                    temp_dict.update({'isEnabled':'true'})
                    temp_dict.update({'logged':'false'})
                    temp_dict.update({'action':'block'})
                    temp_dict.update({'direction':direction})
                    data['securityPolicy']['actionsByCategory']['action'].append(temp_dict)
    else:
        print("SG traditional")
        ''' shuffle the sg list to random order '''
        shuffle(sg_list)
        # print(sp_name,prcd, len(sg_list), direction, fw_sp, sg_sp, mgr)

        if len(sg_list) < fw_sp or len(sg_list) < sg_sp:
                raise ValueError('length of sg_list (%s) is less than fw per SP or SG per SP' % len(sg_list))

        '''security group outer policy definition'''
        data['securityPolicy'] = OD({'name':sp_name})
        data['securityPolicy'].update({'precedence':prcd})

        ''' security grp this policy is bound to'''
        data['securityPolicy']['securityGroupBinding']=[]
        for i in range(0,sg_sp):
                data['securityPolicy']['securityGroupBinding'].append({'objectId':sg_list[i]})

        ''' firewall rules config'''
        data['securityPolicy']['actionsByCategory'] = OD()
        data['securityPolicy']['actionsByCategory'].update({'category':'firewall'})


        data['securityPolicy']['actionsByCategory']['action']=[]
        if filter(lambda x: 'applicationgroup' in x, appL):
            print("Apllication Groups used")
            for i in range(0,fw_sp):
                fw_name = "fw_rule-" + str(i+1)
                temp_dict=OD()
                temp_dict.update({'@class':'firewallSecurityAction'})
                temp_dict.update({'name':fw_name})
                temp_dict.update({'category':'firewall'})
                temp_dict.update({'isEnabled':'true'})
                temp_dict['applications'] = {}
                temp_dict['applications']['applicationGroup'] = []
                for app in appC[i]:
                   temp_dict['applications']['applicationGroup'].append({'objectId':app})
                if not direction.startswith('intra'):
                   temp_dict.update({'secondarySecurityGroup':{'objectId':sg_list[i]}})
                temp_dict.update({'logged':'false'})
                temp_dict.update({'action':action})
                temp_dict.update({'direction':direction})
                data['securityPolicy']['actionsByCategory']['action'].append(temp_dict)
        else:

            for i in range(0,fw_sp):
                fw_name = "fw_rule-" + str(i+1)
                temp_dict=OD()
                temp_dict.update({'@class':'firewallSecurityAction'})
                temp_dict.update({'name':fw_name})
                temp_dict.update({'category':'firewall'})
                temp_dict.update({'isEnabled':'true'})
                temp_dict['applications'] = {}
                temp_dict['applications']['application'] = []
                for app in appC[i]:
                    temp_dict['applications']['application'].append({'objectId':app,'type':{'typeName':'Application'}})
                if not direction.startswith('intra'):
                    temp_dict.update({'secondarySecurityGroup':{'objectId':sg_list[i]}})
                temp_dict.update({'logged':'false'})
                temp_dict.update({'action':action})
                temp_dict.update({'direction':direction})
                data['securityPolicy']['actionsByCategory']['action'].append(temp_dict)

    xml = xmltodict.unparse(data)
    print("xml dump:%s" %xml)

    url = '/api/2.0/services/policy/securitypolicy'

    r = mgr.post(url,xml)
    if r.status_code != 201:
        print("create request for security policy failed with return:%s %s" %(r.status_code,r.text))
        r.raise_for_status()

    return None

def sbux_push_securitypolicy(**kwargs):

    data = OD()
    sp_name = kwargs['kwargs']['sp_name']
    prcd = kwargs['kwargs']['prcd']
    sg_list = kwargs['kwargs']['sg_list']
    direction = kwargs['kwargs']['direction']
    fw_sp = kwargs['kwargs']['fw_sp']
    sg_sp = kwargs['kwargs']['sg_sp']
    action = kwargs['kwargs']['action']
    mgr = kwargs['kwargs']['mgr']
    appL = kwargs['kwargs']['appL']
    appPerFw = kwargs['kwargs']['appPerFw']
    print("enter chunk_list ...")
    appC = chunks_list(appL,appPerFw)

    ''' shuffle the sg list to random order '''
    shuffle(sg_list)
   # print(sp_name,prcd, len(sg_list), direction, fw_sp, sg_sp, mgr)

    if len(sg_list) < fw_sp or len(sg_list) < sg_sp:
        raise ValueError('length of sg_list (%s) is less than fw per SP or SG per SP' % len(sg_list))

    '''security group outer policy definition'''
    data['securityPolicy'] = OD({'name':sp_name})
    data['securityPolicy'].update({'precedence':prcd})

    ''' security grp this policy is bound to'''
    data['securityPolicy']['securityGroupBinding']=[]
    sgId_add = []
    for i in range(0,sg_sp):
        data['securityPolicy']['securityGroupBinding'].append({'objectId':sg_list[i]})
        print("print the SGID %s" %data['securityPolicy']['securityGroupBinding'][i]['objectId'])
        print("print the sg itself %s" %data['securityPolicy']['securityGroupBinding'])
        sgId_add.append(str(sg_list[i]))
        print(sgId_add)
    ''' firewall rules config'''
    data['securityPolicy']['actionsByCategory'] = OD()
    data['securityPolicy']['actionsByCategory'].update({'category':'firewall'})


    data['securityPolicy']['actionsByCategory']['action']=[]

    if filter(lambda x: 'applicationgroup' in x, appL):
       print("Apllication Groups used")
       for i in range(0,fw_sp):
            fw_name = "fw_rule-" + str(i+1)
            temp_dict=OD()
            temp_dict.update({'@class':'firewallSecurityAction'})
            temp_dict.update({'name':fw_name})
            temp_dict.update({'category':'firewall'})
            temp_dict.update({'isEnabled':'true'})
            temp_dict['applications'] = {}
            temp_dict['applications']['applicationGroup'] = []
            for app in appC[i]:
               temp_dict['applications']['applicationGroup'].append({'objectId':app})
            if not direction.startswith('intra'):
               temp_dict.update({'secondarySecurityGroup':{'objectId':sg_list[i]}})
            temp_dict.update({'logged':'false'})
            temp_dict.update({'action':action})
            temp_dict.update({'direction':direction})
            data['securityPolicy']['actionsByCategory']['action'].append(temp_dict)
    else:

        for i in range(0,fw_sp):
            fw_name = "fw_rule-" + str(i+1)
            temp_dict=OD()
            temp_dict.update({'@class':'firewallSecurityAction'})
            temp_dict.update({'name':fw_name})
            temp_dict.update({'category':'firewall'})
            temp_dict.update({'isEnabled':'true'})
            temp_dict['applications'] = {}
            temp_dict['applications']['application'] = []
            for app in appC[i]:
                temp_dict['applications']['application'].append({'objectId':app,'type':{'typeName':'Application'}})
            if not direction.startswith('intra'):
                temp_dict.update({'secondarySecurityGroup':{'objectId':sg_list[i]}})
            temp_dict.update({'logged':'false'})
            temp_dict.update({'action':action})
            temp_dict.update({'direction':direction})
            data['securityPolicy']['actionsByCategory']['action'].append(temp_dict)
    xml = xmltodict.unparse(data)
    print("xml dump:%s" %xml)

    url = '/api/2.0/services/policy/securitypolicy'

    r = mgr.post(url,xml)
    if r.status_code != 201:
        print("create request for security policy failed with return:%s %s" %(r.status_code,r.text))
        r.raise_for_status()

    return None

def config_securitypolicy(mgr,yaml_config):

    sg_list = get_all_sg(mgr)
    for line in yaml_config['securityPolicy']:
        sp_name = line['sp_name_prefix']
        prcd = line['precedence']
        direction = line['direction']
        fw_sp = line['number_fwrules_persp']
        sg_sp = line['number_SG_per_policy']
        number_of_sp = line['number_sp']
        action = line['action']
        if 'appNamePrefix' in line:
                appName =line['appNamePrefix']
                objAppDict = find_application_bynamepattern(mgr,appName)
                objApp = list(objAppDict.viewkeys())
                shuffle(objApp)
        elif 'appGroupNamePrefix' in line:
                appGroupName = line['appGroupNamePrefix']
                objApp = find_applicationgroup_bynamepattern(mgr,appGroupName)
                shuffle(objApp)
        appPerFw = line['appPerFw']

        if len(objApp) < (number_of_sp * fw_sp * appPerFw):
           print('len of app objects is less than expected')
           objApp = expand_list(objApp,(number_of_sp * fw_sp * appPerFw))
        objAppC = chunks_list(objApp,(fw_sp*appPerFw))

        for each_sp in range(number_of_sp):
           sp_new_name = sp_name +'-'+ str(each_sp)
           prcd=prcd +1
           kwargs = {'mgr':mgr,'sp_name':sp_new_name,'prcd':prcd, 'action':action, \
                 'sg_list':sg_list, 'direction':direction, 'fw_sp':fw_sp, 'sg_sp':sg_sp, \
                 'fw_sg_list': False, 'apl_sg': False, \
                        'appL':objAppC[each_sp],'appPerFw':appPerFw,'deny_rule':False}
           push_securitypolicy(kwargs=kwargs)
    return None

def sbux_config_securitypolicy(mgr,yaml_config,sg_list):
    apps = get_all_applications(mgr)
    for line in yaml_config['securityPolicy']:
        sp_name = line['sp_name_prefix']
        prcd = line['precedence']
        direction = line['direction']
        fw_sp = line['number_fwrules_persp']
        sg_sp = line['number_SG_per_policy']
        number_of_sp = line['number_sp']
        action = line['action']
        if 'appNamePrefix' in line:
            appName = line['appNamePrefix']
            app_objs = find_application_by_name_match(mgr, appName, apps=apps)
            objApp = [app['objectId'] for app in app_objs]
            shuffle(objApp)
        elif 'appGroupNamePrefix' in line:
            appGroupName = line['appGroupNamePrefix']
            objApp = find_applicationgroup_bynamepattern(mgr,appGroupName)
            shuffle(objApp)
        appPerFw = line['appPerFw']
        if len(objApp) < (number_of_sp * fw_sp * appPerFw):
           print('len of app objects is less than expected')
           objApp = expand_list(objApp,(number_of_sp * fw_sp * appPerFw))
        objAppC = chunks_list(objApp,(fw_sp*appPerFw))
        sg_list = chunks_list(sg_list, sg_sp)
        for each_sp in range(number_of_sp):
           sp_new_name = sp_name +'-'+ str(each_sp)
           prcd=prcd +1
           kwargs = {'mgr':mgr,'sp_name':sp_new_name,'prcd':prcd, 'action':action, \
                 'sg_list':sg_list[each_sp], 'direction':direction, 'fw_sp':fw_sp, 'sg_sp':sg_sp, \
                        'appL':objAppC[each_sp],'appPerFw':appPerFw}
           print("entering push function...")
           sbux_push_securitypolicy(kwargs=kwargs)
    return None


def sbux_insert_securitypolicy(mgr, yaml_config, sgId_add):
    print(yaml_config )
    print(sgId_add)
    interval =yaml_config['securityPolicy'][0]['time_interval']
    sp_name_insert=yaml_config['securityPolicy'][0]['sp_name_insert_sg']
    sp_list = []
    url = '/api/2.0/services/policy/securitypolicy/all'
    r = mgr.get(url)
    if r.status_code != 200:
       print(("Get all security policy : GET request failed"))
       r.raise_for_status()
    all_sp = xmltodict.parse(r.text)
    i = 0
    for sp in all_sp['securityPolicies']['securityPolicy']:
        sp_raw = {'securityPolicy': sp}  # For xml
        if  sp_name_insert in sp['name']:
            print("found the objectid for the sp %s" %sp['objectId'])
            print("service policy sg binding length before add %s" %(len(sp['securityGroupBinding'])))
            sp['securityGroupBinding'] = listify(sp['securityGroupBinding'])
            print("service policy sg binding type  %s" %(type(sp['securityGroupBinding'])))
            for sg in sgId_add:
               sp['securityGroupBinding'].append({'objectId':sg})
               print(" Adding sercurity group %s to Service policy " %sg)
#       sp['securityGroupBinding'].remove({'objectId':sgId_add[0]} # something to add later )
            print("service policy sg binding length  after add %s" %(len(sp['securityGroupBinding'])))
            url = '/api/2.0/services/policy/securitypolicy/' + sp['objectId']
            xml = xmltodict.unparse(sp_raw)
#            print("xml dump:%s" %xml)
            print('before', datetime.datetime.now())
            r = mgr.put(url,xml)
            print('after', datetime.datetime.now())
            r.raise_for_status()
            i += 1
            print('%s :: %s :: sleeping of interval requested:%d for SP # %s' %(str(datetime.datetime.now()),sp['objectId'],interval,i))
            time.sleep(interval)

    return None

def config_securitypolicy_src_dst_sg(mgr,yaml_config):
    for line in yaml_config['securityPolicy']:
        sp_name = line['sp_name_prefix']
        prcd = line['precedence']
        direction = line['direction']
        fw_sp = line['number_fwrules_persp']
        apl_sg = line['applied_to_SG_name']
        fw_sg = line['fw_src_SG_name']
        number_of_sp = line['number_sp']
        action = line['action']
        def_rule = line['def_rule']
        if 'appNamePrefix' in line:
                appName =line['appNamePrefix']
                objAppDict = find_application_bynamepattern(mgr,appName)
                objApp = list(objAppDict.viewkeys())
                shuffle(objApp)
        elif 'appGroupNamePrefix' in line:
                appGroupName = line['appGroupNamePrefix']
                objApp = find_applicationgroup_bynamepattern(mgr,appGroupName)
                shuffle(objApp)
        appPerFw = line['appPerFw']
        apl_sg = find_security_group_by_name(mgr,apl_sg)
        if apl_sg == None:
                break
        fw_sg_list = find_security_group_by_pattern(mgr,fw_sg)

        deny_rule = (def_rule=='block')
        print(deny_rule )
        if len(objApp) < (number_of_sp * fw_sp * appPerFw):
           print('len of app objects is less than expected')
           objApp = expand_list(objApp,(number_of_sp * fw_sp * appPerFw))
        objAppC = chunks_list(objApp,(fw_sp*appPerFw))

        for each_sp in range(number_of_sp):
           sp_new_name = sp_name +'-'+ str(each_sp)
           prcd=prcd +1
           kwargs = {'mgr':mgr,'sp_name':sp_new_name,'prcd':prcd, 'action':action, \
                        'fw_sg_list':fw_sg_list, 'apl_sg':apl_sg, 'sg_list': False, \
                        'direction':direction, 'fw_sp':fw_sp, 'sg_sp': False, \
                        'appL':objAppC[each_sp],'appPerFw':appPerFw,'deny_rule':deny_rule}
           push_securitypolicy(kwargs=kwargs)
    return None

def update_securitypolicy(mgr, yaml_config):

    ''' modify security groups apply-to based on yaml '''
    toaster = Toaster(yaml_config['number_of_threads'],logging.WARNING)
    for op in yaml_config['securityPolicy']:
        toaster.load(op['name'],update_security_policy_thread,kwargs={'mgr':mgr,'op':op})
    toaster.wait()
    print('modified all requested securityPolicies')
    return None


def update_security_policy_thread(**kwargs):
        ''' Each operation is checked for add / delete'''
        op = kwargs['op']
        mgr = kwargs['mgr']
        name = op['name']
        interval = op['time_interval']
        sg_per_iter = op['no_sg_per_iteration']
        if op['operation'] == 'add_SG':
           max_sg = op['max_sg_apply_to']
           sp_oid = find_security_policy_by_name(mgr, name)
           print('it is add for %s with OID:%s' %(name,sp_oid))
           sp_dt = get_securitypolicy_by_id(mgr,sp_oid)
           sg_current =[]
           if type(sp_dt['securityPolicy']['securityGroupBinding']) == list:
              for sg in sp_dt['securityPolicy']['securityGroupBinding']:
                 sg_current.append(sg['objectId'])
           else:
              sg_current.append(sp_dt['securityPolicy']['securityGroupBinding']['objectId'])

           args = {'sp_oid':sp_oid,'max_sg':max_sg,'interval':interval, \
                        'sg_per_iter':sg_per_iter,'sg_current':sg_current,'mgr':mgr}
           appendSG_securitypolicy(args = args)


        elif op['operation'] == 'delete_SG':
           min_sg = op['min_sg_apply_to']

           sp_oid = find_security_policy_by_name(mgr, name)
           print('it is delete for %s with OID:%s' %(name,sp_oid))
           sp_dt = get_securitypolicy_by_id(mgr,sp_oid)
           sg_current =[]
           if type(sp_dt['securityPolicy']['securityGroupBinding']) == list:
              for sg in sp_dt['securityPolicy']['securityGroupBinding']:
                 sg_current.append(sg['objectId'])
           else:
              sg_current.append(sp_dt['securityPolicy']['securityGroupBinding']['objectId'])
           args = {'sp_oid':sp_oid,'min_sg':min_sg,'interval':interval, \
                        'sg_per_iter':sg_per_iter,'sg_current':sg_current,'mgr':mgr}
           removeSG_securitypolicy(args = args)
        else:
           print('!!!!! ERROR: No Op on the security policy hit!!!!!!')
        return None

def appendSG_securitypolicy(**args):

    sp_id = args['args']['sp_oid']
    max_sg = args['args']['max_sg']
    interval = args['args']['interval']
    sg_iter = args['args']['sg_per_iter']
    sg_current = args['args']['sg_current']
    mgr = args['args']['mgr']

    if max_sg > len(sg_current):
        diff_sg_len = max_sg - len(sg_current)
    else :
        print('appending security group to policy: requested number of SG is less than or equal to current config ')
        return None
    ''' get the difference SG list and split it into equal chunk of iteration size'''
    sg_complete = get_all_sg(mgr)
    diff_sg = list(set(sg_complete) - set(sg_current))
    #diff_sg_split = zip(*[iter(diff_sg)]*sg_iter)
    ''' no of iterations required based on ceil factor'''
    no_iter_reqd = int(math.ceil(float(diff_sg_len)/sg_iter))
    diff_sg_split = chunks_list(diff_sg,sg_iter)

    for itr in range(no_iter_reqd):
       print('%s Starting iteration for %s: %d' %(str(datetime.datetime.now()),sp_id,itr))
       sp_dt = get_securitypolicy_by_id(mgr,sp_id)
       sp_dt['securityPolicy']['securityGroupBinding'] = listify(sp_dt['securityPolicy']['securityGroupBinding'])
       for sg in diff_sg_split[itr]:
          if len(sp_dt['securityPolicy']['securityGroupBinding']) < max_sg:
             sp_dt['securityPolicy']['securityGroupBinding'].append({'objectId':sg})

       xml = xmltodict.unparse(sp_dt)
       #print("xml dump:%s" %xml)

       url = '/api/2.0/services/policy/securitypolicy/' + sp_id

       r = mgr.put(url,xml)
       if r.status_code != 200:
          print("update request for security policy failed with return:%s %s" %(r.status_code,r.text))
          r.raise_for_status()

       print('%s :: %s :: sleeping for interval requested:%d' %(str(datetime.datetime.now()),sp_id,interval))
       time.sleep(interval)
    return None


def removeSG_securitypolicy(**args):

    sp_id = args['args']['sp_oid']
    min_sg = args['args']['min_sg']
    interval = args['args']['interval']
    sg_iter = args['args']['sg_per_iter']
    sg_current = args['args']['sg_current']
    mgr = args['args']['mgr']

    if min_sg < len(sg_current):
        diff_sg_len = len(sg_current) - min_sg
    else :
        print('remvoing security group from policy in batch: requested number of SG is more than or equal to current config ')
        return None

    no_iter_reqd = int(math.ceil(float(diff_sg_len)/sg_iter))

    for itr in range(no_iter_reqd):
       sp_dt = get_securitypolicy_by_id(mgr,sp_id)
       sp_dt['securityPolicy']['securityGroupBinding']=listify(sp_dt['securityPolicy']['securityGroupBinding'])
       for sg in range(sg_iter):
          if len(sp_dt['securityPolicy']['securityGroupBinding']) > min_sg:
                sp_dt['securityPolicy']['securityGroupBinding'].pop()

       xml = xmltodict.unparse(sp_dt)
       print("xml dump:%s" %xml)

       url = '/api/2.0/services/policy/securitypolicy/' + sp_id

       r = mgr.put(url,xml)
       if r.status_code != 200:
          print("update request for security policy failed with return:%s %s" %(r.status_code,r.text))
          r.raise_for_status()
       print('sleeping for interval requested:%d' %interval)
       time.sleep(interval)
    return None

def get_all_sg(mgr):

    sg_list =[]

    url = '/api/2.0/services/securitygroup/scope/globalroot-0'

    r = mgr.get(url)
    if r.status_code != 200:
        print(("Get all security group : GET request failed"))
        r.raise_for_status()

    all_sg = xmltodict.parse(r.text)
    if type(all_sg['list']['securitygroup'])==list:
        for sg in all_sg['list']['securitygroup']:
          sg_list.append(sg['objectId'])
    else:
        sg_list.append(all_sg['list']['securitygroup']['objectId'])

    return sg_list

def find_security_group_by_name(mgr, name, results=None):

    url = '/api/2.0/services/securitygroup/scope/globalroot-0'
    r = mgr.get(url)
    if r.status_code != 200:
        print(("Get all security group : GET request failed"))
        r.raise_for_status()

    all_sg = xmltodict.parse(r.text)
    if type(all_sg['list']['securitygroup'])==list:
        for sg in all_sg['list']['securitygroup']:
           if sg['name'] == name:
              #print(sg['objectId'])
              return sg['objectId']

    else:
        if all_sg['list']['securitygroup']['name'] == name:
           #print(all_sg['list']['securitygroup']['objectId'])
           return all_sg['list']['securitygroup']['objectId']

    print("NO SG with name \"%s\" found, retry by providing the EXACT name of the SG "%(name))
    return None

def find_security_group_by_pattern(mgr, name, results=None):
    #incomplete not tested
    retL = []
    url = '/api/2.0/services/securitygroup/scope/globalroot-0'
    r = mgr.get(url)
    if r.status_code != 200:
        print(("Get all security group : GET request failed"))
        r.raise_for_status()

    all_sg = xmltodict.parse(r.text)
    if type(all_sg['list']['securitygroup'])==list:
        for sg in all_sg['list']['securitygroup']:
           if sg['name'].find(name) != -1:
              retL.append(sg['objectId'])

    else:
        if all_sg['list']['securitygroup']['name'].find(name) != -1:
           retL.append(all_sg['list']['securitygroup']['objectId'])
    return retL

def get_securitygroup_by_id(mgr, id):
    # JPMC cpt
    url = '/api/2.0/services/securitygroup/' + str(id)
    r = mgr.get(url)
    if r.status_code != 200:
        print("Get all security policy : GET request failed")
        r.raise_for_status()
    dt_sg = xmltodict.parse(r.text)
    return dt_sg



def find_security_policy_by_name(mgr, name, results=None):

    url = '/api/2.0/services/policy/securitypolicy/all'

    r = mgr.get(url)
    if r.status_code != 200:
        print("Get all security policy : GET request failed")
        r.raise_for_status()

    all_sg = xmltodict.parse(r.text)
    if type(all_sg['securityPolicies']['securityPolicy'])==list:
        for sg in all_sg['securityPolicies']['securityPolicy']:
           if sg['name'] == name:
              return sg['objectId']

    else:
        if all_sg['securityPolicies']['securityPolicy']['name'] == name:
           return all_sg['securityPolicies']['securityPolicy']['objectId']

    return None

def find_security_policy_by_pattern(mgr, name, results=None):

    retL = []
    url = '/api/2.0/services/policy/securitypolicy/all'
    r = mgr.get(url)
    if r.status_code != 200:
        print("Get all security policy : GET request failed")
        r.raise_for_status()

    all_sg = xmltodict.parse(r.text)
    if type(all_sg['securityPolicies']['securityPolicy'])==list:
        for sg in all_sg['securityPolicies']['securityPolicy']:
           if sg['name'].find(name) != -1:
              retL.append(sg['objectId'])

    else:
        if all_sg['securityPolicies']['securityPolicy']['name'].find(name) != -1:
           retL.append(all_sg['securityPolicies']['securityPolicy']['objectId'])
    return retL

def get_securitypolicy_by_id(mgr, id):
    url = '/api/2.0/services/policy/securitypolicy/' + str(id)
    r = mgr.get(url)
    if r.status_code != 200:
        print("Get all security policy : GET request failed")
        r.raise_for_status()
    dt_sp = xmltodict.parse(r.text)
    return dt_sp

def securitypolicy_fwrule_action(mgr,name,action):
    sp_oid = find_security_policy_by_pattern(mgr,name)
    if len(sp_oid)== 0:
        print("No match found for the Security Policy name !!")
    for sp in sp_oid:
        print('FW policy %s with OID:%s' %(name,sp))
        sp_dt = get_securitypolicy_by_id(mgr,sp)
        if type(sp_dt['securityPolicy']['actionsByCategory']['action']) == list:
            if action == "status":
                ptbl = PrettyTable(['IsEnabled'])
                num_sec = len(sp_dt['securityPolicy']['actionsByCategory']['action'])
                print("Policy has %s rules with status as listed below:"%(num_sec))
                for x in range(num_sec):
                        ptbl.add_row([sp_dt['securityPolicy']['actionsByCategory']['action'][x]['isEnabled']])
                print(ptbl)
            else:
                for fw in sp_dt['securityPolicy']['actionsByCategory']['action']:
                    if action == "disable":
                        fw.update({'isEnabled':'false'})
                    elif action == "enable":
                        fw.update({'isEnabled':'true'})
                    else:
                        print("\nInvalid action, action has to be \"enable\" or \"disable\"")
                update_security_policy_fw_action(mgr,sp,sp_dt)
        else:
            # firewall with single rule
            if action == "disable":
                sp_dt['securityPolicy']['actionsByCategory']['action'].update({'isEnabled':'false'})
                print("Disabling fw rule on security policy id :",sp)
                update_security_policy_fw_action(mgr,sp,sp_dt)
            elif action == "enable":
                sp_dt['securityPolicy']['actionsByCategory']['action'].update({'isEnabled':'true'})
                print("Enabling fw rule on security policy id :",sp)
                update_security_policy_fw_action(mgr,sp,sp_dt)
            elif action == "status":
                print("Single firewall rule exists with Rule Enabled staus =",sp_dt['securityPolicy']['actionsByCategory']['action']['isEnabled'])
            else:
                print("\nInvalid action, action has to be \"enable\" or \"disable\"")


def update_security_policy_fw_action(mgr,sp,sp_dt):
            xml = xmltodict.unparse(sp_dt)
            header={'content-type':'application/xml'}
            url = '/api/2.0/services/policy/securitypolicy/'+ str(sp)
            r = mgr.put(url,xml,headers=header)
            if r.status_code != 200:
                print("create request for application group failed with return:%s %s" %(r.status_code,r.text))
                r.raise_for_status()

def delete_security_group_by_name(mgr, name, objectId=None, logger=None):

    objectIdL = find_security_group_by_pattern(mgr,name,results='objectId')
    if objectIdL:
        for objectId in objectIdL:
            url = '/api/2.0/services/securitygroup/%s?force=true' % objectId
            logger.info('deleting securitygroup %s' %objectId)
            r = mgr.delete(url)
            if not (200 <= r.status_code <= 204):
                logger.error("HTTP return code for delete securitygroup is not 20x: %d and reason:%s" %(r.status_code,r.text))
                r.raise_for_status()
    else:
        logger.warning('security group "%s" not found' % name)

    return None

def delete_security_policy_by_name(mgr,name, objectId=None):

    objectIdL = find_security_policy_by_pattern(mgr,name,results='objectId')


    for objectId in objectIdL:
      url = '/api/2.0/services/policy/securitypolicy/%s?force=true' % objectId
      print('deleting securitypolicy %s' %objectId)
      r = mgr.delete(url)
      if not (200 <= r.status_code <= 204):
        print("HTTP return code for delete securitypolicy is not 20x: %d and reason:%s" %(r.status_code,r.text))
        r.raise_for_status()

    return None



def deleteall_security_group(mgr):

    url = '/api/2.0/services/securitygroup/scope/globalroot-0'

    r = mgr.get(url)
    if r.status_code != 200:
        print("Get all security group : GET request failed")
        r.raise_for_status()

    all_sg = xmltodict.parse(r.text)
    if type(all_sg['list']['securitygroup'])==list:
        for sg in all_sg['list']['securitygroup']:
           print('deleting security group:',sg['name'])
           url = '/api/2.0/services/securitygroup/%s?force=true' % sg['objectId']

           r = mgr.delete(url)
           if not (200 <= r.status_code <= 204):
             print("HTTP return code for delete securitygroup is not 20x: %d and reason:%s" %(r.status_code,r.text))
             r.raise_for_status()
    else:
       url = '/api/2.0/services/securitygroup/%s?force=true' % all_sg['list']['securitygroup']['objectId']
       r = mgr.delete(url)
       if not (200 <= r.status_code <= 204):
         print("HTTP return code for delete securitygroup is not 20x: %d and reason:%s" %(r.status_code,r.text))
         r.raise_for_status()
    return None

def deleteall_security_policy(mgr):

    url = '/api/2.0/services/policy/securitypolicy/all'

    r = mgr.get(url)
    if r.status_code != 200:
        print("Get all security policy : GET request failed")
        r.raise_for_status()

    all_sg = xmltodict.parse(r.text)
    if type(all_sg['securityPolicies']['securityPolicy'])==list:
        for sg in all_sg['securityPolicies']['securityPolicy']:
           print('deleting security policy:',sg['name'])
           url = '/api/2.0/services/policy/securitypolicy/%s?force=true' % sg['objectId']

           r = mgr.delete(url)
           if not (200 <= r.status_code <= 204):
             print("HTTP return code for delete securitypolicy is not 20x: %d and reason:%s" %(r.status_code,r.text))
             r.raise_for_status()
    else:
       url = '/api/2.0/services/policy/securitypolicy/%s?force=true' % all_sg['securityPolicies']['securityPolicy']['objectId']
       r = mgr.delete(url)
       if not (200 <= r.status_code <= 204):
         print("HTTP return code for delete securitypolicy is not 20x: %d and reason:%s" %(r.status_code,r.text))
         r.raise_for_status()
    return None

def push_securitygroup(**kwargs):

   name = kwargs['kwargs']['name']
   mgr = kwargs['kwargs']['mgr']
   objL = kwargs['kwargs']['objL']
   type = kwargs['kwargs']['type']

   data = OD()
   data['securitygroup'] = OD({'name':name})
   data['securitygroup'].update({'type':{'typeName':'SecurityGroup'}})
   if objL != None :
       data['securitygroup']['member'] =[]
       for obj in objL:
           data['securitygroup']['member'].append({'objectId':obj,'type':{'typeName':type}})

   xml = xmltodict.unparse(data)
   print("xml dump:%s" %xml)

   url = '/api/2.0/services/securitygroup/bulk/globalroot-0'
   r = mgr.post(url,xml)
   if r.status_code != 201:
      print("create request for security group failed with return:%s %s" %(r.status_code,r.text))
      r.raise_for_status()
   print(r.text)
   return None

def sbux_insert_push_securitygroup(**kwargs):

   name = kwargs['kwargs']['name']
   mgr = kwargs['kwargs']['mgr']
   objL = kwargs['kwargs']['objL']
   type = kwargs['kwargs']['type']
   data = OD()
   data['securitygroup'] = OD({'name':name})
   data['securitygroup'].update({'type':{'typeName':'SecurityGroup'}})

   data['securitygroup']['member'] =[]
   for obj in objL:
        data['securitygroup']['member'].append({'objectId':obj,'type':{'typeName':type}})

   xml = xmltodict.unparse(data)
   print("xml dump:%s" %xml)

   url = '/api/2.0/services/securitygroup/bulk/globalroot-0'
   r = mgr.post(url,xml)
   if r.status_code != 201:
      print("create request for security group failed with return:%s %s" %(r.status_code,r.text))
      r.raise_for_status()
   print(r.text)
   return r.text

def config_securitygroup(mgr,data,**args):
    name = data['yaml']['securitygroup'][0]['name']
    type = data['yaml']['securitygroup'][0]['typeName']
    prefixType = data['yaml']['securitygroup'][0]['prefix_typeName']
    count = data['yaml']['securitygroup'][0]['count']
    countTypeSG = data['yaml']['securitygroup'][0]['typeCountPerSG']
    objL = []

    if type == 'SecurityTag':
        print("Configring Security group on tag")
        objL = find_securitytag_bynamepattern(mgr,prefixType)
        print("Total num of security tags matching search criteria are :",len(objL))

    elif type == 'VirtualMachine':
       objL=find_vm_bynamepattern(mgr,data,args)
       print("Total num of VMs on VC matching search criteria are :",len(objL))

    elif type == 'IPSet':
        print("Configring Security group with IPSets")
        ipsetd = nsxvlib.Ipset(mgr)
        nameL = ipsetd.find_by_name(prefixType, results=None, matchMethod='re')
        for obj in nameL:
            objL.append(obj['objectId'])
        print("Total num of IPSets matching search criteria are :",len(objL))
    elif type == 'Empty':
        print("Configuring empty SG")
        for i in range(count):
                kwargs = {'name':name + str(i),'objL':None,'mgr':mgr,'type':type}
                push_securitygroup(kwargs=kwargs)
        return None
    else:
       raise ValueError('typeName is invalid in creating Security group:%s' %name)

    if len(objL) < count * countTypeSG:
        objL = expand_list(objL,(count*countTypeSG))
        #raise ValueError('length of type :%s objects is less than the expected' %type)

    objC = chunks_list(objL,(countTypeSG))
    for i in range(count):

        kwargs = {'name':name + str(i),'mgr':mgr,'objL':objC[i],'type':type}
        push_securitygroup(kwargs=kwargs)

    return None

def sbux_insert_securitygroup(mgr,data,**args):
    name = data['yaml']['securitygroup'][0]['name']
    type = data['yaml']['securitygroup'][0]['typeName']
    prefixType = data['yaml']['securitygroup'][0]['prefix_typeName']
    count = data['yaml']['securitygroup'][0]['count']
    countTypeSG = data['yaml']['securitygroup'][0]['typeCountPerSG']
    objL = sgId_add = []

    if type == 'SecurityTag':
        print("Configring Security group on tag")
        objL = find_securitytag_bynamepattern(mgr,prefixType)
        print("Total num of security tags matching search criteria are :",len(objL))

    elif type == 'VirtualMachine':
       #print('skipping virtual machine.. code incomplete')
       objL=find_vm_bynamepattern(mgr,data,args)
       print("Total num of VMs on VC matching search criteria are :",len(objL))
    else:
       raise ValueError('typeName is invalid in creating Security group:%s' %name)

    if len(objL) < count * countTypeSG:
        objL = expand_list(objL,(count*countTypeSG))
        #raise ValueError('length of type :%s objects is less than the expected' %type)
    objC = chunks_list(objL,(countTypeSG))
    for i in range(count):

        kwargs = {'name':name + str(i),'mgr':mgr,'objL':objC[i],'type':type}
        sgId_add.append(sbux_insert_push_securitygroup(kwargs=kwargs))
    return sgId_add


#JPMC testing

def update_securitygroup(mgr, yaml_config):

    ''' modify VMs in a SG based on yaml '''
    toaster = Toaster(yaml_config['number_of_threads'],logging.WARNING)
    for op in yaml_config['securityGroup']:
        toaster.load(op['src_name'],update_security_group_thread,kwargs={'mgr':mgr,'op':op})
    toaster.wait()
    print('Modify operation completed for all the securityGroups')
    return None

def update_security_group_thread(**kwargs):
        ''' Each operation is checked for add / delete'''
        op = kwargs['op']
        mgr = kwargs['mgr']
        src_name = op['src_name']
        dst_name = op['dst_name']
        interval = op['time_interval']
        vm_per_iter = op['no_vm_per_iteration']
        if op['operation'] == 'del_VM':
           max_vm = op['max_vm_apply_to']
           # max_vm is the max number of VM that will be moved out of this SG
           sg_oid = find_security_group_by_name(mgr, src_name)
           print('Deleting VMs from  %s with OID:%s' %(src_name,sg_oid))
           sg_dt = get_securitygroup_by_id(mgr,sg_oid)
           vm_current =[]
           # vm_current holds the list of all the VMs in the SG
           if filter(lambda x: 'member' in x, sg_dt['securitygroup']):
           # if there is atleast one member VM in the SG the do the below
               if type(sg_dt['securitygroup']['member']) == list:
                  for sg in sg_dt['securitygroup']['member']:
                     vm_current.append(sg['objectId'])
               else:
                  vm_current.append(sg_dt['securitygroup']['member']['objectId'])
               args = {'sg_oid':sg_oid,'max_vm':max_vm,'interval':interval, \
                        'vm_per_iter':vm_per_iter,'vm_current':vm_current,'mgr':mgr}
               del_vm_list = removeVM_securitygroup(args = args)
               print("List of VMs deleted :",del_vm_list)
           else:
            # there are no VMs in this SG
                print("NO VMs persent in the SG %s"%(src_name))


        elif op['operation'] == 'move_VM':
           max_vm = op['max_vm_apply_to']
           sg_oid = find_security_group_by_name(mgr, src_name)
           print('Moving VMs from  %s with OID:%s' %(src_name,sg_oid))
           sg_dt = get_securitygroup_by_id(mgr,sg_oid)
           vm_current =[]
           if filter(lambda x: 'member' in x, sg_dt['securitygroup']):
           # if there is atleast one member VM in the SG the do the below
               if type(sg_dt['securitygroup']['member']) == list:
                  for sg in sg_dt['securitygroup']['member']:
                     vm_current.append(sg['objectId'])
               else:
                  vm_current.append(sg_dt['securitygroup']['member']['objectId'])
           else:
            # there are no VMs in this SG
                print("NO VMs persent in the SG %s"%(src_name))
                return None
           args = {'sg_oid':sg_oid,'max_vm':max_vm,'interval':interval, \
                        'vm_per_iter':vm_per_iter,'vm_current':vm_current,'mgr':mgr}
           del_vm_list = removeVM_securitygroup(args = args)
           max_vm = len(del_vm_list)
           print("List of VMs deleted :",del_vm_list)
           # Add the VMs from the above list to the dst_sg
           sg_oid_dst = find_security_group_by_name(mgr, dst_name)
           print("Moving VMs to SG %s with OID: %s"%(dst_name,sg_oid_dst))
           #check to see if VM in the del_vm_list is already part of DST SG , PUT API will fail if VM already present
           # fail the move operation if VM already present
           sg_dt_dst = get_securitygroup_by_id(mgr,sg_oid_dst)
           vm_dst =[]
           if filter(lambda x: 'member' in x, sg_dt_dst['securitygroup']):
           # if there is atleast one member VM in the SG the do the below
               if type(sg_dt_dst['securitygroup']['member']) == list:
                    for sg in sg_dt_dst['securitygroup']['member']:
                       vm_dst.append(sg['objectId'])
               else:
                    vm_current.append(sg_dt_dst['securitygroup']['member']['objectId'])
           else:
            # there are no VMs in this SG
               print("NO VMs persent in the SG %s"%(src_name))

           if (set(del_vm_list).intersection(vm_dst)):
                print("Common VM %s found at destination SG \n !!!!ABORTING VM MOVE OPERATION!!!!"%(list(set(del_vm_list).intersection(vm_dst))))
                return None
           else:
                args = {'sg_oid':sg_oid_dst,'max_vm':None,'interval':interval, \
                        'vm_per_iter':vm_per_iter,'vm_current':del_vm_list,'mgr':mgr}
                addVM_securitygroup(args = args)
        else:
           print('!!!!! ERROR: invalid operation specified !!!!!!')
        return None

def removeVM_securitygroup(**args):
    sg_id = args['args']['sg_oid']
    max_vm = args['args']['max_vm']
    interval = args['args']['interval']
    vm_iter = args['args']['vm_per_iter']
    vm_current = args['args']['vm_current']
    mgr = args['args']['mgr']

    if max_vm > len(vm_current):
        print("MAX number of VMs to be removed from this SG is less than the total number of VMs in the SG ")
        return None
    else :
        print("Deleting %s VMs from SG"%(max_vm))
    no_iter_reqd = int(math.ceil(float(max_vm)/vm_iter))

    del_vm_list = []
    for itr in range(no_iter_reqd):
       for vm in range(vm_iter):
           url = '/api/2.0/services/securitygroup/' + sg_id+"/members/"+vm_current[0]
           del_vm_list.append(vm_current[0])
           print("Deleting VM %s: "%(vm_current[0]))
           vm_current.pop(0)
           r = mgr.delete(url)
           if r.status_code != 200:
               print("update request for security policy failed with return:%s %s" %(r.status_code,r.text))
               r.raise_for_status()
       print('sleeping for interval requested:%d' %interval)
       time.sleep(interval)
    return del_vm_list


def addVM_securitygroup(**args):
    sg_id = args['args']['sg_oid']
    max_vm = args['args']['max_vm']
    interval = args['args']['interval']
    vm_iter = args['args']['vm_per_iter']
    vm_current = args['args']['vm_current']
    mgr = args['args']['mgr']
    if (max_vm > len(vm_current)):
        print("ADD NEW VM TO SG FROM LIST OF VMs IN VC : INCOMPLETE ")
    elif max_vm == None:
        print("Adding %s VMs to SG %s"%(len(vm_current),sg_id))
        no_iter_reqd = int(math.ceil(float(len(vm_current))/vm_iter))
        for itr in range(no_iter_reqd):
           for vm in range(vm_iter):
                url = '/api/2.0/services/securitygroup/' + sg_id+"/members/"+vm_current[0]
                print("Adding VM %s: "%(vm_current[0]))
                vm_current.pop(0)
                r = mgr.put(url)
                if r.status_code != 200:
                    print("update request for security policy failed with return:%s %s" %(r.status_code,r.text))
                    r.raise_for_status()
           print('sleeping for interval requested:%d' %interval)
           time.sleep(interval)
        return None
    else:
        print("requested number of VM is greater than or equal to the num of VMs already in the SG")
        return None

def deleteall_dfw(mgr):

    url = '/api/4.0/firewall/globalroot-0/config'

    r = mgr.delete(url)
    if not (200 <= r.status_code <= 204):
       print("HTTP return code for deleting DFW sections / rules is not 20x: %d and reason:%s" %(r.status_code,r.text))
       r.raise_for_status()


def dfw_rule_en(mgr,l3id,ruleids):
    for ruleid in ruleids:
        url = '/api/4.0/firewall/globalroot-0/config/layer3sections/%s'%(l3id)
        r = mgr.get(url)
        etag = r.headers['etag']
        url = '/api/4.0/firewall/globalroot-0/config/layer3sections/%s/rules/%s'%(l3id,ruleid)
        r = mgr.get(url)
        rule = xmltodict.parse(r.text)
        rule['rule'].update({'@disabled':'false'})
        xml = xmltodict.unparse(rule)
        header={'if-match':etag,'content-type':'application/xml'}
        r = mgr.put(url,xml,headers=header)
        if r.status_code != 200:
            print("create request for application group failed with return:%s %s" %(r.status_code,r.text))
            r.raise_for_status()
    return None

def dfw_rule_dis(mgr,l3id,ruleids):
    for ruleid in ruleids:
        url = '/api/4.0/firewall/globalroot-0/config/layer3sections/%s'%(l3id)
        r = mgr.get(url)
        etag = r.headers['etag']
        url = '/api/4.0/firewall/globalroot-0/config/layer3sections/%s/rules/%s'%(l3id,ruleid)
        r = mgr.get(url)
        rule = xmltodict.parse(r.text)
        rule['rule'].update({'@disabled':'true'})
        xml = xmltodict.unparse(rule)
        header={'if-match':etag,'content-type':'application/xml'}
        r = mgr.put(url,xml,headers=header)
        if r.status_code != 200:
            print("create request for application group failed with return:%s %s" %(r.status_code,r.text))
            r.raise_for_status()
    return None

#def find_fw_bynamepattern(mgr,name,action):
#    url = '/api/4.0/firewall/globalroot-0/config'
#    r = mgr.get(url)
#    if r.status_code != 200:
#        print("Get request for all DFW section failed with return:%s %s" %(r.status_code,r.text))
#        r.raise_for_status()
#    all_fw = xmltodict.parse(r.text)
#    num_fw_sec = len(all_fw['firewallConfiguration']['layer3Sections']['section'])
#    l3id = all_fw['firewallConfiguration']['layer3Sections']['section'][0]['@id']
#    pprint_od(all_fw['firewallConfiguration']['layer3Sections']['section'])
#    ruleids = []
#    if type(all_fw['firewallConfiguration']['layer3Sections']['section'])==list:
#        for x in range(num_fw_sec):
#            if type(all_fw['firewallConfiguration']['layer3Sections']['section'][x]['rule'])==list:
#                if all_fw['firewallConfiguration']['layer3Sections']['section'][x]['@name'].find(name) != -1:
#                    num_fw_rule = len(all_fw['firewallConfiguration']['layer3Sections']['section'][x]['rule'])
#                    #ruleids = []
#                    ptbl = PrettyTable(['Name', 'ID','Rule disabled state'])
#                    print("\n FW section %s has %s firewall rules" % (
#                        all_fw['firewallConfiguration']['layer3Sections']['section'][x]['@name'], num_fw_rule))
#                    for rule in all_fw['firewallConfiguration']['layer3Sections']['section'][x]['rule']:
#                        ptbl.add_row([rule['name'],rule['@id'],rule['@disabled']])
#                        ruleids.append(rule['@id'])
#                    print(ptbl)
#                    if action == "disable":
#                        print("\nDisabling firewall rules")
#                        dfw_rule_dis(mgr,l3id,ruleids)
#                    elif action == "enable":
#                        print("\nEnabling firewall rules")
#                        dfw_rule_en(mgr,l3id,ruleids)
#                    elif action == "status":
#                        print("")
#                    else:
#                        print("\nInvalid action, action has to be \"enable\" or \"disable\"")
#            else:
#                # firewall section with single rule
#                if all_fw['firewallConfiguration']['layer3Sections']['section'][x]['@name'].find(name) != -1:
#                    print("\nFW section",all_fw['firewallConfiguration']['layer3Sections']['section'][x]['@name'],"has a single rule ")
#                    ptbl = PrettyTable(['Name', 'ID','Rule disabled state'])
#                    ptbl.add_row([all_fw['firewallConfiguration']['layer3Sections']['section'][x]['rule']['name'],all_fw['firewallConfiguration']['layer3Sections']['section'][x]['rule']['@id'],all_fw['firewallConfiguration']['layer3Sections']['section'][x]['rule']['@disabled']])
#                    ruleids.append(all_fw['firewallConfiguration']['layer3Sections']['section'][x]['rule']['@id'])
#                    print(ptbl)
#                    if action == "disable":
#                        print("\nDisabling firewall rules")
#                        dfw_rule_dis(mgr,l3id,ruleids)
#                    elif action == "enable":
#                        print("\nEnabling firewall rules")
#                        dfw_rule_en(mgr,l3id,ruleids)
#                    elif action == "status":
#                        print("")
#                    else:
#                        print("\nInvalid action, action has to be \"enable\" or \"disable\"")
#        return None
#    else:
#        print("not a list")
#    return None

def find_fw_bynamepattern(mgr,name,action):
    url = '/api/4.0/firewall/globalroot-0/config'
    r = mgr.get(url)
    if r.status_code != 200:
        print("Get request for all DFW section failed with return:%s %s" %(r.status_code,r.text))
        r.raise_for_status()
    all_fw = xmltodict.parse(r.text)
    num_fw_sec = len(all_fw['firewallConfiguration']['layer3Sections']['section'])
    l3Sections = listify(all_fw['firewallConfiguration']['layer3Sections']['section'])
    pprint_od(l3Sections)
    l3id = l3Sections['@id']
    ruleids = []
    if type(all_fw['firewallConfiguration']['layer3Sections']['section'])==list:
        for x in range(num_fw_sec):
            if type(all_fw['firewallConfiguration']['layer3Sections']['section'][x]['rule'])==list:
                if all_fw['firewallConfiguration']['layer3Sections']['section'][x]['@name'].find(name) != -1:
                    num_fw_rule = len(all_fw['firewallConfiguration']['layer3Sections']['section'][x]['rule'])
                    #ruleids = []
                    ptbl = PrettyTable(['Name', 'ID','Rule disabled state'])
                    print("\n FW section %s has %s firewall rules" % (
                        all_fw['firewallConfiguration']['layer3Sections']['section'][x]['@name'], num_fw_rule))
                    for rule in all_fw['firewallConfiguration']['layer3Sections']['section'][x]['rule']:
                        ptbl.add_row([rule['name'],rule['@id'],rule['@disabled']])
                        ruleids.append(rule['@id'])
                    print(ptbl)
                    if action == "disable":
                        print("\nDisabling firewall rules")
                        dfw_rule_dis(mgr,l3id,ruleids)
                    elif action == "enable":
                        print("\nEnabling firewall rules")
                        dfw_rule_en(mgr,l3id,ruleids)
                    elif action == "status":
                        print("")
                    else:
                        print("\nInvalid action, action has to be \"enable\" or \"disable\"")
            else:
                # firewall section with single rule
                if all_fw['firewallConfiguration']['layer3Sections']['section'][x]['@name'].find(name) != -1:
                    print("\nFW section",all_fw['firewallConfiguration']['layer3Sections']['section'][x]['@name'],"has a single rule ")
                    ptbl = PrettyTable(['Name', 'ID','Rule disabled state'])
                    ptbl.add_row([all_fw['firewallConfiguration']['layer3Sections']['section'][x]['rule']['name'],all_fw['firewallConfiguration']['layer3Sections']['section'][x]['rule']['@id'],all_fw['firewallConfiguration']['layer3Sections']['section'][x]['rule']['@disabled']])
                    ruleids.append(all_fw['firewallConfiguration']['layer3Sections']['section'][x]['rule']['@id'])
                    print(ptbl)
                    if action == "disable":
                        print("\nDisabling firewall rules")
                        dfw_rule_dis(mgr,l3id,ruleids)
                    elif action == "enable":
                        print("\nEnabling firewall rules")
                        dfw_rule_en(mgr,l3id,ruleids)
                    elif action == "status":
                        print("")
                    else:
                        print("\nInvalid action, action has to be \"enable\" or \"disable\"")
        return None
    else:
        print("not a list")
    return None

def find_application_bynamepattern(mgr,name):


    url = '/api/2.0/services/application/scope/globalroot-0'
    rlist = {}
    r = mgr.get(url)
    if r.status_code != 200:
        print("Get all application service : GET request failed")
        r.raise_for_status()

    all_app = xmltodict.parse(r.text)
    if type(all_app['list']['application'])==list:
        for app in all_app['list']['application']:
           if app['name'].find(name) != -1:
                rlist.update({app['objectId']:[app['name'],app['element']['applicationProtocol']]})
        return rlist
    else:
        if all_app['list']['application']['name'].find(name) != -1:
                rlist.update({all_app['list']['application']['objectId']:[all_app['list']['application']['name'],\
                        all_app['list']['application']['element']['applicationProtocol']]})
                return rlist

    return None



def get_all_applications(mgr):
    """
    Guarantees we get a list of applications
    """
    url = '/api/2.0/services/application/scope/globalroot-0'
    r = mgr.get(url)
    r.raise_for_status()
    all_app = xmltodict.parse(r.text)
    results = all_app['list']['application']
    # XXX: Apparently NSX-v can get a single item instead of a list?
    # But we always have at least one, not 0??  =(
    if not isinstance(results, list):
        results = [results]
    return results


def find_application_by_name_match(mgr, name_substring, apps=None):
    """
    Finds applications with a name which contains 'name_substring' and
    returns them as a list.  You may provide a list of applications, otherwise
    we will fetch all applications.
    """
    if apps is None:
        apps = get_all_applications(mgr)
    return [app for app in apps if name_substring in app['name']]


def list_application(mgr):

    url = '/api/2.0/services/application/scope/globalroot-0'
    rlist = {}
    r = mgr.get(url)
    if r.status_code != 200:
        print("Get all application service : GET request failed")
        r.raise_for_status()

    all_app = xmltodict.parse(r.text)
    if type(all_app['list']['application'])==list:
        for app in all_app['list']['application']:
           applicationProtocol = app['element']['applicationProtocol'] if 'element' in app else None
           rlist.update({app['objectId']:[app['name'],applicationProtocol]})
        return rlist
    else:
           rlist.update({all_app['list']['application']['objectId']:[all_app['list']['application']['name'],\
                        all_app['list']['application']['element']['applicationProtocol']]})
           return rlist

    return None



def delete_application_byname(mgr,name):

    objdict = find_application_bynamepattern(mgr,name)
    objList = objdict.viewkeys()
    if objList != None:
        for obj in objList:
            print('deleting application object:%s' %obj)
            url = '/api/2.0/services/application/%s' %obj
            r = mgr.delete(url)
            if not (200 <= r.status_code <= 204):
                print("HTTP return code for delete application is not 20x: %d and reason:%s" %(r.status_code,r.text))
                r.raise_for_status()
    return None

def delAppSlice(mgr, appSlice):
    for obj in appSlice:
        print('deleting application object:%s' %obj)
        url = '/api/2.0/services/application/%s' %obj
        r = mgr.delete(url)
        if not (200 <= r.status_code <= 204):
            mgr.logger.error("HTTP return code is not 20x: %d" %r.status_code)
            mgr.logger.error('url =' % url)
            mgr.responseError(r)

def delete_application_byname2(mgr,name):
    objdict = find_application_bynamepattern(mgr,name)
    objList = objdict.keys()
    l = {}
    nSlice = 4
    nApps = len(objList)
    nPerSlice = nApps/nSlice
    toaster = Toaster(nSlice, logging.WARNING)

    mgr.logger.info('Deleting application with prefix %s (%d total)' % (name, nApps))
    startTime = time.time()
    for i in xrange(0,nSlice):
        l[i] = objList[i*nPerSlice:(i+1)*nPerSlice+1]
        toaster.load('111', delAppSlice, kwargs={'mgr':mgr,'appSlice':l[i]})
    toaster.wait()
    timeDelta = time.time()-startTime
    mgr.logger.info('DELETED %d apps, %4.1f app/s' % (nApps, nApps/timeDelta))

    del toaster
    return None

def push_application(**kwargs):
   name = kwargs['kwargs']['app_name']
   mgr = kwargs['kwargs']['mgr']
   port = kwargs['kwargs']['port']
   protoL = kwargs['kwargs']['protoL']
   for proto in protoL:
        data = OD()
        data['application'] = OD({'name':name + '-'+ str(proto)})
        data['application'].update({'type':{'typeName':'Application'}})
        data['application']['element'] = {}
        data['application']['element'].update({'applicationProtocol':proto,'value':port})

        xml = xmltodict.unparse(data)
        print("xml dump:%s" %xml)

        url = '/api/2.0/services/application/globalroot-0'

        r = mgr.post(url,xml)
        if r.status_code != 201:
            print("create request for application service failed with return:%s %s" %(r.status_code,r.text))
            r.raise_for_status()

   return None


def config_application(mgr,yaml):

  for line in yaml['application']:
     name = line['name']
     protoL = line['protocol']
     startport = line['startValue']
     endport = line['maxValue']

     for port in range(startport,endport):
        app_name = name + str(port)
        kwargs = {'mgr':mgr,'app_name':app_name,'port':port,'protoL':protoL}
        push_application(kwargs = kwargs)
  return None





def find_applicationgroup_bynamepattern(mgr,name):


    url = '/api/2.0/services/applicationgroup/scope/globalroot-0'
    rlist = []
    r = mgr.get(url)
    if r.status_code != 200:
        print("Get all applicationgroup service : GET request failed")
        r.raise_for_status()

    all_app = xmltodict.parse(r.text)
    if type(all_app['list']['applicationGroup'])==list:
        for app in all_app['list']['applicationGroup']:
           if app['name'].find(name) != -1:
              rlist.append(app['objectId'])
        return rlist
    else:
        if all_app['list']['applicationGroup']['name'].find(name) != -1:
           rlist.append(all_app['list']['applicationGroup']['objectId'])
           return rlist

    return None

#def list_applicationgroup(mgr):
#
#    url = '/api/2.0/services/applicationgroup/scope/globalroot-0'
#    rlist = {}
#    r = mgr.get(url)
#    if r.status_code != 200:
#        print("Get all applicationgroup service : GET request failed")
#        r.raise_for_status()
#
#    all_app = xmltodict.parse(r.text)
#    if type(all_app['list']['applicationGroup'])==list:
#        for app in all_app['list']['applicationGroup']:
#           rlist.update({app['objectId']:app['name']})
#        return rlist
#    else:
#           rlist.update({all_app['list']['applicationGroup']['objectId']:all_app['list']['applicationGroup']['name']})
#           return rlist
#
#    return None



#def delete_applicationgroup_byname(mgr,name):
#
#    objList = find_applicationgroup_bynamepattern(mgr,name)
#
#    if objList != None:
#        for obj in objList:
#          print('deleting applicationgroup object:%s' %obj)
#          url = '/api/2.0/services/applicationgroup/%s' %obj
#          r = mgr.delete(url)
#          if not (200 <= r.status_code <= 204):
#            print("HTTP return code for delete applicationgroup is not 20x: %d and reason:%s" %(r.status_code,r.text))
#            r.raise_for_status()
#    return None


def get_applicationgroup_byid(mgr,id):

    url = '/api/2.0/services/applicationgroup/' + id

    r = mgr.get(url)
    if r.status_code != 200:
        print("Get application group : GET request failed")
        r.raise_for_status()
    dt_ag = xmltodict.parse(r.text)
    return dt_ag


def push_applicationgroup(**args):

  name = args['args']['name']
  appL = args['args']['appL']
  mgr = args['args']['mgr']

  data =OD()
  data['applicationGroup'] = OD({'name':name})
  data['applicationGroup'].update({'type':{'typeName':'ApplicationGroup'}})

  xml = xmltodict.unparse(data)
  print(xml)
  url = '/api/2.0/services/applicationgroup/globalroot-0'

  r = mgr.post(url,xml)
  if r.status_code != 201:
    print("create request for application group failed with return:%s %s" %(r.status_code,r.text))
    r.raise_for_status()
  ### get the posted data ###
  group_id = r.text
  app_list = list()
  for app in appL:
        app_list.append(app[0])
  for app in app_list:
        url = '/api/2.0/services/applicationgroup/' +group_id +"/members/"+app
        print(url)
        r = mgr.put(url,xml)
        if r.status_code != 200:
            print("update request for application group failed with return:%s %s" %(r.status_code,r.text))
            r.raise_for_status()
  return None

def config_applicationgroup(mgr,yaml):
  for line in yaml['applicationgroup']:
     name = line['nameGrp']
     appname = line['applicationName']
     total = line['total']
     entriespergrp = line['entriesPerGroup']
     protoL = line['protoPerGroup']

     tmpDict = {}
     objDict = find_application_bynamepattern(mgr, appname)
     for proto in protoL:
        for k,v in objDict.iteritems():
           if v[1] == proto:
              tmpDict.update({k:v})
     sortL = sorted(tmpDict.items(),key=lambda x:x[1][0])
     if len(sortL) < (total * entriespergrp * len(protoL)):
        print('Available application:%d is less than expected' %len(sortL))
        r.raise_for_status()
     '''Application group: chunks of as per entry * length of protocol list '''
     chunkL = chunks_list(sortL,(entriespergrp * len(protoL)))

     for i in range(total):
        args = {'mgr':mgr,'name':name+str(i),'appL':chunkL[i]}
        push_applicationgroup(args = args)
  return None

def find_securitytag_bynamepattern(mgr,name):


    url = '/api/2.0/services/securitytags/tag'
    rlist = []
    r = mgr.get(url)
    if r.status_code != 200:
        print("Get all securitytags : GET request failed")
        r.raise_for_status()

    all_sgtag = xmltodict.parse(r.text)
    if type(all_sgtag['securityTags']['securityTag'])==list:
        for sgtag in all_sgtag['securityTags']['securityTag']:
           if sgtag['name'].find(name) != -1:
              rlist.append(sgtag['objectId'])
        return rlist
    else:
        if all_sgtag['securityTags']['securityTag']['name'].find(name) != -1:
           rlist.append(all_sgtag['securityTags']['securityTag']['objectId'])
           return rlist

    return None

#def list_securitytag(mgr):
#
#    url = '/api/2.0/services/securitytags/tag'
#    rlist = {}
#    r = mgr.get(url)
#    if r.status_code != 200:
#        print("Get all securitytags : GET request failed")
#        r.raise_for_status()
#
#    all_sgtag = xmltodict.parse(r.text)
#    if type(all_sgtag['securityTags']['securityTag'])==list:
#        for sgtag in all_sgtag['securityTags']['securityTag']:
#           rlist.update({sgtag['objectId']:sgtag['name']})
#        return rlist
#    else:
#           rlist.update({all_sgtag['securityTags']['securityTag']['objectId']:all_sgtag['securityTags']['securityTag']['name']})
#           return rlist
#
#    return None



#def delete_securitytag_byname(mgr,name):
#
#    objList = find_securitytag_bynamepattern(mgr,name)
#
#    if objList != None:
#        for obj in objList:
#          print('deleting securitytags/tag object:%s' %obj)
#          url = '/api/2.0/services/securitytags/tag/%s' %obj
#          r = mgr.delete(url)
#          if not (200 <= r.status_code <= 204):
#            print("HTTP return code for delete securitytag is not 20x: %d and reason:%s" %(r.status_code,r.text))
#            r.raise_for_status()
#    return None



def push_securitytag(**args):

   name = args['args']['name']
   mgr = args['args']['mgr']

   data = OD()
   data['securityTag'] = OD({'objectTypeName':'SecurityTag'})
   data['securityTag'].update({'type':{'typeName':'SecurityTag'}})
   data['securityTag'].update({'name':name})

   xml = xmltodict.unparse(data)
   print("xml dump:%s" %xml)

   url = '/api/2.0/services/securitytags/tag'

   r = mgr.post(url,xml)
   if r.status_code != 201:
        print("create request for security tag failed with return:%s %s" %(r.status_code,r.text))
        r.raise_for_status()
   print('created security tag: %s' %r.text)
   return r.text

def config_securitytag(mgr,yaml,**args):

   for item in yaml['securityTag']:
        name = item['name']
        total = item['total']
        clusterL = item['vmCluster']
        vmPerTag = item['vmPerTag']
        vmName = item['vmName']

        vcenter = args['args']['vcenter']
        vuser = args['args']['vuser']
        vpasswd = args['args']['vpasswd']
        kwargs = {'vcenter':vcenter,'vuser':vuser,'vpasswd':vpasswd }
        inv = nsxv.connect_to_vcenter_kwargs(kwargs=kwargs)

        vmList = vs.find_vm_by_clusterlist(inv[1],clusterL,vmName)
        shuffle(vmList)

        if len(vmList) < (total * vmPerTag):
           vmList = expand_list(vmList,(total*vmPerTag))
           #raise ValueError('total VM :%d is less than expected' %len(vmList))
        chunkvmL = chunks_list(vmList,vmPerTag)
        print('chunkvml:%d lenVmL:%d' %(len(chunkvmL),len(vmList)))
        for i in range(total):
           nameC = name + str(i)
           args = {'mgr':mgr,'name':nameC}
           obj = push_securitytag(args=args)
           if obj != None:
              xml = ''
              for vm in chunkvmL[i]:
                 url = '/api/2.0/services/securitytags/tag/' + obj + '/vm/' + vm
                 print('url:%s' %url)
                 r = mgr.put(url,xml)
                 if r.status_code != 200:
                    print("update request for tagging vm to security tag failed with return:%s %s" %(r.status_code,r.text))
                    r.raise_for_status()
   return None


def find_excludevm_bynamepattern(mgr,name):

    url = '/api/2.1/app/excludelist'
    rlist = []
    r = mgr.get(url)
    if r.status_code != 200:
        print("Get all excludevms : GET request failed")
        r.raise_for_status()

    all_sgtag = xmltodict.parse(r.text)
    if type(all_sgtag['VshieldAppConfiguration']['excludeListConfiguration']['excludeMember'])==list:
        for sgtag in all_sgtag['VshieldAppConfiguration']['excludeListConfiguration']['excludeMember']:
           if sgtag['member']['name'].find(name) != -1:
              rlist.append(sgtag['member']['objectId'])
        return rlist
    else:
        if all_sgtag['VshieldAppConfiguration']['excludeListConfiguration']['excludeMember']['member']['name'].find(name) != -1:
           rlist.append(all_sgtag['VshieldAppConfiguration']['excludeListConfiguration']['excludeMember']['member']['objectId'])
           return rlist

    return None

def list_excludevm(mgr):

    url = '/api/2.1/app/excludelist'
    rlist = {}
    r = mgr.get(url)
    if r.status_code != 200:
        print("Get all excludevms : GET request failed")
        r.raise_for_status()

    xmlDict = xmltodict.parse(r.text)
    print(yaml.safe_dump(json.loads(json.dumps(xmlDict))))

    excMember = xmlDict['VshieldAppConfiguration']['excludeListConfiguration'].get('excludeMember', None)
    members = [(m['name'], m['objectId'], m['scope']['objectTypeName'], m['scope']['name'])
        for m in listify(excMember['member'])] if excMember else []
    return members

def find_vm_bynamepattern(mgr,data,args):
    rlist = []
    vmName = data['yaml']['securitygroup'][0]['prefix_typeName']
    clusterL = data['yaml']['securitygroup'][0]['vmCluster']
    vcenter = args['args']['args']['vcenter']
    vuser = args['args']['args']['vuser']
    vpasswd = args['args']['args']['vpasswd']
    kwargs = {'vcenter':vcenter,'vuser':vuser,'vpasswd':vpasswd }
    inv = nsxv.connect_to_vcenter_kwargs(kwargs=kwargs)

    rlist = vs.find_vm_by_clusterlist(inv[1],clusterL,vmName)
    shuffle(rlist)

    return rlist



def delete_excludevm_byname(mgr,name):

    objList = find_excludevm_bynamepattern(mgr,name)

    if objList != None:
        for obj in objList:
          print('deleting excludevm object:%s' %obj)
          url = '/api/2.1/app/excludelist/%s' %obj
          r = mgr.delete(url)
          if not (200 <= r.status_code <= 204):
            print("HTTP return code for delete excludevm is not 20x: %d and reason:%s" %(r.status_code,r.text))
            r.raise_for_status()


def config_excludevm(mgr,yaml,**args):

   for item in yaml['excludeVM']:
        total = item['total']
        clusterL = item['vmCluster']
        vmName = item['vmName']

        vcenter = args['args']['vcenter']
        vuser = args['args']['vuser']
        vpasswd = args['args']['vpasswd']
        kwargs = {'vcenter':vcenter,'vuser':vuser,'vpasswd':vpasswd }
        inv = nsxv.connect_to_vcenter_kwargs(kwargs=kwargs)

        vmList = vs.find_vm_by_clusterlist(inv[1],clusterL,vmName)
        shuffle(vmList)

        if len(vmList) < total :
           raise ValueError('total VM %d requested is less than available %d' %(len(vmList),total))
        for i in range(total):
                 url = '/api/2.1/app/excludelist/' + vmList[i]
                 print('url:%s' %url)
                 r = mgr.put(url)
                 if r.status_code != 200:
                    print("update request for excluding vm failed with return:%s %s" %(r.status_code,r.text))
                    r.raise_for_status()
   return None


def setDictValueByKeyPath(d, kList, val):
    var = d
    kHead, kLast = kList[:-1], kList[-1]
    for k in kHead:
        var = var[k]
    var[kLast] = val

def getDictValueByKeyPath(d, kList):
    var = d
    kHead, kLast = kList[:-1], kList[-1]
    for k in kHead:
        var = var[k]
    return var[kLast]


def format_find_result(obj, results):
    '''
    type return by the function depends on the input content of "results":
    results     return
    -------     -------
    None        dict
    list        list
    str         value of key 'str'
    '''
    resultList = []
    if not results:
        # no results specified, return everything
        return obj
    elif isinstance(results, str):
        return obj[results]
    elif isinstance(results, list):
        for rkey in results:
            for (key,val) in obj.items():
                if key == rkey:
                    if sys.version_info.major==2 and isinstance(val,unicode):
                        val = str(val)
                    resultList.append(val)
                    break
            else:
                resultList.append(None)
        return resultList
    return None, None

def get_inner_list(rObjs, rKeys):
    ''' rObjs is a dict converted from xml retruned by NSX-V manager REST API
    this function peels off laysers of keys provided in the key list "rKeys"
    if the resulting value is a list, return the value as is
    else create a singleton list with the resulting value and return the list
    '''
    for k in rKeys:
        if not k in rObjs:
            return  []
        if not rObjs[k]:
            return  []
        rObjs = rObjs[k]

    if not isinstance(rObjs,list):
        return [rObjs]
    return rObjs

def getYamlObjName(data, path):
    objName = data
    for k in path:
        objName = objName[k]
    return objName

def readYmlFile(ymlFile, logger):
    ''' returns (objects, begin, end) '''
    begin = ''
    end = ''
    objects = []
    ymlPath = os.path.dirname(os.path.abspath(ymlFile))
    if not (os.path.isfile(ymlFile) and os.access(ymlFile, os.R_OK)):
        logger.error('Yaml file "%s" is missing or is not readable' % ymlFile)
        exit(1)

    yml = cptutil.commandsGetoutput('m4 -I %s %s' % (ymlPath, ymlFile))

    yamlDict = yaml.load(yml)
    objects, begin, end = yaml_to_xml(yml = yamlDict, top = True)
    return (objects, begin, end)

def clusterNameToMo(name, vc):
    return vc.getByName(vim.ClusterComputeResource, name)

def clusterNameToMoid(name, vc):
    #return vslib.shortMoid(vc.getByName(vim.ClusterComputeResource, name))
    return vslib.shortMoid(clusterNameToMo(name, vc))

def clusterNameGlobToMoids(nameGlob, vc, shortMoid=True):
    moids = vc.getByNamesGlob(vim.ClusterComputeResource, nameGlob)
    return [vslib.shortMoid(moid) for moid in moids] if shortMoid else moids

def hostNameGlobToMoids(nameGlob, vc, shortMoid=True):
    moids = vc.getByNamesGlob(vim.HostSystem, nameGlob)
    return [vslib.shortMoid(moid) for moid in moids] if shortMoid else moids

def hostNameToMoid(name, vc):
    return vslib.shortMoid(vc.getByName(vim.HostSystem, name))

def checkIsUniversal(d):
    ''' check if data struture contain a dictiionary key 'isUniversal' or 'isUniversal_HIDDEN'
        AND its value is True
    '''
    if isinstance(d, dict):
        if d.get('isUniversal') == 'true' or \
                d.get('HINT_isUniversal') == 'true' or \
                d.get('HINT_isUniversal_HIDDEN') == 'true':
            return True
        for v in d.values():
            if checkIsUniversal(v):
                return True
    elif isinstance(d, list):
        for e in d:
            if checkIsUniversal(e):
                return True
    return False

def unpackSpec(spec, separator, fieldNames, logger):
    ''' unpackColonSeparatedSpec '''
    return unpackCSSpec(spec, separator, fieldNames, logger)

def unpackCSSpec(spec, separator, fieldNames, logger):
    ''' unpackColonSeparatedSpec '''
    nFields = len(fieldNames)
    comps = spec.strip().split(':')
    logger.info3(zip(fieldNames,comps))
    if len(comps)!=nFields:
        logger.error('%d colon separated fields expected: %s' % (nFields, ', '.join(fieldNames)))
        logger.error('%d filelds provied' % len(comps))
        logger.error('\n\t'.join(['%s=%s'%item for item in (itertools.izip_longest(fieldNames,comps))]))
        return []
    return [e.strip() for e in spec.split(separator)]

def unpackCSSpec2(spec, separator, fieldNames, logger):
    ''' unpackColonSeparatedSpec, allow show specification '''
    nFields = len(fieldNames)
    comps = spec.strip().split(':')
    logger.info3(zip(fieldNames,comps))
    if len(comps)!=nFields:
        logger.info2('%d colon separated fields expected: %s' % (nFields, ', '.join(fieldNames)))
        logger.info2('%d filelds provied' % len(comps))
        logger.info2('\n\t'.join(['%s=%s'%item for item in (itertools.izip_longest(fieldNames,comps))]))
    comps = [e.strip() for e in spec.split(separator)] + ['']*(len(fieldNames)-len(comps))
    #print( len(fieldNames), len(comps))
    #print( comps )
    return comps

def swapXmlTag(self, data, tagSwapList=[], certScopeId=''):
    ''' look into "data" for HINT_XXX_yyy tag, replace the tag with yyy and the value
        with the mapped (internal) representation of XXX
    '''

    def _swapXmlTag(self, data, objType, targetName, xmlHintTag, xmlNewTag, obj, attr):
        if not obj:
            raise ValueError('Cannot find %s id for %s name: %s' % (
                objType, objType, targetName))
        objId = getattr(obj, attr) if attr else obj
        self.logger.info('mapping %s(%s) -> %s(%s)' %
            (objType, targetName, xmlNewTag, objId))
        data[xmlNewTag] = str(objId)
        data.pop(xmlHintTag, None)

    def _swapXmlTag_vc(self, data, objType, targetName, xmlHintTag, xmlNewTag, vimType):

        targetMo = vs.getObjectFromVcenterInventory(
            self.mgr.vcInv, [vimType],
            name = targetName)

        if not targetMo:
            raise ValueError('Cannot find %s id for %s name: %s' % (
                objType, objType, targetName))
        objId = targetMo._moId
        self.logger.info('mapping %s(%s) -> %s(%s)' %
            (objType, targetName, xmlNewTag, objId))
        data[xmlNewTag] = str(objId)
        data.pop(xmlHintTag, None)

    #print('DATA:'); pprint(data)
    dCopy = copy.deepcopy(data)
    for t0,t1 in tagSwapList:
        # create new tag 'HINT_<newType>_<newXmlTag>:<oldTag>'
        # remove old tag 'HINT_<oldTag>'
        #dCopy[t1] = dCopy[t0]
        orgTag = t0.strip('HINT_')
        dCopy['%s:%s' % (t1, orgTag)] = dCopy[t0]
        del dCopy[t0]

    unmappedTags = []
    if isinstance(dCopy, dict):
        for k in dCopy:
            #print('XXXXXXX', k)
            if isinstance(dCopy[k], dict):
                swapXmlTag(self, data[k])
            elif k.startswith('HINT_'):
                #objType, xmlTag = k.split('_')[-2:]
                #print('==>%s\t%s\t%s\t%s' % (k, objType, xmlTag, dCopy[k]))

                xmlTag = ''
                tags = k.split('_')[1:]
                objType = tags[0]
                orgOldFmtTag = None
                if len(tags)>1:
                    xmlTag = '_'.join(tags[1:])
                    if ':' in  xmlTag:
                        xmlTag, orgOldFmtTag = xmlTag.split(':')
                elif objType.upper().endswith('NAME'):
                        xmlTag = objType.replace('Name', 'Id')
                        xmlTag.replace('Name', 'Id')
                        objType = objType.replace('Name', '')
                #else:
                #    xmlTag = {'DATASTORE':'datastoreId'}[objType]

                objType = objType.upper()
                targetName = dCopy[k]
                #print('k=%-30sobjType=%-14sxmlTag=%-10s' % (k, objType, xmlTag))

                if objType == 'DATACENTER':
                    self.logger.info('mapping %s(%s) to %s' % (objType, targetName, xmlTag))
                    _swapXmlTag_vc(self, data, objType, targetName, k, xmlTag, vim.Datacenter)
                elif objType == 'CLUSTER':
                    self.logger.info('mapping %s(%s) to %s' % (objType, targetName, xmlTag))
                    _swapXmlTag_vc(self, data, objType, targetName, k, xmlTag, vim.ClusterComputeResource)
                elif objType == 'DATASTORE':
                    self.logger.info('mapping %s(%s) to %s' % (objType, targetName, xmlTag))
                    _swapXmlTag_vc(self, data, objType, targetName, k, xmlTag, vim.Datastore)
                elif objType == 'HOST':
                    self.logger.info('mapping %s(%s) to %s' % (objType, targetName, xmlTag))
                    _swapXmlTag_vc(self, data, objType, targetName, k, xmlTag, vim.HostSystem)
                elif objType == 'RESOURCEPOOL':
                    self.logger.info('mapping %s(%s) to %s' % (objType, targetName, xmlTag))
                    _swapXmlTag_vc(self, data, objType, targetName, k, xmlTag, vim.ClusterComputeResource)
                elif objType == 'FOLDER':
                    self.logger.info('mapping %s(%s) to %s' % (objType, targetName, xmlTag))
                    _swapXmlTag_vc(self, data, objType, targetName, k, xmlTag, vim.Folder)
                elif objType == 'DVS':
                    self.logger.info('mapping %s(%s) to %s' % (objType, targetName, xmlTag))
                    _swapXmlTag_vc(self, data, objType, targetName, k, xmlTag, vim.DistributedVirtualSwitch)
                elif objType == 'DVPG':
                    self.logger.info('mapping %s(%s) to %s' % (objType, targetName, xmlTag))
                elif objType == 'NETWORK':
                    self.logger.info('mapping %s(%s) to %s' % (objType, targetName, xmlTag))
                    pg = nsxv.find_portgroup_or_logical_switch_by_name(self.mgr,
                        data = data,
                        args = self.mgr.vcInfo, inv = self.mgr.vcInv,
                        name = targetName,
                        )
                        #tz = yml['HINT_transportzone'] if 'HINT_transportzone' in yml else None)
                    _swapXmlTag(self, data, objType, targetName, k, xmlTag, pg, None)
                elif objType == 'IPPOOL':
                    self.logger.info('mapping %s(%s) to %s' % (objType, targetName, xmlTag))
                    ippId = nsxvlib.Ippool(self.mgr).find_by_name(targetName)
                    _swapXmlTag(self, data, objType, targetName, k, xmlTag, ippId, None)
                elif objType == 'TRANSPORTZONE':
                    self.logger.info('mapping %s(%s) to %s' % (objType, targetName, xmlTag))
                    tzId = nsxvlib.Transport_zone(self.mgr).find_by_name(targetName)
                    _swapXmlTag(self, data, objType, targetName, k, xmlTag, tzId, None)
                elif objType == 'GROUPINGOBJECT':
                    self.logger.info('mapping %s(%s) to %s' % (objType, targetName, xmlTag))
                    grpObj = self._procGrpObjs(targetName)
                    grpObjId = grpObj[0]['value']
                    #print('>>>>>>>>>> %s' %grpObj )
                    #print('>>>>>>>>>> %s' %grpObj[0]['value'] )
                    _swapXmlTag(self, data, objType, targetName, k, xmlTag, grpObjId, None)
                elif objType == 'CERT':
                    comps = targetName.split('|')
                    targetCertFile = comps[0]
                    targetCertPrivKey = comps[1] if len(comps)>1 else None
                    with open(targetCertFile) as f:
                        certPem = f.read()
                    cert = OpenSSL.crypto.load_certificate(OpenSSL.crypto.FILETYPE_PEM, certPem)
                    targetCertCN = cert.get_subject().commonName
                    targetCertFP = cert.digest("sha1")

                    self.logger.info('mapping %s(%s) to %s for scope %s' % (objType, targetCertCN, xmlTag, certScopeId))
                    certd = nsxvlib.Certificate(self.mgr)
                    certd.find(objectId=certScopeId, refresh=True)

                    foundMatchedCert = False
                    esgCerts = certd.find_by_name(targetCertCN, results=['objectId', 'name', 'pemEncoding'], matchMethod='glob') \
                        if certd.cachedObjs else []

                    for esgCert in esgCerts:
                        esgCertId, esgCertCN, esgCertPem = esgCert
                        cert = OpenSSL.crypto.load_certificate(OpenSSL.crypto.FILETYPE_PEM, certPem)
                        esgCertFP = cert.digest("sha1")
                        if foundMatchedCert:
                            self.logger.warning('Multiple certificates with the same CN and fingerprint found: %s %s'
                                % (esgCertCN, esgCertFP))
                        foundMatchedCert = (esgCertFP == targetCertFP)

                    if not foundMatchedCert:
                        self.logger.warning('%s does not exist in %s, uploading %s' % (targetCertCN, certScopeId, targetCertFile))
                        esgCertId = certd.create('', cptutil.expandArgFile('@%s'%targetCertFile),
                            cptutil.expandArgFile('@%s'%targetCertPrivKey) if targetCertPrivKey else None,
                            scopeId=certScopeId)

                    #print('==> %s %s' % (targetCertCN, esgCertId))
                    _swapXmlTag(self, data, objType, targetName, k, xmlTag, esgCertId, None)

                else:
                    unmappedTags.append(k)
                if orgOldFmtTag:
                    data.pop('HINT_%s' % orgOldFmtTag)
            else:
                # key is not a 'HINT_'
                #print('DICT key -->', k)
                #swapXmlTag(self, data[k])
                pass
    elif isinstance(data, list):
        for k in data:
            swapXmlTag(self, k)

    del dCopy
    return unmappedTags

