#!/usr/bin/python
import xmltodict
from collections import OrderedDict as OD
from pyVmomi import vim
import vslib

def mkSgCreateParser(sg_subparsers):
    #sgCreate_subparsers = parser.add_subparsers(dest='ns1')
    sgCreate_parser = sg_subparsers.add_parser('create0')

    sgCreate_parser.add_argument('--sgName', required=True)

    ns1_subparsers = sgCreate_parser.add_subparsers(dest='ns2')
    ns1_dyn_parser = ns1_subparsers.add_parser('dyn')
    ns1_dyn_parser.add_argument('op')
    ns1_dyn_parser.add_argument('dynCrits', nargs='+')
    ns1_mem_parser = ns1_subparsers.add_parser('member')
    ns1_mem_parser.add_argument('memCrit')
    ns1_exc_parser = ns1_subparsers.add_parser('excludeMember')
    ns1_exc_parser.add_argument('memCrit')
    ns1_emt_parser = ns1_subparsers.add_parser('empty')

    return sgCreate_parser

def mapVcObjNameToMoid(mgr, vimType, name):
    targetMo = mgr.vslibVc.getByName(vimType, name)

    shortVimTypeName = vslib.classTypeToShortVimTypeName(vimType)
    if targetMo:
        objId = targetMo._moId
        #mgr.logger.info('mapping %s(%s) -> %s' %
        #    (shortVimTypeName, name, objId))

        return str(objId)
    else:
        mgr.logger.error('Cannot find %s id for %s name: %s' % (
            shortVimTypeName, shortVimTypeName, name))
        return None

def mapNsxvObjNameToId(mgr, objType, name):
    ''' objType: securitytag, vm
    '''
    objectId = None
    if objType.lower() == 'securitytag':
        std = nsxvlib.Security_tag(mgr)
        objectId = std.find_by_name(name)
    elif objType.lower() == 'cluster':
        objectId = mapVcObjNameToMoid(mgr, vim.ClusterComputeResource, name)
    elif objType.lower() == 'network':
        objectId = mapVcObjNameToMoid(mgr, vim.Network, name)
    elif objType.lower() == 'virtualwire':
        lsd = nsxvlib.Logical_switch(mgr)
        objectId = lsd.find_by_name(name)
    elif objType.lower() == 'ipset':
        ipsetd = nsxvlib.Ipset(mgr)
        objectId = ipsetd.find_by_name(name)

    if not objectId:
        mgr.logger.error('Cannot find %s name %s' % (objType, name))
    return objectId

def fmtSgXml(mgr, dic, d2=None, pretty=False):
    ''' convert a security group specification in dic to an XML string
        suitable for SG creation API
        dic holds member/excludedMember/dynamicMember criteria
        d2 holds OD for XML converstion, create if necessary
        d2 updated base on info from dic
        convert d2 to xml
        calls mapNsxvObjNameToId() to do mapping
    '''
    if not d2:
        d2 = {'securitygroup':dic}
        d2['securitygroup'] = OD()
        d2['securitygroup']['name'] = dic['sgName']

    memberType = dic['ns2']
    if memberType in ['member', 'excludeMember' ]:
        memberTag = dic['ns2']
        if memberTag not in d2['securitygroup']:
            d2['securitygroup'][memberTag] = []
        mType, mName = dic['memCrit'].split(':') 
        mgr.logger.info('mapping %s %s(%s) to objectId' %
            (dic['ns2'], mType, mName))
        mObjId = mapNsxvObjNameToId(mgr, mType, mName)
        mgr.logger.info('mapped  %s %s(%s) to %s' %
            (dic['ns2'], mType, mName, mObjId))
        memDict = OD()
        memDict['objectTypeName'] = mType
        memDict['objectId'] = mObjId
        d2['securitygroup'][memberTag].append(memDict)
    elif memberType == 'dyn':
        d2['securitygroup']['dynamicMemberDefinition'] = OD()
        d2['securitygroup']['dynamicMemberDefinition']['dynamicSet'] = OD()
        d2['securitygroup']['dynamicMemberDefinition']['dynamicSet']['operator'] = dic['op']
        d2['securitygroup']['dynamicMemberDefinition']['dynamicSet']['dynamicCriteria'] = []
        for crit in dic['dynCrits']:
            cOp,cKey,cCrit,cVal = crit.split(':')
            critDic = {'operator': cOp,
                'key': cKey,        # VM.SECURITY_TAG, VM.NAME, VM.GUEST_OS_FULL_NAME, VM.GUEST_HOST_NAME, ENTITY
                'criteria': cCrit,  # =, !=, contains, 'does not contain', 'starts with', 'ends with', 'similar_to', 'belongs to' ('security group', 'cluster', 'logical switch', 'legacy port group', 'vApp', 'Datacenter')
                'value': cVal,
                'isValid': 'true'
            }
            d2['securitygroup']['dynamicMemberDefinition']['dynamicSet']['dynamicCriteria'].append(critDic)
    elif memberType == 'empty':
        pass

    xml = xmltodict.unparse(d2, pretty=pretty)
    return xml, d2


def doSgCreate(mgr, args, extra, sgCreateParser, pretty=False):
    od = None
    if extra:
        rest = extra
        #print '#### EXTRA  args: ', args
        #print '#### EXTRA  rest: ', rest
        argsNs = vars(args); #argsNs['name']='test1'
        xml, od = fmtSgXml(mgr, argsNs, od, pretty=pretty)
        while rest:
            args,rest =  sgCreateParser.parse_known_args(rest,namespace=args)
            #print ('---')
            #print 'args: ', args
            #print 'rest: ', rest
            #print args
            argsNs = vars(args); #argsNs['name']='test1'
            xml, od = fmtSgXml(mgr, argsNs, od, pretty=pretty)
    else:
        argsNs = vars(args); #argsNs['name']='test1'
        xml, od = fmtSgXml(mgr, argsNs, od, pretty=pretty)

    #print("""nmc1 api post /api/2.0/services/securitygroup/bulk/globalroot-0 '%s'""" % xml)
    #print('nmc1 securitygroup delete test1')
    #print('')

import nsxvlib

'''
./nsxv-ctl.py nsxmgr1 securitygroup  show test

sucurity policy

 ./nsxv-ctl.py nsxmgr1 securitypolicy show testpolicy

./nsxv-ctl.py nsxmgr1 securitytag  list


- Security tag
    nsxv-ctl.py nsxmgr1 securitytag create test-simon
    nsxv-ctl.py nsxmgr1 securitytag delete test-simon
- Assign security tag to VM by VM name
    nsxv-ctl.py nsxmgr1 securitytag apply testtag -T cluster MGMT
    nsxv-ctl.py nsxmgr1 securitytag apply testtag -T vm DLR1-1
    nsxv-ctl.py nsxmgr1 securitytag apply securitytag-12 -T vm DLR1-1
- Create Security group with membership based on security tag.  
    - by name string matching (dynamic in xml)
        nsxv-ctl.py nsxmgr1 securitygroup create --sgName test1 dyn OR AND,VM.SECURITY_TAG,=,xyz AND,VM.SECURITY_TAG,contains,xyz
    - by object (member in XML)
- Create Security policy, by name, to include FW in YAML
- Apply security Poiicy to SG
'''



'''
vsc3b vm list
- Security tag
    nsxv-ctl.py nsxmgr3b securitytag list --brief
    nsxv-ctl.py nsxmgr3b securitytag create testtag
    for i in {100..120}; do echo testtag-$i; done | xargs nsxv-ctl.py nsxmgr3b securitytag create
    for i in {100..120}; do echo testtag-$i; done | xargs nsxv-ctl.py nsxmgr3b securitytag delete
    nsxv-ctl.py nsxmgr3b securitytag delete testtag-11?
- Assign security tag to VM by VM name
    nsxv-ctl.py nsxmgr3b securitytag apply testtag -T vm vm-Web254U-0143 vm-Private1-0142
    nsxv-ctl.py nsxmgr3b securitytag apply testtag -T cluster cluster4
    nsxv-ctl.py nsxmgr3b securitytag listVMs testtag --brief
    nsxv-ctl.py nsxmgr3b securitytag detach testtag -T vm vm-Web254U-0143
- Create Security group with membership based on security tag.  
    nsxv-ctl.py nsxmgr1 securitygroup create --sgName test1 \
        member          SecurityTag:testtag \
        member          cluster:Cluster01 \
        excludeMember   'Network:VM Network' \
        excludeMember   cluster:Cluster01 \
        member          VirtualWire:LS0001 \
        member          SecurityTag:VULNERABILITY_MGMT.VulnerabilityFound.threat=high \
        member          ipset:mgmt \
        dyn OR \
            AND:VM.SECURITY_TAG:contains:xyz \
            AND:VM.SECURITY_TAG:contains:def \
            AND:VM.SECURITY_TAG:contains:adasdf \
            AND:VM.SECURITY_TAG:contains:abc \
            AND:ENTITY:belongs_to:securitygroup-1 \
            AND:ENTITY:belongs_to:domain-c48
    nsxv-ctl.py nsxmgr3b securitygroup list --brief
    nsxv-ctl.py nsxmgr3b securitygroup show test1
    nsxv-ctl.py nsxmgr3b securitygroup show test1 --br
    nsxv-ctl.py nsxmgr3b securitygroup delete test1
    for i in {100..119}; do nsxv-ctl.py nsxmgr3b securitygroup create --sgName testSg-$i member SecurityTag:testtag; done
    for i in {110..112}; do nsxv-ctl.py nsxmgr3b securitygroup create --sgName testSg-$i member SecurityTag:testtag; done
    nsxv-ctl.py nsxmgr3b securitygroup show testSg-100 --br
    nsxv-ctl.py nsxmgr3b securitygroup delete testSg-11[12]
- Create Security policy, by name, to include FW in YAML
    nsxv-ctl.py nsxmgr1 securitypolicy list --br
    nsxv-ctl.py nsxmgr1 securitypolicy show testpolicy --br
- Apply security Poiicy to SG
    nsxv-ctl.py nsxmgr1 securitypolicy apply testpolicy test test1
    nsxv-ctl.py nsxmgr1 securitypolicy create testpolicy4 104 \
        --secGrps test,test1 \
        --fwAppSpecs ':intra:allow::ICMP Echo,ICMP Echo Reply;   :outbound:allow:test1:HTTP,HTTPS;   :inbound:block:test,test1:HTTP,HTTPS' \
        --fwAppGrpSpecs ':intra:allow:Microsoft Exchange 2010;   :outbound:block:vCenter5.x,Oracle Database'
    for i in {100..110}; do nsxv-ctl.py nsxmgr3b securitypolicy create testSp-$i 1$i; done

    nsxv-ctl.py nsxmgr1 securitypolicy delete testpolicy4
    nsxv-ctl.py nsxmgr1 securitypolicy show testpolicy4 --br
    nsxv-ctl.py nsxmgr1 securitypolicy show testpolicy5 --br
    nsxv-ctl.py nsxmgr1 application list --br
    nsxv-ctl.py nsxmgr1 applicationgroup list --br
    nsxv-ctl.py nsxmgr1 applicationgroup list | grep -B 10 -A 30 'Microsoft Exchange 2010'

'''

