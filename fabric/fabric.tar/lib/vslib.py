#re!/usr/bin/env python
#from __future__ import print_function
import pinit
import sys
import time
import argparse
import atexit
import string
import textwrap
import hashlib
import ssl
import restlib
from pprint import pformat, pprint
import collections
import pyVmomi
from pyVmomi import vim
from pyVim import connect
from tools import tasks
import operator
import tasklib      ;# monkey patching task.wait()
from nsxvlib import *
import  cptutil
from cptutil import isGlobMatched, textWrapCol
from toasterlib2 import Toaster
from soaplib import Soap
import prettytable
from prettytable import PrettyTable
import inspect
from xml.etree.ElementTree import Element, SubElement, tostring
import paramiko

################################################################################
def _create_char_spinner():
    """Creates a generator yielding a char based spinner.
    """
    while True:
        for c in '|/-\\':
            yield c

_spinner = _create_char_spinner()

def spinner(label=''):
    """Prints label with a spinner.
    When called repeatedly from inside a loop this prints
    a one line CLI spinner.
    """
    sys.stdout.write("\r\t%s %s" % (label, _spinner.next()))
    sys.stdout.flush()
################################################################################

##################################
## function adopted from ansible #
##################################
def create_vmkernel_adapter(host_system, port_group_name,
                            vlan_id, vswitch_name,
                            ip_address, subnet_mask,
                            mtu, enable_vsan, enable_vmotion, enable_mgmt, enable_ft):

    host_config_manager = host_system.configManager
    host_network_system = host_config_manager.networkSystem
    host_virtual_vic_manager = host_config_manager.virtualNicManager
    config = vim.host.NetworkConfig()

    config.portgroup = [vim.host.PortGroup.Config()]
    config.portgroup[0].changeOperation = "add"
    config.portgroup[0].spec = vim.host.PortGroup.Specification()
    config.portgroup[0].spec.name = port_group_name
    config.portgroup[0].spec.vlanId = vlan_id
    config.portgroup[0].spec.vswitchName = vswitch_name
    config.portgroup[0].spec.policy = vim.host.NetworkPolicy()

    config.vnic = [vim.host.VirtualNic.Config()]
    config.vnic[0].changeOperation = "add"
    config.vnic[0].portgroup = port_group_name
    config.vnic[0].spec = vim.host.VirtualNic.Specification()
    config.vnic[0].spec.ip = vim.host.IpConfig()
    config.vnic[0].spec.ip.dhcp = False
    config.vnic[0].spec.ip.ipAddress = ip_address
    config.vnic[0].spec.ip.subnetMask = subnet_mask
    if mtu:
        config.vnic[0].spec.mtu = mtu

    host_network_config_result = host_network_system.UpdateNetworkConfig(config, "modify")

    for vnic_device in host_network_config_result.vnicDevice:
        if enable_vsan:
            vsan_system = host_config_manager.vsanSystem
            vsan_config = vim.vsan.host.ConfigInfo()
            vsan_config.networkInfo = vim.vsan.host.ConfigInfo.NetworkInfo()

            vsan_config.networkInfo.port = [vim.vsan.host.ConfigInfo.NetworkInfo.PortConfig()]

            vsan_config.networkInfo.port[0].device = vnic_device
            host_vsan_config_result = vsan_system.UpdateVsan_Task(vsan_config)

        if enable_vmotion:
            host_virtual_vic_manager.SelectVnicForNicType("vmotion", vnic_device)

        if enable_mgmt:
            host_virtual_vic_manager.SelectVnicForNicType("management", vnic_device)

        if enable_ft:
            host_virtual_vic_manager.SelectVnicForNicType("faultToleranceLogging", vnic_device)
    return True


def find_vswitch_by_name(host, vswitch_name):
    ''' give hostMo, find vss by name '''
    for vss in host.config.network.vswitch:
        if vss.name == vswitch_name:
            return vss
    return None

def moveVmnic0(vss, host):
    '''
    config = vim.host.NetworkConfig()
    print(config.vswitch)
    vswitch = vim.host.VirtualSwitch.Config()
    vswitch.name = 'vSwitch0'

    config.vswitch.append(vswitch)
    config.vswitch.spec = vim.host.VirtualSwitch.Config()
    config.vswitch.spec.bridge = vim.host.VirtualSwitch.Bridge(nicDevice=['vmnic1'])
    #config.vswitch.spec.bridge = vim.host.VirtualSwitch.BondBridge(nicDevice=['vmnic1'])


    print(vss)
    #pnicConfig.device = 'key-vim.host.PhysicalNic-vmnic0'
    '''

    print(vss)
    vsSpec = vim.host.VirtualSwitch.Specification()
    vsSpec.numPorts = vss.numPorts
    #vsBridge = vim.host.VirtualSwitch.Bridge()
    vsBridge = vss.spec.bridge
    vsBridge.nicDevice = ['vmnic3']
    vsSpec.bridge = vsBridge
    print('vss: %s' % vss.name)
    host.configManager.networkSystem.UpdateVirtualSwitch(vss.name, vsSpec)
    print('DONE configurating vss')
    exit()


def modify_dvs_host(dv_switch, host, operation, uplink_portgroup=None, vmnics=None, logger=None):

    spec = vim.DistributedVirtualSwitch.ConfigSpec()
    spec.configVersion = dv_switch.config.configVersion
    spec.host = [vim.dvs.HostMember.ConfigSpec()]
    spec.host[0].operation = operation
    spec.host[0].host = host

    if operation in ("edit", "add"):
        spec.host[0].backing = vim.dvs.HostMember.PnicBacking()
        count = 0

        for nic in vmnics:
            spec.host[0].backing.pnicSpec.append(vim.dvs.HostMember.PnicSpec())
            spec.host[0].backing.pnicSpec[count].pnicDevice = nic
            spec.host[0].backing.pnicSpec[count].uplinkPortgroupKey = uplink_portgroup.key
            count += 1

    task = dv_switch.ReconfigureDvs_Task(spec)
    return wait_for_task(task, logger=logger)

def reconfigure_vvs(taskName, dvs, hosts, pnics='', op='add'):
    ''' op: add | edit | delete '''
    hostOp = {
        'add':      vim.ConfigSpecOperation.add,
        'delete':   vim.ConfigSpecOperation.remove,
        'edit':     vim.ConfigSpecOperation.edit
    }[op]
    pnics = [n.lower() for n in listify(pnics)] if pnics else []
    print('>>>>', taskName, dvs, hosts, pnics, op)
    dvs_config_spec = vim.DistributedVirtualSwitch.ConfigSpec()
    dvs_config_spec.configVersion = dvs.config.configVersion
    dvs_host_configs = []
    for host in hosts:
        dvs_host_config = vim.dvs.HostMember.ConfigSpec()
        dvs_host_config.operation = hostOp
        dvs_host_config.backing = vim.dvs.HostMember.PnicBacking()
        dvs_host_config.backing.pnicSpec = [
            vim.dvs.HostMember.PnicSpec(pnicDevice=n) for n in pnics]
        dvs_host_config.host = host
        dvs_host_configs.append(dvs_host_config)
    dvs_config_spec.host = dvs_host_configs
    print(dvs_config_spec)
    task = dvs.ReconfigureDvs_Task(dvs_config_spec)
    return wait_for_task(task, taskName)


######################################
## END function adopted from ansible #
######################################

def updatedList(curList, updateSpecs):
    ''' updateSpecs: ['+e1,'-e2','!e2','~e2'] OR ['e1','e2'] '''
    curList = listify(curList)
    updateSpecs = listify(updateSpecs)
    newList = curList
    if updateSpecs and updateSpecs[0][0] in ['+', '!', '~', '-']:
        newList = curList[:]
        for spec in updateSpecs:
            op, elem = spec[0], spec[1:]
            if op == '+':
                if elem not in newList:
                    newList.append(elem)
            elif op in  ['!', '~', '-']:
                while elem in newList:
                    newList.remove(elem)
    #print('updatedList(%s,%s): %s' % (curList, updateSpecs, newList))
    return newList



VimRec = collections.namedtuple('VimRec', ('vimType', 'subCmds', 'className'))

vimDict = {
    'cluster':      vim.ClusterComputeResource,
    'compute':      vim.ComputeResource,
    'extension':    vim.ExtensionManager,
    'dvPg':         vim.dvs.DistributedVirtualPortgroup,
    'folder':       vim.Folder,
    'host':         vim.HostSystem,
    'dc':           vim.Datacenter,
    'ds':           vim.Datastore,
    'dvs':          vim.DistributedVirtualSwitch,
    'vss':          vim.host.VirtualSwitch,
    'license':      vim.LicenseManager,
    'network':      vim.Network,
    'resPool':      vim.ResourcePool,
    'vm':           vim.VirtualMachine,
    'vmwDvs':       vim.dvs.VmwareDistributedVirtualSwitch,

    'VirtualStandardSwitch':            vim.host.VirtualSwitch,
    'ClusterComputeResource':           vim.ClusterComputeResource,
    'ComputeResource':                  vim.ComputeResource,
    'Datacenter':                       vim.Datacenter,
    'Datastore':                        vim.Datastore,
    'DistributedVirtualPortgroup':      vim.dvs.DistributedVirtualPortgroup,
    'DistributedVirtualSwitch':         vim.DistributedVirtualSwitch,
    'VirtualSwitch':                    vim.host.VirtualSwitch,
    'Folder':                           vim.Folder,
    'HostSystem':                       vim.HostSystem,
    'Network':                          vim.Network,
    'VirtualMachine':                   vim.VirtualMachine,
    'VmwareDistributedVirtualSwitch':   vim.dvs.VmwareDistributedVirtualSwitch,
}

def vimType2shortVimName(vimType):
    for k,v in vimDict.items():
        if isinstance(vimType, v):
            return k

def wait_for_task(task, actionName='job', logger=None, hideResult=False):
    """
    Waits and provides updates on a vSphere task
    """

    #raise Exception('wait_for_task(): state:%s, actionName:%s' % (task.info.state, actionName))
    while task.info.state in [vim.TaskInfo.State.running, vim.TaskInfo.State.queued]:
        time.sleep(2)
        #print('task.info.state: %s' % task.info.state)
    #print(type(task.info.state))

    if task.info.state == vim.TaskInfo.State.success:
        msg = '%s completed successfully.' % actionName
        if task.info.result and not hideResult:
            msg += ', result: %s' % task.info.result
        if logger: logger.info(msg)
    elif task.info.state == vim.TaskInfo.State.error:
        msg = '%s retuns with error state: %s' % (actionName, task.info.error.msg)
        if logger: logger.error(msg)
    else:
        msg = '%s did not complete successfully: %s' % (actionName, task.info)
        if logger: logger.error(msg)
    return msg


def waitForTask(task, taskName='job', logger=None, ignoreErrors=None):
    # ENUM: task.info.state.{success,error,running,queued}
    lastTaskState = ''
    intermediateStates = ['queued', 'running']
    finalStates = ['success', 'error']
    while task.info.state not in finalStates:
        if lastTaskState != task.info.state:
            lastTaskState = task.info.state
            logger.info('%s %s STATE=%s' % (task, taskName, lastTaskState))
        if lastTaskState != task.info.state:
            time.sleep(2)
    if lastTaskState != task.info.state:
        logger.info('%s %s STATE=%s' % (task, taskName, task.info.state))
    if task.info.state == 'error' and (
            ignoreErrors is None or type(task.info.error) not in ignoreErrors):
        logger.error('error: %s' % (task.info.error.msg))
        #raise Exception('error: %s' % (task.info.error.msg))
    return task

def my_workload(**kwargs):
    import random
    msg = kwargs['msg']
    delay = random.randint(0,50)/10.0
    print('%s, delay=%s' % (msg, str(delay)))
    time.sleep(delay)

class Singleton(type):
    _instances = {}
    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        return cls._instances[cls]

def kvValue(kv):
    ''' returns V or a KV pair if kv is in KV format, return kv otherwise '''
    kvStr = str(kv).strip("'")
    return kvStr.split(':')[1] if kvStr.count(':') == 1 else kvStr

def kvsiValues(kvs):
    ''' returns list of Vs of kvs '''
    r = []
    if isinstance(kvs, list):
        for kv in kvs:
            r.append(kvValue(kv))
    else:
        r = [kvsiValues(kv)]
    return r

def shortMoid(moid):
    ''' INPUT: "vim.vm.Snapshot:snapshot-161"
        RETURN: "snapshot-161"
    '''
    if moid==None: return None
    moid = str(moid)
    l = moid.strip("'").split(':')
    return l[0] if len(l)==1 else l[1]

def vimClassNameToShortVimTypeName(vimType, len=1):
    ''' INPUT: "<class 'pyVmomi.VmomiSupport.vim.ClusterComputeResource'>"
        RETURN: "vim.ClusterComputeResource" or "ClusterComputeResource"
    '''
    #l = vimType.__name__.split('.')
    #while l.pop(0) != 'vim': pass
    #print '.'.join(l)
    #return '.'.join(l)

    return '.'.join(vimType.__name__.split('.')[-len:])

def classTypeToShortVimTypeName(vimType):
    #print('vimType=', vimType); exit()
    return str(vimType).split("'")[1].split('.')[-1]

def submitVcTaskAndWait(fn, si, taskName, logger, *args, **kwargs):
#def submitVcTaskAndWait(fn, si, taskName, logger, args=None, kwargs=None):
    def taskState(task, logger, *args):
        if task.info.state=='error':
            logger.error('%s %s %s' % (taskName, task.info.state, task.info.error.msg))
        else:
            logger.info('%s %s' % (taskName, task.info.state))

    if args and kwargs:
        task = fn(*args, **kwargs)
    elif args and not kwargs:
        task = fn(*args)
    elif not args and kwargs:
        task = fn(**kwargs)
    elif not args and not kwargs:
        task = fn()
    if logger:
        logger.info('%s' % taskName)

    #task.wait(queued=taskState,
    #          running=taskState,
    #          success=taskState,
    #          error=taskState)
    task.wait(logger, success=taskState,
              error=taskState)


def loopVcObjActionForTargets(ns, methodName, targets, vc, defAllTargets=False, *args, **kwargs):
    ''' this function replace the following block of code
    className = vimClassNameToShortVimTypeName(vimDict[ns])
    mo = eval(className)(vc)
    for target in args.targets:
        task = mo.hostOp(target, argsNs[ns])
    '''
    className = vimClassNameToShortVimTypeName(vimDict[ns])
    mo = eval(className)(vc)
    fn = getattr(mo, methodName)
    if not targets and defAllTargets:
        targets = '*'
    for target in targets:
        # second arg is <action>
        fn(target, *args, **kwargs)


class VS_object(object):
    list_attrs = ['name', '_moId', 'parent']
    vs_obj_cache = {}
    def __init__(self, vc):
        self.vc = vc
        self.className = self.__class__.__name__
        self.logger = vc.logger

    def getByName(self, vimName, container=None, refresh=False):
        """
        Get object of vimtype from vcenter inventory by name
        """
        vimType = vimDict[self.__class__.__name__]
        objs = self.vc.getByType(vimType, container, refresh=refresh)
        for obj in objs:
            if obj.name == vimName:
                return obj
        return None

    def getByNameGlob(self, vimNamesGlob, container=None, refresh=False):
        self.logger.warning('This method is deprecated, use getByNamesGlob instead')    # 2017-05-03
        return self.getByNamesGlob(vimNamesGlob, container=container, refresh=refresh)

    def getByNamesGlob(self, vimNamesGlob, container=None, refresh=False):
        """
        Get object of vimtype from vcenter inventory by name (glob)
        """
        vimType = vimDict[self.__class__.__name__]
        objs = self.vc.getByNamesGlob(vimType, vimNamesGlob, container, refresh=refresh)
        return objs
        #for obj in objs:
        #    if obj.name == vimName:
        #        return obj
        #return None

    def find_by_name(self, name, results='moid', useCache=False):
        vimType = self.vimType
        results = []

        if useCache and vimType in self.vs_obj_cache:
            objs = self.vs_obj_cache[vimType]
        else:
            objs = self.vc.getByType(vimType)

        self.vs_obj_cache[vimType] = objs

        # ACCESSING i.name is VERY slow, need to do something about it
        for i in sorted(objs, key=lambda x: x.__getattribute__('name')):
            if isGlobMatched(name, i.name):
                results.append(i)
        return results

    def list(self, details=None, targetNames=['*']):        # VS_object()
        #objs = self.vc.getByType(self.vimType)
        objs = self.getByNamesGlob(targetNames)
        attrs = self.list_attrs
        if details and hasattr(self, 'list_details_attrs'):
            attrs += self.list_details_attrs
        ptbl = PrettyTable(attrs)
        ptbl.align = 'l'
        if 'name' in self.list_attrs:
            ptbl.sortby = 'name'
        vmHostList = []
        for obj in sorted(objs, key=lambda x: x.__getattribute__('name')):
            ''' obj sorted by name '''

            objList = []
            for attr in attrs:
                if attr == '_dvPgVlanId':
                    dvPgVlanId = obj.config.defaultPortConfig.vlan.vlanId;
                    _dvPgVlanId = []
                    if not isinstance(dvPgVlanId, int):
                        for r in dvPgVlanId:
                            _dvPgVlanId.append('%s'%r.start if r.start==r.end else '%s-%s'%(r.start, r.end))
                        dvPgVlanId = ','.join(_dvPgVlanId)
                    objList.append(dvPgVlanId)
                elif attr == '_networkType':
                    nType = 'vssPg'
                    if type(obj.summary)==vim.OpaqueNetwork.Summary:
                        nType = 'opaqueNetwork'
                    elif hasattr(obj, 'config') and isinstance(obj.config, vim.dvs.DistributedVirtualPortgroup.ConfigInfo):
                        reo = re.match(r'^vxw-dvs-\d+-virtualwire-\d+-sid-\d+-\S+$', obj.name)
                        nType = 'dvsPg-nsxvLs' if reo else 'dvsPg'
                    objList.append(nType)
                elif '.' in attr:
                    mObj = obj
                    for subAttr in attr.split('.'):
                        if '[' in subAttr:
                            subAttrBase, subAttrIdx = re.search('(\w+)\[(\d+)]', subAttr).groups()
                            mObj = getattr(mObj, subAttrBase)[int(subAttrIdx)]
                        else:
                            mObj = getattr(mObj, subAttr) if mObj else '_UNKNOWN_'
                    objList.append(mObj)
                else:
                    attrVals = obj.__getattribute__(attr),
                    if attr == 'parent':
                        parentName = attrVals[0].name
                        ##print('%s:%s' % (str(attrVals[0]).strip("'")[4:],parentName),)
                        objList.append('%s:%s' % (str(attrVals[0]).strip("'")[4:],parentName))
                    else:
                        for idx, attrVal in enumerate(attrVals):
                            #print('attrVals:'+str(attrVals),)
                            #print('attrValType:'+str(type(attrVal)),)
                            ### print('attrVal-%d:%s' % (idx, str(attrVal)))
                            ##print('%-15s\t' % str(attrVal),)
                            objList.append(attrVal)
            ##print('')
            #print('\t'.join(objList))
            #print('>>', objList)
            ptbl.add_row(objList)
        #ptbl.hrules = prettytable.HEADER
        #ptbl.vrules = prettytable.NONE

        if ptbl._rows: print(ptbl)
        print('Count: %d' % ptbl.rowcount)

    def delete(self, name):         # VS_object()
        mo = self.getByName(name, refresh=True)
        self.logger.info('deleting %s %s' % (self.__class__.__name__, name))
        if mo :
            task = mo.Destroy()
            waitForTask(task, 'Delete %s %s'%(self.__class__.__name__, name), self.logger)
        else:
            self.logger.error('object %s does not exist!' % name)

    def deleteMultiple(self, globNames):            # VS_object
        for globName in globNames:
            mos = self.getByNamesGlob(globName, refresh=True)
            for mo in mos:
                name = mo.name
                self.logger.info('deleting %s %s' % (self.__class__.__name__, name))
                if mo :
                    task = mo.Destroy()
                    waitForTask(task, 'Delete %s %s'%(self.__class__.__name__, name), self.logger)
                else:
                    self.logger.error('object %s does not exist!' % name)

    def getMembersByNames(self, names, entSpec, memNameGlob=''):
        ''' entSpec:
                host,      host.name,      host._moId,
                host.vm,   host.vm.name,   host.vm._moId
                datastore, datastore.name, datastore._moId
                network,   network.name,   network._moId
        '''
        entList = []
        aIdx = 0
        entList.append([])

        #print('>>>>>>>>>>>>')
        #print('A> entSpec=%s' % entSpec)
        entAttrs = entSpec.split('.') if '.' in entSpec else [entSpec]
        entAttr = entAttrs.pop(0)
        #print('B> entAttr=%s entAttrs=%s' % (entAttr, entAttrs))

        for name in names:
            cMos = self.getByNamesGlob(name)
            for cMo in cMos:
                #entList[aIdx].extend([h for h in getattr(cMo, entAttr) if not memNameGlob or isGlobMatched(memNameGlob, h.name)])
                if isinstance(entAttr, list):
                    entList[aIdx].extend([h for h in getattr(cMo, entAttr)])
                    #entList[aIdx] = list(set(cptutil.flatten(entList[aIdx])))
                else:
                    entList[aIdx] = [getattr(cMo, entAttr)]

        #print('>1a entList%d: %s' % (aIdx, entList[aIdx]))
        if isinstance(entList[aIdx][0], list):
            entList[aIdx] = list(set(cptutil.flatten(entList[aIdx])))
        #print('C> entList[%d]: %s' % (aIdx, entList[aIdx]))

        while entAttrs:
            aIdx += 1
            entList.append([])
            entAttr = entAttrs.pop(0)
            #print('D0> aIdx=%d entAttr=%s entAttrs=%s' % ( aIdx, entAttr, entAttrs))
            #for e in entList[aIdx-1]:
            #    print(e, entAttr, getattr(e, entAttr))
            #print('-----')

            entList[aIdx] = [getattr(e, entAttr) for e in entList[aIdx-1]]
            #print('entList[%d]: %s' % (aIdx, entList[aIdx]))

            if isinstance(entList[aIdx][0], list):
                entList[aIdx] = list(set(cptutil.flatten(entList[aIdx])))

            #print('D1> aIdx=%d entAttr=%s entAttrs=%s' % (aIdx, entAttr, entAttrs))
            #print('D1> entList[%d]=%s' % (aIdx-1, entList[aIdx-1]))
            #print('D1> entList[%d]=%s' % (aIdx, entList[aIdx]))
            #print('<<<<<<<<<<<<')

        if memNameGlob:
            #print '>>>>', aIdx, entAttr
            if entAttr=='name':
                entList[aIdx] = [e for e in entList[aIdx] if isGlobMatched(memNameGlob, e)]
            elif entAttr=='_moId':
                entList[aIdx] = [e._moId for e in entList[aIdx-1] if isGlobMatched(memNameGlob, e.name)]
            else:
                entList[aIdx] = [e for e in entList[aIdx] if isGlobMatched(memNameGlob, e.name)]
        return entList[aIdx]

    def rename(self, name, newName):
        vimType = self.vimType
        mo = self.vc.getByName(vimType, name)
        if not mo:
            self.logger.info('Cannot find %s %s' % (vimType, name))
            return None

        self.logger.info('Rnamnge %s %s to %s' % (
            vimType, name, newName))
        task = mo.Rename(newName)
        waitForTask(task, 'Rnamnge %s %s to %s'%(vimType,name,newName), self.logger)


class Task(VS_object):
    vimType = vim.Task

class Alarm(VS_object):
    vimType = vim.AlarmManager

    def alarmOp(self, op, entVimType, targetAlarm, targetEntNames):
        self.logger.info('%s Alarm "%s" for "%s"' % (op, targetAlarm, targetEntNames))
        alrmMgr = self.vc.si.content.alarmManager
        ptbl = PrettyTable(['entName', 'entType', 'alarmName', 'status', 'trigTime', 'ack'], sortby='entName')
        ptbl.align = 'l'
        for trigAlrm in self.vc.si.content.rootFolder.triggeredAlarmState:
            alarmName = trigAlrm.alarm.info.name
            if isinstance(trigAlrm.entity, entVimType) and \
                    cptutil.isGlobMatched(targetAlarm, alarmName):
                entType = type(trigAlrm.entity)
                entType = vimType2shortVimName(trigAlrm.entity)
                entName = self.vc.moid2name(trigAlrm.entity.name) if ':' in trigAlrm.entity.name \
                    else trigAlrm.entity.name
                if cptutil.isGlobMatchedInList(targetEntNames, entName):
                    ptbl.add_row([entName, entType, trigAlrm.alarm.info.name, trigAlrm.overallStatus,
                        (str(trigAlrm.time).split('.')[0]), trigAlrm.acknowledged])
                    if op=='ack':
                        self.logger.info('Acknowledge Alarm "%s" for "%s"' % (targetAlarm, entName))
                        alrmMgr.AcknowledgeAlarm(trigAlrm.alarm, trigAlrm.entity)
                    elif op=='reset':
                        self.logger.info('Reseting Alarm "%s" status to green for "%s"' % (targetAlarm, entName))
                        self.resetAlarm(self.vc.si, trigAlrm.alarm.info.key, 'VirtualMachine', shortMoid(trigAlrm.entity))
                    elif op=='resetVm':
                        if isinstance(trigAlrm.entity, vim.VirtualMachine):
                            self.logger.info('Reseting VM "%s"' % entName)
                            vmObj = VirtualMachine(self.vc)
                            vmObj.vmOp(entName, action='power_reset')
                        else:
                            self.logger.error('"%s" is not a VM, cannot reset' % entName)
        if op=='list':
            print(ptbl)
            print('Count: %d' % ptbl.rowcount)

        #for alrm in sorted([str(a) for a in alrmMgr.GetAlarm()], key=cptutil.numInStr):
        #    #print(alrm)
        #    #AcknowledgeAlarm
        #    pass

    def _buildResetAlarmSoapPayload(self, entType, entMoid, alarmMoid):
        """
        Builds a SOAP envelope to send to the vCenter hidden API

        :param entMoid:   entity_moref
        :param alarmMoid: alarm_moref
        :param entType:   entity_type
        :return:
        """
        if not entMoid or not entType or not alarmMoid:
            raise ValueError("entMoid, entType, and alarmMoid "
                             "must be set")

        attribs = {
            'xmlns:xsd': 'http://www.w3.org/2001/XMLSchema',
            'xmlns:xsi': 'http://www.w3.org/2001/XMLSchema-instance',
            'xmlns:soap': 'http://schemas.xmlsoap.org/soap/envelope/'
        }
        root = Element('soap:Envelope', attribs)
        body = SubElement(root, 'soap:Body')
        alarm_status = SubElement(body, 'SetAlarmStatus', {'xmlns': 'urn:vim25'})
        this = SubElement(alarm_status, '_this', {
            'xsi:type': 'ManagedObjectReference',
            'type': 'AlarmManager'
        })
        this.text = 'AlarmManager'
        alarm = SubElement(alarm_status, 'alarm', {'type': 'Alarm'})
        alarm.text = alarmMoid
        entity = SubElement(alarm_status, 'entity', {
            'xsi:type': 'ManagedObjectReference',
            'type': entType
        })
        entity.text = entMoid
        status = SubElement(alarm_status, 'status')
        status.text = 'green'
        # I hate hard coding this but I have no idea how to do it any other way
        # pull requests welcome :)
        return '<?xml version="1.0" encoding="UTF-8"?>{0}'.format(tostring(root))


    def resetAlarm(self, si, alarmMoid, entType, entMoid):
        """
        Resets an alarm on a given HostSystem in a vCenter to the green state
        without someone having to log in to do it manually.

        This is done by using an unexposed API call. This requires us
        to manually construct the SOAP envelope. We use the session key
        that pyvmomi provides during its connection.

        More information can be found about this process
        in this article written by William Lam:
        http://www.virtuallyghetto.com/2010/10/how-to-ack-reset-vcenter-alarm.html

        I adopted his process from perl to groovy:
        https://gist.github.com/michaelrice/d54a237295e017b032a5
        and from groovy now to python.

        Usage:
        SI = SmartConnect(xxx)
        HOST = SI.content.searchIndex.FindByxxx(xxx)
        alarm.reset_alarm(entity_moref=HOST._moId, entity_type='HostSystem',
                        : alarm_moref='alarm-1', service_instance=SI)
        :param service_instance:
        :param entity_moref:
        :param alarm:
        :return boolean:
        """
        soap = Soap()
        payload = self._buildResetAlarmSoapPayload(entType, entMoid, alarmMoid)
        logging.debug(payload)
        session = si._stub
        if not soap._send_request(payload, session):
            return False
        return True


class ResourcePool(VS_object):
    vimType = vim.ResourcePool

class DvsVirtualwire(VS_object):
    vimType = vim.Network
    list_details_attrs = ['vm']

    def find_by_name(self, name, results='moid'):
        name = 'vxw-dvs-*-virtualwire-*-sid-*-%s' % name
        return super(self.__class__, self).find_by_name(
            name, results)


class ExtensionManager(VS_object):
    vimType = vim.ExtensionManager

    def list(self, details=False):      # ExtensionManager()
        for ext in self.vc.si.content.extensionManager.extensionList:
            print('    %-35s%s' % (ext.key, ext.description.label))

class UserDirectory(VS_object):
    vimType = vim.UserDirectory

    def list(self, targetType='domain', searchStr='', details=False):   # UserDirectory()
        ud = self.vc.si.content.userDirectory
        if targetType=='domain':
            print('Domain list: %s' % ', '.join(ud.domainList))
        elif targetType=='user':
            for domain in ud.domainList:
                print('User/Group in Domain: %s' % domain)
                udResults = ud.RetrieveUserGroups(domain, searchStr=searchStr,
                    exactMatch=False, findUsers=True, findGroups=True)
                print(udResults)
                #print(', '.join([r.principal for r in udResults]))

                ptbl = PrettyTable(
                    field_names = ['principal', 'group'],
                    sortby = 'group',
                    )
                ptbl.align='l'
                for r in udResults:
                    ptbl.add_row([r.principal, ['user', 'group'][r.group]])

                if ptbl._rows: print(ptbl)
                print('Count: %d' % ptbl.rowcount)


class LicenseManager(VS_object):
    vimType = vim.LicenseManager

    #licKeyVs6ep100u = 'RM6U1-D208Q-18C3H-0U482-3DW5L'    ;# vSphere 6 Enterprise Plus 100, indefinite
    #licKeyVs6ep0u   = 'MM2L3-D2215-J8231-0R8R0-C5W7L'    ;# vSphere 6 Enterprise Plus unlimited, indefinite
    #licKeyVs6e  =     'D52J6-CLK1P-P8190-0980P-3X0L6'    ;# vSphere 6 Enterprise
    licKeyVs6  =     'HJ2RP-CF016-688C8-0A42M-AWAJ2'    ;# vSphere 6 Enterprise Plus
    licKeyVc6  =     'HJ0V3-FLL80-18CA9-0298K-3MP2L'    ;# vCenter 6 Standard
    licKeyVsan =     '1J2VK-88HE3-68UE9-08802-3MMLP'    ;# VSAN Enterprise

    def mapEntId(self, targetType, targetName):
        if targetType == 'host':
            return self.vc.getByName(vim.HostSystem, targetName)._moId
        elif targetType == 'nsx':
            return 'nsx-netsec'
        elif targetType == 'vc':
            return self.vc.si.content.about.instanceUuid
        else:
            self.logger.warning("Don't konow how to handle entity type %s" % targetType)

    def list(self, details=False):      # LicenseManager()
        for lic in self.vc.si.content.licenseManager.licenses:
            print('%s %s' % (lic.name, lic.licenseKey))
            field_names = ['ProductName', 'ProductVersion', 'expirationDate', 'FileVersion']
            ptbl = PrettyTable(field_names=field_names, sortby='ProductName', align='l')
            ptbl.align='l'
            for kv in lic.properties:
                if getattr(kv, 'value') and getattr(kv.value, 'properties', None):
                    expirationDate, FileVersion, ProductName, ProductVersion = '', '', '', ''
                    for iprop in kv.value.properties:
                        if iprop.key in field_names:
                            exec('%s = "%s"' % (iprop.key, iprop.value))
                    ptbl.add_row([ProductName, ProductVersion, expirationDate, FileVersion])
            print(ptbl)

    def addLicense(self, lics):
        for lic in lics:
            self.logger.info('Adding license %s to vc' % lic)
            self.vc.si.content.licenseManager.AddLicense(lic)
            self.logger.info('Added  license %s to vc' % lic)

    def delete(self, lics):         # LicenseManager()
        for lic in lics:
            self.logger.info('Deleting license %s from vc' % lic)
            self.vc.si.content.licenseManager.RemoveLicense(lic)
            self.logger.info('Deleted  license %s from vc' % lic)

    def assignLicense(self, lic, targetType, targetName):
        entId = self.mapEntId(targetType, targetName)
        self.logger.info('Updating %s %s license to %s' % (targetType, targetName, lic))
        self.vc.si.content.licenseManager.licenseAssignmentManager.UpdateAssignedLicense(entId, lic)
        self.logger.info('Updated  %s %s license to %s' % (targetType, targetName, lic))

    def unassignLicense(self, targetType, targetName):
        self.logger.info('Removing license %s from %s' % (targetType, targetName))
        entId = self.mapEntId(targetType, targetName)

        try:
            self.vc.si.content.licenseManager.licenseAssignmentManager.RemoveAssignedLicense(entId)
        except Exception as e:
            #print(e)
            self.logger.error(e.msg)
            for fmsg in e.faultMessage:
                #for arg in fmsg.arg:
                #    print(arg.key, arg.value)
                self.logger.error(fmsg.message)
            if 'reason' in e:
                self.logger.error(e.reason)
        self.logger.info('Removed  license %s from %s' % (targetType, targetName))

    @staticmethod
    def _key(vals):
        vals[0] += vals[3]
        return vals

    def listAssignedLicenses(self):
        ptbl = PrettyTable(
            field_names = ['license Description', 'licKey', 'expireDate', 'entity', 'entityId'],
            sortby = 'licKey',
            sort_key=self._key, align='l')
        ptbl.align='l'
        for lae in self.vc.si.content.licenseManager.licenseAssignmentManager.QueryAssignedLicenses():
            laeLic, laeName, laeId = lae.assignedLicense, lae.entityDisplayName, lae.entityId
            licKey, licName = laeLic.licenseKey, laeLic.name

            expireDatetime = next((p.value for p in laeLic.properties if p.key=='expirationDate'),
                datetime.datetime(9999, 12, 31))
            expireDate = expireDatetime.__str__().split()[0]

            ptbl.add_row([licName, licKey, expireDate, laeName, laeId])

        if ptbl._rows: print(ptbl)
        print('Count: %d' % ptbl.rowcount)

class VimType(VS_object):
    resPool =  vim.ResourcePool,
    network =  vim.Network,
    dvPg    =  vim.dvs.DistributedVirtualPortgroup,
    vmwDvs  =  vim.dvs.VmwareDistributedVirtualSwitch,
    folder  =  vim.Folder,
    host    =  vim.HostSystem,
    cluster =  vim.ClusterComputeResource,
    compute =  vim.ComputeResource,
    dc      =  vim.Datacenter,
    ds      =  vim.Datastore,
    dvs     =  vim.DistributedVirtualSwitch,
    vm      =  vim.VirtualMachine,

class Network(VS_object):
    vimType = vim.Network
    list_attrs = ['name', '_moId', '_networkType']
    list_details_attrs = ['vm']
    netspecHelpMsg = '''
        network specification format: <type>:<name>
            eg:
                "o:VLAN2002", "p:VM Network", "d:DVS1-VLAN2001"
            where:
                type:
                    o=opaque/nvds, p=VSS portgroup, d=DVS portgroup')
                name: portgroup or opaque/n-vds name
        '''
    '''
        SWITCH            OWNER           SEGMENT        INFO
        V:VSS             HOST            p:PG
        D:DVS             vCenter         d:dvsPG        (backed by nsxv-LS)
        O:OpaqueSwitch    vCenter         o:opaqNetwork  (backed by nsx.LogicalSwitch)
    '''


    def disconnectvm(self, targetNetName, vmNamePat):
        ''' THis method is not actually doing anything yet '''
        #objs = self.vc.getInvObjListByType(self.vimType)
        objs = self.vc.getByType(self.vimType)
        for obj in sorted(objs, key=lambda x: x.__getattribute__('name')):
            ''' obj sorted by name '''
            targetNetNamePat = r'vxw-dvs-\d+-virtualwire-\d+-sid-\d+-%s' % targetNetName
            netName = obj.__getattribute__('name')
            targetNetNamePat = 'vxw-dvs-*-virtualwire-*-sid-*-%s' % targetNetName
            if isGlobMatched(targetNetNamePat, netName):
                print('%s %s %s' % (targetNetName, netName, vmNamePat))

                #print('vmList=', obj.vm)
                for vmObj in obj.vm:
                    #print(dir(vmObj))
                    vmName = vmObj.name
                    if isGlobMatched(vmNamePat, vmName):
                        folderType == eval('dc.%sFolder' % folderType)
                        print('\t%s %s %s %s' % (vmObj, type(vmObj).__name__, vmObj._moId, vmObj.name))


class VirtualStandardSwitch(VS_object):
    vimType = vim.host.VirtualSwitch
    list_attrs = ['name']
Vss = VirtualStandardSwitch

class DistributedVirtualPortgroup(VS_object):
    vimType = vim.dvs.DistributedVirtualPortgroup
    list_attrs = ['name', '_moId', '_dvPgVlanId', 'config.distributedVirtualSwitch.name']

    def create(self, dvpgName, dvsName, vlanId):
        vimType = self.vimType

        dvsMo = self.vc.getByName(vim.DistributedVirtualSwitch, dvsName)

        if not dvsMo:
            self.logger.error('DVS %s not found' % dvsName)
            return None

        defPortPolicy = vim.dvs.VmwareDistributedVirtualSwitch.VmwarePortConfigPolicy()
        defPortPolicy.vlan = vim.dvs.VmwareDistributedVirtualSwitch.VlanIdSpec()
        defPortPolicy.vlan.vlanId = vlanId

        dvpgSpec = vim.dvs.DistributedVirtualPortgroup.ConfigSpec()
        dvpgSpec.name = dvpgName
        dvpgSpec.numPorts = 8
        dvpgSpec.type = 'earlyBinding'
        dvpgSpec.autoExpand = True
        dvpgSpec.defaultPortConfig = defPortPolicy

        task = dvsMo.CreateDVPortgroup_Task(dvpgSpec)
        while task.info.state not in ['success', 'error']:
            time.sleep(1)
            self.logger.info('%s %s' % (task, task.info.state))

        if task.info.state == 'success':
            resultDvpg = task.info.result
            self.logger.info(
                'dvPortgroup %s (%s) created on dvs %s (vlan%d)' % (
                dvpgName, resultDvpg, dvsMo.name, vlanId))
        elif task.info.state == 'error':
            self.logger.error(task.info.error)
        else :
            self.logger.warning(task.info.state)


    def setVlan(self, dvpgName, vlanId=0):
        vimType = self.vimType
        dvpgMo = self.vc.getByName(self.vimType, dvpgName)
        if not dvpgMo:
            self.logger.error('dvPg %s not found' % dvpgName)
            return None

        defPortPolicy = vim.dvs.VmwareDistributedVirtualSwitch.VmwarePortConfigPolicy()
        defPortPolicy.vlan = vim.dvs.VmwareDistributedVirtualSwitch.VlanIdSpec()
        defPortPolicy.vlan.vlanId = vlanId

        dvpgSpec = vim.dvs.DistributedVirtualPortgroup.ConfigSpec()
        dvpgSpec.defaultPortConfig = defPortPolicy
        dvpgSpec.configVersion = dvpgMo.config.configVersion

        task = dvpgMo.ReconfigureDVPortgroup_Task(spec=dvpgSpec)
        while task.info.state not in ['success', 'error']:
            time.sleep(1)
            self.logger.info('%s %s' % (task, task.info.state))

        if task.info.state == 'success':
            resultDvpg = task.info.result
            self.logger.info('set dvPortgroup %s vlan to vlan%d' % (dvpgName, vlanId))
        elif task.info.state == 'error':
            self.logger.error(task.info.error)
        else :
            self.logger.warning(task.info.state)


class VmwareDistributedVirtualSwitch(DistributedVirtualPortgroup):
    vimType = vim.dvs.VmwareDistributedVirtualSwitch

    def get(self, nameGlob, getChoice=None):        # VmwareDistributedVirtualSwitch
        objs = self.vc.getByType(self.vimType)

        nTargetFound = 0
        for dvs in sorted(objs, key=lambda x: x.__getattribute__('name')):
            if not isGlobMatched(nameGlob, dvs.name): continue
            nTargetFound += 1
            if getChoice == 'status':
                ptble = PrettyTable(['nHost', 'missingHost', '#PG', '#VM'])
                print('nHost(%d) missingHost(%s) nPG(%d) nVM(%d)' % (
                    len(dvs.summary.host),
                    list(set(dvs.summary.host)-set(dvs.summary.hostMember)),
                    len(dvs.summary.portgroupName),
                    len(dvs.summary.vm), ))
            elif getChoice == 'config':
                ptble = PrettyTable(['name', 'moid', 'mtu', 'linkDisProto'])
                ptble.add_row('%(name)-15s %(moid)-16s %(mtu)-20s '
                    '%(ldp)s' % {
                    'name':dvs.name,
                    'moid':dvs._moId,
                    'mtu':dvs.config.maxMtu,
                    'ldp':dvs.config.linkDiscoveryProtocolConfig.protocol,
                    })
                print(ptble)
                #print('%(name)-15s %(moid)-16s %(mtu)-20s '
                #    '%(ldp)s' % {
                #    'name':dvs.name,
                #    'moid':dvs._moId,
                #    'mtu':dvs.config.maxMtu,
                #    'ldp':dvs.config.linkDiscoveryProtocolConfig.protocol,
                #    })
            elif getChoice == 'network':
                hNet = dvs.config.network
                print('%s %s %s %s' % (hNet.ipRouteConfig.defaultGateway,
                    [n.key for n in hNet.netStackInstance],
                    [p.device for p in hNet.pnic],
                    [(v.device, v.spec.mtu) for v in hNet.vnic]))

        if nTargetFound == 0:
            self.logger.error('%s %s not found' % (self.className, nameGlob))


class VirtualSwitch(VS_object):
    vimType = vim.host.VirtualSwitch.Specification()

class DistributedVirtualSwitch(VS_object):
    vimType = vim.DistributedVirtualSwitch
    list_attrs = ['name', '_moId', 'summary.productInfo.version', 'parent']

    def get(self, nameGlob, getChoice=None):        #  DistributedVirtualSwitch
        objs = self.vc.getByType(self.vimType)

        if getChoice == 'status':
            ptbl = PrettyTable(['dvs', 'nHost', 'missingHost', '#PG', '#VM'])
        elif getChoice == 'config':
            ptbl = PrettyTable(['dvs', 'moid', 'mtu', 'linkDiscover'])
        elif getChoice == 'host':
            ptbl = PrettyTable(['dvs', 'host', 'vmnic'])
        elif getChoice == 'summary':
            ptbl = PrettyTable(['dvs', 'host', 'PG', 'VM'])
        ptbl.align = 'l'

        nTargetFound = 0
        for dvs in sorted(objs, key=lambda x: x.__getattribute__('name')):
            dvsName = dvs.name
            if not isGlobMatched(nameGlob, dvs.name): continue
            nTargetFound += 1
            if getChoice == 'status':
                summary = dvs.summary
                ptbl.add_row([dvsName,
                    len(summary.host),
                    ','.join(set(summary.host)-set(summary.hostMember)),
                    len(summary.portgroupName),
                    len(summary.vm) ])
            elif getChoice == 'config':
                ptbl.add_row([dvsName, dvs._moId, dvs.config.maxMtu,
                    dvs.config.linkDiscoveryProtocolConfig.protocol])
            elif getChoice == 'host':
                for h in dvs.config.host:
                    hc = h.config
                    ptbl.add_row([dvsName, hc.host.name,
                        ','.join([pnic.pnicDevice for pnic in hc.backing.pnicSpec])])
            elif getChoice == 'summary':
                summary = dvs.summary
                ptbl.add_row([dvsName,
                    cptutil.textWrapCol([h.name for h in summary.hostMember], 20),
                    cptutil.textWrapCol([str(pg) for pg in summary.portgroupName], 40),
                    cptutil.textWrapCol([vm.name for vm in summary.vm], 30),
                    ])

        if nTargetFound == 0:
            self.logger.error('%s %s not found' % (self.className, nameGlob))
        else:
            print(ptbl)

    def listLacp(self,name=None):
        switch = self.vc.getByName(self.vimType, name)
        if not switch:
            self.logger.error(
                '%s %s does not exist!' % (self.vimType, dvsName))
            exit(0)

        if type(switch) != vim.dvs.VmwareDistributedVirtualSwitch:
            self.logger.error('%s is not a VMware DVS' %(name))
            exit(0)
        if switch.config.lacpApiVersion != 'multipleLag':
            print("Switch %s lacpApiVersion is %s, not multipleLag"
                   %(name,switch.config.lacpApiVersion))
            return
        else:
            print("Switch %s, lacpApiVersion: %s"
                   %(name,switch.config.lacpApiVersion))

        for s in switch.config.lacpGroupConfig:
            print(s)



    def addLacp(self,dvsName,name, dcName=None, mode='active',
                ports=2, lb='srcDestIpTcpUdpPortVlan'):
        switch = self.vc.getByName(self.vimType, dvsName)
        if not switch:
            self.logger.error(
                '%s %s does not exist!' % (self.vimType, dvsName))
            exit(0)
        print(switch)
        #print(switch.config)
        print(switch.config.lacpApiVersion)
        operation = 'add'
        lacpCfg = vim.dvs.VmwareDistributedVirtualSwitch.LacpGroupConfig()

        for s in switch.config.lacpGroupConfig:
            print(s.name)
            print(s.key)
            if s.name == name:
                operation = 'edit'
                lacpCfg.key = s.key
                break
        print(operation)
        lacpCfg.name = name
        lacpCfg.mode = mode
        lacpCfg.uplinkNum = ports
        lacpCfg.loadbalanceAlgorithm = lb
        lacpSpec = vim.dvs.VmwareDistributedVirtualSwitch.LacpGroupSpec()
        print(lacpCfg)
        lacpSpec.lacpGroupConfig = lacpCfg
        lacpSpec.operation = operation
        switch.UpdateDVSLacpGroupConfig_Task([lacpSpec])




    def create(self, dvsName, dcName=None, version='6.5.0'):
        vimType = self.vimType

        if self.vc.getByName(self.vimType, dvsName):
            self.logger.error(
                'DVS "%s" already exist!' % dvsName)
            return

        dcs = self.vc.getByNamesGlob(vim.Datacenter, dcName or '*')
        if len(dcs)>1:
            self.logger.warning('multple datacenters found, DC "%s" is chosen' % dcs[0].name)
        dc = dcs[0]
        networkFolder = dc.networkFolder

        # CreateSpec:
        #   configSpec: ConfigSpec()
        #     name: str(
        #     uplinkPortPolicy: NameArrayUplinkPortPolicy()
        #       uplinkPortName: list(names)
        #     maxPorts: int(2000)
        #     host: HostMember.ConfigSpec()[]
        #       backing: HostMember.PnicBacking()
        #           pnicSpec: HostMember.PnicSpec()
        #   productSpec: ProductInfo()
        #       version: '5.5.0'
        #   uplinkPortPolicy: NameArrayUplinkPortPolicy()

        pnicSpecs = []
        dvs_host_configs = []
        uplink_port_names = []

        dvsCreateSpec = vim.DistributedVirtualSwitch.CreateSpec()
        dvsConfigSpec = vim.DistributedVirtualSwitch.ConfigSpec()
        dvsCreateSpec.productInfo = vim.dvs.ProductSpec(version=version)
        dvsConfigSpec.uplinkPortPolicy = vim.DistributedVirtualSwitch.NameArrayUplinkPortPolicy()

        # uplink related to # of host, create 1 for now!
        for x in range(2):
            uplink_port_names.append("dvUplink%d" % x)

        dvsCreateSpec.configSpec = dvsConfigSpec

        dvsConfigSpec.name = dvsName
        dvsConfigSpec.uplinkPortPolicy.uplinkPortName = uplink_port_names

        task = networkFolder.CreateDVS_Task(dvsCreateSpec)
        waitForTask(task, 'create DVS %s'%dvsName, self.logger)

        '''
        cluster = self.vc.getByType(vim.ClusterComputeResource)[0]
        networkFolder = self.vc.getByType(vim.Folder)[0]

        pnic_specs = []
        dvs_host_configs = []
        uplink_port_names = []
        dvs_create_spec = vim.DistributedVirtualSwitch.CreateSpec()
        dvs_config_spec = vim.DistributedVirtualSwitch.ConfigSpec()
        dvs_config_spec.name = dvsName
        dvs_config_spec.uplinkPortPolicy = vim.DistributedVirtualSwitch.NameArrayUplinkPortPolicy()
        hosts = cluster.host
        for x in range(len(hosts)+1):
            uplink_port_names.append("dvUplink%d" % x)

        #import pdb; pdb.set_trace()
        for host in hosts:
            dvs_config_spec.uplinkPortPolicy.uplinkPortName = uplink_port_names
            dvs_config_spec.maxPorts = 2000
            pnic_spec = vim.dvs.HostMember.PnicSpec()
            pnic_spec.pnicDevice = 'vmnic1'
            pnic_specs.append(pnic_spec)
            dvs_host_config = vim.dvs.HostMember.ConfigSpec()
            dvs_host_config.operation = vim.ConfigSpecOperation.add
            dvs_host_config.host = host
            dvs_host_configs.append(dvs_host_config)
            dvs_host_config.backing = vim.dvs.HostMember.PnicBacking()
            dvs_host_config.backing.pnicSpec = pnic_specs
            dvs_config_spec.host = dvs_host_configs

        dvs_create_spec.configSpec = dvs_config_spec
        dvs_create_spec.productInfo = vim.dvs.ProductSpec(version='5.5.0')

        task = networkFolder.CreateDVS_Task(dvs_create_spec)
        wait_for_task(task, self.vc.si, self.logger)
        print("Successfully created DVS ", inputs['dvs_name'])
        return get_obj(content, [vim.DistributedVirtualSwitch], inputs['dvs_name'])
        '''

    # from ansible vmware_migrate_vmk.py
    def state_migrate_vss_vds(self, hostNames, vmkName, dvsName, dvpgName, curDvsName, curDvpgName):
        def create_host_vnic_config(device, dv_switch_uuid, portgroup_key):
            host_vnic_config = vim.host.VirtualNic.Config()
            host_vnic_config.spec = vim.host.VirtualNic.Specification()

            host_vnic_config.changeOperation = "edit"
            host_vnic_config.device = device
            host_vnic_config.portgroup = ""
            host_vnic_config.spec.distributedVirtualPort = vim.dvs.PortConnection()
            host_vnic_config.spec.distributedVirtualPort.switchUuid = dv_switch_uuid
            host_vnic_config.spec.distributedVirtualPort.portgroupKey = portgroup_key

            return host_vnic_config

        def create_port_group_config(current_switch_name, current_portgroup_name):
            port_group_config = vim.host.PortGroup.Config()
            port_group_config.spec = vim.host.PortGroup.Specification()

            port_group_config.changeOperation = "remove"
            port_group_config.spec.name = current_portgroup_name
            port_group_config.spec.vlanId = -1
            port_group_config.spec.vswitchName = current_switch_name
            port_group_config.spec.policy = vim.host.NetworkPolicy()

            return port_group_config



        dvs = self.vc.getByName(self.vimType, dvsName)
        hosts = self.vc.getByNamesGlob(vim.HostSystem, hostNames)

        for host in hosts:
            host_network_system = host.configManager.networkSystem
            #dvs = find_dvs_by_name(self.content, dvsName)
            pg = find_dvspg_by_name(dvs, dvpgName)

            config = vim.host.NetworkConfig()
            config.portgroup = [create_port_group_config(curDvsName, curDvpgName)]
            config.vnic = [create_host_vnic_config(device, dvs.uuid, pg.key)]
            host_network_system.UpdateNetworkConfig(config, "modify")
            self.module.exit_json(changed=True)

    def reconfigure_dvs(self, dvs, hosts, pnics='', op='add'):    # DistributedVirtualSwitch
        ''' op: add | edit | delete '''
        hosts = listify(hosts)
        hostOp = {
            'add':      vim.ConfigSpecOperation.add,
            'delete':   vim.ConfigSpecOperation.remove,
            'edit':     vim.ConfigSpecOperation.edit,
            'update':   vim.ConfigSpecOperation.edit,
        }[op]
        hostNames = [h.name for h in hosts]
        if not isinstance(pnics, list):
            pnics = [n.lower() for n in listify(pnics.split(',')) if n] if pnics else []
        taskName = '%s_HOST_%s_DVS_%s_PNIC_%s' % (
            op, '_'.join(hostNames), dvs.name, 
            '_'.join(pnics))
        self.logger.alert('12> %s' % [ op, hostOp, hosts, dvs, dvs.name, pnics])
        #import pdb; pdb.set_trace()
        #print('1> %s' % pnics)
        #self.logger.info1('taskName=%s, dvs=%s, hosts=%s, pnics=%s, op=%s'%(taskName, dvs, hosts, pnics, op))
        dvs_config_spec = vim.DistributedVirtualSwitch.ConfigSpec()
        dvs_config_spec.configVersion = dvs.config.configVersion
        dvs_host_configs = []
        for host in hosts:
            dvs_host_config = vim.dvs.HostMember.ConfigSpec()
            dvs_host_config.operation = hostOp
            dvs_host_config.backing = vim.dvs.HostMember.PnicBacking()
            dvs_host_config.backing.pnicSpec = [
                vim.dvs.HostMember.PnicSpec(pnicDevice=n) for n in pnics]
            dvs_host_config.host = host
            dvs_host_configs.append(dvs_host_config)
        dvs_config_spec.host = dvs_host_configs
        #self.logger.alert('dvs_config_spec>>> %s', dvs_config_spec)
        task = dvs.ReconfigureDvs_Task(dvs_config_spec)
        return wait_for_task(task, taskName, logger=self.logger)

    def dvsSetPnics(self, dvs, hosts, pnics='', op='edit'):    # DistributedVirtualSwitch
        ''' op: add | edit | delete '''
        hosts = listify(hosts)
        hostOp = vim.ConfigSpecOperation.edit
        hostNames = [h.name for h in hosts]
        if not isinstance(pnics, list):
            pnics = [n.lower() for n in listify(pnics.split(',')) if n] if pnics else []
        taskName = 'set_HOST_%s_DVS_%s_PNIC_%s' % (
            '_'.join(hostNames), dvs.name, 
            '_'.join(pnics))
        self.logger.alert('22> %s' % [hostOp, hosts, dvs, dvs.name, pnics])
        #import pdb; pdb.set_trace()
        #print('1> %s' % pnics)
        #self.logger.info1('taskName=%s, dvs=%s, hosts=%s, pnics=%s, op=%s'%(taskName, dvs, hosts, pnics, op))
        dvs_config_spec = vim.DistributedVirtualSwitch.ConfigSpec()
        dvs_config_spec.configVersion = dvs.config.configVersion
        dvs_host_configs = []
        for host in hosts:
            dvs_host_config = vim.dvs.HostMember.ConfigSpec()
            dvs_host_config.operation = hostOp
            dvs_host_config.backing = vim.dvs.HostMember.PnicBacking()
            dvs_host_config.backing.pnicSpec = [
                vim.dvs.HostMember.PnicSpec(pnicDevice=n) for n in pnics]
            dvs_host_config.host = host
            dvs_host_configs.append(dvs_host_config)
        dvs_config_spec.host = dvs_host_configs
        #print('reconfigure_dvs>>>', dvs_config_spec)
        task = dvs.ReconfigureDvs_Task(dvs_config_spec)
        return wait_for_task(task, taskName, logger=self.logger)

    def detachPnicIfNotAlreadyOnDstSwitch(self, pnicName, dstSwSpec, hostName): # DistributedVirtualSwitch
        ''' dstSwSpec ::= <swType>:<swName>
                swType ::= 'V' | 'D' | 'O'
        '''
        self.logger.alert('argv: %s, %s, %s' % (pnicName, dstSwSpec, hostName))
        hostObj = HostSystem(self.vc)
        hostMos = self.vc.getByNamesGlob(vim.HostSystem, hostName)
        hostMo = hostMos[0]

        curSwSpecs, curSws, curPnicDict, curSwTypeDict, hSwDict = hostObj._curHostSws(hostMo)
        pnicAlreadyOnDstDvs = False
        dstSwType, dstSwName = dstSwSpec.split(':')

        if curPnicDict[pnicName]:   # attached to some switch
            curSwType, curSwName = curPnicDict[pnicName].split(':')
            #print(curPnicDict[pnicName], curSwType, curSwName)
            if curSwType==dstSwType and curSwName==dstSwName:
                # pnic already attached to correct switch
                return True

            if curSwType=='D':
                if curSwName!=dstSwName:
                    curDvs = self.vc.getByName(self.vimType, curSwName)
                    #curPnics = hSwDict[dstSwSpec]['pnics']
                    curPnics = hSwDict['D:'+curSwName]['pnics']
                    newPnics = updatedList(curPnics, '-'+pnicName)
                    self.logger.alert('    %s: %s => %s' % (curSwName, curPnics, newPnics))
                    msg = self.reconfigure_dvs(curDvs, hostMos, newPnics, 'edit')
                    self.logger.info(msg)
                else:
                    self.logger.info('PNIC %s already on DVS %s' % (pnicName, dstSwName))
                    pnicAlreadyOnDstDvs = True
            elif curSwType=='V':
                hostObj.vssOp('modify', [hostName], hVssDict={
                    'vssName':curSwName, 'pgNames':'', 'pnics':'~'+pnicName})
            elif curSwType=='O':
                self.logger.alert('    #### NEED TO remove PNIC %s from OPN:%s' % (
                    pnicName, curSwName))
                ### remove <pnic> from OPN <curSwName>
        self.logger.alert('RETURN: %s' % pnicAlreadyOnDstDvs)
        return pnicAlreadyOnDstDvs

    def detachPnicIfOnSwitch(self, pnicName, dstSwSpec, hostName):
        ''' dstSwSpec ::= <swType>:<swName>
                swType ::= 'V' | 'D' | 'O'
        '''
        if not dstSwSpec:
            return False

        self.logger.alert('argv: %s, %s, %s' % (pnicName, dstSwSpec, hostName))
        hostObj = HostSystem(self.vc)
        hostMos = self.vc.getByNamesGlob(vim.HostSystem, hostName)
        hostMo = hostMos[0]
        curSwSpecs, curSws, curPnicDict, curSwTypeDict, hSwDict = hostObj._curHostSws(hostMo)

        pnicDetached = False
        dstSwType, dstSwName = dstSwSpec.split(':')
        if curPnicDict[pnicName]:   # attached to some switch
            curSwType, curSwName = curPnicDict[pnicName].split(':')
            if curSwType==dstSwType and curSwName==dstSwName:
                curPnics = hSwDict[dstSwSpec]['pnics']
                newPnics = updatedList(curPnics, '-'+pnicName)
                pnicDetached = True
                #print('    %s <-> %s:%s' % (curPnicDict[pnicName], curSwType, curSwName))
                #print('    %s <:> %s' % (curSwType, dstSwType))
                #print('    %s <:> %s' % (curSwName, dstSwName))
                #print('    sws=%s'% curSws)
                self.logger.alert('    %s: %s => %s' % (dstSwSpec, curPnics, newPnics))
                if curPnics != newPnics:
                    if curSwType=='D':
                        curDvs = self.vc.getByName(self.vimType, curSwName)
                        msg = self.reconfigure_dvs(curDvs, hostMos, newPnics, 'edit')
                        self.logger.info(msg)
                        '''
                        if curSwName!=dstSwName:
                            curDvs = self.vc.getByName(self.vimType, curSwName)
                            msg = self.reconfigure_dvs(curDvs, hostMos, [pnicName], 'delete')
                            self.logger.info(msg)
                        else:
                            self.logger.info('PNIC %s already on DVS %s' % (pnicName, dstSwName))
                            pnicDetached = True
                        '''
                    elif curSwType=='V':
                        hostObj.vssOp('modify', [hostName], hVssDict={
                            'vssName':curSwName, 'pgNames':'', 'pnics':'~'+pnicName})
                        pnicDetached = True
                    elif curSwType=='O':
                        self.logger.alert('    #### NEED TO remove PNIC %s from OPN:%s' % (
                            pnicName, curSwName))
                        ### remove <pnic> from OPN <curSwName>
                        pnicDetached = True
        self.logger.alert('RETURN: %s' % pnicDetached)
        return pnicDetached





    def hostOp(self, operation, dvsName, hostsGlob, pnics='', **kwargs):    # DistributedVirtualSwitch
        ''' operation:
            add:        add host to DVS ---- use addHosts() instead
            delete:     delete host drom DVS
            setpnic:    set host pnics on DVS
            modpnic:    modify host pnics on DVS
        '''
        '''
            V:vssName,              D:dvsName,                  O:opaqueSwitchName/nvdsName
            p:porgroup[:vssName]    d:dvsPortgroup[:dvsName]    o:opaqueNetworkName[:opaqueSwitchName]

            PNIC operation on *DVS* only
             pnicInUse
                ~inDst
                     vssSrc
                        +DETACH
                        -DETACH
                     dvsSrc
                        +DETACH
                        -DETACH
                     opsSrc
                        +not implemented
                        -not implemented
                 inDst
                    +noop
                    -DETACH,noop

             dvsDstInUse
                +dstDvs.append(pnic)
            ~dvsDstInUse
                +dstDvs = [pnic]
                    '''
        argPnics = pnics
        pnics = [n.lower() for n in listify(pnics.split(',')) if n] if pnics else []
        dstDvsName = dvsName
        dstDvs = self.vc.getByName(self.vimType, dstDvsName)
        hostObj = HostSystem(self.vc)

        if not dstDvs:
            self.logger.error('DVS "%s" not found' % dvsName)
            self.logger.error('operation %s cannot proceed'%operation)
            return

        action = cptutil.def_kv_dict({'setpnic':'edit', 'modpnic':'edit'})[operation]
        #print(operation, dstDvsName, hostsGlob, pnics, kwargs)
        self.logger.info1('calling w/args=(operation=%s, dstDvsName=%s, hostsGlob=%s, pnics=%s, kwargs=%s)'%(
            operation, dstDvsName, hostsGlob, pnics, kwargs))





        '''
        pnics = 'vmnic1'
        dvs0 = dstDvs = self.vc.getByName(self.vimType, 'dvs0')
        dvs1 = dstDvs = self.vc.getByName(self.vimType, 'vds1')
        self.logger.info( self.reconfigure_dvs(dvs1, hostMos, pnics, 'delete'))
        self.logger.info( self.reconfigure_dvs(dvs0, hostMos, pnics, 'add'))
        self.logger.info( self.reconfigure_dvs(dvs0, hostMos, pnics, 'delete'))
        self.logger.info( self.reconfigure_dvs(dvs1, hostMos, pnics, 'add'))
        exit()
        '''




        hostMos = self.vc.getByNamesGlob(vim.HostSystem, hostsGlob)
        #print(hostsGlob)
        #print([h.name for h in hostMos]); exit()
        for hostMo in hostMos:
            hostName = hostMo.name
            if operation=='modpnic':
                self.logger.alert('dstDvs: %s %s'%(dstDvsName,dstDvs))
                #self.logger.alert('#### modpnic')
                #pnicSpecs = pnics
                #self.logger.alert('modpnic: dstDvsName=%s hostsGlob=%s pnics=%s kwargs=%s'%(
                #    dstDvsName, hostsGlob, pnics, kwargs))
                curSwSpecs, curSws, curPnicDict, curSwTypeDict, hSwDict = hostObj._curHostSws(hostMo)
                curPnicNames = [p.device for p in hostMo.config.network.pnic]
                #self.logger.alert('curPnicDict: %s' % pformat(curPnicDict))
                #self.logger.alert('curSwTypeDict: %s' % pformat(curSwTypeDict))
                #self.logger.alert('target: %s %s' % (pnics, dstDvsName))
                #self.logger.alert('pnics: %s' % pnics)
                #self.logger.alert('='*40)
                #newPnics = curSwTypeDict['dvs'][dstDvsName][:]




                pnicModSpecs = listify(pnics)
                for pnicModSpec in pnicModSpecs:
                    pnicAlreadyOnDstDvs = False
                    pnicOp, pnicName = pnicModSpec[0], pnicModSpec[1:] 
                    if pnicOp not in ['!', '-', '~', '+']:
                        self.logger.error('pnic spec MUST start with operator: !, -, ~, or +')
                        return
                    #print('>>>', pnicModSpec, pnicOp, pnicName)
                    if pnicOp=='+':
                        pnicAlreadyOnDstDvs = \
                            self.detachPnicIfNotAlreadyOnDstSwitch(pnicName, 'D:'+dvsName, hostMo.name)
            #pnicDict = {}
                        '''
                        if curPnicDict[pnicName]:   # attached to some switch
                            curSwType, curSwName = curPnicDict[pnicName].split(':')
                            print(curPnicDict[pnicName], curSwType, curSwName)
                            if curSwType=='D':
                                if curSwName!=dvsName:
                                    curDvs = self.vc.getByName(self.vimType, curSwName)
                                    msg = self.reconfigure_dvs(curDvs, hostMos, [pnicName], 'delete')
                                    self.logger.info(msg)
                                else:
                                    self.logger.info('PNIC %s already on DVS %s' % (pnicName, dvsName))
                                    pnicAlreadyOnDstDvs = True
                            elif curSwType=='V':
                                hostObj.vssOp('modify', hostsGlob, hVssDict={
                                    'vssName':curSwName, 'pgNames':'', 'pnics':'~'+pnicName})
                            elif curSwType=='O':
                                self.logger.alert('    #### NEED TO remove PNIC %s from OPN:%s' % (
                                    pnicName, curSwName))
                                ### remove <pnic> from OPN <curSwName>
                        '''
                        if not pnicAlreadyOnDstDvs:
                            msg = self.reconfigure_dvs(dstDvs, hostMos, [pnicName], 'edit')
                            self.logger.info(msg)
                    elif pnicOp in ['!', '-', '~']:
                        self.logger.alert('pnicName = %s'%pnicName)
                        #self.logger.alert( curSwSpecs)
                        #self.logger.alert( curSws)
                        #self.logger.alert( curPnicDict)
                        #self.logger.alert( curSwTypeDict)
                        self.logger.alert( 'PNIC %s currenly on SWITCH %s' % (pnicName, curPnicDict[pnicName]))
                        #self.logger.alert( 'SWITCH %s curPNICconfig %s' % (curPnicDict[pnicName], ))
                        self.detachPnicIfOnSwitch(pnicName, curPnicDict[pnicName], hostName)
                        #msg = self.dvsSetPnics(dstDvs, hostMos, [pnicName], 'edit')
                        #self.logger.info(msg)
            elif operation in ['setpnic', 'update']:
                #msg = self.reconfigure_dvs(dstDvs, hostMos, argPnics, action)
                msg = self.dvsSetPnics(dstDvs, hostMos, argPnics)
                self.logger.info(msg)
            elif operation in ['add', 'delete']:    # add/delete host ONLY, pnics are not handled here
                dvsHostCfgOp = vim.ConfigSpecOperation.add if operation=='add' else vim.ConfigSpecOperation.remove
                dvsConfigSpec = vim.DistributedVirtualSwitch.ConfigSpec()

                dvsHostConfig = vim.dvs.HostMember.ConfigSpec()
                dvsHostConfig.operation = dvsHostCfgOp
                dvsHostConfig.host = hostMo
                dvsHostConfig.backing = vim.dvs.HostMember.PnicBacking()
                dvsConfigSpec.host = [dvsHostConfig]
                dvsConfigSpec.configVersion = dstDvs.config.configVersion
                task = dstDvs.ReconfigureDvs_Task(dvsConfigSpec)
                waitForTask(task, '%s HOST "%s" on DVS "%s"' % (
                    operation.capitalize(), hostMo.name, dvsName), self.logger)


    def addHosts(self, dvsName, hostNames, **kwargs):
        ''' add host to dvs w/o adding pnic'''
        vimType = self.vimType
        dvs = self.vc.getByName(vimType, dvsName)

        logLevel = logging.WARNING
        logLevel = self.logger.getEffectiveLevel()
        #toaster = Toaster(self.vc.nThread, logLevel, logger=self.logger)

        #print(dvs.config.configVersion)

        pnicSpecs = []
        dvsHostConfigs = []
        dvsConfigSpec = vim.DistributedVirtualSwitch.ConfigSpec()

        '''
        dvsConfigSpec
            host = dvsHostConfigs
                dvsHostConfigs = [dvsHostConfig,...]
                    dvsHostConfig = vim.dvs.HostMember.ConfigSpec()
                        operation  = vim.ConfigSpecOperation.add
                        host = self.vc.getByName(vimDict['host'], hostName)
                        backing = vim.dvs.HostMember.PnicBacking()
                            pnicSpec = [pnicSpec0,...]
                                pnicSpec0 = vim.dvs.HostMember.PnicSpec()
                                pnicSpec0.pnicDevice = 'vmnic0'
                                pnicSpec1 = vim.dvs.HostMember.PnicSpec()
                                pnicSpec1.pnicDevice = 'vmnic1'
            configVersion = dvs.config.configVersion
        '''
        pnicDevs = ['vmnic0', 'vmnic1']
        for hostName in hostNames:
            host = self.vc.getByName(vimDict['host'], hostName)
            self.logger.alert('HOST:%s(%s) DVS:%s(%s)' % (host.name, host, dvsName, dvs))
            #pnicSpec0 = vim.dvs.HostMember.PnicSpec()
            #pnicSpec1 = vim.dvs.HostMember.PnicSpec()
            #pnicSpec0.pnicDevice = 'vmnic0'
            #pnicSpec1.pnicDevice = 'vmnic1'
            #pnicSpecs.append(pnicSpec0)
            #pnicSpecs.append(pnicSpec1)
            for pnicDev in pnicDevs:
                pnicSpec = vim.dvs.HostMember.PnicSpec()
                pnicSpec.pnicDevice = pnicDev
                pnicSpecs.append(pnicSpec)
            dvsHostConfig = vim.dvs.HostMember.ConfigSpec()
            dvsHostConfig.operation = vim.ConfigSpecOperation.add
            #dvsHostConfig.operation = vim.ConfigSpecOperation.remove
            dvsHostConfig.host = host
            dvsHostConfigs.append(dvsHostConfig)
            dvsHostConfig.backing = vim.dvs.HostMember.PnicBacking()
            #dvsHostConfig.backing.pnicSpec = pnicSpecs
            dvsConfigSpec.host = dvsHostConfigs
            dvsConfigSpec.configVersion = dvs.config.configVersion
            print(dvsConfigSpec); #exit()
            task = dvs.ReconfigureDvs_Task(dvsConfigSpec)
            waitForTask(task, 'Add hosts %s to DVS %s'%(hostNames,dvsName), self.logger)

class Folder(VS_object):
    vimType = vim.Folder

    def folderOp(self, namePattern, action=None):
        vimType = self.vimType
        folders = self.vc.getByType([vimType])

    def create(self, folderNames, folderType='', dcName=None):
        vimType = self.vimType

        if not dcName:
            dcs = self.vc.getByNamesGlob(vim.Datacenter, '*')
            if len(dcs)!=1:
                self.logger.error('Please spcify which datacenter you want to have the folder created')
                exit(102)
            dcName = dcs[0].name
        dc = self.vc.getByName(vim.Datacenter, dcName)
        if not dc:
            self.logger.error('Datacenter "%s" not found'%dcName, self.logger)

        parentFolder = eval('dc.%sFolder' % folderType)

        for folderName in folderNames:
            if self.vc.getByName(self.vimType, folderName):
                self.logger.error('folder "%s" already exist!' % folderName)
            else:
                newFolder = parentFolder.CreateFolder(folderName)
                self.logger.info('%s folder %s created: %s' % (
                    folderType, folderName, newFolder._moId))

    def moveInto(self, folderName, memberNames, dcName, memberType):
        dcMo = Datacenter(self.vc).getByName(dcName)
        folderMo = self.getByName(folderName, container=dcMo)

        memberVimType = {'vm':vim.VirtualMachine, 'host':vim.HostSystem}[memberType]
        members = self.vc.getByNamesGlob(memberVimType, memberNames)
        if not members:
            self.logger.warning('%s %s not found' % (memberType, memberNames))
        else:
            self.logger.info('Moving %s into folder %s' % (
                [(m.name,m._moId) for m in members], folderName))
            task = folderMo.MoveIntoFolder_Task(members)
            time.sleep(1)
            self.logger.info('%s %s' % (task, task.info.state))


class HostSystem(VS_object):
    vimType = vim.HostSystem
    methodDict = {
        'status':       '',
        'off':          'Shutdown',
        'reboot':       'Reboot',
        'disconnect':   'Disconnect',
        'delete':       'Destroy_Task',
        'reconnect':    'ReconnectHost_Task',
        'uptime':       'RetrieveHardwareUptime',
        'mainten_on':    'EnterMaintenanceMode',
        'mainten_off':   'ExitMaintenanceMode',
        'mainten_status':'runtime.inMaintenanceMode',
    }
    list_attrs = ['name', '_moId', 'runtime.connectionState', 'parent']

    def _connectSshClient(self, hostname, username, password):
        c = paramiko.SSHClient()
        c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        c.load_system_host_keys()
        c.connect(hostname=hostname, username=username,password=password)
        return c
    def _sshExec(self, client, cmd, fmt="read"):
        _, out, err = client.exec_command(cmd)
        status=out.channel.recv_exit_status()
        return out.read() if fmt=='read' else [str(l).strip() for l in out.readlines()]

    def getSslThumbprint(self, hostname, username='root', password='Vmware123!', display=False):
        c = self._connectSshClient(hostname=hostname,username=username,password=password)
        cmd='openssl x509 -in /etc/vmware/ssl/rui.crt -fingerprint -sha1 -noout'
        sslStr = self._sshExec(client=c, cmd=cmd).strip().split('=')[1]
        if display:
            print("%s=%s" %(hostname, sslStr))
        return sslStr

    def getDvsByHostnamesLs(self, hostnames, lsName=''):
        if not isinstance(hostnames, list):
            self.logger.error('Expecting list of hostnames, got %s' % hostnames)
        dvsSet = set({})
        dvsByHostnane = {}
        #startTm = datetime.datetime.now()
        hostDvsPgDict = {}
        for host in self.vc.getByNamesGlob(vim.HostSystem, hostnames):
            hostName  = host.name
            dvsMoidSet = set({})
            dvsByHostnane[hostName] = []
            for hNet in host.network:
                hNetName = hNet.name
                if hNetName.startswith('vxw-dvs-'):
                    reObj = re.search('vxw-(dvs-\d+)-virtualwire-\d+-sid-\d+-(.*)', hNetName)
                    pgMatch = (reObj.group(2)==lsName) if lsName else True
                    dvsMoid = reObj.group(1)
                    if (dvsMoid not in dvsMoidSet) and pgMatch:
                        dvsMo = hNet.config.distributedVirtualSwitch
                        dvsByHostnane[hostName].append(dvsMo)
                        dvsSet.add(dvsMo)
                        dvsMoidSet.add(dvsMoid)
                        hostDvsPgDict[hostName] = ((dvsMo, hNet))
                        #print('dvs,dvspg:', dvsMo.name, dvsMo._moId, hNet.name, hNet._moId, lsName)
        #print('Time: %s' % (datetime.datetime.now()-startTm))

        #pprint(hostDvsPgDict)
        return list(dvsSet), hostDvsPgDict

    '''
    def create_vmkernel_adapter0(self, host_system, port_group_name,
                                vlan_id, vswitch_name,
                                ip_address, subnet_mask,
                                mtu, enable_vsan, enable_vmotion, enable_mgmt, enable_ft):

        host_config_manager = host_system.configManager
        host_network_system = host_config_manager.networkSystem
        host_virtual_vic_manager = host_config_manager.virtualNicManager
        config = vim.host.NetworkConfig()

        config.portgroup = [vim.host.PortGroup.Config()]
        config.portgroup[0].changeOperation = "add"
        config.portgroup[0].spec = vim.host.PortGroup.Specification()
        config.portgroup[0].spec.name = port_group_name
        config.portgroup[0].spec.vlanId = vlan_id
        config.portgroup[0].spec.vswitchName = vswitch_name
        config.portgroup[0].spec.policy = vim.host.NetworkPolicy()
        print('config.portgroup[0].spec:', config.portgroup[0].spec)

        config.vnic = [vim.host.VirtualNic.Config()]
        config.vnic[0].changeOperation = "add"
        config.vnic[0].portgroup = port_group_name
        config.vnic[0].spec = vim.host.VirtualNic.Specification()
        config.vnic[0].spec.ip = vim.host.IpConfig()
        config.vnic[0].spec.ip.dhcp = False
        config.vnic[0].spec.ip.ipAddress = ip_address
        config.vnic[0].spec.ip.subnetMask = subnet_mask
        if mtu:
            config.vnic[0].spec.mtu = mtu

        host_network_config_result = host_network_system.UpdateNetworkConfig(config, "modify")

        for vnic_device in host_network_config_result.vnicDevice:
            if enable_vsan:
                vsan_system = host_config_manager.vsanSystem
                vsan_config = vim.vsan.host.ConfigInfo()
                vsan_config.networkInfo = vim.vsan.host.ConfigInfo.NetworkInfo()

                vsan_config.networkInfo.port = [vim.vsan.host.ConfigInfo.NetworkInfo.PortConfig()]

                vsan_config.networkInfo.port[0].device = vnic_device
                host_vsan_config_result = vsan_system.UpdateVsan_Task(vsan_config)

            if enable_vmotion:
                host_virtual_vic_manager.SelectVnicForNicType("vmotion", vnic_device)

            if enable_mgmt:
                host_virtual_vic_manager.SelectVnicForNicType("management", vnic_device)

            if enable_ft:
                host_virtual_vic_manager.SelectVnicForNicType("faultToleranceLogging", vnic_device)
        return True
    '''

    def opaqueSwitchOp(self, op, hostNamesGlob=['*'], hopswDict={}):    # HostSystem
        ''' op: list '''
        ptbl = PrettyTable(['host', 'opaqueSwitch', 'pnic', 'vtep', 'status', 'opaqueNetwork'])
        ptbl.align = 'l'
        hostMos = sorted(self.getByNamesGlob(listify(hostNamesGlob)),
                key=lambda h:cptutil.alnum_keys(h.name))
        for hostMo in hostMos:
            hcNet = hostMo.config.network if hostMo.config else {}
            if op=='list':
                opNets = ',\n'.join([opNet.opaqueNetworkName for opNet in hcNet.opaqueNetwork])
                for ops in hcNet.opaqueSwitch:
                    pnics = ',\n'.join(
                        [pnKey.replace('key-vim.host.PhysicalNic-','') for pnKey in ops.pnic])
                    vteps = ',\n'.join([vtep.device for vtep in ops.vtep])
                    ptbl.add_row([hostMo.name, ops.name, pnics, vteps, ops.status, opNets])
        if op=='list':
            print(ptbl)

    def vssOp(self, op, hostNamesGlob=['*'], hVssDict={}):              # HostSystem
        ''' op: list, add, delete '''
        ''' https://github.com/rreubenur/vmware-pyvmomi-examples/blob/master/create_vswitch_and_portgroup.py '''

        def addVssPg(self, hostMo, vssName, pgName):
            print('>>>>>>>>>>>>>>>>>>>>>>>')
            for vss in [vss for vss in hostMo.config.network.vswitch if vssName == vss.name]:
                vssPgNames = [str(pg).replace('key-vim.host.PortGroup-','') for pg in vss.portgroup]
                if pgName in vssPgNames:
                    self.logger.error('PORTGROUP "%s" already exist on VSS "%s"' %
                        (pgName, vssName))
                    return False
            self.logger.info('Creating PortGroup "%s"' % pgName)
            pgSpec = vim.host.PortGroup.Specification()
            pgSpec.name = pgName
            pgSpec.vlanId = 0
            pgSpec.vswitchName = vssName
            security_policy = vim.host.NetworkPolicy.SecurityPolicy()
            security_policy.allowPromiscuous = True
            security_policy.forgedTransmits = True
            security_policy.macChanges = False
            pgSpec.policy = vim.host.NetworkPolicy(security=security_policy)

            hostMo.configManager.networkSystem.AddPortGroup(portgrp=pgSpec)
            self.logger.info('Created  PortGroup "%s"' % pgName)
            return True

        def deleteVssPg(self, hostMo, vssName, pgName):
            #### THIS IS NOT WORKING YET ####
            for vss in [vss for vss in hostMo.config.network.vswitch if vssName == vss.name]:
                vssPgNames = [str(pg).replace('key-vim.host.PortGroup-','') for pg in vss.portgroup]
                if pgName not in vssPgNames:
                    self.logger.warning('PORTGROUP "%s" does not exist on VSS "%s"' %
                        (pgName, vssName))
                    return False
            self.logger.info('Deleting PORTGROUP "%s" on VSS "%s"' % (pgName,vssName))
            hostMo.configManager.networkSystem.RemovePortGroup(pgName=pgName)
            self.logger.info('Deleted  PORTGROUP "%s" on VSS "%s"' % (pgName,vssName))
            return True

        ptbl = PrettyTable(['host', 'vss', 'pnic', 'portgroup'])
        ptbl.align = 'l'
        for hostMo in sorted(self.getByNamesGlob(listify(hostNamesGlob)),
                key=lambda h:cptutil.alnum_keys(h.name)):
            hName = hostMo.name
            hcNet = hostMo.config.network if hostMo.config else {}
            curVssNames =  [s.name for s in hcNet.vswitch]
            if op=='list':
                for vss in hcNet.vswitch:
                    pnics = ','.join(vss.spec.bridge.nicDevice) if vss.spec.bridge else ''
                    #pgs = ',\n'.join(sorted([str(pg).split('-')[-1] for pg in vss.portgroup]))
                    pgs = ',\n'.join(sorted([str(pg).replace('key-vim.host.PortGroup-','')
                        for pg in vss.portgroup]))
                    ptbl.add_row([hName, vss.name, pnics, pgs])
            elif op=='add':
                host_network_system = hostMo.configManager.networkSystem
                vssName = hVssDict['vssName']
                pnics = hVssDict['pnics']
                pgNames = hVssDict['pgNames']

                if vssName in [s.name for s in hcNet.vswitch]:
                    self.logger.error('VSS "%s" already exist'%vssName)
                    return

                self.logger.info('Creating vSwitch "%s"'%vssName)
                vss_spec = vim.host.VirtualSwitch.Specification()
                vss_spec.numPorts = hVssDict.get('nport', 128)
                if hVssDict.get('mtu'):
                    vss_spec.mtu = hVssDict.get('mtu')
                if pnics:
                    vss_spec.bridge = vim.host.VirtualSwitch.BondBridge(nicDevice=pnics)
                    vss_spec.bridge.linkDiscoveryProtocolConfig = vim.host.LinkDiscoveryProtocolConfig()
                    vss_spec.bridge.linkDiscoveryProtocolConfig.protocol = 'cdp'
                    vss_spec.bridge.linkDiscoveryProtocolConfig.operation = 'listen'
                    vss_spec.bridge.beacon = vim.host.VirtualSwitch.BeaconConfig()
                    vss_spec.bridge.beacon.interval = 1
                #print('vss_spec:', vss_spec)
                host_network_system.AddVirtualSwitch(vswitchName=vssName, spec=vss_spec)
                for pgName in pgNames:
                    addVssPg(self, hostMo, vssName, pgName)
                self.logger.info('Created  vSwitch "%s"'%vssName)
            elif op=='modify':
                host_network_system = hostMo.configManager.networkSystem
                vssName = hVssDict['vssName']
                #pprint(hVssDict); print('<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<')
                pgNames = hVssDict['pgNames']
                pnicModSpecs = hVssDict['pnics']   ; # list of [+/-/!]pnics
                #self.logger.alert('pnicModSpecs: %s %s' % (pnicModSpecs, isinstance(pnicModSpecs, list)))
                if not isinstance(pnicModSpecs, list):
                    pnicModSpecs = pnicModSpecs.split(',')
                #self.logger.alert('pnicModSpecs: %s %s' % (pnicModSpecs, isinstance(pnicModSpecs, list)))

                for pnicModSpec in pnicModSpecs:
                    self.logger.alert('pnicModSpec: %s' % pnicModSpec )
                    pnOp, pnName = pnicModSpec[0], pnicModSpec[1:]
                    if pnOp not in ['!', '-', '~', '+']:
                        self.logger.error('pnic spec ("%s") MUST start with operator: !, -, ~, or +' % pnicModSpec)
                        return
                    if pnOp=='+':
                        self.pnicDetachIfNotOnTargetSwitch([hName], [pnName], 'V:'+vssName)

                hcNet = hostMo.config.network if hostMo.config else {}
                vssCadidates = [vss for vss in hcNet.vswitch if vss.name==vssName]
                if not vssCadidates:
                    self.logger.error('VSS "%s" not found"'%vssName)
                    return
                vss = vssCadidates[0]
                curPnics = [str(n) for n in vss.spec.bridge.nicDevice] if vss.spec.bridge else []
                newPnics = updatedList(curPnics, pnicModSpecs) 

                if curPnics != newPnics:
                    self.logger.info('Modifying VSWITCH "%s" PNIC "%s" => "%s"'%
                        (vssName,','.join(curPnics),','.join(newPnics)))
                    vss_spec = vim.host.VirtualSwitch.Specification()
                    vss_spec.numPorts = hVssDict.get('nport', 128)
                    if newPnics:
                        vss_spec.bridge = vim.host.VirtualSwitch.BondBridge(nicDevice=newPnics)
                        vss_spec.bridge.linkDiscoveryProtocolConfig = vim.host.LinkDiscoveryProtocolConfig()
                        vss_spec.bridge.linkDiscoveryProtocolConfig.protocol = 'cdp'
                        vss_spec.bridge.linkDiscoveryProtocolConfig.operation = 'listen'
                        vss_spec.bridge.beacon = vim.host.VirtualSwitch.BeaconConfig()
                        vss_spec.bridge.beacon.interval = 1
                    #print('vss_spec:', vss_spec)
                    #print('vssName:', vssName)
                    host_network_system.UpdateVirtualSwitch(vswitchName=vssName, spec=vss_spec)
                    self.logger.info('Modified  VSWITCH "%s" PNIC "%s" => "%s"'%
                        (vssName,','.join(curPnics),','.join(newPnics)))

                for pgName in pgNames:
                    pgOp, pgName = pgName[0], pgName[1:]
                    if pgOp not in ['!', '-', '~', '+']:
                        self.logger.error('PORTGROUP spec ("%s") MUST start with operator: !, -, ~, or +' % pgName)
                        return
                    if pgOp == '+':
                        opCompeted = addVssPg(self, hostMo, vssName, pgName)
                    if pgOp in ['!', '-', '~']:
                        opCompeted = deleteVssPg(self, hostMo, vssName, pgName)
            elif op=='delete':
                vssName = hVssDict['vssName']
                if vssName not in curVssNames:
                    self.logger.error('VSS "%s" not found in HOST "%s"'%(vssName,hName))
                else:
                    self.logger.info('Deleting vSwitch "%s"'%vssName)
                    host_network_system = hostMo.configManager.networkSystem
                    host_network_system.RemoveVirtualSwitch(vswitchName=hVssDict['vssName'])
                    self.logger.info('Deleted  vSwitch "%s"'%vssName)
        if op=='list':
            print(ptbl)

    def netstackOp(self, op, hostNamesGlob=['*']):                      # HostSystem
        ''' op: list '''

        ptbl = PrettyTable(['host', 'netstack', 'state', 'vmk'])
        ptbl.align = 'l'
        for hostMo in sorted(self.getByNamesGlob(listify(hostNamesGlob)),
                key=lambda h:cptutil.alnum_keys(h.name)):
            if op=='list':
                hVnicCfg = hostMo.runtime.networkRuntimeInfo.netStackInstanceRuntimeInfo
                hNss, hStates, hVmks = [], [], []
                for ns in hVnicCfg:
                    hNss.append(ns.netStackInstanceKey)
                    hStates.append(ns.state)
                    hVmks.append(','.join(ns.vmknicKeys))
                ptbl.add_row([hostMo.name, '\n'.join(hNss), '\n'.join(hStates),
                    '\n'.join(hVmks)])
        if op=='list':
            print(ptbl)

    def addModVmk(self, op, host, vmkDict={}):
        opDict = {'oping': 'Creating', 'oped': 'Created'} if op=='add' else \
            {'oping': 'Modifying', 'oped': 'Modified'}

        nic = vim.host.VirtualNic.Specification()
        if op == 'add':
            vmkMtu = vmkDict['vmkMtu']
            vmkIp = vmkDict['vmkIp']
            vmkNetmask = vmkDict['vmkNetmask']
            if vmkIp and not vmkDict['vmkNetmask']:
                vmkNetmask = cptutil.ipNetmaskDefault(vmkIp)
            nic.ip = vim.host.IpConfig(dhcp=(not vmkIp), ipAddress=vmkIp, subnetMask=vmkNetmask)
        elif op == 'modify':
            vmkName = vmkDict['vmkName']
            vnics = host.config.network.vnic
            vnic = [n for n in host.config.network.vnic if n.device==vmkName][0]
            #print('addModVmk() vnic=',vnic)
            #print('addModVmk() vmkDict=')
            #pprint(vmkDict)
            vmkMtu = vmkDict['vmkMtu'] or vnic.spec.mtu
            if vmkDict['vmkIp']:
                vmkIp = vmkDict['vmkIp']
                vmkNetmask = vmkDict['vmkNetmask']
                if vmkIp and not vmkDict['vmkNetmask']:
                    vmkNetmask = cptutil.ipNetmaskDefault(vmkIp)
                nic.ip = vim.host.IpConfig(dhcp=(not vmkIp), ipAddress=vmkIp, subnetMask=vmkNetmask)
            else:
                nic.ip = vnic.spec.ip

        netType, netName = vmkDict['vmkNetspec'].split(':')
        #print(netType, netName)

        host_config_manager =      host.configManager
        host_network_system =      host.configManager.networkSystem
        host_virtual_vic_manager = host_config_manager.virtualNicManager

        pgName = ''
        if netType=='o':    # opaqueNetwork, nsxt
            self.logger.info('%s VMKernel adapter on opaque network "%s"' % (opDict['oping'], netName))
            opnet = self.vc.getByNamesGlob(vim.OpaqueNetwork, netName)[0]
            nic.opaqueNetwork = vim.host.VirtualNic.OpaqueNetworkSpec()
            nic.opaqueNetwork.opaqueNetworkId = opnet.summary.opaqueNetworkId
            nic.opaqueNetwork.opaqueNetworkType = opnet.summary.opaqueNetworkType
        elif netType=='d':  # dvsPortgroup
            dvpg = self.vc.getByNamesGlob(vim.dvs.DistributedVirtualPortgroup, netName)[0]
            dvs = dvpg.config.distributedVirtualSwitch
            self.logger.info('%s VMKernel adapter on DVS portgroup "%s"' % (opDict['oping'], netName))
            nic.distributedVirtualPort = vim.dvs.PortConnection()
            nic.distributedVirtualPort.switchUuid = dvs.uuid
            nic.distributedVirtualPort.portgroupKey = dvpg.key
        elif netType in ['v','n','p']:
            self.logger.info('%s VMKernel adapter on VSS portgroup "%s"' % (opDict['oping'], netName))
            nic.portgroup = netName
            pgName = netName

        if vmkDict.get('svcVmot')=='on':
            nic.netStackInstanceKey="vmotion"
        if vmkDict.get('svcProv')=='on':
            nic.netStackInstanceKey="vSphereProvisioning"
        #print('>>>>> netName=%s, pgName=%s', (netName, pgName))
        #print('>>>>> nic', nic)
        if op=='add':
            vmkName = host_network_system.AddVirtualNic(portgroup=pgName, nic=nic)
        elif op == 'modify':
            host_network_system.UpdateVirtualNic(device=vmkName, nic=nic)
        self.logger.info ("%s  VMKernel adapter %s on host %s" % (opDict['oped'], vmkName, host.name))

        if vmkDict.get('svcVsan')=='on':
            cfg = vim.vsan.host.ConfigInfo()
            pcfg=vim.vsan.host.ConfigInfo.NetworkInfo.PortConfig(device=vmkName)
            cfg.networkInfo = vim.vsan.host.ConfigInfo.NetworkInfo(port=[pcfg])
            vsn = host.configManager.vsanSystem
            vsn.UpdateVsan_Task(cfg)
            self.logger.info("Enabled vsan on %s on host %s" %(vmkName, host.name))

        if vmkDict.get('svcMgmt')=='on':
            host_virtual_vic_manager.SelectVnicForNicType('management', vmkName)
        if vmkDict.get('svcFtLog')=='on':
            host_virtual_vic_manager.SelectVnicForNicType('faultToleranceLogging', vmkName)
        if vmkDict.get('svcRep')=='on':
            host_virtual_vic_manager.SelectVnicForNicType('vSphereReplication', vmkName)
        if vmkDict.get('svcRepNfc')=='on':
            host_virtual_vic_manager.SelectVnicForNicType('vSphereReplicationNFC', vmkName)
        #if vmkDict.get('svcVsan')=='on':
        #    host_virtual_vic_manager.SelectVnicForNicType('vsan', vmkName)
        #if vmkDict.get('svcProv')=='on':
        #    host_virtual_vic_manager.SelectVnicForNicType('vSphereProvisioning', vmkName)
        #if vmkDict.get('svcVmot')=='on':
        #    host_virtual_vic_manager.SelectVnicForNicType('vmotion', vmkName)

    def _curHostSws(self, host):                                                # HostSystem
        hcNet = host.config.network if host.config else {}
        #self.logger.notice('vss=%s'%[(s.name,s.pnic) for s in hcNet.vswitch])
        #self.logger.notice('dvs=%s'%[(s.dvsName, s.pnic) for s in hcNet.proxySwitch])
        #self.logger.notice('opn=%s'%[(s.name, s.pnic) for s in hcNet.opaqueSwitch])
        curPnicNames = [p.device for p in host.config.network.pnic]

        swSpecs = []                                # ["<swType>:<swName>"}
        sws = []                                    # [switchMo] :: swMo
        hSwDict = {}                                # {"<swType>:<swName>":swMo}
        pnicDict = {p:None for p in curPnicNames}   # {pnicName:"<swType>:<swName>"}
        swTypeDict = {'vss':{}, 'dvs':{}, 'opn':{}} # {"swType":[swName]}  type=('vss', 'dvs', opn')

        for swName,pnics,vss in [(s.name, s.pnic, s) for s in hcNet.vswitch]:
            swSpec = 'V:%s'%swName
            swSpecs.append(swSpec)
            sws.append(vss)
            #print('>>>>>>>%s :- %s'%(swSpec,swName))
            pnicNames = [str(pnic).replace('key-vim.host.PhysicalNic-','')
                for pnic in pnics]
            hSwDict[swSpec] = {'mo':vss,'name':swName,'type':'vss','pnics':pnicNames}
            swTypeDict['vss'][swName] = pnicNames
            #print('VSS %s %s %s' % (swName,pnics,pnicNames))
            for pnicName in  pnicNames:
                pnicDict[pnicName] = swSpec
        for swName,pnics,dvs in [(s.dvsName, s.pnic, s) for s in hcNet.proxySwitch]:
            swSpec = 'D:%s'%swName
            swSpecs.append(swSpec)
            sws.append(dvs)
            #print('>>>>>>>%s :- %s'%(swSpec,swName))
            pnicNames = [str(pnic).replace('key-vim.host.PhysicalNic-','')
                for pnic in pnics]
            hSwDict[swSpec] = {'mo':dvs,'name':swName,'type':'dvs','pnics':pnicNames}
            swTypeDict['dvs'][swName] = pnicNames
            #print('DVS %s %s %s' % (swName,pnics, pnicNames))
            for pnicName in  pnicNames:
                pnicDict[pnicName] = swSpec
        for swName,pnics,ops in [(s.name, s.pnic, s) for s in hcNet.opaqueSwitch]:
            swSpec = 'O:%s'%swName
            swSpecs.append(swSpec)
            sws.append(ops)
            #print('>>>>>>>%s :- %s'%(swSpec,swName))
            pnicNames = [str(pnic).replace('key-vim.host.PhysicalNic-','')
                for pnic in pnics]
            hSwDict[swSpec] = {'mo':ops,'name':swName,'type':'ops','pnics':pnicNames}
            swTypeDict['ops'][swName] = pnicNames
            #print('OPS %s %s %s' % (swName,pnics, pnicNames))
            for pnicName in  pnicNames:
                pnicDict[pnicName] = swSpec
        #print('>> keys = %s'%
        return swSpecs, sws, pnicDict, swTypeDict, hSwDict

    def pnicDetachIfNotOnTargetSwitch(self, hostNamesGlob=[], pnicNames=[], swSpec=''): # HostSystem
        if not isinstance(pnicNames,list):
            pnicNames = pnicNames.split(',')
        hostObj = HostSystem(self.vc)
        hostMos = self.vc.getByNamesGlob(vim.HostSystem, hostNamesGlob)
        dvsObj = DistributedVirtualSwitch(self.vc)

        swType, swName = swSpec.split(':')

        for hostMo in hostMos:
            curSwSpecs, curSws, curPnicDict, curSwTypeDict, hSwDict = self._curHostSws(hostMo)
            #self.logger.alert('pnicNames=%s' % pnicNames)
            for pnicName in pnicNames:
                self.logger.alert('pnicName=%s %s curPnicDict=%s' % (pnicName, pformat(curPnicDict), (pnicName in curPnicDict)))
                if pnicName in curPnicDict and curPnicDict[pnicName]:
                    # pnicName is currently in use
                    #self.logger.alert('===> curPnicDict[%s] = %s' % (pnicName,curPnicDict[pnicName]))
                    curSwType, curSwName = curPnicDict[pnicName].split(':')
                    #self.logger.alert('===> swSpec = %s' % (swSpec))
                    if swSpec == curPnicDict[pnicName]: continue

                    self.logger.alert('#### - DETACH  %s from %s' % (pnicName, curPnicDict[pnicName]))
                    curSwType, curSwName = curPnicDict[pnicName].split(':')
                    #if swType==curSwType and swName==curSwName: continue
                    if curSwType=='V':
                        self.logger.info('Detaching PNIC "%s" from VSS "%s"' % (pnicName, curSwName))
                        hVssDict={'vssName':curSwName, 'pgNames':[], 'pnics':['!'+pnicName]}
                        #self.logger.alert('modify', hostMo.name, hVssDict)
                        hostObj.vssOp('modify', hostMo.name, hVssDict=hVssDict)
                    elif curSwType=='D':
                        self.logger.info(
                            'Detaching PNIC "%s" from DVS "%s"' % (pnicName, curSwName))
                        curSwTypeDict['dvs'][curSwName] = updatedList(curSwTypeDict['dvs'][curSwName],  '!'+pnicName)
                        curDvs = self.vc.getByName(vim.DistributedVirtualSwitch, curSwName)
                        #self.logger.alert('curSwName=%s    curDvs=%s' % (curSwName,curDvs))

                        dvsObj.reconfigure_dvs(curDvs, hostMo, 
                            curSwTypeDict['dvs'][curSwName], 'edit')
                    elif curSwType=='O':
                        self.logger.warning('PNIC "%s" currently attached to opaqueSwitch "%" cannot detach'
                            % (pnicName, curSwName))
                        operation = 'noop'
                        continue
                else:
                    self.logger.info('PNIC "%s" is not attached to any switch' % pnicName)

    def pnicDetach(self, hostNamesGlob=[], pnicNames=[]):                       # HostSystem
        #### ????????????????????????????????????????????? ####
        self.pnicDetachIfNotOnTargetSwitch(hostNamesGlob, pnicNames, swSpec=':')
        return
        if not isinstance(pnicNames,list):
            pnicNames = pnicNames.split(',')
        self.logger.notice('(hostNames=%s pnicNames=%s)' % (hostNamesGlob, pnicNames))
        dvsObj = DistributedVirtualSwitch(self.vc)
        hostObj = HostSystem(self.vc)
        hostMos = self.vc.getByNamesGlob(vim.HostSystem, hostNamesGlob)
        for hostMo in hostMos:
            curSwSpecs, curSws, curPnicDict, curSwTypeDict, hSwDict = self._curHostSws(hostMo)
            for pnicName in pnicNames:
                #print('#### pnicName=%s' % pnicName)
                if pnicName in curPnicDict:
                    # pnicName is currently in use
                    curSwType, curSwName = curPnicDict[pnicName].split(':')
                    #print('===> PNIC=%s curSwType=%s curSwName=%s' % (pnicName, curSwType, curSwName))
                    #print('#### - DETACH  %s from %s' % (pnicName, curPnicDict[pnicName]))
                    curSwType, curSwName = curPnicDict[pnicName].split(':')
                    if curSwType=='V':
                        self.logger.info('Detaching PNIC "%s" from VSS "%s"' % (pnicName, curSwName))
                        hVssDict={'vssName':curSwName, 'pgNames':[], 'pnics':['!'+pnicName]}
                        #print('modify', hostMo.name, hVssDict)
                        hostObj.vssOp('modify', hostMo.name, hVssDict=hVssDict)
                    elif curSwType=='D':
                        self.logger.info(
                            'Detaching PNIC "%s" from DVS "%s"' % (pnicName, curSwName))
                        curSwTypeDict['dvs'][curSwName] = updatedList(curSwTypeDict['dvs'][curSwName],  '!'+pnicName)
                        curDvs = self.vc.getByName(vim.DistributedVirtualSwitch, curSwName)
                        #print('curSwName=%s    curDvs=%s' % (curSwName,curDvs))

                        dvsObj.reconfigure_dvs(curDvs, hostMo, 
                            curSwTypeDict['dvs'][curSwName], 'edit')
                    elif curSwType=='O':
                        self.logger.warning('PNIC "%s" currently attached to opaqueSwitch "%" cannot detach'
                            % (pnicName, curSwName))
                        operation = 'noop'
                        continue
                else:
                    self.logger.info('PNIC "%s" is not attached to any switch' % pnicName)

    def pnicOp(self, hostNamesGlob=['*'], pnicNames=[], pnicDict={}):   # HostSystem
        self.logger.notice('pnicOp(%s, %s, %s' % (hostNamesGlob, pnicNames, pnicDict))
        swType, swName = pnicDict['netSpec'].split(':')
        swType = swType.upper()

        if swType=='V':
            '''
            hostMos = sorted(self.getByNamesGlob(listify(hostNamesGlob)),
                    key=lambda h:cptutil.alnum_keys(h.name))
            for hostMo in hostMos:
                hVssDict={'vssName':swName, 'pgNames':[], 'pnics':pnicNames}
                print('modify', hostMo.name, hVssDict)
                self.vssOp('modify', hostMo.name, hVssDict=hVssDict)
            '''
            self.pnicDetachIfNotOnTargetSwitch(hostNamesGlob,
                pnicNames=[p.strip('+-!~') for p in pnicNames], swSpec='V:'+swName)
            hVssDict={'vssName':swName, 'pgNames':[], 'pnics':pnicNames}
            print('modify', hostNamesGlob, hVssDict)
            self.vssOp('modify', hostNamesGlob, hVssDict=hVssDict)
        elif swType=='D':
            dvsObj = DistributedVirtualSwitch(self.vc)
            print('dvsObj.hostOp("modpnic", %s, %s, %s') % (swName, hostNamesGlob, pnicNames)
            dvsObj.hostOp('modpnic', swName, hostNamesGlob, pnicNames)


    def vmkOp(self, op, hostNamesGlob=['*'], vmkNames=[], vmkDict={}):      # HostSystem
        ''' op: list, create, modify, delete '''

        #print('vmkop():', op, hostNamesGlob, vmkNames, vmkDict)
        vmkNames = listify(vmkNames)
        ptbl = PrettyTable(['host', 'vmk', 'ip', 'ipStack', 'MTU', 'network', 'service'],
            sortby='vmk',
            sort_key=operator.itemgetter(1, 0))
        ptbl.align = 'l'

        opnets = []
        for hostMo in sorted(self.getByNamesGlob(listify(hostNamesGlob)),
                key=lambda h:cptutil.alnum_keys(h.name)):
            # https://github.com/ansible/ansible/blob/devel/lib/ansible/modules/cloud/vmware/vmware_vmkernel.py
            # addVmkToHost.py  -v vcChowsHtb -u administrator@vsphere.local -p 'Vmware123!' -d htb -g 'VM Network' -t vmotion -s 10.33.86.2 --dvs ds-emu --pg DPortGroup

            #hNet = hostMo.network
            vnics = hostMo.config.network.vnic
            if op=='list':
                hVnicCfg = hostMo.configManager.virtualNicManager.info.netConfig
                nTypeVnics = ([(n.nicType,n.selectedVnic) for n in hVnicCfg])
                #print('<<<<<<'); pprint(nTypeVnics); print('>>>>>>')
                for vnic in vnics:
                    vnicSpec = vnic.spec
                    #print('>>>', vnicSpec)
                    dvpgMoid = vnicSpec.distributedVirtualPort.portgroupKey \
                        if vnicSpec.distributedVirtualPort else None
                    opnetId = vnicSpec.opaqueNetwork.opaqueNetworkId if vnicSpec.opaqueNetwork else None
                    #print('>>>', dvpgMoid, type(dvpgMoid), vnicSpec.portgroup, vnicSpec.opaqueNetwork)
                    #print('>>>', vnicSpec.portgroup, vnicSpec.opaqueNetwork)

                    dvsDvpgName = None
                    if dvpgMoid:
                        dvpg = self.vc.moid2mo(dvpgMoid) if dvpgMoid else None
                        dvsDvpgName = '%s/%s'%(
                            dvpg.config.distributedVirtualSwitch.name, dvpg.name)
                    if opnetId:
                        opnets = opnets or self.vc.getByNamesGlob(vim.OpaqueNetwork, '*')
                        opnet = [n for n in opnets if n.summary.opaqueNetworkId==opnetId][0]
                        opnetName = opnet.name

                    ipSpec = vnicSpec.ip
                    vmkConn = 'DVPG:  %s'%dvsDvpgName if dvpgMoid else (
                        'PG:    %s'%vnicSpec.portgroup if vnicSpec.portgroup else 
                        'opNet: %s'%opnetName)

                    vnicName = vnic.device
                    vmkSvcs = []
                    for nType,nKeys in nTypeVnics:
                        vmkSvcs += [nType for nKey in nKeys if nKey.endswith(vnicName)]
                    vmkSvcs = ',\n'.join(vmkSvcs)

                    ptbl.add_row([hostMo.name, vnic.device,
                        '%s/%s'%(ipSpec.ipAddress,cptutil.netmask_to_cidr(ipSpec.subnetMask)),
                        vnicSpec.netStackInstanceKey, vnicSpec.mtu, vmkConn, vmkSvcs])
            elif op=='create':
                #netSpec = 'o:VLAN2002'
                #netSpec = 'p:Management Network'
                #netSpec = 'p:VM Network'
                #netSpec = 'd:DVS1-VLAN2002'
                #vmkDict['vmkNetspec'] = netSpec
                #pprint(vmkDict)
                self.addModVmk('add', hostMo, vmkDict=vmkDict)
            elif op=='modify':
                self.addModVmk('modify',hostMo, vmkDict=vmkDict)
            elif op=='delete':
                self.logger.info('Deleting VMKernel adapter "%s"' % vmkDict['vmkName'])
                hostMo.configManager.networkSystem.RemoveVirtualNic(device=vmkDict['vmkName'])
                self.logger.info('Deleted  VMKernel adapter "%s"' % vmkDict['vmkName'])

        if op=='list':
            print(ptbl)
            '''
            create_vmkernel_adapter(hostMo, 'VM Network',
                            0, 'VM Network',
                            '192.168.22.1', '255.255.255.0',
                            1500, False, True, True, False)
            create_vmkernel_adapter(host_system, port_group_name,
                            vlan_id, vswitch_name,
                            ip_address, subnet_mask,
                            mtu, enable_vsan, enable_vmotion, enable_mgmt, enable_ft):
            networkSystem = hostMo.configManager.networkSystem
            nic = vim.host.VirtualNic.Specification()
            #nic.netStackInstanceKey = "vmotion" # "vsan" "defaultTcpipStack" "vSphereProvisioning"
            if op=='add':
                vmk = networkSystem.AddVirtualNic(portgroup='', nic=nic)
                pass
            elif op=='delete':
                pass
            '''

    def get(self, nameGlob, getChoice=None, outFmt='table'):            # HostSystem
        objs = self.vc.getByType(self.vimType)

        #self.nic('add', '10.33.86.2'); exit()

        ptbl = PrettyTable()
        ptbl_j = PrettyTable()
        if getChoice == 'status':
            ptbl.field_names = ['host', 'moId', 'bootTime', 'connState', 'maintMode', 'pwdState']
        elif getChoice == 'config':
            ptbl.field_names = ['host', 'vendor', 'model', 'thread', 'core', 'socket', 'ramGB']
        elif getChoice == 'network':
            ptbl.field_names = ['host', 'defaultGW', 'pnic', 'vmk']
        elif getChoice == 'pnic':
            ptbl.field_names = ['host', 'pnic', 'speed(Mb)', 'switch']
            ptbl_j.field_names = ptbl.field_names
        elif getChoice == 'storage':
            ptbl.field_names = ['host', 'name/type']
        elif getChoice == 'vmlist':
            ptbl.field_names = ['host', 'vmMoid/vmName']
        elif getChoice == 'vmautostart':
            ptbl.field_names = ['host', 'startAction', 'startOrder', 'startDelay', 'stopAction', 'stopDelay']
        ptbl.align        = ptbl_j.align        = 'l'
        ptbl.float_format = ptbl_j.float_format = '5.1'

        nHost = 0
        for host in sorted(objs, key=lambda x: x.__getattribute__('name')):
            if not isGlobMatched(nameGlob, host.name): continue
            nHost += 1
            hName, hMoid = host.name, host._moId
            if getChoice == 'status':
                ptbl.add_row([
                    hName,
                    str(host._moId),
                    str(host.runtime.bootTime),
                    host.runtime.connectionState,
                    ('OUT', 'IN')[host.runtime.inMaintenanceMode],
                    host.runtime.powerState])
            elif getChoice == 'config':
                hostConfigOption = host.config.option
                hostHardware = host.hardware
                hostHardwareSystemInfo = hostHardware.systemInfo
                hostHardwareCpuInfo =   hostHardware.cpuInfo
                ptbl.add_row([
                    hName,
                    hostHardwareSystemInfo.vendor,
                    hostHardwareSystemInfo.model,
                    hostHardwareCpuInfo.numCpuThreads,
                    hostHardwareCpuInfo.numCpuCores,
                    hostHardwareCpuInfo.numCpuPackages,
                    hostHardware.memorySize/1024/1024/1024.0])
            elif getChoice == 'pnic':
                hcNet = host.config.network if host.config else {}
                pnicDict = {
                    pnic.key:{'switch':'',
                    'speed':(str(pnic.linkSpeed.speedMb) if pnic.linkSpeed else '')
                } for pnic in hcNet.pnic}

                #print('==================='); pprint(pnicDict)
                for sw,nics in [(s.name,s.pnic) for s in hcNet.vswitch]:
                    for nic in nics:
                        pnicDict[nic]['switch'] = 'VSS:   %s' % sw
                for sw,nics in [(s.dvsName, s.pnic) for s in hcNet.proxySwitch]:
                    for nic in nics:
                        pnicDict[nic]['switch'] = 'DVS:   %s' % sw
                for sw,nics in [(s.name, s.pnic) for s in hcNet.opaqueSwitch]:
                    for nic in nics:
                        pnicDict[nic]['switch'] = 'OPNET: %s' % sw
                #print('-------------------'); pprint(pnicDict)

                pnic_s, speed_s, switch_s = [], [], []
                for pnicKey in sorted(pnicDict):
                    pnic = pnicKey.split('-')[-1]
                    ptbl_j.add_row([hName, pnic, pnicDict[pnicKey]['speed'], pnicDict[pnicKey]['switch']])
                    speed_s.append(pnicDict[pnicKey]['speed'])
                    pnic_s.append(pnic)
                    switch_s.append(pnicDict[pnicKey]['switch'])
                ptbl.add_row([hName, '\n'.join(pnic_s), '\n'.join(speed_s), '\n'.join(switch_s)])

            elif getChoice == 'network':
                '''
                config.network.vnic["key-vim.host.VirtualNic-vmk0"].spec.ip.HostIpConfig
                config.network.vnic["key-vim.host.VirtualNic-vmk0"].spec.HostVirtualNicSpec.mtu
                config.network.vnic["key-vim.host.VirtualNic-vmk0"].spec.HostVirtualNicSpec.netStackInstanceKey
                runtime.networkRuntimeInfo.netStackInstanceRuntimeInfo.HostRuntimeInfoNetStackInstanceRuntimeInfo[]
                runtime.networkRuntimeInfo.netStackInstanceRuntimeInfo.HostRuntimeInfoNetStackInstanceRuntimeInfo[].netStackInstanceKey
                runtime.networkRuntimeInfo.netStackInstanceRuntimeInfo.HostRuntimeInfoNetStackInstanceRuntimeInfo[].vmknicKeys
                '''
                vmkPtbl = PrettyTable(['vmk', 'ip', 'netstack', 'mtu', 'network'], sortby='vmk')
                vmkPtbl.align = 'l'

                hNets = host.network
                hcNet = host.config.network if host.config else {}

                # host default gateway
                hcNetDefGateway = hcNet.ipRouteConfig.defaultGateway if hasattr(hcNet, 'ipRouteConfig') else ''

                # list of PNIC  (hcNet.pnic)
                pnics = []
                if hasattr(hcNet, 'pnic'):
                    for p in hcNet.pnic:
                        pnics.append(p.device+'/'+
                            (('%sMb'%p.linkSpeed.speedMb) if p.linkSpeed else ''))
                pnics_s = '\n'.join(sorted(pnics))

                # dict of opaqueNetwork indexed by opaqueNetworkId
                opNetDict = {}
                opNetTbl = PrettyTable(border=False, header=False)
                opNetTbl.field_names = ['opNetName']
                opNetTbl.align = 'l'
                if hasattr(hcNet, 'opaqueNetwork'):
                    for opNet in hcNet.opaqueNetwork:
                        opNetTbl.add_row([opNet.opaqueNetworkName])
                        #print(opNet)
                        #print('opNet: %s %s' % (opNet.opaqueNetworkId, opNet.opaqueNetworkName))
                        opNetDict[opNet.opaqueNetworkId] = opNet.opaqueNetworkName

                # list of opaqueSwitch
                opSwDict = {}
                opSwTbl = PrettyTable(border=False, header=False)
                opSwTbl.field_names = ['opSwName']
                opSwTbl.align = 'l'
                if hasattr(hcNet, 'opaqueSwitch'):
                    for opSw in hcNet.opaqueSwitch:
                        opSwTbl.add_row([opSw.name])
                        #print(opSw)
                        #print('opSw: %s %s' % (opSw.key, opSw.name))
                        opSwDict[opSw.key] = opSw.name

                # list of VMKs  (hcNet.vnic, hcNet.vnic[].spec.distributedVirtualPort )
                if hasattr(hcNet, 'vnic'):
                    for vnic in hcNet.vnic:
                        #if isinstance(n, vim.dvs.DistributedVirtualPortgroup):
                        dvpg = vnic.spec.distributedVirtualPort
                        opNet = vnic.spec.opaqueNetwork
                        vssPgName = vnic.portgroup
                        if dvpg:
                            dvpg = self.vc.moid2mo(dvpg.portgroupKey)
                            dvs = dvpg.config.distributedVirtualSwitch
                            vmkNet = 'dvsPg:%s/%s' % (dvs.name, dvpg.name)
                        elif opNet:
                            opNetNameId = opNet.opaqueNetworkId
                            vmkNet = 'opNet:%s' % opNetDict[opNetNameId]
                        elif vssPgName:
                            vmkNet = 'vssPg:%s' % vssPgName
                        else:
                            self.logger.error('Don\'t know how to handle network: %s' % vnic.spec)
                        vmkPtbl.add_row([vnic.device, vnic.spec.ip.ipAddress,
                            vnic.spec.netStackInstanceKey, vnic.spec.mtu, vmkNet])

                ptbl.add_row([hName, hcNetDefGateway,
                    pnics_s, vmkPtbl])
                HostNetwork = collections.namedtuple('HostNetwork',
                    ('hName', 'gateway', 'vmnics', 'vmks'))
            elif getChoice == 'storage':
                mInfos = host.config.fileSystemVolume.mountInfo
                #print((hName, [(m.volume.name, m.volume.type)
                #    for m in mInfos if m.volume.name]))

                dsTbl = PrettyTable(border=False, header=False)
                dsTbl.field_names = ['name', 'type']
                dsTbl.align = 'l'
                for m in mInfos:
                    if m.volume.name:
                        dsTbl.add_row([m.volume.name, m.volume.type])

                ptbl.add_row([hName, dsTbl])
                del dsTbl

            elif getChoice == 'vmlist':
                vms = host.vm
                #print('Host %s' % hName)
                #pprint([(vm._moId, vm.name) for vm in
                #    sorted(vms, key=lambda x: x.__getattribute__('name'))])

                vmTbl = PrettyTable(border=False, header=False)
                vmTbl.field_names = ['vmMoid', 'vmName']
                vmTbl.align = 'l'
                for vm in sorted(vms, key=lambda x: x.__getattribute__('name')):
                    vmTbl.add_row([vm._moId, vm.name])
                ptbl.add_row([hName, vmTbl])
                del vmTbl
            elif getChoice == 'vmautostart':
                def _prSection(secName, secHdr, vms):
                    secHdr[0] = secName
                    ptbl.add_row(secHdr)
                    for vm in vms:
                        ptbl.add_row([vm.key.name, vm.startAction, vm.startOrder, vm.startDelay, vm.stopAction, vm.stopDelay])

                vms = host.config.autoStart.powerInfo
                autoVms = [vm for vm in sorted(vms, key=lambda x: x.__getattribute__('startOrder'))
                    if vm.startAction=='powerOn' and vm.startOrder>0]
                autoAnyVms = [vm for vm in sorted(vms, key=lambda x: x.__getattribute__('startOrder'))
                    if vm.startAction=='powerOn' and vm.startOrder==-1]
                manualVms = [vm for vm in sorted(vms, key=lambda x: x.__getattribute__('startOrder'))
                    if vm.startAction!='powerOn']

                secHdr = ['## Automatic Startup',':::::::::::','::::::::::','::::::::::',':::::::::::','::::::::::']
                _prSection('## Automatic Startup', secHdr, autoVms)
                _prSection('## Automatic Startup (Any Order)', secHdr, autoAnyVms)
                _prSection('## Manual Startup', secHdr, manualVms)

            elif getChoice == 'vmautostartdefaults':
                pprint(host.config.autoStart.defaults)

        if outFmt=='table':
            if ptbl._rows:
                print(ptbl)
            print('Count: %d' % ptbl.rowcount)
        elif outFmt=='json':
            if ptbl_j._rows:
                print(cptutil.fmtPrettytableAsJson(ptbl_j, indent=4))
            else:
                print(cptutil.fmtPrettytableAsJson(ptbl, indent=4))
        else:
            self.logger.error('Unsupported output format "%s"' % outFmt)

        if nHost == 0:
            self.logger.error('%s %s not found' % (self.className, nameGlob))


    def hostOptionsOp(self, op, hostNamePattern, varSpec=None): # HostSystem
        def _hostOptionsSet(advOpt, varSpec):
            k,v = varSpec.split('=')
            opts = advOpt.QueryOptions(k)
            opt0 = opts[0]
            opt0TypeName = type(opt0.value).__name__
            opt0.value = pyVmomi.VmomiSupport.vmodlTypes[opt0TypeName](v)
            advOpt.UpdateOptions(opts)

        vimType = self.vimType
        hostMos = self.vc.getByType([vimType])
        ptbl = PrettyTable(['host', 'key', 'value', 'type'])
        ptbl.align = 'l'

        try:
            hostMos = sorted(hostMos, key=lambda x: x.__getattribute__('name'))
        except Exception as e:
            self.logger.error(e)

        for hostMo in hostMos:
            try:
                hostName = hostMo.name
                if not isGlobMatched(hostNamePattern, hostName): continue
                advOpt = hostMo.configManager.advancedOption
                if op == 'listOptions':
                    opts = advOpt.QueryOptions()
                    for opt in opts:
                        ptbl.add_row([hostName, opt.key, opt.value, type(opt.value).__name__])
                elif op == 'getOptions':
                    opts = advOpt.QueryOptions(varSpec)
                    opt = opts[0]
                    ptbl.add_row([hostName, opt.key, opt.value, type(opt.value).__name__])
                elif op == 'setOptions':
                    _hostOptionsSet(advOpt, varSpec)
                elif op in ['SuppressHyperthreadWarning', 'SuppressShellWarning']:
                    _hostOptionsSet(advOpt, 'UserVars.%s=1'%op)
            except Exception as e:
                self.logger.error(e)
        if op in ['getOptions','listOptions']:
            print(ptbl)

    def hostOp(self, hostNamePattern, action=None, get=None, args=None):    # HostSystem
        vimType = self.vimType
        hostMos = self.vc.getByType([vimType])
        #print('hostOp(%s, %s)' % (hostNamePattern, action))
        #print('hostMos: %s' % hostMos)
        #print(dir(hostMos[0]))
        #print('%s attrs:%s' % (vimType, attrs))

        logLevel = logging.WARNING
        logLevel = self.logger.getEffectiveLevel()
        toaster = Toaster(self.vc.nThread, logLevel, logger=self.logger)

        maxTask = 8
        for hostMo in sorted(hostMos, key=lambda x: x.__getattribute__('name')):
            ''' host sorted by name '''
            hostName = hostMo.name
            if not isGlobMatched(hostNamePattern, hostName): continue
            #self.logger.info('%s\t%s\t%s\t%s\t%s' %
            #        (vm._moId, vm.name, vm.runtime.powerState, action, \
            #        action in vm.runtime.powerState.lower()))

            if action == 'mainten_on':
                if hostMo.runtime.inMaintenanceMode:
                    self.logger.warning('host %s already in maintenance mode' % hostName)
                else:
                    self.logger.info('host %s entering maintenance mode' % hostName)
                    #task = getattr(hostMo, methodDict[action])(timeout=0)

                    taskName = '%s-%s' % (action, hostName)
                    fn = getattr(hostMo, self.methodDict[action])
                    toaster.load(taskName, submitVcTaskAndWait,
                            fn=fn, si=self.vc.si, taskName=taskName,
                            logger=self.logger, timeout=0)

            elif action == 'mainten_off':
                if hostMo.runtime.inMaintenanceMode:
                    self.logger.info('host %s existing maintenance mode' % hostName)
                    #task = getattr(hostMo, self.methodDict[action])(timeout=0)

                    taskName = '%s-%s' % (action, hostName)
                    fn = getattr(hostMo, self.methodDict[action])
                    toaster.load(taskName, submitVcTaskAndWait,
                            fn=fn, si=self.vc.si, taskName=taskName,
                            logger=self.logger, timeout=0)
                else:
                    self.logger.warning('host %s already out of maintenance mode' % hostName)

            elif action == 'mainten_status':
                print('host %s is %sin maintenance mode' % (hostName,
                    '' if hostMo.runtime.inMaintenanceMode else 'NOT '))

            elif action == 'reboot' and hostMo.runtime.powerState == 'poweredOn':
                self.logger.info('Rebooting host %s' % hostName)
                #task = getattr(hostMo, self.methodDict[action])(True)

                taskName = '%s-%s' % (action, hostName)
                fn = getattr(hostMo, self.methodDict[action])
                toaster.load(taskName, submitVcTaskAndWait,
                        fn=fn, si=self.vc.si, taskName=taskName,
                        logger=self.logger,
                        force=True)

            elif action == 'vmautostart':
                self.logger.info('configure VM %s autostart setting on host %s' % (args.vms, hostName))

                api = []    ;# AutoPowerInfo
                for vmObj in hostMo.vm:
                    for vmNameGlob in args.vms:
                        if isGlobMatched(vmNameGlob, vmObj.name):
                            api.append(vim.host.AutoStartManager.AutoPowerInfo())
                            api[-1].key = vmObj
                            api[-1].startAction = args.action
                            api[-1].startOrder = args.order ;# -1: any order
                            api[-1].startDelay = -1
                            api[-1].stopAction = 'systemDefault'
                            api[-1].stopDelay = -1
                            api[-1].waitForHeartbeat = vim.host.AutoStartManager.AutoPowerInfo.WaitHeartbeatSetting.systemDefault

                autoStartMgrCfg = vim.host.AutoStartManager.Config()
                autoStartMgrCfg.powerInfo = api

                hostMo.configManager.autoStartManager.ReconfigureAutostart(autoStartMgrCfg)
                self.get(hostNamePattern, 'vmautostart')

            elif action == 'vmautostartdefaults':
                self.logger.info('configure VM autostart default settings for host %s' % hostName)

                apiDef = vim.host.AutoStartManager.SystemDefaults()
                apiDef.enabled = args.enable
                apiDef.startDelay = args.startdelay
                apiDef.stopDelay = args.stopdelay
                apiDef.waitForHeartbeat = False
                apiDef.stopAction = 'PowerOff'

                autoStartMgrCfg = vim.host.AutoStartManager.Config()
                autoStartMgrCfg.defaults = apiDef

                hostMo.configManager.autoStartManager.ReconfigureAutostart(autoStartMgrCfg)
                self.get(hostNamePattern, 'vmautostartdefaults')

            elif action == 'disconnect':
                self.logger.info('%s host %s' % (action, hostName))

                taskName = '%s-%s' % (action, hostName)
                fn = getattr(hostMo, self.methodDict[action])
                toaster.load(taskName, submitVcTaskAndWait,
                        fn=fn, si=self.vc.si, taskName=taskName,
                        logger=self.logger)

            elif action == 'delete':
                #if isinstance(hostMo.parent, vim.ComputeResource):
                #    self.logger.info('Remove Host %s and ComputeResource %s from vCenter inventory'
                #        % (hostName, hostMo.parent.name))
                #    taskName = 'Destroy_ComputeResource_%s' % hostMo.parent.name
                #    fn = hostMo.parent.Destroy
                #    toaster.load(taskName, submitVcTaskAndWait,
                #            fn=fn, si=self.vc.si, taskName=taskName,
                #            logger=self.logger)
                #    #r = hostMo.parent.Destroy()
                #    #waitForTask(r, taskName='destroy standalonehost', logger=self.logger)
                #else:
                    self.logger.info('Remove Host %s from vCenter inventory' % hostName)
                    taskName = '%s-%s' % (action, hostName)
                    fn = getattr(hostMo, self.methodDict[action])
                    toaster.load(taskName, submitVcTaskAndWait,
                            fn=fn, si=self.vc.si, taskName=taskName,
                            logger=self.logger)


            elif action == 'reconnect':
                self.logger.info('->%s host %s' % (action, hostName))
                taskName = '%s-%s' % (action, hostName)

                cnxSpec = vim.host.ConnectSpec()
                cnxSpec.hostName = hostName
                cnxSpec.userName = 'root'
                cnxSpec.password = 'Vmware123!'
                cnxSpec.sslThumbprint=self.getSslThumbprint(hostname=hostName,display=False)
                #cnxSpec.port = 443
                #cnxSpec.force = True
                print(cnxSpec)

                self.logger.info('Reconnecting host %s' % (hostName))
                #task = getattr(hostMo, self.methodDict[action])(cnxSpec)
                task = hostMo.ReconnectHost_Task(cnxSpec)
                waitForTask(task, 'Reconnecting host %s'%hostName, self.logger, [vim.fault.SSLVerifyFault])
                if task.info.state == 'error' and getattr(task.info.error,'thumbprint', None):
                    thumbprint = task.info.error.thumbprint
                    hostConnectSpec.sslThumbprint = thumbprint
                    self.logger.info('Reconnecting host %s (thumbprint=%s)' % (
                        hostName, thumbprint ))
                    task = hostMo.ReconnectHost_Task(cnxConnectSpec)
                    waitForTask(task, 'Reconnect (thumbprint=%s)'%(hostNames,thumbprint), self.logger)

        '''
        else:
                self.logger.info('ELSE %s host %s' % (action, hostName))
                taskName = '%s-%s' % (action, hostName)
                #task = getattr(hostMo, self.methodDict[action])()

                fn = getattr(hostMo, self.methodDict[action])
                toaster.load(taskName, submitVcTaskAndWait,
                        fn=fn, si=self.vc.si, taskName=taskName,
                        logger=self.logger)
        '''
        toaster.wait()

    def hostDsOp(self, op, hostName, dsName, uuid):
        uuid = uuid.replace('-', '').lower()
        self.logger.info('Adding datastore "%s" using disk with uuid "%s"' % (dsName, uuid))

        hostMo = self.vc.getByName(vim.HostSystem, hostName)
        if hostMo:
            if op=='add':
                Datastore(self.vc).add(dsName, uuid, hostName=hostName)
            elif op=='list':
                Datastore(self.vc).list(dsName)
            elif op=='delete':
                Datastore(self.vc).delete(dsName)
        else:
            self.logger.warning('host "%s" NOT FOUND' % hostName)

    def hostService(self, op, targetHosts, svcKeys=[], svcNames=[], policy=''):
        ''' vc here is actually host itself '''
        vimType = self.vimType
        if op == 'list':
            ptbl0 = PrettyTable(['dc/cluster/hsot', 'service'] , sortby='dc/cluster/hsot')
            ptbl0.align = 'l'

        for dc in self.vc.si.content.rootFolder.childEntity:
            dcName = dc.name
            #print('targetHosts:', targetHosts)
            if not dc.hostFolder.childEntity: continue
            for cluster in dc.hostFolder.childEntity:
                #for host in cluster.host:
                #for host in cluster.host.sort(key=lambda x:cptutil.num_keys(x.name)):
                hosts = cluster.host
                #print('hosts0:', hosts)
                #print('hosts0a:', [h.name for h in hosts])
                #cluster.host.sort(key=lambda x:cptutil.num_keys(x.name))
                #print('hosts1:', hosts)
                for host in hosts:
                    hostName = host.name
                    if not targetHosts: continue
                    if not cptutil.isGlobMatchedInList(targetHosts, hostName): continue
                    serviceSystem = host.configManager.serviceSystem
                    fnPolicy = serviceSystem.UpdateServicePolicy

                    hostPath = '%s\n %s\n  %s' % (dc.name,cluster.name,host.name)
                    if op == 'list':
                        ptbl = PrettyTable(['name', 'key', 'running', 'startUpDefault'], sortby='name')
                        ptbl.align = 'l'
                        for s in serviceSystem.serviceInfo.service:
                            if not svcKeys or s.key in svcKeys:
                                ptbl.add_row([s.label, s.key, s.running, s.policy])
                        ptbl0.add_row([hostPath,ptbl])
                    elif op in ['start', 'stop', 'restart']:
                        self.logger.info('%s service %s on host %s' % (op, svcKeys, hostName))
                        fnMap = {'start':'StartService', 'stop':'StopService', 'restart':'RestartService'}
                        fn = getattr(serviceSystem, fnMap[op])
                        for svcKey in svcKeys:
                            fn(svcKey)
                            #curMethodName = inspect.stack()[0][3]
                            #getattr(self, curMethodName)('list', [svcKey])
                            if policy:
                                fnPolicy(svcKey, policy)
                    elif op == 'startup':
                        self.logger.info('host %s: start service %s at boot: %s' %
                            (hostName, svcKeys, policy))
                        for svcKey in svcKeys:
                            fnPolicy(svcKey, policy)

        if op == 'list':
            print(ptbl0)
        else:
            self.hostService('list', targetHosts, svcKeys)

def locateDcByName(dcName, vc, abort=0):
    if dcName:
        dc = vc.getByName(vim.Datacenter, dcName)
        if not dc:
            vc.logger.error(
                'Datacenter %s does not exist. ABORT' % dcName)
            if abort:
                exit(abort)
    else:
        dcs = vc.getByType([vim.Datacenter])
        if len(dcs)==1:
            dc = dcs[0]
        else:
            vc.logger.error('More than 1 datacenter to choose from: %s' %
                [dc.name for dc in dcs])
            if abort:
                vc.logger.error('ABORT')
                exit(abort)
    return dc


class ComputeResource(VS_object):
    ''' The base type ComputeResource, when instantiated by calling
        vim.Folder.CreateStandaloneHost, represents a single host '''
    vimType = vim.ComputeResource
    list_details_attrs = ['host']


class ClusterComputeResource(ComputeResource):
    ''' The subclass ClusterComputeResource represents a cluster of hosts
        and adds distributed management features such as availability
        and resource scheduling '''
    vimType = vim.ComputeResource
    list_attrs = ['name', '_moId', 'parent.parent.name']
    #list_details_attrs = ['_moId', 'name', 'host', 'network', 'parent', 'resourcePool', 'summary']

    def create(self, clusterNames, dcName):
        clusterNames = listify(clusterNames)

        dcMos = self.vc.getByNamesGlob(vim.Datacenter, dcName or '*')
        if len(dcMos)==1:
            dcMo = dcMos[0]
        elif len(dcMos)>1:
            self.logger.error('Please secifiy datacenter name: %s' % ','.join([dcMo.name for dcMo in dcMos]))
            return(120)
        elif len(dcMos)==0:
            self.logger.error('datacenter %s not found' % dcName)
            return(121)

        for clusterName in clusterNames:
            if self.vc.getByName(self.vimType, clusterName, container=dcMo):
                self.logger.error('cluster %s already exist!' % clusterName)
                continue
            clusterSpec = vim.cluster.ConfigSpec()
            clusterObj = dcMo.hostFolder.CreateCluster(clusterName, clusterSpec)
            self.logger.info('Cluster %s created: moId=%s' % (
                clusterName, clusterObj._moId))

    def delete(self, clusterNames, dcName):         # ClusterComputeResource()
        container = self.vc.getByName(vimDict['dc'], dcName) if dcName else None
        clusterMos = self.getByNamesGlob(clusterNames, container=container, refresh=True)
        if len(clusterMos) > len(set([c.name for c in clusterMos])):
            self.logger.error('More than 1 cluster with the same name exist, please specify datacenter\n%s\n%s'% (
                '%-16s%s'%('DATACENTER','CLUSTER'),
                '\n'.join([('%-16s%s'%(c.parent.parent.name,c.name)) for c in clusterMos])))
            return
        for clusterMo in clusterMos:
            dcMo = clusterMo.parent.parent
            self.logger.info('Deleting cluster "%s" in datacenter "%s"' % (clusterMo.name, dcMo.name))
            task = clusterMo.Destroy()
            waitForTask(task, 'Delete cluster %s in datacenter %s'%(clusterMo.name,dcMo.name), self.logger)

    def listHost(self, clusterNames, **kwargs):
        vimType = self.vimType
        clusterNames = clusterNames or [c.name for c in self.vc.getByType(self.vimType)]
        for clusterName in clusterNames:
            ptbl = PrettyTable(['name/objId', 'hardware/boot', 'network', 'VMs'], sortBy='name')
            ptbl.align = 'l'
            cluster = self.vc.getByName(vimType, clusterName)
            if not cluster:
                self.logger.info('Cannot find cluster %s' % clusterName)
            print('%s hosts in cluster %s: ' % (len(cluster.host), clusterName))
            for h in cluster.host:
                vmNames = '\n'.join([vm.name for vm in h.vm])
                hshw = h.summary.hardware
                hsrt = h.summary.runtime
                vmks = '\n'.join([ ', '.join(
                    (ri.netStackInstanceKey, str([vmknickey for vmknickey in ri.vmknicKeys])))
                    for ri in hsrt.networkRuntimeInfo.netStackInstanceRuntimeInfo]) if hsrt.networkRuntimeInfo else ''
                nameOid = '\n'.join([h.name, h._moId])
                model =  '\n'.join([hshw.vendor, hshw.model, str(hsrt.bootTime).split('.')[0]])
                ptbl.add_row([nameOid, model, vmks, vmNames])
            if ptbl._rows: print(ptbl)
            print('Count: %d' % ptbl.rowcount)

    def addHosts(self, clusterName, hostNames, hostUser, hostPasswd, **kwargs):
        vimType = self.vimType
        cluster = self.vc.getByName(vimType, clusterName)
        if not cluster:
            self.logger.info('Cannot find cluster %s' % clusterName)
            return None

        for hostName in hostNames:
            hostConnectSpec = vim.host.ConnectSpec()
            hostConnectSpec.hostName = hostName
            hostConnectSpec.userName = hostUser
            hostConnectSpec.password = hostPasswd
            hostConnectSpec.force = True
            self.logger.info('Adding host %s to cluster "%s"' % (hostName, clusterName))
            task = cluster.AddHost(hostConnectSpec, asConnected=True)
            waitForTask(task, 'Add host %s to cluster %s'%(hostName,clusterName),
                self.logger, [vim.fault.SSLVerifyFault])
            if task.info.state == 'error' and getattr(task.info.error,'thumbprint', None):
                thumbprint = task.info.error.thumbprint
                hostConnectSpec.sslThumbprint = thumbprint
                self.logger.info('Adding host %s (thumbprint=%s) to cluster %s' % (
                    hostName, thumbprint, clusterName))
                task = cluster.AddHost(hostConnectSpec, asConnected=True)
                waitForTask(task, 'Add host %s (thumbprint=%s) to cluster %s' %
                    (hostNames,thumbprint,clusterName), self.logger)

    def moveInto(self, clusterName, hostNames, optDict={}):
        vimType = self.vimType
        cluster = self.vc.getByName(vimType, clusterName)
        self.logger.info('Moving host %s into cluster %s' % (hostNames, clusterName))
        if not cluster:
            self.logger.info('Cannot find cluster %s' % clusterName)
            return None

        hostd = HostSystem(self.vc)
        for hostName in hostNames:
            self.logger.info('Moving host %s into cluster %s' % (hostName, clusterName))
            hosts = self.vc.getByNamesGlob(vim.HostSystem, hostName)
            if optDict['mainten']:
                hostd.hostOp(hostName, 'mainten_on')
            task = cluster.MoveInto(hosts)
            #waitForTask(task, 'Move host %s into cluster %s' % (hostNames, clusterName), self.logger)
            task.wait()
            self.logger.info('Moved host %s into cluster %s' % (hostName, clusterName))
            if optDict['mainten']:
                hostd.hostOp(hostName, 'mainten_off')

    def xfind_vmNames_by_clusters(self, clusterNames, vmNameGlobPat=''):
        vmMos = self.xfind_vmMos_by_clusters(clusterNames, vmNameGlobPat=vmNameGlobPat)
        return [mo.name for mo in vmMos]

    def xfind_vmMoids_by_clusters(self, clusterNames, vmNameGlobPat=''):
        vmMos = self.xfind_vmMos_by_clusters(clusterNames, vmNameGlobPat=vmNameGlobPat)
        return [mo._moId for mo in vmMos]

    def xfind_vmMos_by_clusters(self, clusterNames, vmNameGlobPat=''):
        vmList = []
        for clusterName in clusterNames:
            cMos = self.getByNamesGlob(clusterName)
            for cMo in cMos:
                for hMo in cMo.host:
                    vmList.extend([vmMo for vmMo in hMo.vm if not vmNameGlobPat or isGlobMatched(vmNameGlobPat, vmMo.name)])
        return vmList

    def find_vmNames_by_clusters(self, clusterNames, vmNameGlobPat=''):
        return self.getMembersByNames(clusterNames, 'host.vm.name', vmNameGlobPat)
    def find_vmMoids_by_clusters(self, clusterNames, vmNameGlobPat=''):
        return self.getMembersByNames(clusterNames, 'host.vm._moId', vmNameGlobPat)
    def find_vmMos_by_clusters(self, clusterNames, vmNameGlobPat=''):
        return self.getMembersByNames(clusterNames, 'host.vm', vmNameGlobPat)

    #def rename(self, clusterName, newClusterName, **kwargs):
    #    vimType = self.vimType
    #    cluster = self.vc.getByName(vimType, clusterName)
    #    if not cluster:
    #        self.logger.info('Cannot find cluster %s' % clusterName)
    #        return None

    #    self.logger.info('Rnamnge cluster %s to %s' % (
    #        clusterName, newClusterName))
    #    task = cluster.Rename(newClusterName)
    #    waitForTask(task, 'Rnamnge cluster %s to %s' %
    #        (clusterName, newClusterName), self.logger)

    # adopted from https://github.com/vmware/pyvmomi/issues/245
    def addVmsToVmGroup(self, clusterName, groupName, vmNames):
        self.logger.info('Adding VM %s to vmGroup "%s" on cluster "%s"' % (vmNames, groupName, clusterName))
        vms = [self.vc.getByName(vim.VirtualMachine, vmName) for vmName in vmNames]
        cluster = self.vc.getByName(vim.ComputeResource, clusterName)

        # check if VmGroup Exists
        vmGroup = filter(lambda x: x.name == groupName,
            filter(lambda x: x.__class__.__name__ == 'vim.cluster.VmGroup',
               cluster.configurationEx.group)
            )
        spec = vim.cluster.ConfigSpecEx()
        group_vm = vim.cluster.GroupSpec()
        if vmGroup:
            group_vm.operation = 'edit'
            group_vm.info = vmGroup[0]
        else:
            self.logger.info('Creating new vmGroup "%s" on cluster "%s"' % (groupName, clusterName))
            group_vm.operation = 'add'
            group_vm.info = vim.cluster.VmGroup()
            group_vm.info.name = groupName
        group_vm.info.vm = vms
        spec.groupSpec.append(group_vm)
        task = cluster.ReconfigureComputeResource_Task(spec, modify=True)
        self.logger.info('%s: %s' % (task, task.info.state))
        #tasks.wait_for_tasks(self.vc.si, [task])
        task.wait()
        self.logger.info('%s: %s' % (task, task.info.state))
        self.logger.info('Added VM %s to vmGroup "%s" on cluster "%s"' % (vmNames, groupName, clusterName))

    def addHostsToHostGroup(self, clusterName, groupName, hostNames):
        print(clusterName, hostNames)
        self.logger.info('Adding VM %s to hostGroup "%s" on cluster "%s"' % (hostNames, groupName, clusterName))
        hosts = [self.vc.getByName(vim.HostSystem, hostName) for hostName in hostNames]
        cluster = self.vc.getByName(vim.ComputeResource, clusterName)
        print(cluster, hosts)

        # check if hostGroup Exists
        print('>>>', cluster.configurationEx.group)
        hostGroup = filter(lambda x: x.name == groupName,
            filter(lambda x: x.__class__.__name__ == 'vim.cluster.HostGroup',
               cluster.configurationEx.group)
            )
        print('hostGroup: %s' % hostGroup)
        spec = vim.cluster.ConfigSpecEx()
        group_host = vim.cluster.GroupSpec()
        if hostGroup:
            group_host.operation = 'edit'
            group_host.info = hostGroup[0]
        else:
            self.logger.info('Creating new hostGroup "%s" on cluster "%s"' % (groupName, clusterName))
            group_host.operation = 'add'
            group_host.info = vim.cluster.HostGroup()
            group_host.info.name = groupName
        group_host.info.host = hosts
        spec.groupSpec.append(group_host)
        task = cluster.ReconfigureComputeResource_Task(spec, modify=True)
        self.logger.info('%s: %s' % (task, task.info.state))
        #tasks.wait_for_tasks(self.vc.si, [task])
        task.wait()
        self.logger.info('%s: %s' % (task, task.info.state))
        self.logger.info('Added host %s to hostGroup "%s" on cluster "%s"' % (hostNames, groupName, clusterName))

    def addMembersToGroup(self, clusterName, groupType, groupName, memberNames):
        #print(clusterName, memberNames)
        if groupType=='vm':
            vimType = vim.VirtualMachine
            vimType_s = 'vim.VirtualMachine'
            vimClusterGroup = vim.cluster.VmGroup()
            vimClusterGroupType_s = 'vim.cluster.VmGroup'
        elif groupType=='host':
            vimType = vim.HostSystem
            vimType_s = 'vim.HostSystem'
            vimClusterGroup = vim.cluster.HostGroup()
            vimClusterGroupType_s = 'vim.cluster.HostGroup'

        self.logger.info('Adding %s %s to %sGroup "%s" on cluster "%s"' % ( groupType.upper(), memberNames, groupType.upper(), groupName, clusterName))
        members = [self.vc.getByName(vimType, memberName) for memberName in memberNames]
        cluster = self.vc.getByName(vim.ComputeResource, clusterName)
        #print(cluster, members)

        # check if Group Exists
        #print('>>>', cluster.configurationEx.group)
        #print('>>>vimClusterGroupType_s: ', vimClusterGroupType_s)
        group = filter(lambda x: x.name == groupName,
            filter(lambda x: x.__class__.__name__ == vimClusterGroupType_s,
               cluster.configurationEx.group)
            )
        #print('group:: %s' % group)
        spec = vim.cluster.ConfigSpecEx()
        groupSpec = vim.cluster.GroupSpec()
        if group:
            groupSpec.operation = 'edit'
            groupSpec.info = group[0]
        else:
            self.logger.info('Creating new %sGroup "%s" on cluster "%s"' %
                (groupType, groupName, clusterName))
            groupSpec.operation = 'add'
            #groupSpec.info = vim.cluster.HostGroup()
            groupSpec.info = vimClusterGroup

        #groupSpec.info.host = members
        #eval('groupSpec.info.%s = members' % groupType)
        if groupType=='vm':
            groupSpec.info.vm = members
        elif groupType=='host':
            groupSpec.info.host = members
        spec.groupSpec.append(groupSpec)
        task = cluster.ReconfigureComputeResource_Task(spec, modify=True)
        self.logger.info('%s: %s' % (task, task.info.state))
        #tasks.wait_for_tasks(self.vc.si, [task])
        task.wait()
        self.logger.info('%s: %s' % (task, task.info.state))
        self.logger.info('Added %s %s to %sGroup "%s" on cluster "%s"' %
            (groupType, memberNames, groupType, groupName, clusterName))

    def affinityRuleOp(self, op, clusterNames, ruleType=None, ruleNames=[], vms=[], modal='should'):
        ''' vms: list of VMnames/full vmMoids '''
        self.logger.info('%s rule %s from cluster %s' %
            (op, ruleNames, clusterNames))
        for clusterNameGlob in clusterNames:
            for cluster in self.vc.getByNamesGlob(self.vimType, clusterNameGlob):
                clusterName = cluster.name
                #print('clusterName:',  clusterName)
                #print('cluster:',  cluster)
                #cluster = self.getByName(clusterName)
                if op=='list':
                    print('DRS %sABLED for culster %s' % (
                        {False:'DIS', True:'EN'}[cluster.configuration.drsConfig.enabled], clusterName))
                    ptbl = PrettyTable(
                        field_names = ['cluster', 'ruleName', 'ruleType', 'enabled', 'mandatory', 'vm/vm-host'],
                        sortby = 'cluster')
                    ptbl.align = 'l'
                    for rule in cluster.configuration.rule:
                        # type(rule) returns one of
                        #   '<class 'pyVmomi.VmomiSupport.vim.cluster.AffinityRuleSpec'>
                        #   '<class 'pyVmomi.VmomiSupport.vim.cluster.AntiAffinityRuleSpec'>
                        #   '<class 'pyVmomi.VmomiSupport.vim.cluster.VmHostRuleInfo'>
                        #print(rule)
                        ruleType = str(type(rule)).split('.')[-1].strip("'>")[:-8]

                        if hasattr(rule, 'vm'):
                            vms = '\n'.join(['%s (%s)' % (vm.name, vm._moId) for vm in rule.vm])
                        else:
                            if rule.affineHostGroupName:
                                vms = '%s > %s' % (rule.vmGroupName, rule.affineHostGroupName)
                            elif rule.antiAffineHostGroupName:
                                vms = '%s <|> %s' % (rule.vmGroupName, rule.antiAffineHostGroupName)
                        ptbl.add_row([clusterName, rule.name, ruleType, rule.enabled, rule.mandatory, vms])
                    if ptbl._rows:
                        print(ptbl)
                        print('Count: %d' % ptbl.rowcount)

                    #print(type(vim.cluster.VmGroup))
                    #vmGroup = self.vc.getByName(vim.cluster.VmGroup, 'vmGroup-911')
                    #print(vmGroup.vm)
                elif op=='delete':
                    ruleSpec = vim.cluster.RuleSpec()
                    ruleSpec.operation = 'remove'
                    configSpec = vim.cluster.ConfigSpec()
                    configSpec.rulesSpec = [ruleSpec]
                    for rule in cluster.configuration.rule:
                        if rule.name in ruleNames:
                            self.logger.info('Deleting rule %s from cluster %s' %
                                (rule.name, clusterName))
                            ruleSpec.removeKey = rule.key
                            task = cluster.ReconfigureCluster_Task(configSpec, modify=True)
                            while task.info.state == 'running':   # 'running', 'success'
                                #spinner(task.info.state)
                                time.sleep(1)
                                #tasks.wait_for_tasks(self.vc.si, [task])
                            if task.info.state == 'error':
                                self.logger.info('Error when Deleting rule %s from cluster %s: %s' %
                                    (rule.name, clusterName, task.info.error.msg))

                elif op=='find':
                    ptbl = PrettyTable(['vmName', 'ruleType', 'ruleName', 'members', 'enabled'])
                    ptbl.align = 'l'
                    #print(vms)
                    vmObj = VirtualMachine(self.vc)
                    vmMos = [
                        (self.vc.moid2mo('vim.VirtualMachine:%s'%vm.split(':')[1])
                            if ':' in vm else vmObj.getByName(vm))
                            for vm in vms]
                    for vmMo in vmMos:
                        rules = cluster.FindRulesForVm(vm=vmMo)
                        #print(rules)
                        for rule in rules:
                            vmNames = '\n'.join([vm.name for vm in rule.vm])
                            rType = str(type(rule)).split('.')[-1].strip("'>")[:-8]
                            ptbl.add_row([vmMo.name, rType, rule.name, vmNames, rule.enabled])
                    if ptbl._rows: print(ptbl)
                    print('Count: %d' % ptbl.rowcount)

                elif op=='add':
                    self.logger.info('Adding affinity rule to cluster %s' % clusterName)

                    clusterObj = ClusterComputeResource(self.vc)
                    clusterMo = clusterObj.getByName(clusterNames[0])

                    configSpec = vim.cluster.ConfigSpec()

                    # enable DRS (configSpec.drsConfig.enable)
                    self.logger.info('Enabling DRS on cluster %s' % clusterName)
                    configSpec.drsConfig = vim.cluster.DrsConfigInfo()
                    configSpec.drsConfig.enabled = True

                    # configSpec.rulesSpec[0]
                    ruleSpec = vim.cluster.RuleSpec()
                    # configSpec.rulesSpec[0].<attrs>
                    ruleSpec.operation = 'add'

                    if 'affinityrule' in ruleType.lower():
                        # get vmMos
                        vmObj = VirtualMachine(self.vc)
                        vmMos = [
                            (self.vc.moid2mo('vim.VirtualMachine:%s'%vm.split(':')[1])
                                if ':' in vm else vmObj.getByName(vm))
                                for vm in vms]

                        # To be attached to configSpec.rulesSpec[0].info
                        affRuleSpec = {'AntiAffinityRule':vim.cluster.AntiAffinityRuleSpec(),
                            'AffinityRule':vim.cluster.AffinityRuleSpec()}[ruleType]
                        affRuleSpec.mandatory = 'must' in modal
                        affRuleSpec.vm = vmMos

                        # configSpec.rulesSpec[0].info
                        ruleSpec.info = affRuleSpec
                        # configSpec.rulesSpec[0].info.enabled
                        ruleSpec.info.enabled = False

                        # configSpec.rulesSpec[0].info.name
                        ruleSpec.info.name = '%s-API-%s' % (
                            '-'.join(re.findall(r'[A-Z][a-z]*',ruleType)).lower(),
                            hashlib.sha256(str(vmMos)).hexdigest()[:4])

                    elif ruleType=='VmHostRule':
                        self.logger.error('Adding affinity rule of type %s NOT implemented yet' % ruleType)
                        hostGroupName = vms[-1]

                        affRuleSpec = vim.cluster.VmHostRuleInfo()
                        affRuleSpec.mandatory = 'must' in modal
                        affRuleSpec.vmGroupName = 'vmGropup-911'    # XXXXXXXXXXXXXXXXXXXXXXXX
                        if 'Not' in modal:
                            affRuleSpec.antiAffineHostGroupName = hostGroupName
                        else:
                            affRuleSpec.affineHostGroupName = hostGroupName

                        # configSpec.rulesSpec[0].info
                        ruleSpec.info = affRuleSpec
                        # configSpec.rulesSpec[0].info.enabled
                        ruleSpec.info.enabled = False
                        # configSpec.rulesSpec[0].info.name
                        ruleSpec.info.name = '%s-API-%s' % (
                            '-'.join(re.findall(r'[A-Z][a-z]*',ruleType)).lower(),
                            hashlib.sha256(str(vms)).hexdigest()[:4])

                    configSpec.rulesSpec = [ruleSpec]

                    task = clusterMo.ReconfigureCluster_Task(configSpec, modify=True)
                    self.logger.info('%s: %s' % (task, task.info.state))
                    #tasks.wait_for_tasks(self.vc.si, [task])
                    task.wait()
                    self.logger.info('%s: %s' % (task, task.info.state))
                    self.logger.info('Added rule %s to cluster %s' % (ruleSpec.info.name, clusterName))


class Datacenter(VS_object):
    vimType = vim.Datacenter

    def create(self, dcName, folder=None):
        if folder is None:
            folder = self.vc.si.content.rootFolder

        if folder is not None and isinstance(folder, vim.Folder):
            try:
                dcMoref = folder.CreateDatacenter(name=dcName)
            except vim.fault.DuplicateName:
                self.logger.error('The name "%s" already exists' % dcName)
                return None
            return dcMoref

    def moveinto(self, dcName, memberNames, memberType):
        dcMo = self.getByName(dcName)
        if memberType=='host':
            for hostName in memberNames:
                folderMo = dcMo.hostFolder
                hostConnectSpec = vim.host.ConnectSpec()
                hostConnectSpec.hostName = hostName
                #hostConnectSpec.userName = hostUser
                #hostConnectSpec.password = hostPasswd
                hostConnectSpec.force = True
                r = folderMo.AddStandaloneHost_Task(spec=hostConnectSpec, addConnected=False)
                if isinstance(r, vim.Task):
                    waitForTask(r, taskName='Move_%s_to_%s'%(hostName,dcName), logger=self.logger)
                else:
                    self.logger.warning(r)
        elif memberType=='vm':
            folderd = Folder(self.vc)
            for vmName in memberNames:
                folderd.moveInto('vm', vmName, dcName, 'vm')


class Datastore(VS_object):
    vimType = vim.Datastore
    list_attrs = ['name', '_moId', 'summary.type', 'summary.capacity', 'host[0].key.name']

    # http://madeforcloud.com/2015/10/24/pyVmomi-part-4/

    def show(self, dsName='*'):
        ptbl = PrettyTable(
            field_names = ['name', 'type', 'path', 'capacity', 'free', 'url'],
            sortby = 'name')
        ptbl.align = 'l'
        for ds in self.vc.getByNamesGlob(vim.Datastore, dsName):
            dsInfo = ds.info
            if hasattr(dsInfo, 'nas'):
                ptbl.add_row([dsInfo.name, dsInfo.nas.type,
                    '%s:%s' % (dsInfo.nas.remoteHost, dsInfo.nas.remotePath),
                    cptutil.normDiskSize(dsInfo.nas.capacity), cptutil.normDiskSize(dsInfo.freeSpace),
                    dsInfo.url,
                    ])
            elif hasattr(dsInfo, 'vmfs'):
                ptbl.add_row([dsInfo.name, dsInfo.vmfs.type,
                    ','.join([e.diskName for e in dsInfo.vmfs.extent]),
                    cptutil.normDiskSize(dsInfo.vmfs.capacity), cptutil.normDiskSize(dsInfo.freeSpace),
                    dsInfo.url])
            else:
                ptbl.add_row([dsInfo.name, 'UNKNOW',  dsInfo.url, 'UNKNOW',  dsInfo.freeSpace])
            #print(dsInfo)

        if ptbl._rows: print(ptbl)
        print('Count: %d' % ptbl.rowcount)

    def refresh(self, hostNames=[]):
        hostNames = ['20.5.26.150']
        if hostNames:
            hosts = cptutil.flatten([self.vc.getByNamesGlob(vim.HostSystem, hn) for hn in hostNames])
        else:
            content = self.vc.si.RetrieveContent()
            hosts = content.viewManager.CreateContainerView(
                content.rootFolder, [vim.HostSystem], True).view
        datastores = {}
        for host in hosts:
            ss = host.configManager.storageSystem
            ss.RefreshStorageSystem()
            print(host.name)
            #print(ss.fileSystemVolumeInfo.mountInfo)
            #print([(fsmi.volume.name, fsmi.volume.capacity) for fsmi in ss.fileSystemVolumeInfo.mountInfo])
            for fsmi in ss.fileSystemVolumeInfo.mountInfo:
                print('    {:<15} {:<10} {:<8} {:<10} {:<35} {:<8} {:<8}'.format(
                    fsmi.volume.name,
                    cptutil.normDiskSize(fsmi.volume.capacity),
                    fsmi.volume.type,
                    #getattr(fsmi.volume, 'uuid', ''),
                    fsmi.mountInfo.accessMode,
                    fsmi.mountInfo.path,
                    getattr(fsmi.volume, 'ssd', ''),
                    getattr(fsmi.volume, 'local', ''),
                    ))
                for ext in getattr(fsmi.volume, 'extent', []):
                    print('        {:<20} {:<2}'.format(ext.diskName, ext.partition))

    def add(self, dsName=None, uuid=None, hostName=None):
        uuid = uuid.replace('-', '').lower()
        self.logger.info('Adding datastore "%s" using disk with uuid "%s"' % (dsName, uuid))
        if hostName:
            hosts = [self.vc.getByName(vim.HostSystem, hostName)]
        else:
            content = self.vc.si.RetrieveContent()
            hosts = content.viewManager.CreateContainerView(
                content.rootFolder, [vim.HostSystem], True).view

        for host in hosts:
            hostdssystem = host.configManager.datastoreSystem

            vDisks = [vDisk for vDisk in hostdssystem.QueryAvailableDisksForVmfs()
                if vDisk.devicePath.endswith(uuid)]
            if vDisks:
                vDisk = vDisks[0]
                self.logger.info('Found disk "%s" (%s) on host "%s"' % (uuid,
                    cptutil.normDiskSize(vDisk.capacity.blockSize*vDisk.capacity.block), host.name))

                vmfs_ds_options = hostdssystem.QueryVmfsDatastoreCreateOptions(vDisk.devicePath, 5)

                if dsName:
                    vmfs_ds_options[0].spec.vmfs.volumeName = dsName

                ds = vim.host.DatastoreSystem.CreateVmfsDatastore(hostdssystem, vmfs_ds_options[0].spec)
                self.logger.info('Added datastore "%s" (%s)' % (dsName, ds))
                break
        else:
            self.logger.warning('DISK with uuid "%s" NOT FOUND"' % uuid)


def prSnapshotInfo(snapName, snapMoid, snapCtime, snapCur, depth):
    #print(str(snapMoid), str(snapCur))
    print('%s%-12s(%-12s)  %19.19s %s' % (''.ljust((depth+1)*4),
        snapName, shortMoid(snapMoid), snapCtime,
        '' if str(snapMoid) != str(snapCur) else '<-- CURRENT SNAPSHOT'))

def walkSnapshotTree(root,depth, curSnapshot):
    for child in root.childSnapshotList:
        prSnapshotInfo(child.name, shortMoid(child.snapshot), child.createTime,
            curSnapshot, depth)
        if child.childSnapshotList:
            walkSnapshotTree(child, depth+1, curSnapshot)

def walkSnapshotTreeG(root, depth):
    for child in root.childSnapshotList:
        #prSnapshotInfo(child.name, child.snapshot, child.createTime, curSnapshot, depth)
        yield (child, depth)
        #print('yield (%s, %d)' % (child.name, depth))
        if child.childSnapshotList:
            for (child, depth) in walkSnapshotTreeG(child, depth):
                yield (child, depth+1)

def walkSnapshotForrestG(vm):
    # the root of vmSnapshot is special node diff from the snapshotTree
    if not vm.snapshot or not vm.snapshot.rootSnapshotList:
        return
    curSnapshot = shortMoid(vm.snapshot.currentSnapshot)
    for root in vm.snapshot.rootSnapshotList:
        yield(root)
        #walkSnapshotTree(root, 1, curSnapshot)
        for (snap, depth) in walkSnapshotTreeG(root, 1):
            yield(snap)

def prVmSnapshotTree(vm):
    # the root of vmSnapshot is special node diff from the snapshotTree
    if not vm.snapshot or not vm.snapshot.rootSnapshotList:
        print('Snapshot for VM %s(%s): None' % (vm.name, vm._moId))
        return
    curSnapshot = shortMoid(vm.snapshot.currentSnapshot)
    print('Snapshot for VM %s(%s):' % (vm.name, vm._moId))
    for root in vm.snapshot.rootSnapshotList:
        prSnapshotInfo(root.name, shortMoid(
            root.snapshot), root.createTime, curSnapshot, 0)
        #walkSnapshotTree(root, 1, curSnapshot)
        for (snap, depth) in walkSnapshotTreeG(root, 1):
            prSnapshotInfo(snap.name, shortMoid(snap.snapshot), snap.createTime, curSnapshot, depth)

def submitTask_revertToSnapshot(self, action, vm, snapshotName, snap, toaster):
    taskName = '%s %s/%s/%s' % (action, vm.name, snapshotName, shortMoid(snap.snapshot))
    fn = getattr(snap.snapshot, self.methodDict[action])
    toaster.load(taskName, submitVcTaskAndWait,
        fn=fn, si=self.vc.si,
        taskName=taskName, logger=self.logger)

def submitTask_removeSnapshot(self, action, vm, snapshotName, snap, toaster):
    taskName = '%s %s/%s/%s' % (action, vm.name, snapshotName, shortMoid(snap.snapshot))
    fn = getattr(snap.snapshot, self.methodDict[action])
    #toaster.load(taskName, submitVcTaskAndWait, \
    #    kwargs={'fn':fn, 'si':self.vc.si,
    #    'taskName':taskName, 'logger':self.logger,
    #    'kwargs':{'removeChildren':False, 'consolidate':False}})
    toaster.load(taskName, submitVcTaskAndWait,
        fn=fn, si=self.vc.si,
        taskName=taskName, logger=self.logger,
        removeChildren=False, consolidate=False)
        #kwargs={'removeChildren':False, 'consolidate':False})

class VirtualMachine(VS_object):
    vimType = vim.VirtualMachine
    list_attrs = ['name', '_moId', 'parent', 'vmHost', 'summary.config.instanceUuid']
    list_attrs = ['name', '_moId', 'parent', 'runtime.host.name']
    list_details_attrs = ['config']
    methodDict = {
        'power_on':'PowerOn',
        'power_off':'PowerOff',
        'power_reset':'ResetVM_Task',
        'bios_enter':'ReconfigVM_Task',
        'bios_exit':'ReconfigVM_Task',
        'boot_pxeB':'ReconfigVM_Task',
        'boot_hd':'ReconfigVM_Task',
        'boot_cdrom':'ReconfigVM_Task',
        'boot_default':'ReconfigVM_Task',

        'snapshot_create':'CreateSnapshot_Task',
        'snapshot_revertToCurrent':'RevertToCurrentSnapshot_Task',
        'snapshot_revert':'RevertToSnapshot_Task',
        'snapshot_delete':'RemoveSnapshot_Task',
        'snapshot_deleteall':'RemoveAllSnapshots_Task',
        'snapshot_list':'rootSnapshot',
        'snapshot_consolidate':'RemoveAllSnapshots_Task',

        'delete':'Destroy_Task',
        'powerstate':'runtime.powerState',
    }

    def get(self, vmNameGlob, getChoice=None, ipSet=set()):     # VirtualMachine
        objs = self.vc.getByType(self.vimType)

        nTargetFound = 0
        ptbl = PrettyTable()
        if getChoice == 'status':
            ptbl.field_names = ['vmName', 'powerState', 'bootTime (local)', 'cState', 'host']
        elif getChoice == 'config':
            ptbl.field_names = ['vmName', '_moId', 'RAM', 'power', 'nCPU', 'instanceUuid']
        elif getChoice == 'network':
            ptbl.field_names = ['vmName', 'vmId', 'devLabel (Key)', 'IPs', 'mac', 'netType', 'netSegment', 'connected']
        elif getChoice == 'networkGlobal':
            ptbl.field_names = ['vmName', 'gw', 'domain', 'dnsServers', 'dnsSuffixes']
        elif getChoice == 'boot':
            ptbl.field_names = ['vmName', 'enterBios', 'bootDelay', 'bootOrder']
        elif getChoice == 'regInfo':
            ptbl.field_names = ['vmName', 'vmxFile', 'cluster', 'host', 'folder']
        ptbl.sortby = 'vmName'
        ptbl.align = 'l'

        # vm.config.hardware.device.key
        # vm.config.hardware.device.deviceInfo.label
        # vm.guest.net.deviceConfigId
        # vm.guest.net.ipAddress

        for vm in self.vc.getByNamesGlob(vim.VirtualMachine, vmNameGlob):
            nTargetFound += 1
            vmName = self.vc.vimTypeNameCache['VirtualMachine'][vm]
            vmRuntime = vm.runtime
            vmCfg = vm.config
            vmCfgHw = vmCfg.hardware if vmCfg else None
            vmPowerState = vmRuntime.powerState
            if getChoice == 'status':
                bdt = vmRuntime.bootTime
                bdtLocal = cptutil.utcToLocalDatetime(bdt) if bdt else ''
                ptbl.add_row([vmName, vmPowerState,
                    '%-20.19s' % bdtLocal,
                    vmRuntime.connectionState, vmRuntime.host.name])
            elif getChoice == 'boot':
                vmBootOptions = vmCfg.bootOptions
                ptbl.add_row([vmName, vmBootOptions.enterBIOSSetup, vmBootOptions.bootRetryDelay, vmBootOptions.bootOrder])
            elif getChoice == 'regInfo':
                ptbl.add_row([vm.name, vm.config.files.vmPathName,
                    vm.resourcePool.parent.name, vm.summary.runtime.host.name, vm.parent.name])
            elif getChoice == 'networkGlobal':
                print('guest.ipStack:   ',vm.guest.ipStack)
                ipStack0 = vm.guest.ipStack[0]
                dhcpConfig = ipStack0.dhcpConfig
                dnsConfig = ipStack0.dnsConfig
                ipRouteConfig = ipStack0.ipRouteConfig
                ipStackConfig = ipStack0.ipStackConfig
                print('%-20s %s' % ('dhcpConfig', dhcpConfig))
                print('%-20s %s' % ('  domainName', dnsConfig.domainName))
                print('%-20s %s' % ('  dnsServers', dnsConfig.ipAddress))
                print('%-20s %s' % ('  dnsSuffixes', dnsConfig.searchDomain))
                print('%-20s %s' % ('ipStackConfig', ipStackConfig))
                print('Routes:')
                for ipRoute in sorted(ipRouteConfig.ipRoute, key=lambda e:e.gateway.device):
                    #if ':' in ipRoute.network: continue
                    print('    %s: %-20s %s' % (
                        ipRoute.gateway.device,
                        '%s/%s'%(ipRoute.network,ipRoute.prefixLength),
                        ipRoute.gateway.ipAddress
                        ))
                #ptbl.field_names = ['vmName/moId', 'gw', 'domain', 'dnsServers', 'dnsSuffixes']
                #ptbl.add_row(['%s\n(%s)'%(vmName,vm._moId),  'gw', 'domain', 'dnsServers', 'dnsSuffixes']
            elif getChoice == 'network':
                ''' index 400x belongs to network interfaces '''
                if not vmCfgHw:
                    ptbl.add_row(['%s\n(%s)'%(vmName,vm._moId), '', '', '', '', '', ''])
                    continue
                devIdx2AdptrMap = {dev.key%4000:dev.deviceInfo.label[16:] for dev in vmCfgHw.device if dev.key/1000 == 4}
                adptrNums = [devIdx2AdptrMap[n.deviceConfigId%4000] for n in vm.guest.net if n.deviceConfigId>=4000]

                _ip46s = ['\n    '.join(n.ipAddress) for n in vm.guest.net if n.deviceConfigId>=4000]
                _ip4s =  ['\n    '.join([ip for ip in n.ipAddress if '.' in ip]) for n in vm.guest.net if n.deviceConfigId>=4000]
                _ip6s =  ['\n    '.join([ip for ip in n.ipAddress if ':' in ip]) for n in vm.guest.net if n.deviceConfigId>=4000]
                ip46s = ('\n'.join(sorted('%2s: %s'%(i,n2) for i,n2 in zip(adptrNums,_ip46s))))
                ip4s =  ('\n'.join(sorted('%2s: %s'%(i,n2) for i,n2 in zip(adptrNums,_ip6s))))
                ip6s =  ('\n'.join(sorted('%2s: %s'%(i,n2) for i,n2 in zip(adptrNums,_ip4s))))

                '''
                if 'v4' in ipSet and 'v6' in ipSet:
                    ips = '%s\n%s' % (
                        ('\n'.join(sorted('%2s: %s'%(i,n2) for i,n2 in zip(adptrNums,_ip4s)))),
                        ('\n'.join(sorted('%2s: %s'%(i,n2) for i,n2 in zip(adptrNums,_ip6s)))))
                elif 'v6' in ipSet:
                    ips = ('\n'.join(sorted('%2s: %s'%(i,n2) for i,n2 in zip(adptrNums,_ip6s))))
                elif 'v4' in ipSet:
                    ips = ('\n'.join(sorted('%2s: %s'%(i,n2) for i,n2 in zip(adptrNums,_ip4s))))
                '''

                ips = []
                if 'v6' in ipSet:
                    ips.append(('\n'.join(sorted('%2s: %s'%(i,n2) for i,n2 in zip(adptrNums,_ip6s)))))
                if 'v4' in ipSet:
                    ips.append(('\n'.join(sorted('%2s: %s'%(i,n2) for i,n2 in zip(adptrNums,_ip4s)))))
                ips = '\n'.join(ips)

                macs, netTypes, netSegs, connecteds, devLabels = [], [], [], [], []
                devIdxes, adptrNums = [], []
                for dev in sorted([d for d in vmCfgHw.device if d.key/1000==4],key=lambda d:d.key):
                    devIfKey = dev.key%4000
                    macs.append(dev.macAddress)
                    connecteds.append(dev.connectable.connected)
                    devLabels.append('%s (%s)' % (dev.deviceInfo.label, dev.key))
                    devIdxes.append(devIfKey)
                    adptrPat = re.search(r'Network adapter (\d+)', dev.deviceInfo.label)
                    adptrNums.append('%02s'%adptrPat.group(1))
                    devBacking = dev.backing
                    devBackingStr = classTypeToShortVimTypeName(type(
                        devBacking)).replace('BackingInfo','')
                    if devBackingStr == 'DistributedVirtualPort':
                        netType = 'dvsPG'
                        try:
                            netSeg = self.vc.moid2mo(devBacking.port.portgroupKey).name
                        except Exception as e:
                            #self.logger.error('%s: %s' % (vm.name, e.msg))
                            # This happen if VM is powered off
                            netSeg = None
                    elif devBackingStr == 'OpaqueNetwork':
                        netType = devBacking.opaqueNetworkType
                        opnId = devBacking.opaqueNetworkId
                        netSeg = [n for n,k in self.vc.networkCache.items()
                            for e in k if e['opnId']==opnId][0]
                    elif devBackingStr == 'Network':
                        netType = 'vssPG'
                        netSeg = devBacking.deviceName
                    else:
                        netType = 'other'
                        netSeg = dev
                    netTypes.append(netType)
                    netSegs.append(netSeg)
                macs =       ('\n'.join('%2s:%s'%(i,n) for i,n in zip(adptrNums,macs)))
                netTypes =   ('\n'.join('%2s:%s'%(i,n) for i,n in zip(adptrNums,netTypes)))
                netSegs =    ('\n'.join('%2s:%s'%(i,n) for i,n in zip(adptrNums,netSegs)))
                connecteds = ('\n'.join('%2s:%s'%(i,n) for i,n in zip(adptrNums,connecteds)))
                devLabels =  ('\n'.join('%2s:%s'%(i,n) for i,n in zip(adptrNums,devLabels)))
                #ptbl.add_row(['%s\n(%s)'%(vmName,vm._moId), devLabels, ips, macs, netTypes, netSegs, connecteds])
                ptbl.add_row([vmName, vm._moId, devLabels, ips, macs, netTypes, netSegs, connecteds])
                #dev.deviceInfo.label == nic_label:
            elif getChoice == 'config':
                memoryMB = vmCfgHw.memoryMB if vmCfgHw else None
                numCPU = vmCfgHw.numCPU if vmCfgHw else None
                if vmPowerState == 'poweredOn':
                    ptbl.add_row([vmName, vm._moId,
                        memoryMB, vmPowerState,
                        numCPU,
                        vmCfg.instanceUuid])
                        #vmCfg.files.vmPathName])
                else:
                    ptbl.add_row([vmName, vm._moId, memoryMB,
                        vmPowerState, '', ''])

        #ptbl.hrules = prettytable.HEADER
        #ptbl.vrules = prettytable.NONE

        if ptbl._rows: print(ptbl)
        print('Count: %d' % ptbl.rowcount)

        if nTargetFound:
            self.logger.info('%d VM(s) match(es) vmName %s' % (nTargetFound, vmNameGlob))
        else:
            self.logger.error('%s %s not found' % (self.className, vmNameGlob))

    def vmHddOp(self, vmNameGlob, op=None, hddLabel='', hddSizeInMB=2048):
        vmFound = False
        VimVmDevVdiskType = vim.vm.device.VirtualDisk
        for vm in self.vc.getByNamesGlob(vim.VirtualMachine, vmNameGlob):
            ''' vm sorted by name '''
            vmFound = True
            vmName, vmMoid = vm.name, vm._moId
            if op=='add':
                disknum = 1
                controllerkey = 1000
                for disk in range(disknum):
                    self.logger.info('Adding a %d MB HDD to VM "%s"' % (hddSizeInMB, vmName))
                    dev_changes=[]
                    unit_number = 0
                    spec = vim.vm.ConfigSpec()
                    for dev in vm.config.hardware.device:
                        if hasattr(dev.backing, 'fileName') and dev.controllerKey == controllerkey:
                            unit_number += 1
                            if unit_number == 7:
                                unit_number += 1
                            if unit_number == 16:
                                cntr+=1
                                if cntr > 3:
                                    print("Can not add any more disk to vm : {0}".format(vmName))
                                    return
                                unit_number = 1
                                controllerkey +=1
                                continue
                    disk_spec = vim.vm.device.VirtualDeviceSpec()
                    disk_spec.fileOperation = "create"
                    disk_spec.operation = vim.vm.device.VirtualDeviceSpec.Operation.add
                    disk_spec.device = vim.vm.device.VirtualDisk()
                    disk_spec.device.backing = vim.vm.device.VirtualDisk.FlatVer2BackingInfo()
                    disk_spec.device.backing.thinProvisioned = True
                    disk_spec.device.backing.diskMode = "persistent"
                    disk_spec.device.unitNumber = unit_number
                    disk_spec.device.capacityInKB = hddSizeInMB * 1024
                    disk_spec.device.controllerKey = controllerkey
                    dev_changes.append(disk_spec)
                    spec.deviceChange = dev_changes

                    task = vm.ReconfigVM_Task(spec=spec)
                    self.logger.debug(task)
                    wait_for_task(task, '%s: Add HDD to "%s"'%(task,vmName), self.logger)
            elif op=='delete':
                self.logger.info('Removing disk "%s" from VM "%s"' % (hddLabel, vmName))
                vDevs = [vDev for vDev in vm.config.hardware.device
                    if isinstance(vDev, VimVmDevVdiskType) and vDev.deviceInfo.label==hddLabel]
                if len(vDevs)==1:
                    vDevUnit =  vDevs[0].unitNumber
                    virtual_disk_spec = vim.vm.device.VirtualDeviceSpec()
                    virtual_disk_spec.operation = vim.vm.device.VirtualDeviceSpec.Operation.remove
                    virtual_disk_spec.device = vDevs[0]
                    spec = vim.vm.ConfigSpec()
                    spec.deviceChange = [virtual_disk_spec]

                    task = vm.ReconfigVM_Task(spec=spec)
                    self.logger.debug(task)
                    wait_for_task(task, '%s: Delete HDD "%s" from "%s"'%(task,hddLabel,vmName), self.logger)
                else:
                    self.logger.warning('Disk "%s" not found on VM "%s"' % (hddLabel, vmName))
            elif op=='list':
                self.logger.info('Lising HDD for VM "%s"' % vmNameGlob)
                #ptbl = PrettyTable(['vm', 'diskLabel', 'capacity', 'backingDS', 'diskMode', 'thin', 'uuid', 'fileName'])
                ptbl = PrettyTable(['vm', 'diskLabel', 'capacity', 'backingDS', 'diskMode', 'thin', 'uuid'])
                ptbl.align = 'l'
                #for vDev in [vDev for vDev in vm.config.hardware.device if 2000<=vDev.key<3000]:
                for vDev in [vDev for vDev in vm.config.hardware.device if isinstance(vDev, VimVmDevVdiskType)]:
                    vDevBacking =  vDev.backing
                    #vDevBacking.fileName, vDevBacking.datastore,
                    #vDevBacking.uuid, vDevBacking.contentId, vDevBacking.parent,
                    ptbl.add_row([vm.name, vDev.deviceInfo.label, cptutil.normDiskSize(vDev.capacityInBytes),
                        vDevBacking.datastore.name, vDevBacking.diskMode, vDevBacking.thinProvisioned,
                        vDevBacking.uuid])
                if ptbl and ptbl._rows:
                    print(ptbl)
                    print('Count: %d' % ptbl.rowcount)
        if not vmFound:
            self.logger.warning('VM "%s" not found' % vmNameGlob)

    def vmOp(self, vmNameGlob, action=None, get=None, snapshotName=None,
            takeMemorySnapshot=False, powerOnAfterRevert=False, quiesce=False,
            ans=None, vmDict={}):
        ''' action:
                power    on | off | reset,
                snapshot create | delete | deleteall | revert | vevertToCurrent | list | consolidate
                bios     enter | exit
                boot     pxe | hd | cdrom | default
        '''
        vimType = self.vimType

        logLevel = logging.WARNING
        logLevel = self.logger.getEffectiveLevel()
        toaster = Toaster(self.vc.nThread, logLevel, logger=self.logger)

        vmFound = False
        ptbl = None
        for vm in self.vc.getByNamesGlob(vim.VirtualMachine, vmNameGlob):
            ''' vm sorted by name '''
            vmFound = True
            vmPowerState =  vm.runtime.powerState
            vmName = self.vc.vimTypeNameCache['VirtualMachine'][vm]

            if action in ['on', 'power_on'] and vmPowerState == 'poweredOff' or \
                    action in ['off', 'reset', 'power_off', 'power_reset'] and vmPowerState == 'poweredOn':
                self.logger.info("performing VM operation %s on %s" % (action, vmName))
                taskName = '%s-%s' % (action, vmName)
                fn = getattr(vm, self.methodDict[action])
                # using toaster from toasterlib
                #toaster.load(taskName, submitVcTaskAndWait,
                #        kwargs={'fn':fn, 'si':self.vc.si, 'taskName':taskName,
                #        'logger':self.logger})

                # using toaster from toasterlib2
                #kwargs={'fn':fn, 'si':self.vc.si, 'taskName':taskName,
                #        'logger':self.logger}
                #toaster.load(taskName, submitVcTaskAndWait,
                #        **kwargs)
                toaster.load(taskName, submitVcTaskAndWait,
                    fn=fn, si=self.vc.si, taskName=taskName,
                    logger=self.logger)
            elif action in ['on', 'off', 'reset', 'power_on', 'power_off', 'power_reset']:
                self.logger.warning("operation %s cannot be performed when VM %s is %s"
                    % (action, vmName, vmPowerState))
            elif action in ['createSnapshot', 'snapshot_create']:
                self.logger.info("%s %s for VM %s" % (action, snapshotName, vmName))
                taskName = '%s %s/%s' % (action, vmName, snapshotName)
                fn = getattr(vm, self.methodDict[action])
                #toaster.load(taskName, submitVcTaskAndWait,
                #    kwargs={'fn':fn, 'si':self.vc.si, 'taskName':taskName,
                #    'logger':self.logger,
                #    'args':(snapshotName, '', takeMemorySnapshot, True)})
                ##toaster.load(taskName, submitVcTaskAndWait,
                ##    fn=fn, si=self.vc.si, taskName=taskName,
                ##    logger=self.logger,
                ##    args=(snapshotName, '', takeMemorySnapshot, True))
                toaster.load(taskName, submitVcTaskAndWait,
                    fn, self.vc.si, taskName,
                    self.logger,
                    snapshotName, snapshotName, takeMemorySnapshot, quiesce)
            elif action in ['removeSnapshot', 'snapshot_delete']:
                ''' NOTE: if VM has multiple snapshot w/same name, removal cannot be done in parallel
                          so some remval will fail
                '''
                if not vm.snapshot or not vm.snapshot.rootSnapshotList:
                    self.logger.warning('No snapshots found on VM %s' % vmName)
                    return
                self.logger.info('removing snapshot %s from VM %s' % (
                    snapshotName, vmName))
                for root in vm.snapshot.rootSnapshotList:
                    snap = root
                    if snapshotName == snap.name:
                        submitTask_removeSnapshot(self, action, vm,
                            snapshotName, snap, toaster)
                    ssFound = False
                    for (snap, depth) in walkSnapshotTreeG(root, 1):
                        if snapshotName == snap.name:
                            ssFound = True
                            submitTask_removeSnapshot(self, action, vm,
                                snapshotName, snap, toaster)
                if not ssFound:
                    self.logger.warning('snapshot %s not found on VM %s' % (
                        snapshotName, vmName))
            elif action in ['revertToSnapshot', 'snapshot_revert']:
                if not vm.snapshot or not vm.snapshot.rootSnapshotList:
                    self.logger.warning('No snapshots found on VM %s' % vmName)
                    return
                self.logger.info('Reverting back to snapshot %s for VM %s' % (
                    snapshotName, vmName))
                snap = self.getSnapshotByName(vm, snapshotName)
                if snap:
                    submitTask_revertToSnapshot(self, action, vm,
                        snapshotName, snap, toaster)
                else:
                    self.logger.warning('snapshot %s not found on VM %s' % (
                        snapshotName, vmName))
                if powerOnAfterRevert:
                    action2 = 'power_on'
                    self.logger.info("Power on VM %s" % vmName)
                    taskName = '%s-%s' % (action2, vmName)
                    fn = getattr(vm, self.methodDict[action2])
                    toaster.load(taskName, submitVcTaskAndWait,
                        fn=fn, si=self.vc.si, taskName=taskName,
                        logger=self.logger)
            elif action == 'snapshot_revertToCurrent':
                self.logger.info("%s for VM %s" % (action, vmName))
                taskName = '%s-%s' % (action, vmName)
                fn = getattr(vm, self.methodDict[action])
                toaster.load(taskName, submitVcTaskAndWait,
                    fn=fn, si=self.vc.si, taskName=taskName,
                    logger=self.logger)
            elif action == 'snapshot_list':
                prVmSnapshotTree(vm)
            elif action.endswith('AllSnapshots') or action in ['snapshot_deleteall', 'snapshot_consolidate']:
                # removeAllSnapshots, consolidateAllSnapshots
                self.logger.info("%s for VM %s" % (action, vmName))
                taskName = '%s-%s' % (action, vmName)
                fn = getattr(vm, self.methodDict[action])
                toaster.load(taskName, submitVcTaskAndWait,
                        fn=fn, si=self.vc.si, taskName=taskName,
                        logger=self.logger,
                        consolidate = action == 'consolidateAllSnapshots')
            elif action in ['enterBios', 'exitBios', 'bios_enter', 'bios_exit']:
                self.logger.info('%s mode on next boot for VM: %s' % (action, vmName))
                bootOptions = vim.vm.BootOptions()
                bootOptions.enterBIOSSetup = (action in ['enterBios', 'bios_enter'])
                configSpec = vim.vm.ConfigSpec()
                configSpec.bootOptions = bootOptions
                taskName = '%s-%s' % (action, vmName)
                fn = getattr(vm, self.methodDict[action])
                #toaster.load(taskName, submitVcTaskAndWait,
                #        kwargs={'fn':fn, 'si':self.vc.si, 'taskName':taskName,
                #        'logger':self.logger,
                #        'args':(configSpec,)})
                #toaster.load(taskName, submitVcTaskAndWait,
                #        fn=fn, si=self.vc.si, taskName=taskName,
                #        logger=self.logger,
                #        args=(configSpec,) )
                toaster.load(taskName, submitVcTaskAndWait,
                        fn=fn, si=self.vc.si, taskName=taskName,
                        logger=self.logger,
                        spec=configSpec )
            elif action.endswith('Boot') or action.startswith('boot'):
                # pxeBoot hdBoot cdromBoot defaultBoot
                self.logger.info('set boot order to %s for VM: %s' % (action, vmName))
                intNicDeviceKey = 4000
                intHdDeviceKey = 2000
                intCdromDeviceKey = 3002
                oBootableNIC = vim.VirtualMachineBootOptionsBootableEthernetDevice()
                oBootableNIC.deviceKey = intNicDeviceKey
                oBootableHD = vim.VirtualMachineBootOptionsBootableDiskDevice()
                oBootableHD.deviceKey = intHdDeviceKey
                oBootableCDROM = vim.VirtualMachineBootOptionsBootableCdromDevice()
                bootOptions = vim.vm.BootOptions()
                if action.startswith('pxe') or action.endswith('pxe'):
                    bootOptions.bootOrder = [oBootableNIC, oBootableCDROM, oBootableHD]
                elif action.startswith('hd') or action.endswith('hd'):
                    bootOptions.bootOrder = [oBootableHD, oBootableCDROM, oBootableNIC]
                elif action.startswith('cdrom') or action.endswith('cdrom'):
                    bootOptions.bootOrder = [oBootableCDROM, oBootableHD, oBootableNIC]
                elif action.startswith('default') or action.endswith('default'):
                    bootOptions.bootOrder = [oBootableCDROM, oBootableNIC, oBootableHD]
                configSpec = vim.vm.ConfigSpec()
                configSpec.bootOptions = bootOptions
                taskName = '%s-%s' % (action, vmName)
                fn = getattr(vm, self.methodDict[action])
                toaster.load(taskName, submitVcTaskAndWait,
                        fn=fn, si=self.vc.si, taskName=taskName,
                        logger=self.logger,
                        spec=configSpec)
                        #args=(configSpec,))
            elif action == 'alarm_list':
                if ptbl==None:
                    ptbl = PrettyTable(['vm', 'time', 'name', 'ACKed', 'ACKtime', 'status'])
                    ptbl.align = 'l'
                alarms = vm.triggeredAlarmState
                #print('List (%d) Alarms for %s' % (len(alarms), vmName))
                for alm in alarms:
                    ptbl.add_row([vm.name, alm.time.strftime('%D %T.%f')[:21], alm.alarm.info.name,
                        alm.acknowledged, alm.acknowledgedTime, alm.overallStatus, ])
            elif action.startswith('question_'):
                question = vm.runtime.question
                if question:
                    qId = question.id
                    defAnsIdx = question.choice.defaultIndex
                    choices = [':'.join((choice.key, choice.label))
                        for choice in question.choice.choiceInfo]
                    if action == 'question_list':
                        ptbl = PrettyTable(['vmName', 'Question', 'Answers'])
                        ptbl.align = 'l'
                        if question:
                            #print(question)
                            choices[defAnsIdx] += '*'
                            ptbl.add_row(['%s\n(%s)'%(vm.name,vm._moId),
                                textWrapCol('%s(%s)'%(question.text,qId), 50),
                                '\n'.join(choices)])
                        if ptbl._rows:
                            print(ptbl)
                            print('Count: %d' % ptbl.rowcount)
                    elif action == 'question_answer':
                        if question:
                            defFlag = '(default)' if ans is None else ''
                            ansIdx = str(ans or defAnsIdx)
                            self.logger.info('Answering for VM %s: "%s...": %s%s' %
                                (vm.name, question.text[:20], choices[int(ansIdx)], defFlag))
                            vm.AnswerVM(qId, ansIdx)
            elif action=='register':
                # handles down below in 'not vmFound' block
                self.logger.error('VM with name "%s" already exist' % vm.name)
            elif action=='unregister':
                self.logger.info('Unregistering VM %s' % vm.name)
                vm.Unregister()
            elif action=='reregister':
                vmName = vm.name
                vmDict = {
                    'vmName':vmName,
                    'vmxFile':vm.config.files.vmPathName,
                    'clusterName':vm.resourcePool.parent.name,
                    'folderName':vm.parent.name,
                    'hostName':vm.summary.runtime.host.name}
                self.logger.info('Unregistering VM %s' % vmName)
                vm.Unregister()
                self.logger.info('Reregistering VM %s' % vmName)
                vmFound = False
                action = 'register'
            else:
                self.logger.error("Don't know how to handle %s for VM: %s" %
                    (action, vmName))

        if ptbl and ptbl._rows:
            print(ptbl)
            print('Count: %d' % ptbl.rowcount)

        if not vmFound:
            if action=='register':
                #vmDict = {
                #    'vmName':'vlan2026-vm0197',
                #    'vmxFile':'[nsx_nfs1]/vlan2026-vm0197/vlan2026-vm0197.vmx',
                #    'clusterName':'cluster4',
                #    'folderName':'testfolder',
                #    'hostName':'50.5.0.26',
                #    }
                for k in vmDict:
                    exec('%s = "%s"' % (k, vmDict[k]))
                pool = self.vc.getByName(vim.ComputeResource, clusterName).resourcePool
                host = self.vc.getByName(vim.HostSystem, hostName)
                folder  = self.vc.getByName(vim.Folder, folderName)

                self.logger.info('Registering %s as %s on %s/%s in folder %s' %
                    (vmxFile, vmName, clusterName, hostName, folderName))

                #si = self.vc.si
                #host = si.content.searchIndex.FindByDnsName(None, hostName, False)
                #folder = si.content.searchIndex.FindByInventoryPath(folderName)
                #print(hostName, host, folderName, folder)

                #for k in vmDict:
                #    print('%s = %s' % (k, vmDict[k]))
                #print('pool = %s' % pool)
                #exit()

                task = folder.RegisterVM_Task(path=vmxFile, name=vmName, asTemplate=False, pool=pool, host=host)
                wait_for_task(task, '%s:register_VM_%s'%(task,vmName), self.logger)
            else:
                self.logger.warning('VM %s not found' % vmNameGlob)
        else:
            toaster.wait()

    def changeVmsNicsState(self, vmNames, nicStatesSpec):
        """
        :param vmNames: list of VM names (glob style)
        :param nicStatesSpec: <n>:<state>[,<n>:<state>]...
            n:      nic number starts from 1
            state:  "connect" | "disconnect"
            eg: 1:connect,2:disconnect,3:connect
        """
        self.logger.info('Set VM "%s" NICs state: "%s"' % (vmNames, nicStatesSpec))
        nicDict = dict([item.split(':') for item in
            [spec for spec in nicStatesSpec.split(',')]])
        for vmMo in self.getByNamesGlob(vmNames):
            dev_changes = []
            for nicNum,nicState in nicDict.items():
                nicNum = int(nicNum)
                if nicState not in ['connect', 'disconnect', 'delete']:
                    self.logger.error('Invalid VM NIC state "%s"' % nicState)
                    return False

                nic_prefix_label = 'Network adapter '
                nic_label = nic_prefix_label + str(nicNum)
                virtual_nic_device = None
                for dev in vmMo.config.hardware.device:
                    if isinstance(dev, vim.vm.device.VirtualEthernetCard) \
                            and dev.deviceInfo.label == nic_label:
                        virtual_nic_device = dev
                if not virtual_nic_device:
                    raise RuntimeError('Virtual {} could not be found.'.format(nic_label))

                virtual_nic_spec = vim.vm.device.VirtualDeviceSpec()
                virtual_nic_spec.operation = \
                    vim.vm.device.VirtualDeviceSpec.Operation.remove \
                    if nicState == 'delete' \
                    else vim.vm.device.VirtualDeviceSpec.Operation.edit
                virtual_nic_spec.device = virtual_nic_device
                virtual_nic_spec.device.key = virtual_nic_device.key
                virtual_nic_spec.device.macAddress = virtual_nic_device.macAddress
                virtual_nic_spec.device.backing = virtual_nic_device.backing
                if hasattr(virtual_nic_device.backing, 'port'):
                    virtual_nic_spec.device.backing.port = virtual_nic_device.backing.port
                elif hasattr(virtual_nic_device.backing, 'network'):
                    virtual_nic_spec.device.backing.network = virtual_nic_device.backing.network
                virtual_nic_spec.device.wakeOnLanEnabled = virtual_nic_device.wakeOnLanEnabled
                connectable = vim.vm.device.VirtualDevice.ConnectInfo()
                if nicState in ['connect', 'disconnect']:
                    connectable.connected = connectable.startConnected = nicState=='connect'
                else:
                    connectable = virtual_nic_device.connectable
                virtual_nic_spec.device.connectable = connectable
                dev_changes.append(virtual_nic_spec)
            spec = vim.vm.ConfigSpec()
            spec.deviceChange = dev_changes
            task = vmMo.ReconfigVM_Task(spec=spec)
            #tasks.wait_for_tasks(self.vc.si, [task])
            task.wait()
            self.logger.info('Set NIC states: %s' % task.info.state)
        return True

    def attachOpaqueNetworkDevBacking(self, vmName, dev, opaqueNet):
        self.logger.info('Attaching opaque network "%s" to network adapter' % opaqueNet.name)
        dev.backing = vim.vm.device.VirtualEthernetCard.OpaqueNetworkBackingInfo()
        dev.backing.opaqueNetworkId = opaqueNet.summary.opaqueNetworkId
        dev.backing.opaqueNetworkType = opaqueNet.summary.opaqueNetworkType
        if hasattr(dev, 'externalId') and dev.externalId:
            # initilize dev.externalId empty string to trigger creation of new VIF
            self.logger.info("current external id: %s" % dev.externalId)
            self.logger.info("setting external id to null for %s" % vmName)
            #dev.externalId = None # this is the VIF, should be '' for newly cloned VM, so new VIF will be create

    def changeVmsNicsConnection(self, vmNames, nicConnsSpec):
        """
        :param vmNames: list of VM names (glob style)
        :param nicConnsSpec: <n>:<netType>:<swName>:<connState>
            n:          nic number starts from 1
            netType:     n=VSS, d=DVSPG, v=NSXV-LoggicalSwich, t=NSXT-switch
            swName:     name of switch/logial switch
            connState:  "connect" | "disconnect"
            eg: 1:n:VM Network:connect,2:d:vlan2023a:connect,3:v:LS1:connect,4:t:LS2:connect
        """

        self.logger.info('Set VM "%s" NICs state: "%s"' % (vmNames, nicConnsSpec))
        nicTuples = [item.split(':') for item in
            [spec for spec in nicConnsSpec.split(',')]]
        swTypeMap = {'pg':'vss', 'dvpg':'dvpg', 'ls':'nsxvLS', 'opaque':'nsxtLS'}
        swTypeMap = {'pg':'pg', 'dvpg':'dvpg', 'ls':'ls', 'opaque':'opaque'}
        swTypeMap = {'n':'pg', 'd':'dvpg', 'v':'ls', 't':'opaque'}
        inv = self.vc.si.RetrieveContent()
        dvpgMo = DistributedVirtualPortgroup(self.vc)
        # vs-ctl.py --log debug 10.114.13.191 -u administrator@vsphere.local -p 'Vmware123!' vm nic connection 2:d:Nest_Trunk_Ext:connect,1:d:Nest_Trunk_Int:connect  nesx-50-4-0-0136
        configSpec = vim.vm.ConfigSpec()
        for vmMo in self.getByNamesGlob(vmNames):
            vmName = vmMo.name
            #print(vmMo.name); continue
            for nicNum,netType,swName,connState in nicTuples:
                nicNum = int(nicNum)
                netType = swTypeMap.get(netType, None) or netType
                self.logger.info('VM "%s": %10s NIC #%d to %s "%s"' %
                    (vmName, connState, nicNum, netType, swName))
                for dev in vmMo.config.hardware.device:
                    reo = re.match('Network adapter (\d+)', dev.deviceInfo.label)
                    if reo and reo.group(1)==str(nicNum):
                        dev.connectable.startConnected = True
                        dev.connectable.allowGuestControl = True
                        dev.connectable.connected=True
                        break
                else:
                    dev = None
                    self.logger.error('Network adapter %s not found' % nicNum)
                swMo = dvpgMo.getByName(swName)
                if netType=='dvpg':
                    dvsPortConn = vim.dvs.PortConnection()
                    dvsPortConn.portgroupKey = swMo.key
                    dvsPortConn.switchUuid = swMo.config.distributedVirtualSwitch.uuid
                    dev.backing = vim.vm.device.VirtualEthernetCard.DistributedVirtualPortBackingInfo()
                    dev.backing.port = dvsPortConn
                    virdev = vim.vm.device.VirtualDeviceSpec()
                    virdev.device = dev
                    virdev.operation = vim.vm.device.VirtualDeviceSpec.Operation.edit
                    configSpec.deviceChange.append(virdev)
                else:
                    vcNetCache = self.vc.networkCache
                    if swName in vcNetCache:
                        for netMap in [n for n in vcNetCache[swName] if n['type']=='opaque']:
                            self.logger.info('Found %s "%s (%s)' % (
                                netmap['type'], swName, netmap['mo']._moId))
                            self.attachOpaqueNetworkDevBacking(vmName, dev, netmap['mo'])
            task = vmMo.Reconfigure(configSpec)
            #tasks.wait_for_tasks(self.vc.si, [task])
            waitForTask(task, 'reconfig vnic for %s'%vmName, self.logger)

        return True

    #def delete(self, vmName, mo=None):                             # VirtualMachine()
    #    print('DELETE vmName: %s' % vmName)
    #    if not mo:
    #        mo = self.getByName(vmName)
    #    if mo:
    #        if mo.config.template:
    #            self.logger.warning("VM %s is a template, will not delete" % mo.name)
    #            return
    #    else:
    #        self.logger.error('%s %s not found' % (
    #            vimClassNameToShortVimTypeName(self.vimType), vmName))
    #        return
    #    super(self.__class__, self).delete(vmName)

    def deleteMultiple(self, globNames, pwrOffFirst=False):         # VirtualMachine()
        for globName in globNames:
            mos = self.getByNamesGlob(globName, refresh=True)
            for mo in mos:
                name = mo.name
                if mo.config.template:
                    self.logger.warning("VM %s is a template, will not delete" % mo.name)
                    continue
                if pwrOffFirst:
                    self.vmOp(name, action='power_off')
                self.logger.info('deleting %s %s' % (self.__class__.__name__, name))
                if mo :
                    task = mo.Destroy()
                    waitForTask(task, 'Delete %s %s'%(self.__class__.__name__, name), self.logger)
                else:
                    self.logger.error('object %s does not exist!' % name)

    def getSnapshotByName(self, vm, snapshotName):
        if not vm.snapshot or not vm.snapshot.rootSnapshotList:
            self.logger.warning('snapshot %s not found on VM %s' % (
                snapshotName, vm.name))
            return None
        for root in vm.snapshot.rootSnapshotList:
            if snapshotName == root.name:
                return root
            for (snap, depth) in walkSnapshotTreeG(root, 1):
                if snapshotName == snap.name:
                    return snap

def connectSmartConnectWrapper(host, user, pwd, logger=None):
    """
    return connect.SmartConnect(host=host,      user=user,      pwd=pwd)

    if 'sslContext' in cptutil.funcArgs(connect.SmartConnect):
        ''' pyVmomi 6.0: SmartConnect accepts sslContext '''
        context = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
        context.verify_mode = ssl.CERT_NONE
        si = connect.SmartConnect(host=host, user=user, pwd=pwd,
            sslContext=context)
    else:
        ''' pre pyVmomi 6.0: have to change default ssl context for SmartConnect '''
        default_context = ssl._create_default_https_context
        ssl._create_default_https_context = ssl._create_unverified_context
        si = connect.SmartConnect(host=host, user=user, pwd=pwd)
        ssl._create_default_https_context = default_context
    """

    if hasattr(ssl, 'SSLContext'):
        context = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
        context.verify_mode = ssl.CERT_NONE
        si = connect.SmartConnect(host=host, user=user, pwd=pwd,
            sslContext=context)
    else:
        si = connect.SmartConnect(host=host, user=user, pwd=pwd)


    if not si:
        if logger:
            logger.error("Could not connect to the vcenter %s" % vcenter)
        return None
    else:
        atexit.register(connect.Disconnect, si)
        return si

#class Vcenter(object, metaclass=Singleton):
class Vcenter(object):
    __metaclass__ = Singleton
    def __init__(self, vcIp, vcUser, vcPass,
            logLevel=logging.INFO, nThread=1,
            logger=None, requestsLogLevel=logging.WARNING):
        # get vCenter info from NSX manager
        self.vcIp = vcIp
        self.vcUser = vcUser
        self.vcPass = vcPass
        self.nThread = nThread

        self.logger = logger if logger else cptutil.cptLogger(logLevel)
        logging.getLogger("requests").setLevel(requestsLogLevel)

        self.logger.info2('Connecting to vCenter: %s (%s, %s)' % (vcIp, vcUser, vcPass))
        si = connectSmartConnectWrapper(vcIp, vcUser, vcPass, logger=self.logger)

        """
        if 'sslContext' in cptutil.funcArgs(connect.SmartConnect):
            ''' pyVmomi 6.0: SmartConnect accepts sslContext '''
            context = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
            context.verify_mode = ssl.CERT_NONE
            si = connect.SmartConnect(host=vcIp, user=vcUser, pwd=vcPass,
                sslContext=context)
        else:
            ''' pre pyVmomi 6.0: have to change default ssl context for SmartConnect '''
            default_context = ssl._create_default_https_context
            ssl._create_default_https_context = ssl._create_unverified_context
            si = connect.SmartConnect(host=vcIp, user=vcUser, pwd=vcPass)
            ssl._create_default_https_context = default_context

        '''
        try:
            si = connect.SmartConnect(host=vcIp, user=vcUser, pwd=vcPass)
        except Exception as e:
            # exception handling for pyVmomi 6.0.0/python 2.7.9
            import ssl, socket
            if isinstance(e, ssl.SSLError) and 'SSL' in e.library \
                    and 'CERTIFICATE_VERIFY_FAILED' in e.reason:
                self.logger.warning('vCenter SmartConnect: %s' % e.reason)
                try:
                    default_context = ssl._create_default_https_context
                    ssl._create_default_https_context = ssl._create_unverified_context
                    si = connect.SmartConnect(host=vcIp, user=vcUser, pwd=vcPass)
                    ssl._create_default_https_context = default_context
                except Exception as e1:
                    self.logger.error('%s %s' % (type(e), e))
                    raise Exception(e1)
            else:
                self.logger.error('%s %s' % (type(e), e))
                raise Exception(e)
        '''

        if not si:
            self.logger.error("Could not connect to the vcenter %s" % vcenter)
        else:
            atexit.register(connect.Disconnect, si)
        """

        self.vimTypeNameCache = {}
        self.inv = si.RetrieveContent()
        self.si = si

    def get_properties(self, viewType, props, specType):
        # Build a view and get basic properties for all Virtual Machines
        """
        Obtains a list of specific properties for a particular Managed Object Reference data object.

        :param content: ServiceInstance Managed Object
        :param viewType: Type of Managed Object Reference that should populate the View
        :param props: A list of properties that should be retrieved for the entity
                      poperty can be a immediate property of SpecType OR
                      indirect property (denoted by '.', indirect poperty must be moref, not leaf property
        :param specType: Type of Managed Object Reference that should be used for the Property Specification

        Example usage:
        retProps = vc.get_properties([vim.VirtualMachine], ['name', 'snapshot'], vim.VirtualMachine)
        retProps = vc.get_properties([vim.VirtualMachine], ['name', 'network'], vim.VirtualMachine)

        """
        content = self.si.content
        objView = content.viewManager.CreateContainerView(content.rootFolder, viewType, True)
        tSpec = vim.PropertyCollector.TraversalSpec(name='tSpecName', path='view', skip=False, type=vim.view.ContainerView)
        pSpec = vim.PropertyCollector.PropertySpec(all=False, pathSet=props, type=specType)
        oSpec = vim.PropertyCollector.ObjectSpec(obj=objView, selectSet=[tSpec], skip=False)
        pfSpec = vim.PropertyCollector.FilterSpec(objectSet=[oSpec], propSet=[pSpec], reportMissingObjectsInResults=False)
        retOptions = vim.PropertyCollector.RetrieveOptions()
        totalProps = []
        retProps = content.propertyCollector.RetrievePropertiesEx(specSet=[pfSpec], options=retOptions)
        totalProps += retProps.objects
        while retProps.token:
            retProps = content.propertyCollector.ContinueRetrievePropertiesEx(token=retProps.token)
            totalProps += retProps.objects
        objView.Destroy()
        # Turn the output in retProps into a usable dictionary of values
        gpOutput = []
        for eachProp in totalProps:
            propDic = {}
            for prop in eachProp.propSet:
                propDic[prop.name] = prop.val
            propDic['moref'] = eachProp.obj
            gpOutput.append(propDic)
        return gpOutput


    def getByType(self, vimTypes, container=None, refresh=False):
        """
        Get object list by vimtype from vcenter inventory
        vmtype - object type
        Returns list of objects if found, None otherwise
        """
        self.logger.debug4('ENTER')
        if not isinstance(vimTypes, list):
            vimTypes = [ vimTypes ]
        vimType = vimTypes[0]
        vimType_s = vimClassNameToShortVimTypeName(vimType)
        if not refresh and vimType_s in self.vimTypeNameCache:
            self.logger.debug4('RETURN (cache)')
            return self.vimTypeNameCache[vimType_s].keys()
        container = container or self.inv.rootFolder
        mos = self.inv.viewManager.CreateContainerView(container, vimTypes, True).view
        self.vimTypeNameCache[vimType_s] = {}
        for mo in mos:
            self.vimTypeNameCache[vimType_s][mo] = mo.name
        self.logger.debug4('RETURN (non-cache)')
        return self.vimTypeNameCache[vimType_s].keys()

    def getByName(self, vimType, vimName, container=None, refresh=False):               # class Vcenter
        """
        Get object of vimtype from vcenter inventory by name
        """
        self.logger.debug4('ENTER')
        sVimType = vimClassNameToShortVimTypeName(vimType)
        objs = self.getByType(vimType, container, refresh=refresh)
        for obj in objs:
            #if obj.name == vimName:
            #    return obj
            if self.vimTypeNameCache[sVimType][obj] == vimName:
                return obj
        self.logger.debug4('RETURN')
        return None

    def getByNameGlob(self, vimType, vimNamesGlob, container=None, refresh=False):      # class Vcenter
        self.logger.warning('This method is deprecated, use getByNamesGlob instead')    # 2017-05-03
        return self.getByNamesGlob(vimType, vimNamesGlob, container=container, refresh=refresh)

    def getByNamesGlob(self, vimType, vimNamesGlob, container=None, refresh=False):     # class Vcenter
        """
        Get object of vimtype from vcenter inventory by name
        """
        self.logger.debug4('ENTER')
        rList = []
        sVimType = vimClassNameToShortVimTypeName(vimType)
        objs = self.getByType(vimType, container, refresh=refresh)
        #print(self.vimTypeNameCache[sVimType])
        for vimNameGlob in listify(vimNamesGlob):
            tList = filter(lambda x:
                isGlobMatched(vimNameGlob, self.vimTypeNameCache[sVimType][x]),
                self.vimTypeNameCache[sVimType])
            rList.extend(tList)
        self.logger.debug4('RETURN')
        return rList

    def moid2mo(self, moid):
        if ':' in moid:
            mo = eval('%s("%s")' % tuple(moid.split(':')))
        elif moid.startswith('host-'):
            mo = vim.HostSystem(moid)
        elif moid.startswith('datacenter-'):
            mo = vim.Datacenter(moid)
        elif moid.startswith('vm-'):
            mo = vim.VirtualMachine(moid)
        elif moid.startswith('network-'):
            mo = vim.Network(moid)
        elif moid.startswith('dvportgroup-'):
            mo = vim.dvs.DistributedVirtualPortgroup(moid)
        elif moid.startswith('group-'):
            mo = vim.Folder(moid)
        elif moid.startswith('domain-'):
            mo = vim.ClusterComputeResource(moid)
        elif moid.startswith('datastore-'):
            mo = vim.Datastore(moid)
        elif moid.startswith('resgroup-'):
            mo = vim.ResourcePool(moid)
        elif moid.startswith('dvs-'):
            mo = vim.DistributedVirtualSwitch(moid)
        elif moid.startswith('task-'):
            mo = vim.Task(moid)
        else:
            self.logger.error("Don't know how to handle MOID %s" % moid)
            return None
        mo._stub = self.si._stub
        return mo

    def moid2name(self, moid):
        return shortMoid(self.moid2mo(moid))

    @property
    def networkCache(self):
        if not hasattr(self, '_networkCache'):
            self.logger.info('Populating network configuration cache')
            networkCache = {}
            container = self.inv.viewManager.CreateContainerView(self.inv.rootFolder, [vim.Network], True)
            for obj in container.view:
                nName, nSummary, nType, dvsName, dvsMoid = obj.name, obj.summary, 'Unknown', '', None
                vlsName, opnId = '', ''
                if type(nSummary)==vim.OpaqueNetwork.Summary:
                    nType = 'opaque'
                    vlsName = obj.name
                    opnId = obj.summary.opaqueNetworkId
                elif hasattr(obj, 'config') and isinstance(obj.config,
                        vim.dvs.DistributedVirtualPortgroup.ConfigInfo):
                    nType = 'dvsPG'
                    dvsMo = obj.config.distributedVirtualSwitch
                    dvsName = dvsMo.config.name
                    dvsMoid = dvsMo._moId
                    reObj = re.search('vxw-dvs-\d+-virtualwire-\d+-sid-\d+-(.*)', obj.name)
                    if reObj:
                        vlsName = reObj.group(1)
                else:
                    nType = 'vssPG'
                    #print('%-25s %-60s %s' % (nType, nName, obj))
                #print('Caching netweork %-25s %-20s %-10s %-12s %s' % (nName, obj._moId, nType, dvsName, dvsMoid))

                newEntry = {
                    'mo':     obj,
                    'type':   nType,
                    'dvsName':dvsName,
                    'dvsMoid':dvsMoid,
                    'vlsName':vlsName,
                    'opnId':  opnId,
                }
                if nName not in networkCache:
                    networkCache[nName] = [newEntry]
                else:
                    ''' multiple entries w/same nName found, store all and sort by moId '''
                    networkCache[nName].append(newEntry)
                    networkCache[nName] = sorted(networkCache[nName], key=lambda a:a['mo']._moId)
                    self.logger.warning('Duplicated network name: %s (%s)' % (
                        nName, ', '.join([n['mo']._moId for n in networkCache[nName]])))
            self._networkCache = networkCache
            self.logger.info('Populated  network configuration cache')
        return self._networkCache

    def findNetwork(self, netName=None, netType=None, opnId=None):
        ''' netType: opaque | vssPG | dvsPG
            required: netName + netType
                      opnId
        '''
        vcNetCache = self.networkCache()
        for n,v in vcNetCache.items():
            if (netName and n==netName):
                pass
        pass

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('vcenter')
    args = parser.parse_args()

    vc = Vcenter(args.vcenter, 'administrator@vsphere.local', 'Vmware123!')

    vimType = vimDict['folder']; vimName = 'Web1'
    vimType = vimDict['vm'];     vimName = 'vm-App1-0111'; container='vim.Folder:group-v17'

    #print(vc.getByType(vimType))
    #print(vc.getByName(vimType, vimName))

    #print(vc.getByType(vimDict['dc']); exit())

    objClusters = vc.getByType(vimDict['cluster'])
    objClusters = sorted(objClusters, key=lambda x: x.__getattribute__('name'))
    print([(obj.name, obj._moId)  for obj in objClusters])
    objCluster1 = vc.getByName(vimDict['cluster'], 'cluster1')

    print(vc.getByType(vimDict['host'], objCluster1))
    print(vc.getByName(vimDict['host'], '50.4.0.45', objCluster1))

    task = vim.Task('task-25296')
    print('task = %s' % task)
    print('type(task) = %s' % type(task))
    print('dir(task) = %s' % dir(task))
    print('dir.info = %s' % task.info)
    print('%s %s %s %s' % (task, task.info.name, task.info.state, task.info.reason))

    #print(vc.getByName(vimType, vimName, container))

    #print(vc.getObjectFromVcenterInventory([vimVMType], vmName))
    #print(vc.getInvObjListByType([vimVMType]))
    #print(vc.getObjectListFromContainer(vc.inv.rootFolder, [vimVMType]))
    #print(vc.getObjectFromContainer(vc.inv.rootFolder, [vimVMType], vmName))


if __name__ == "__main__":
    main()
