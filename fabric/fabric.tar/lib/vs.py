#!/usr/bin/python
import pinit
import vslib
#from vslib import connectSmartConnectWrapper
from pyVim import connect
from pyVmomi import vim
from tools import tasks
import atexit
import argparse
import getpass
import requests
import ssl
requests.packages.urllib3.disable_warnings()

def findPortGroup(dvs, pgname):
    """
    Find and return portgroup in DVS object by portgroup name
    """
    obj = None
    for n in dvs.portgroup:
        if n.name == pgname:
            obj = n
            break
    return obj

def findPortGroupById(inv, pgid):
    container = inv.viewManager.CreateContainerView(inv.rootFolder,
            [vim.dvs.DistributedVirtualPortgroup], True)

    for i in container.view:
        if i.key == pgid:
            return i
    return None
                                    


def getObjectListFromContainer(inv, container, vimtype):
    """
    Find and return all objects of vimtype in container
    """
    view =  inv.viewManager.CreateContainerView(container, vimtype, True)
    return view.view



def getObjectFromContainer(inv, container, vimtype, name):
    """
    Find an object by name within the specified vcenter container.
    Return the object if found, else None.

    Containers are defined in:
    https://github.com/vmware/pyvmomi/blob/master/docs/vim/view/ViewManager.rst 
      Folder, Datacenter, ComputeResource, ResourcePool, HostSystem
      

    *Does not seem to work for vim.Network/vim.dvs.DistributedVirtualPortgroup
         for HostSystem
    """

    obj = None
    objects = inv.viewManager.CreateContainerView(container, 
                                                  vimtype,
                                                  True)
    for i in objects.view:
        if i.name == name:
            obj = i;
            break;
    return obj


def getObjectFromVcenterInventory(inv, vimtype, name):
    """
    Get object by name from vcenter inventory
    inv - Inventory
    vmtype - object type 
    name - object name to search for
    Returns object if found, None otherwise
    """
    obj = None
    container = inv.viewManager.CreateContainerView(inv.rootFolder, 
                                                    vimtype, 
                                                    True)

    for i in container.view:
        if i.name == name:
            obj = i
            break
    return obj


def find_cluster_by_name(inv, name):
    '''
    Given VC inventory object, find and return a cluster by name, None otherwise
    '''
    return getObjectFromVcenterInventory(inv, [vim.ClusterComputeResource], name)


def find_vm_by_clusterlist(inv, clusterlist,name):

   retL = []

   for cluster in clusterlist:
        obj = find_cluster_by_name(inv,cluster)
        if obj == None:
          raise ValueError('no cluster object found for :%s' %cluster)
        for host in obj.host:
           for vm in host.vm:
                if (isinstance(vm, vim.VirtualMachine)):
                 if (vm.name.find(name) != -1):
                   if vm.config.template == False:
                        retL.append(vm._moId)
   return retL


def incrIp(ip):
    """
    Increase the IP address by 1 and return it
    ip - IP address in dotted notation
    """

    iplist = ip.split(".")
    iplist[0] = int(iplist[0])
    iplist[1] = int(iplist[1])
    iplist[2] = int(iplist[2])
    iplist[3] = int(iplist[3])
    if (iplist[3] < 255):
        iplist[3] = iplist[3] + 1
    else:
        iplist[3] = 1
        if (iplist[2] < 255):
            iplist[2] = iplist[2] + 1
        else:
            iplist[2] = 0
            if (iplist[1] < 255):
                iplist[1] = iplist[1] + 1
            else:
                print("broken IP setup")
                exit()

    newip = str(iplist[0]) + "." + str(iplist[1]) + "." + str(iplist[2]) + "." + str(iplist[3])
    return newip

def getPassword(service, user, pwd):
    if pwd:
        password = pwd
    else:
        password = getpass.getpass("Enter the password for user %s for %s:" 
                %(service, user))
    return password



def getConnected(vcenter, user, pwd=None):
    """
    Connected to the specified vcenter, user and password.  
    Return service instance
    """

    if not pwd:
        pwd=getpass.getpass("Enter password for vcenter user %s:" %user)

    if hasattr(ssl, 'SSLContext'):
        context = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
        context.verify_mode=ssl.CERT_NONE
        si = connect.SmartConnect(host=vcenter, user=user, pwd=pwd, sslContext=context)
    else:
        si = connect.SmartConnect(host=vcenter, user=user, pwd=pwd)
        
    if not si:
        print("Could not connect to the vcenter %s" %vcenter)
        return None
    else:
        atexit.register(connect.Disconnect, si)
    inv = si.RetrieveContent()
    return {'si': si, 'inv': inv}

def main():
    pass


if __name__ == "__main__":
    main()

