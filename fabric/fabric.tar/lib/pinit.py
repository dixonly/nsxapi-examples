import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))+'/../lib')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))+'/../nsxv')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))+'/../vm')
