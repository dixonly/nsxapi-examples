#!/usr/bin/python
import pinit
import atexit
import requests
import json
requests.packages.urllib3.disable_warnings()

class VCenter(object):
    def __init__(self, host, port=443, user='Administrator@vsphere.local',
                 password='Vmware123!', content='application/json',
                 accept='application/json', verify=False,timeout=None,
                 cookie=None):
    

        self.host = host
        self.port = port
        self.server='https://%s:%s' %(self.host, self.port)
        self.headers={'Content-Type': content, 'Accept': accept}
        self.user = user
        self.password=password
        self.session = requests.Session()
        self.timeout=timeout

        self.requestAttr = {
            'headers': self.headers,
            'verify': verify,
        }
        self.headers['vmware-api-session-id'] = None
        if cookie:
            self.headers['vmware-api-session-id'] = cookie
        else:
            self.requestAttr['auth'] = (self.user, self.password)
            self.headers['vmware-api-session-id'] = self.getConnected()
            del self.requestAttr['auth']
            
    def __checkReturnCode(self, result, codes):
        '''
        Checks HTTP requests result.status_code against a list of accepted codes
        '''
        if codes:
            if result.status_code not in codes:
                raise ValueError("Return code '%d' not in list of expected codes: %s\n %s"
                      %(result.status_code,codes, result.text))

    def getConnected(self):
        r = self.post(api='/rest/com/vmware/cis/session',
                  data=None, codes=[200])
        
        return r['value']
    
    def get(self, api, verbose=True, trial=False, codes=None):
        '''
        REST API get request
        api - REST API, this will be appended to self.server
        verbose - if True, will print info about API and results
        trial - if True, will not execute the specified called.
                combine with verbose=true to see what'll be submitted
                NSX
        codes - List of HTTP request status codes for success
        '''

        url = self.server+api
        if verbose:
            print("API: GET %s" %url)
        if not trial:
            r = self.session.get(url, timeout=self.timeout,
                                 **self.requestAttr)
            self.__checkReturnCode(r, codes)
            if verbose:
                print("result code: %d" % r.status_code)
                #print(json.dumps(json.loads(r.text), indent=4))
        else:
            if verbose:
                print("API not called - in safe mode")
            return None
        return json.loads(r.text)

    def patch(self, api, data=None, verbose=True,trial=False, codes=None):
        '''
        REST API patch request.  Note that this does not
             check entity revision
        api - REST API, this will be appended to self.server
        data - dictionary (not json string) to be submiited
        verbose - if True, will print info about API and results
        trial - if True, will not execute the specified called.
                combine with verbose=true to see what'll be submitted
                NSX
        '''
        url=self.server+api
        if verbose:
            print("API: PATCH %s with data:" %url)
            print(json.dumps(data, indent=4))
        if not trial:
            r = self.session.patch(url,data=json.dumps(data),
                                   timeout=self.timeout,
                                   **self.requestAttr)
            if verbose:
                print('result code: %d' %r.status_code)
                if r.text:
                    print(r.text)
        else:
            if verbose:
                print("API not called - in safe mode")
            return None
        self.__checkReturnCode(r, codes)
        return  r

    def put(self, api, data=None,verbose=True,trial=False, codes=None):
        '''
        REST API put requests.  Note that any put request must submit data
            contain a revision version that matches current version in NSX
        api - REST API, this will be appended to self.server
        data - dictionary (not json string) to be submiited
        verbose - if True, will print info about API and results
        trial - if True, will not execute the specified called.
                combine with verbose=true to see what'll be submitted
                NSX
        codes - List of HTTP request status codes for success
        '''
        url=self.server+api
        if verbose:
            print("API: PUT %s with data:" %url)
            print(json.dumps(data, indent=4))

        if not trial:
            r = self.session.put(url, data=json.dumps(data),
                                 timeout=self.timeout,
                                 **self.requestAttr)
            self.__checkReturnCode(r, codes)
            if verbose:
                print('result code: %d' %r.status_code)
                return json.loads(r.text)
        else:
            if verbose:
                print("API not called - in safe mode")
            return None

    def delete(self, api, verbose=True,trial=False,codes=None):
        '''
        REST API delete requests
        api - REST API, this will be appended to self.server
        verbose - if True, will print info about API and result
        trial - if true, will not execute the request
        codes - List of HTTP request status codes for success
        '''
        url = self.server+api
        if verbose:
            print("API: DELETE %s" %url)
        if not trial:
            r = self.session.delete(url,timeout=self.timeout,
                                    **self.requestAttr)
            self.__checkReturnCode(r,codes)
            if verbose:
                print('result code: %d' %r.status_code)
        else:
            if verbose:
                print("API not alled - in safe mode")
            return None
            

    def post(self, api, data, verbose=True, codes=[]):
        url = self.server + api
        if verbose:
            print("API: POST %s" % url)

        r = self.session.post(url, data=json.dumps(data), timeout=self.timeout,
                              **self.requestAttr)
        self.__checkReturnCode(r, codes)
        if r.text:
            return json.loads(r.text)
        else:
            return None
        

class VC_object(object):
    def __init__(self, vc):
        # VC is VCenter object
        self.vc = vc
        self.listApi=None

    def __checkListApi(self, api, exception=True):
        if not api:
            api=self.listApi
        if not api and exception:
            raise ValueError("Invalid listApi in class %s" %self.__class__)
        return api
    
    def jsonPrint(self, data):
        print(json.dumps(data, indent=4))
              
    def list(self, listApi=None, filters=None, display=True):
        listApi = self.__checkListApi(api=listApi)
        data = self.vc.get(api=listApi, verbose=True)
        if display:
            self.jsonPrint(data=data)
        return data
    
    def findByName(self, name, listApi=None, filters=None, display=True):
        data=self.list(listApi=listApi, filters=filters, display=False)
        for n in data['value'] or []:
            if n['name'] == name:
                if display:
                    self.jsonPrint(n)
                return n
        return None

        
class Networks(VC_object):
    def __init__(self, vc):
        super(self.__class__, self).__init__(vc=vc)
        self.listApi='/rest/vcenter/network'
    
    
def main():
    v =VCenter(host="sfvc2.cptroot.com")
    print(v.requestAttr)

    n = Networks(vc=v)
    n.findByName(name="DVS4-vmk0", display=True)


              
    

if __name__ == "__main__":
    main()

