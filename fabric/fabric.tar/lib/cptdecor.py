def traceFunc(func):
    def inner(*args, **kwargs):
        print('calling {0} with {1} {2}'.format(func.__name__, args, kwargs))
        result = func(*args, **kwargs)
        print('result was {0}'.format(result))
        return result
    return inner


def timeMe(func):
    import time
    def inner(*args, **kwargs):
        startTime = time.time()
        result = func(*args, **kwargs)
        timeDelta = time.time()-startTime
        print('{0}() taken {1}s to complete'.format(func.__name__, timeDelta))
        return result
    return inner


def loopMe(n):
    def realLoopMe(func):
        def inner(*args, **kwargs):
            for i in xrange(0, n):
                result = func(*args, **kwargs)
            return result
        return inner
    return realLoopMe

def dumpArgs(func):

    "This decorator dumps out the arguments passed to a function before calling it"
    argnames = func.func_code.co_varnames[:func.func_code.co_argcount]
    fname = func.func_name

    def echo_func(*args,**kwargs):
        print(fname, ":", ', '.join(
            '%s=%r' % entry
            for entry in zip(argnames,args) + kwargs.items()))
        return func(*args, **kwargs)

    return echo_func


import sys
import os
import linecache

def trace(f):
    def globaltrace(frame, why, arg):
        if why == "call":
            return localtrace
        return None

    def localtrace(frame, why, arg):
        if why == "line":
            # record the file name and line number of every trace
            filename = frame.f_code.co_filename
            lineno = frame.f_lineno

            bname = os.path.basename(filename)
            #print("{}({}): {}".format(  bname,
            #                            lineno,
            #                            linecache.getline(filename, lineno)), end='')
            # TEMP FIX FOR python 2.x
            print("{}({}): {}".format(  bname,
                                        lineno,
                                        linecache.getline(filename, lineno)))
        return localtrace

    def _f(*args, **kwds):
        sys.settrace(globaltrace)
        result = f(*args, **kwds)
        sys.settrace(None)
        return result

    return _f


if __name__ == '__main__':
    @timeMe
    #@loopMe(3)
    #@dumpArgs
    @trace
    def sleeping(n):
        import time
        time.sleep(1)

    print('start')
    sleeping(3)
    print('done')



