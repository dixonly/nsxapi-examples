#!/usr/bin/python
#from __future__ import print_function
import pinit
import logging
import cptutil
from   cptutil import pformat_xml, pprint_xml
import requests
from requests.structures import CaseInsensitiveDict
import base64
from requests_toolbelt.multipart import encoder
import os, sys, inspect
import time, datetime
import socket
import re
import copy
import pprint
from pprint import pprint, pformat
#import commands
import subprocess
import xml.dom.minidom, json
import traceback
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
#from requests import ConnectTimeout, HTTPError, ReadTimeout, Timeout, ConnectionError

statusCode = dict([
    ('1xx', 'Informational'),
    (100, 'Continue'),
    (101, 'Switching Protocols'),
    ('2xx', 'Successful'),
    (200, 'OK'),
    (201, 'Created'),
    (202, 'Accepted'),
    (203, 'Non-Authoritative Information'),
    (204, 'No Content'),
    (205, 'Reset Content'),
    (206, 'Partial Content'),
    ('3xx', 'Redirection'),
    (300, 'Multiple Choices'),
    (301, 'Moved Permanently'),
    (302, 'Found'),
    (303, 'See Other'),
    (304, 'Not Modified'),
    (305, 'Use Proxy'),
    (307, 'Temporary Redirect'),
    ('4xx', 'Client Error'),
    (400, 'Bad Request'),
    (401, 'Unauthorized'),
    (402, 'Payment Required'),
    (403, 'Forbidden'),
    (404, 'Not Found'),
    (405, 'Method Not Allowed'),
    (406, 'Not Acceptable'),
    (407, 'Proxy Authentication Required'),
    (408, 'Request Timeout'),
    (409, 'Conflict'),
    (410, 'Gone'),
    (411, 'Length Required'),
    (412, 'Precondition Failed'),
    (413, 'Request Entity Too Large'),
    (414, 'Request-URI Too Long'),
    (415, 'Unsupported Media Type'),
    (416, 'Requested Range Not Satisfiable'),
    (417, 'Expectation Failed'),
    ('5xx', 'Server Error'),
    (500, 'Internal Server Error'),
    (501, 'Not Implemented'),
    (502, 'Bad Gateway'),
    (503, 'Service Unavailable'),
    (504, 'Gateway Timeout'),
    (505, 'HTTP Version Not Supported'),
])

def merge_dicts(x, y):
    '''Given two dicts, merge them into a new dict as a shallow copy
       Single level merge only
       member of y overwrite member of x
    '''
    #z = x.copy()
    z = copy.deepcopy(x)
    #z.update(y)
    for k in y:
        if k not in x:
            z[k] = y[k]
        else:
            if isinstance(z[k], dict) and isinstance(y[k], dict):
                z[k].update(y[k])
            else:
                z[k] = y[k]
    return z


def defRestRetryHdlr(r, retryParams, **kwargs):
    ''' retryDict = {'method': 'put', 'maxTry': 3, 'interval': 30, 'handler': defRestRetryHdlr, 'statusCodes': [500],
            'rTextPat': 'Could not commit JPA transaction; nested exception is javax.persistence.RollbackException', }
        return (nAttempt, attemptInterval) '''
    retries = (0,0)
    retryParams['curTry'] = retryParams.get('curTry', 0) + 1

    if (('method' not in retryParams or retryParams['method'].upper() == r.request.method) and
            r.status_code in retryParams['statusCodes'] and re.search(retryParams['rTextPat'], r.text)):
        retries = (retryParams['maxTry']-retryParams['curTry'], retryParams['interval'])
    return retries

class HTTPRemoteAuth(requests.auth.AuthBase):
    """ Attaches HTTP Remote Authentication to the given Request object
        The following 2 heeders fields being returned should be used in subsequent requerst:
            Set-Cookie: JSESSIONID=CD68523468A804F846FA2FB79E24EEAD; Path=/; Secure; HttpOnly
            X-XSRF-TOKEN: e766b0d2-ea10-4a3e-bcf0-4d29523e6b56
    """

    def __init__(self, username, password):
        self.username = username
        self.password = password

    def __call__(self, r):
        r.headers['Authorization'] = 'Remote %s' % base64.b64encode(
            '%s:%s' % (self.username,self.password))
        return r

class RestConnect(requests.Request):
    """ Provide APIs for NSX-Manager to access its components """

    def __init__(self, url_prefix, user='admin', password='Vmware123!',
        content_type='application/xml', accept='application/xml',
        verify=True, tardy=60,
        logLevel=logging.INFO, requestsLogLevel=logging.WARNING, logTag='',
        logFile=None, logger=None, nsxtAuth=False,
        certFiles=[], sessCookieFile=None, timeout=None):

        # cannot use self.__class__ as 1st argument due to multi-level inheritance
        super(RestConnect, self).__init__()

        self.logger = logger if logger \
            else cptutil.cptLogger(logLevel, logFile=logFile, logTag=logTag)

        self.url_prefix = url_prefix
        self.headers = {'content-type':content_type, 'Accept':accept}
        self.username = user
        self.password = password
        self.auth = (user, password)
        self.verify = verify    # verfiy SSL certificate
        self.tardy = tardy     # amount of time a call took to trigger warning msg
        self.tardyTD = datetime.timedelta(seconds=tardy) # amount of time a call took to trigger warning msg
        self.nsxtAuth = nsxtAuth
        self.clientCertFile = certFiles
        self.session = requests.Session()
        self.timeout = timeout
        #self.session = requests

        m = re.match(r'http(s*)://([^:]+):*(\d+)*', url_prefix)
        if m:
            https, self.hostname, port = m.groups()
            self.port = port if port else '443' if https else '80'
            try:
                self.hostip = socket.gethostbyname(self.hostname)
            except Exception as e:
                raise ValueError("Given hostname or IP is not valid: %s" % self.hostname)
        else:
            self.logger.warning('cannot parse url "%s"' % url_prefix)

        logging.getLogger("requests").setLevel(requestsLogLevel)

        ''' All http verbs are allowed by default '''
        self.verbAllowd = {k:True for k in
            ['get', 'delete', 'head', 'options', 'patch', 'put', 'post']}

        self.reqAttr = {
            'auth' : self.auth,
            'headers' : {'Content-Type':content_type, 'Accept':accept},
            'verify' : verify
        }
        if certFiles:
            certFiles=cptutil.deListify(certFiles.split(','))
            #del self.reqAttr['auth']
            self.reqAttr.pop('auth')
            self.logger.info2('cert auth: %s' % self.clientCertFile)
            self.session.cert = certFiles
            self.session.headers.update(self.reqAttr['headers'])
            self.session.verify = verify

        if sessCookieFile and os.access(sessCookieFile, os.R_OK):
            with open(sessCookieFile) as f:
                headers = CaseInsensitiveDict(json.loads(f.read()))
                self.reqAttr.pop('auth')
                #if hasattr(self, 'auth'):
                #    del self.auth
                self.sess = {
                    'cookie': headers['set-cookie'].split()[0].strip(';'),
                    'xsrfToken': headers['x-xsrf-token']
                }
                self.logger.info2('cookie: %s' % self.sess['cookie'])
                self.logger.info2('x-xsrf-token=%s' % self.sess['xsrfToken'])
                self._checkNsxtAuth()

        if self.nsxtAuth:
            self._checkNsxtAuth()

        #print('>>>>>', self.session)
        #print('>>>>>', self.sess)
        #exit()

    def setVerbOp(self, verb, op):
        self.verbAllowd[verb] = op

    def _checkNsxtAuth(self):
        ''' chneck if nsxtAuth scheme should used
                if sessCookieFile is provided, remove basic authz header, insert cookie and xsrfThoken headers.
                    this method should be called AFTER processing sessCookieFile (SessionCookie.use())
                if user is remote (contain '@') change basic authz to remote authz.
                    this method should be called as last step for RestConnect.__init__()
        '''
        if self.nsxtAuth:
            if hasattr(self, 'sess'):
                self.reqAttr['headers']['Cookie'] = self.sess['cookie']
                if 'xsrfToken' in self.sess:
                    self.reqAttr['headers']['X-xsrf-token'] = self.sess['xsrfToken']
                self.reqAttr.pop('auth', None)

            if '@' in self.username:
                self.reqAttr['auth'] = HTTPRemoteAuth(self.username, self.password)

    def _addNsxtSessCookie(self, rHeaders):
        if self.nsxtAuth and 'X-XSRF-TOKEN' in rHeaders:
            self.sess = {
                'cookie': rHeaders['set-cookie'].split()[0].strip(';'),
                'xsrfToken': rHeaders['X-XSRF-TOKEN']
            }
            self._checkNsxtAuth()


    def delete(self, url, retryParams=None, **kwargs):
        ''' retryParams is a dict describing retry triggers and handler
            The handler returns a tuple (additionalRetryCount, retryInterval) '''
        #print('>>>DELETE', url, retryParams)
        retryParamDict = copy.deepcopy(retryParams)
        fullUrl = self.url_prefix+url
        restSendTime = datetime.datetime.now()
        reqAttr = merge_dicts(self.reqAttr, kwargs)
        self.logger.debug('REQUEST %s' % fullUrl)
        self.logger.debug('REQUEST HEADERS %s' % reqAttr)

        methodName = sys._getframe().f_code.co_name
        if self.verbAllowd[methodName]:
            remainingTry, retryInterval = 1, 0
            while remainingTry>0:
                r = self.session.delete(fullUrl, timeout=self.timeout, **reqAttr)

                self._addNsxtSessCookie(CaseInsensitiveDict(r.headers))

                remainingTry -= 1
                if retryParamDict:
                    retryHandler = retryParamDict.get('handler', defRestRetryHdlr)
                    retryParamDict['maxTry'] = retryParamDict.get('maxTry', 3)
                    retryParamDict['interval'] = retryParamDict.get('interval', 30)
                    remainingTry, retryInterval = retryHandler(r, retryParamDict, **kwargs)

                if r.elapsed>self.tardyTD:
                    self.logger.warning('RESPONSE took %s, REQUEST sent at %s' % (
                        r.elapsed, restSendTime.strftime('%H:%M:%S')))
                    self.logger.warning('REQUEST was DELETE %s' % fullUrl)
                self.logger.debug('RESPONSE STATUS_CODE %d' % r.status_code)
                self.logger.debug('RESPONSE REASON %s' % r.reason)
                self.logger.debug('RESPONSE HEADERS %s' % r.headers)
                self.logger.debug('RESPONSE_TEXT %s' % r.text)
            return r
        else:
            self.logger.info('URL %s' % fullUrl)
            self.logger.info('#### ABORT: only safe http methods allowed')
            exit(101)

    def get(self, url, retryParams=None, **kwargs):
        ''' retryParams is a dict describing retry triggers and handler
            The handler returns a tuple (additionalRetryCount, retryInterval) '''
        retryParamDict = copy.deepcopy(retryParams)
        fullUrl = self.url_prefix+url
        restSendTime = datetime.datetime.now()
        reqAttr = merge_dicts(self.reqAttr, kwargs)
        self.logger.debug("REQUEST-curlEqv: curl -sku '%s:%s' %s" % (self.username,self.password, fullUrl))
        self.logger.debug('REQUEST %s' % fullUrl)
        self.logger.debug('REQUEST HEADERS %s' % reqAttr)
        #self.logger.debug('REQUEST HEADER Auth: %s' % repr(reqAttr['auth']))
        remainingTry, retryInterval = 1, 0
        while remainingTry>0:
            r = self.session.get(fullUrl, timeout=self.timeout, **reqAttr)

            self._addNsxtSessCookie(r.headers)

            remainingTry -= 1
            if retryParamDict:
                retryHandler = retryParamDict.get('handler', defRestRetryHdlr)
                retryParamDict['maxTry'] = retryParamDict.get('maxTry', 3)
                retryParamDict['interval'] = retryParamDict.get('interval', 30)
                remainingTry, retryInterval = retryHandler(r, retryParamDict, **kwargs)

            if r.elapsed>self.tardyTD:
                self.logger.warning('RESPONSE took %s, REQUEST sent at %s' % (
                    r.elapsed, restSendTime.strftime('%H:%M:%S')))
                self.logger.warning('REQUEST was GET %s' % fullUrl)
            rTextLen = len(r.text)
            self.logger.debug('RESPONSE REASON: %s' % r.reason)
            self.logger.debug('RESPONSE HEADERS: %s' % pformat(r.headers))
            self.logger.debug('RESPONSE TEXT size: %d bytes' % rTextLen)
            self.logger.debug('RESPONSE TEXT (first 200): %s' % r.text[:max(200,rTextLen)])
            self.logger.debug('RESPONSE TEXT: %s' % r.text)


            if remainingTry==0 or r.status_code not in retryParamDict['statusCodes']:
                break
            if remainingTry:
                self.logger.warning('Retry condition: cdoe=%d; pattern="%s"' % (
                    r.status_code, retryParamDict['rTextPat']))
                self.logger.warning('Request: %s' % r.url)
                self.logger.warning('%d more retries, retry in %d seconds' % (
                    remainingTry, retryInterval))
                time.sleep(retryInterval)
            #if self.logger.getEffectiveLevel()<=logging.DEBUG:
            #    self.logger.debug('RESPONSE_TEXT (%d)\n%s' % (
            #        len(r.text), cptutil.StringData(r.text)))
        self.logger.debug('RESPONSE_TEXT (%d bytes) DONE' % len(r.text))
        return r

    def getStream(self, url, retryParams=None, **kwargs):
        fullUrl = self.url_prefix+url
        restSendTime = datetime.datetime.now()
        reqAttr = merge_dicts(self.reqAttr, kwargs)
        self.logger.debug('REQUEST %s' % fullUrl)
        self.logger.debug('REQUEST HEADERS %s' % reqAttr)
        r = self.session.get(fullUrl, stream=True, **reqAttr)
        self._addNsxtSessCookie(r.headers)

        deltaTime = cptutil.fmtDeltaDatetime(restSendTime, fmt='%0.6f')
        if deltaTime >= self.tardy:
            self.logger.warning('RESPONSE took %ss (%s), REQUEST sent at %s' % (
                deltaTime, cptutil.normTime(deltaTime), restSendTime.strftime('%H:%M:%S')))
            self.logger.warning('REQUEST was GETSTREAM %s' % fullUrl)
        self.logger.debug('RESPONSE STATUS_CODE %d' % r.status_code)
        self.logger.debug('RESPONSE REASON %s' % r.reason)
        self.logger.debug('RESPONSE HEADERS %s' % r.headers)
        self.logger.debug('RESPONSE_TEXT (%d)\n%s' % (len(r.text), cptutil.StringData(r.text)))
        #self.logger.debug('RESPONSE_TEXT\n%s' % r.text)

        n, size = 0, 0
        fname=url.split('/')[-1]
        fpath='%s/%s' % (self.tmpDir, fname)

        with open(fpath, 'w') as f:
            for chunk in r.iter_content(8192):
                size += len(chunk)
                n += 1
                f.write(chunk)
        self.dumpResquestsResponse(r)
        #cptutil.prClassAttrs(r)
        return r


    def head(self, url, retryParams=None, **kwargs):
        fullUrl = self.url_prefix+url
        restSendTime = datetime.datetime.now()
        reqAttr = merge_dicts(self.reqAttr, kwargs)
        self.logger.debug('REQUEST %s' % fullUrl)
        self.logger.debug('REQUEST HEADERS %s' % reqAttr)
        return self.session.head(fullUrl, **reqAttr)

    def options(self, url, retryParams=None, **kwargs):
        fullUrl = self.url_prefix+url
        restSendTime = datetime.datetime.now()
        reqAttr = merge_dicts(self.reqAttr, kwargs)
        self.logger.debug('REQUEST %s' % fullUrl)
        self.logger.debug('REQUEST HEADERS %s' % reqAttr)
        r = self.session.options(fullUrl, **reqAttr)
        self._addNsxtSessCookie(r.headers)

        self.logger.debug('RESPONSE HEADERS %s' % r.headers)
        #print(r.headers)
        return r

    def patch(self, url, data=None, retryParams=None, **kwargs):
        fullUrl = self.url_prefix+url
        restSendTime = datetime.datetime.now()
        reqAttr = merge_dicts(self.reqAttr, kwargs)
        self.logger.debug('REQUEST %s' % fullUrl)
        self.logger.debug('REQUEST HEADERS %s' % reqAttr)
        self.logger.debug('REQUEST BODY %s' % data)
        r = self.session.patch(fullUrl, data=data, timeout=self.timeout, **reqAttr)

        self.logger.debug('RESPONSE STATUS_CODE %d' % r.status_code)
        self.logger.debug('RESPONSE REASON %s' % r.reason)
        self.logger.debug('RESPONSE HEADERS %s' % r.headers)
        self.logger.debug('RESPONSE_TEXT %s' % pformat_xml(r.text) \
            if r.text.startswith('<?xml ') else r.text)
        return r

    def put(self, url, data=None, retryParams=None, **kwargs):
        ''' retryParams is a dict describing retry triggers and handler
            The handler returns a tuple (additionalRetryCount, retryInterval) '''
        retryParamDict = copy.deepcopy(retryParams)
        fullUrl = self.url_prefix+url
        restSendTime = datetime.datetime.now()
        reqAttr = merge_dicts(self.reqAttr, kwargs)
        self.logger.debug('REQUEST %s' % fullUrl)
        self.logger.debug('REQUEST HEADERS %s' % reqAttr)
        self.logger.debug('REQUEST BODY %s' % data)

        methodName = sys._getframe().f_code.co_name
        if self.verbAllowd[methodName]:
            remainingTry, retryInterval = 1, 0
            while remainingTry>0:
                r = self.session.put(fullUrl, data=data, timeout=self.timeout, **reqAttr)

                self._addNsxtSessCookie(r.headers)

                remainingTry -= 1
                if retryParamDict:
                    retryHandler = retryParamDict.get('handler', defRestRetryHdlr)
                    retryParamDict['maxTry'] = retryParamDict.get('maxTry', 3)
                    retryParamDict['interval'] = retryParamDict.get('interval', 30)
                    remainingTry, retryInterval = retryHandler(r, retryParamDict, **kwargs)

                if r.elapsed>self.tardyTD:
                    self.logger.warning('RESPONSE took %s, REQUEST sent at %s' % (
                        r.elapsed, restSendTime.strftime('%H:%M:%S')))
                    self.logger.warning('REQUEST was PUT %s' % fullUrl)
                    self.logger.warning('REQUEST BODY was %s' % \
                        pformat_xml(data) if data and data.startswith('<?xml ') else data)
                self.logger.debug('RESPONSE STATUS_CODE %d' % r.status_code)
                self.logger.debug('RESPONSE REASON %s' % r.reason)
                self.logger.debug('RESPONSE HEADERS %s' % r.headers)
                self.logger.debug('RESPONSE_TEXT %s' % r.text)

                if remainingTry==0 or r.status_code not in retryParamDict['statusCodes']:
                    break
                if remainingTry:
                    self.logger.warning('Retry condition: cdoe=%d; pattern="%s"' % (
                        r.status_code, retryParamDict['rTextPat']))
                    self.logger.warning('Request: %s' % r.url)
                    self.logger.warning('%d more retries, retry in %d seconds' % (
                        remainingTry, retryInterval))
                    time.sleep(retryInterval)

            return r
        else:
            self.logger.info('URL %s' % fullUrl)
            self.logger.info('BODY %s' % data)
            if data:
                #print(commands.getoutput('echo "%s" | tidy -xml -indent -q' % data))
                echo = subprocess.Popen(['echo', data], stdout=subprocess.PIPE)
                output = subprocess.check_output(['tidy', '-xml', '-indent', '-q'], stdin=echo.stdout)
                echo.wait()
                print(output)
            self.logger.info('#### ABORT: only safe http methods allowed')
            exit()

    def post(self, url, data=None, retryParams=None, **kwargs):
        #print('POST:- %s' % kwargs)
        #print('data=%s, len=%d' % (data, len(data)))
        fullUrl = self.url_prefix+url
        restSendTime = datetime.datetime.now()
        reqAttr = merge_dicts(self.reqAttr, kwargs)
        self.logger.debug('REQUEST %s' % fullUrl)
        self.logger.debug('REQUEST HEADERS %s' % reqAttr)
        self.logger.debug('REQUEST BODY %s' % \
            (pformat_xml(data) if data and data.startswith('<?xml ') else data))
        methodName = sys._getframe().f_code.co_name
        if self.verbAllowd[methodName]:
            r = self.session.post(fullUrl, data=data, timeout=self.timeout, **reqAttr)

            self._addNsxtSessCookie(r.headers)

            deltaTime = cptutil.fmtDeltaDatetime(restSendTime, fmt='%0.6f')
            if deltaTime >= self.tardy:
                self.logger.warning('RESPONSE took %ss (%s), REQUEST sent at %s' % (
                    deltaTime, cptutil.normTime(deltaTime), restSendTime.strftime('%H:%M:%S')))
                self.logger.warning('REQUEST was POST %s' % fullUrl)
                self.logger.warning('REQUEST BODY was %s' % \
                    pformat_xml(data) if data and data.startswith('<?xml ') else data)
            self.logger.debug('RESPONSE STATUS_CODE %d' % r.status_code)
            self.logger.debug('RESPONSE REASON %s' % r.reason)
            self.logger.debug('RESPONSE HEADERS %s' % r.headers)
            self.logger.debug('RESPONSE_TEXT %s' % pformat_xml(r.text) \
                if r.text.startswith('<?xml ') else r.text)
            return r
        else:
            self.logger.info('REQUEST %s' % fullUrl)
            self.logger.info('REQUEST BODY %s' % data)
            if data:
                #print(commands.getoutput('echo "%s" | tidy -xml -indent -q' % data))
                echo = subprocess.Popen(['echo', data], stdout=subprocess.PIPE)
                output = subprocess.check_output(['tidy', '-xml', '-indent', '-q'], stdin=echo.stdout)
                echo.wait()
                print(output)

            self.logger.info('#### ABORT: only http methods allowed')
            exit()

    def postMultipartFile(self, url, fileName, retryParams=None, **kwargs):
        fullUrl = self.url_prefix+url
        restSendTime = datetime.datetime.now()
        startSec = time.time()
        fileSize = os.stat(fileName).st_size
        #session = requests.Session()
        with open(fileName, 'rb') as f:
            form = encoder.MultipartEncoder({
                "file": (fileName, f, "application/octet-stream"),
            })
            headers = {"Prefer": "respond-async", "Content-Type": form.content_type}
            r = self.session.post(fullUrl, headers=headers, data=form, auth=self.auth, verify=False)
            self._addNsxtSessCookie(r.headers)

            if int(r.status_code)/100 == 2:
                timeDelta = time.time()-startSec
                self.logger.info('DONE uploading fileName (%s, %s/s)' % (
                    cptutil.normTime(timeDelta),
                    cptutil.normDiskSize(fileSize/timeDelta)))
            else:
                self.responseError(r)

    def checkForError(self, r):
        if not 200<=r.status_code<300:
            self.dumpResquestsResponse(r)
            try:
                self.logger.error(json.dumps(r.json(), indent=4))
            except:
                self.logger.error(pformat(r.text))
            return True
        else:
            return False

    def responseError(self, r, cond='', raiseException=False):
        self.logger.error('REQUEST: %s %s' % (r.request.method, r.url))
        reqBody = r.request.body
        self.logger.error("REQUEST body: %s" %
            pformat_xml(reqBody) if reqBody and reqBody.startswith('<?xml ') else reqBody)
        #if reqBody.startswith('<?xml'):
        #    self.logger.error("REQUEST body: xml(%s)" % pformat_xml(reqBody))
        #else:
        #    self.logger.error("REQUEST body: %s" % reqBody)
        self.logger.error('RESPONSE status_code: %s %s' % (r.status_code, r.reason))
        try:
            self.logger.error('TEXT(xml): %s' % pformat_xml(r.text))
        except:
            #self.logger.error('TEXT: %s' % r.text)
            self.logger.error('TEXT: %s' % cptutil.StringData(r.text))
        if raiseException:
            r.raise_for_status()

    def dumpResquestsResponse(self, r):
        ''' attrs:
            _content, _content_consumed, apparent_encoding, close, connection,
            content, cookies, elapsed, encoding, headers, history,
            is_permanent_redirect, is_redirect, iter_content, iter_lines, json,
            links, ok, raise_for_status, raw, reason, status_code, text, url
        '''
        print('REQUEST:')
        for attr in ['method', 'url', 'body']:
            print(" '%s': %s" % (attr, getattr(r.request, attr)))
        print('RESPONSE:')
        attrs = vars(r)
        print(pformat(dict(attrs)))
        return

        #for attr in attrs:
        #    if not hasattr(r, attr): continue
        #    if attr=='text' and r'<?xml' in getattr(r, attr):
        #        print('r.text(xml): %s' % pformat_xml(r.text))
        #    else:
        #        print('r.%s = %s' % (attr, getattr(r, attr)))

        request = r.request
        for attr in ['method', 'url', 'body']:
            print('r.request.%s = %s' % (attr, getattr(request, attr)))

    def getWithRetry(self, url, timeout=None, maxAttempt=3, backoff=03, **kwargs):
        ''' retryParams is a dict describing retry triggers and handler
            The handler returns a tuple (additionalRetryCount, retryInterval) '''
        fullUrl = self.url_prefix+url
        restSendTime = datetime.datetime.now()
        reqAttr = merge_dicts(self.reqAttr, kwargs)
        self.logger.debug("REQUEST-curlEqv: curl -sku '%s:%s' %s" % (self.username,self.password, fullUrl))
        self.logger.debug('REQUEST %s' % fullUrl)
        self.logger.debug('REQUEST HEADERS %s' % reqAttr)
        #self.logger.debug('REQUEST HEADER Auth: %s' % repr(reqAttr['auth']))

        if timeout==None: timeout=self.timeout
        attemptCnt, backoffTime, done, r = 1, 0, False, None

        while not done and attemptCnt<=maxAttempt:
            try:
                r = self.session.get(fullUrl, timeout=timeout, **reqAttr)
                #r = None
                #raise Timeout()
            #except (ConnectTimeout, HTTPError, ReadTimeout, Timeout, ConnectionError) as e:
            #    backoffTime = backoff * (2**(attemptCnt-1))
            #    print('Request Exception: %s BO=%s'%(e.__class__.__name__, backoffTime))
            except Exception as e:
                backoffTime = backoff * (2**(attemptCnt-1))
                print('Unxepected exception: %s'%e.__class__.__name__)
            else:
                #print('It eventually worked', response.status_code)
                done = True
            finally:
                t1 = time.time()
                #print('%d/%d: Took %ds' % (attemptCnt, maxAttempt, t1-t0))
                attemptCnt += 1
                time.sleep(backoffTime)

        if done and r:
            self._addNsxtSessCookie(r.headers)
            if r.elapsed>self.tardyTD:
                self.logger.warning('RESPONSE took %s, REQUEST sent at %s' % (
                    r.elapsed, restSendTime.strftime('%H:%M:%S')))
                self.logger.warning('REQUEST was GET %s' % fullUrl)
            rTextLen = len(r.text)
            self.logger.debug('RESPONSE REASON: %s' % r.reason)
            self.logger.debug('RESPONSE HEADERS: %s' % pformat(r.headers))
            self.logger.debug('RESPONSE TEXT size: %d bytes' % rTextLen)
            self.logger.debug('RESPONSE TEXT (first 200): %s' % r.text[:max(200,rTextLen)])
            self.logger.debug('RESPONSE TEXT: %s' % r.text)

            self.logger.debug('RESPONSE_TEXT (%d bytes) DONE' % len(r.text))
        return r
    """
    """

if __name__ == "__main__":
    '''
    requests.packages.urllib3.disable_warnings()
    mgr = RestConnect('https://50.5.0.200', verify=False)
    r = mgr.get('/api/2.0/services/vcconfig')
    print(r.text)
    esx = RestConnect('https://esx1', user='root', password='deadstar', verify=False)
    r = esx.get('/folder?dcPath=ha-datacenter')
    print(r.text)
    '''
    pass

