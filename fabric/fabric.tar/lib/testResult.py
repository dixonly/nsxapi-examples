#!/usr/bin/env python

import sys, datetime, json, ast
from pprint import pprint

class TestResult(object):
    def __init__(self, cmdln, testId, taskId, testNumber=1):
        self.testId = testId
        self.taskId = taskId
        self.cmdln = cmdln
        self._result = {
            'header': {
                'title':    '',
                'testId':   testId,
                'taskId':   taskId,
                'cmdLine':  cmdln,
                'testNumber': testNumber,
            },
            'steps': [
            #    {
            #        'api': {
            #            'url':      '',
            #            'response': '',
            #            'desc':     '',
            #            'pass':     False,
            #        },
            #    },
            ],
            'result': {
                'pass':             False,
            #    'pingable':         False,
            #    'httpsConnect':     False,
            #    'httpsTimeout':     False,
                'failureReasons':    [],
                'verifications':    [],
            },
            'startTime':    str(datetime.datetime.now()),
            'endTime':      '',
        }

    def appendStep(self, step):
        self._result['steps'].append(step)

    def setResult(self, tag, val):
        #self._result['result'][tag] = val
        self.setAttr('result', tag, val)




    def appendAttr(self, attr, tag, val):
        if tag:
            self._result[attr][tag].append(val)
        else:
            self._result[attr].append(val)

    def extendAttr(self, attr, tag, val):
        self._result[attr][tag].extend(val)

    def setAttr(self, attr, tag, val):
        #print(attr, self._result[attr][tag], val)
        self._result[attr][tag] = val

    def addVerify(self, verifyMsg, vPass=None):
        #print('addVerify(%s, %s)' % (verifyMsg, vPass))
        verifyMsg = str(verifyMsg)
        if vPass==None:
            self._result['result']['verifications'].append(verifyMsg)
        elif vPass==True:
            self._result['result']['verifications'].append('%s: Pass' % verifyMsg)
        elif vPass==False:
            self._result['result']['failureReasons'].append('%s: Fail' % verifyMsg)

    def addError(self, val):
        self._result['result']['failureReasons'].append(val)

    #@property
    #def passed(self):
    #    self._result['result']['pass'] = not self._result['result']['failureReasons']
    #    return self._result['result']['pass']

    def prologue(self, funcName, title):
        #self._result['header']['_function'] = funcName
        #self._result['header']['title'] = title
        self.setAttr('header', '_function', funcName)
        self.setAttr('header', 'title', title)

    def epilogue(self, errMsgs=[], verMsgs=[]):
        self.extendAttr('result', 'failureReasons', errMsgs)
        self.extendAttr('result', 'verifications', verMsgs)
        self.setAttr('result', 'pass', not self._result['result']['failureReasons'])

    @property
    def rStr(self):
        return str(self._result)
    @property
    def rDict(self):
        return self._result



if __name__ == '__main__':
    cmdln = ' '.join(sys.argv)
    testResult = TestResult(cmdln, 'TEST01', 'task01')
    tResultDict = ast.literal_eval(testResult.rStr)
    print(json.dumps(tResultDict, indent=4))
    tResultDict = testResult.rDict
    print(json.dumps(tResultDict, indent=4))

